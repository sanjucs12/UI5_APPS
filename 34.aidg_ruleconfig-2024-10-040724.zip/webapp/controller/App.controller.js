sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("aidgruleconfig.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  