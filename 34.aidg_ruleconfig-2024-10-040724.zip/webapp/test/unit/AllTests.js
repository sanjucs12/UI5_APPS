sap.ui.define([
	"aidg_ruleconfig/test/unit/controller/RuleHome.controller"
], function () {
	"use strict";
});
