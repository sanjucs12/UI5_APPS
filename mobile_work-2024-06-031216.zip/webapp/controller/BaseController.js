/*global Keyboard:true*/
/*global _:true*/
sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "mobilework/util/Formatter",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
  ],
  function (Controller, Format, MBox, MToast) {
    "use strict";

    /**
     *
     * @namespace mobilework.controller.BaseController
     * @param {sap.ui.core.mvc.Controller} Controller - Sap Core Controller
     * @param {mobilework.util.Formatter} Format - Sap Core Controller
     * @param {sap.m.MessageBox} MBox - Sap Message Box Control
     * @param {sap.m.MToast} MToast - Sap Message toast Control
     * @returns {mobilework.controller.BaseController} The instance of the App controller class.
     */

    return Controller.extend("mobilework.controller.BaseController", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      /** @type sap.ui.core.EventBus */
      oEventBus: null,

      /** @type sap.f.routing.Router*/
      oRouter: null,

      /** @type mobilework.util.ScannerHandler*/
      oScannerHandler: null,

      /** @type mobilework.util.Helper*/
      oHelper: null,

      /** @type mobilework.util.Formatter*/
      oFormatter: Format,

      /** @type mobilework.util.Validator*/
      oValidator: null,

      /** @type mobilework.model.DatabaseService*/
      oDBService: null,

      /** @type mobilework.model.service*/
      oService: null,

      /** @type mobilework.util.GdlDoc*/
      oGdlApi: null,

      //---------------------------//
      // PUBLICS
      //---------------------------//

      /**
		* Convenience method for accessing the model in the controller.
		
		* @public
		* @memberof mobilework.controller.BaseController
		* @param {string} sName - Name of the model
		* @returns {sap.ui.model.JSON.jsonModel} The jsonmodel instance.
		*/

      getModel: function (sName) {
        return this.getView().getModel(sName);
      },

      setModel: function (oModel, sName) {
        return this.getView().setModel(oModel, sName);
      },

      getEventBus: function () {
        if (!this.oEventBus) {
          this.oEventBus = sap.ui.getCore().getEventBus();
        }
        return this.oEventBus;
      },

      getRouter: function () {
        if (!this.oRouter) {
          this.oRouter = this.getOwnerComponent().getRouter();
        }
        return this.oRouter;
      },

      getScanHandler: function () {
        if (!this.oScannerHandler) {
          this.oScannerHandler = this.getOwnerComponent().scanHandler;
        }
        return this.oScannerHandler;
      },

      getService: function () {
        // if (!this.oService) {
        // 	this.oService = this.getOwnerComponent().service;
        // }
        return this.getOwnerComponent().service;
      },

      getDBService: function () {
        if (!this.oDBService) {
          this.oDBService = this.getOwnerComponent().dbService;
        }
        return this.oDBService;
      },

      getHelper: function () {
        if (!this.oHelper) {
          this.oHelper = this.getOwnerComponent().helper;
        }
        return this.oHelper;
      },

      getValidator: function () {
        if (!this.oValidator) {
          this.oValidator = this.getOwnerComponent().validator;
        }
        return this.oValidator;
      },

      getGdlApi: function () {
        if (
          !this.oGdlApi ||
          this.getSharedModel().getProperty("/reloadedRun")
        ) {
          this.oGdlApi = this.getOwnerComponent().gdlApi;
        }
        return this.oGdlApi;
      },

      getDialogManager: function () {
        return this.getOwnerComponent().dialogManager;
      },

      getSharedModel: function () {
        return this.getOwnerComponent().getModel("shared");
      },

      getManifestEntry: function (sPath) {
        return this.getOwnerComponent().getManifestEntry(sPath);
      },

      getText: function (sKey, aArray) {
        var _aArray = aArray;
        if (!_aArray) {
          _aArray = [];
        }
        return this.getOwnerComponent()
          .getModel("i18n")
          .getResourceBundle()
          .getText(sKey, _aArray);
      },

      addEmptyLine: function (table) {
        var emptyline = {};
        for (var j in table[0]) {
          emptyline[j] = "";
        }
        return emptyline;
      },

      addEmptyLineToTable: function (table) {
        if (table && table.length > 0) {
          var aArray = [];
          aArray.push(this.addEmptyLine(table));

          return _.concat(aArray, table);
        } else {
          return table;
        }
      },

      getLogs: function () {
        //	if (!this.getHelper().isDevModeActive())
        return this.getOwnerComponent().logs;
        //	else return {addLog: function(){}};
      },

      getConnection: function () {
        this.getSharedModel().setProperty(
          "/connected",
          this.getHelper().isOnline()
        );
      },

      getOnboardingModel: function () {
        return this.getOwnerComponent().getModel("Onboarding");
      },

      getDefaultsModel: function () {
        return this.getOwnerComponent().getModel("Defaults");
      },

      getShiftValue: function (oSapSettings) {
        var oDate = new Date();

        var sSeconds =
          oDate.getSeconds() < 10
            ? "0" + oDate.getSeconds()
            : oDate.getSeconds();

        var sMinutes =
          oDate.getMinutes() < 10
            ? "0" + oDate.getMinutes()
            : oDate.getMinutes();

        var sDateTime = oDate.getHours() + "" + sMinutes + "" + sSeconds;

        var iDateTime = parseInt(sDateTime);

        if (
          oSapSettings.SHIFTINDIC &&
          (oSapSettings.SHIFTINDIC === true || oSapSettings.SHIFTINDIC === "X")
        ) {
          if (
            oSapSettings.S_STRT_E &&
            oSapSettings.S_STRT_L &&
            oSapSettings.S_STRT_N
          ) {
            if (
              iDateTime >= parseInt(oSapSettings.S_STRT_E) &&
              iDateTime < parseInt(oSapSettings.S_STRT_L)
            ) {
              return "E";
            } else if (
              iDateTime >= parseInt(oSapSettings.S_STRT_L) &&
              iDateTime < parseInt(oSapSettings.S_STRT_N)
            ) {
              return "L";
            } else if (
              iDateTime >= parseInt("000000") &&
              iDateTime < parseInt(oSapSettings.S_STRT_E)
            ) {
              return "N";
            }
          } else {
            if (iDateTime >= 60000 && iDateTime < 140000) {
              return "E";
            } else if (iDateTime >= 140000 && iDateTime < 220000) {
              return "L";
            } else if (iDateTime >= 220000 && iDateTime < 60000) {
              return "N";
            }
          }
        } else {
          return "D";
        }
      },

      connectionCheckTogiveColour: function (control) {
        var oUser = this.getSharedModel().getProperty("/sapSettings"),
          d = jQuery.Deferred(),
          me;
        if (this.getOwnerComponent().ViewLocation) {
          me = this.getOwnerComponent().ViewLocation;
        } else me = this;
        // if(this.getHelper().isDevModeActive()){
        // 	d.resolve();
        // 	return;
        // }
        $.when(
          this.getService() &&
            this.getService().connectionCheck(
              oUser.sapUser,
              oUser.sapPass,
              this.getHelper().isDevModeActive()
            )
        )
          .done(
            jQuery.proxy(function (oData) {
              if (oData && oData.ConnectionCheck) {
                var sMessageType = oData.ConnectionCheck.Type,
                  sMessage = oData.ConnectionCheck.Message;
                if (sMessageType === "S") {
                  //
                  MToast.show(sMessage);
                  this.genericSetDeviceIdColor("Green");
                  this.genericReplaceStyleClass(me.getView(), "Green");
                  d.resolve();
                } else {
                  MToast.show(
                    sMessage + "\n" + this.getText("ConnectionCheckWarning")
                  );

                  this.genericSetDeviceIdColor("Red");
                  this.genericReplaceStyleClass(me.getView(), "Red");

                  d.reject();
                }
              } else {
                MToast.show(this.getText("NoNetwork"));

                this.genericSetDeviceIdColor("Red");
                this.genericReplaceStyleClass(me.getView(), "Red");

                d.reject();
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oData) {
              this.genericSetDeviceIdColor("Red");
              this.genericReplaceStyleClass(me.getView(), "Red");

              if (oData && oData.statusCode === 401) {
                var oShared = this.getModel("shared"),
                  oSettings = oShared.getProperty("/sapSettings");
                MBox.error(
                  this.getText("UserNotAuthorized", oSettings.sapSysId)
                );
                d.reject();
              } else {
                MBox.error(
                  this.getText("ConnectionUnknown") +
                    "\n" +
                    this.getText("NoConnectionToSap")
                );
                d.reject();
              }
            }, this)
          );
        return d.promise();
      },

      changeColorOfDeviceId: function () {
        this.getOwnerComponent().ViewLocation = this;
        if (this.getSharedModel()) {
          let color = this.getSharedModel().getProperty("/deviceIdColor");
          if (color === "deviceIdColourGreen") {
            this.genericReplaceStyleClass(this.getView(), "Green");
          } else if (color === "deviceIdColourRed") {
            this.genericReplaceStyleClass(this.getView(), "Red");
          }
        }
      },

      restrictMaxLength: function (oEvent) {
        var maxLength = oEvent.getSource().getMaxLength(),
          value = oEvent.getSource().getValue();
        if (maxLength && value && maxLength < value.length) {
          oEvent.getSource().setValue(value.substring(0, maxLength));
          MToast.show(
            this.getText("MaxCharacterExceeds", [
              oEvent.getSource().getLabels()[0].getText(),
              oEvent.getSource().getMaxLength(),
            ])
          );
        }
      },

      _onInstallationTreeRequest: function () {
        var d = jQuery.Deferred();
        $.when(this.getDBService().getEntitySet("TechnicalObject"))
          .done(
            jQuery.proxy(function (oData) {
              var aTechnicalObjectSet = this.getHelper().rowsToArray(oData);
              aTechnicalObjectSet = _.filter(
                aTechnicalObjectSet,
                function (oTechnicalObject) {
                  return oTechnicalObject.TechObjectType !== "PA";
                }
              );
              aTechnicalObjectSet = this.divideFunctionLocParent(
                aTechnicalObjectSet,
                "Parent"
              );
              this.getSharedModel().setProperty(
                "/techObjects",
                this.getHelper().rowsToArray(oData)
              );
              this.getSharedModel().setProperty(
                "/techObjectsFiltered",
                aTechnicalObjectSet.filter(function (oTech) {
                  return (
                    oTech.Ktx01 &&
                    (oTech.TechObjectType === "FL" ||
                      oTech.TechObjectType === "IF" ||
                      oTech.TechObjectType === "EQ")
                  );
                })
              );
              var flData = this.getHelper().createTree(
                aTechnicalObjectSet,
                "TechObject",
                "Parent",
                "Children",
                "sort",
                "TechObjectType"
              );
              flData.forEach(
                jQuery.proxy(function (locGrp) {
                  if (locGrp && locGrp.Groupname) {
                    locGrp.Children = this.sortFunctionLocationGroup(
                      locGrp.Children,
                      "Posnr",
                      "Tplnr"
                    );
                    if (locGrp.Children) {
                      var withoutSeqno = locGrp.Children.filter(function (row) {
                          return !row.Seqno;
                        }),
                        withSeqno = locGrp.Children.filter(function (row) {
                          return row.Seqno;
                        });
                      withSeqno = _.sortBy(withSeqno, "Seqno");
                      withoutSeqno = _.sortBy(withoutSeqno, "Ktx01");
                      //.concat(withoutSeqno);
                      locGrp.Children = withSeqno.concat(withoutSeqno);
                    }
                  } else if (locGrp) {
                    locGrp.Children = this.sortFunctionLocationGroup(
                      locGrp.Children,
                      "Posnr"
                    );
                  }
                }, this)
              );
              this.getSharedModel().setProperty("/tree", flData);
              d.resolve();
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              d.reject();
            }, this)
          );
        return d.promise();
      },

      divideFunctionLocParent: function (rows, value) {
        var techSet = [];
        rows.forEach(
          jQuery.proxy(function (row) {
            var parents = row[value].split("+#+#");
            for (var i = 0; i < parents.length; i++) {
              var res = Object.keys(row).reduce(function (obj, k) {
                if (k != value) obj[k] = row[k];
                return obj;
              }, {});
              res[value] = parents[i];
              techSet.push(res);
            }
          }, this)
        );
        return techSet;
      },

      sortFunctionLocationGroup: function (oData, Value, Value2) {
        if (oData) {
          oData.forEach(
            jQuery.proxy(function (locGrp) {
              if (locGrp.Children) {
                this.sortFunctionLocationGroup(locGrp.Children, Value, Value2);
                locGrp.Children = this.getHelper().onSortTreeTable(
                  locGrp.Children,
                  Value,
                  Value2
                );
              }
            }, this)
          );
          return this.getHelper().onSortTreeTable(oData, Value, Value2);
        }
      },

      findImpacts: function (oObject, oData) {
        if (oObject) {
          let impact = _.find(oData, { TechObject: oObject.TechObject });
          if (impact) {
            return impact;
          } else {
            let fl = _.find(this.getSharedModel().getProperty("/techObjects"), {
              TechObject: oObject.Parent,
            });
            return this.findImpacts(fl, oData);
          }
        } else {
          return null;
        }
      },

      _saveTableToDB: function (newData, table, type) {
        var oDBService = this.getDBService(),
          d = $.Deferred();

        //save settings to Database

        $.when(oDBService.getEntitySet(table.name))
          .done(
            jQuery.proxy(function (oData) {
              var data = this._rowsToData(oData.rows),
                oPromIns;
              // Create table data
              if (Array.isArray(newData)) {
                oPromIns = oDBService.multipleDataDb(
                  table.name,
                  newData,
                  table,
                  type
                );
              } else {
                if (type === "Replace") {
                  oPromIns = oDBService.replaceObject(
                    table.name,
                    newData,
                    table
                  );
                } else {
                  oPromIns = oDBService.insertObject(
                    table.name,
                    newData,
                    table
                  );
                }
              }
              $.when(oPromIns)
                .done(
                  jQuery.proxy(function (oData2) {
                    d.resolve();
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    console.error(
                      "saveTableToDB: Error occured while updating the database" +
                        oError
                    );
                    data.push(newData);
                    $.when(this.getDBService().createTableAndFill(table, data))
                      .done(
                        jQuery.proxy(function (oData) {
                          d.resolve();
                        }, this)
                      )
                      .fail(
                        jQuery.proxy(function (oErrorMessage) {
                          d.reject(oErrorMessage);
                        })
                      );
                  }, this)
                );
            }, this)
          )
          .fail(
            jQuery.proxy(function (oErr) {
              var aSettings = [];
              if (Array.isArray(newData)) {
                aSettings = newData;
              } else {
                aSettings.push(newData);
              }
              $.when(this.getDBService().createTableAndFill(table, aSettings))
                .done(
                  jQuery.proxy(function (oData) {
                    d.resolve();
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    d.reject();
                  })
                );
            }, this)
          );
        return d.promise();
      },

      _rowsToData: function (rows) {
        var data = [];
        for (var i = 0; i < rows.length; i++) {
          if (rows.item(i)) data.push(rows.item(i));
        }
        return data;
      },

      onFileSizeExceed: function () {
        MBox.error(this.getText("FileAbove5MB"), {
          title: "Error",
          actions: [MBox.Action.OK],
        });
      },
      onFilenameLengthExceed: function () {
        MBox.error(this.getText("FileNameExceed"), {
          title: "Error",
          actions: [MBox.Action.OK],
        });
      },

      onStatusColor: function (severity) {
        if (severity === "Error") {
          return "Error";
        } else if (severity === "Success") {
          return "Success";
        } else {
          return "Warning";
        }
      },

      exitTimeCheck: function (noNetwork) {
        var d = jQuery.Deferred();
        this.messageLog = [];
        var sqlCustom =
            "SELECT a.* FROM TimeRegistration a INNER JOIN ( SELECT Pernr, MAX(Timestamp) AS last_time FROM TimeRegistration GROUP BY Pernr ) b ON a.Pernr = b.Pernr AND a.Timestamp = b.last_time",
          oTimeRegistration = this.getDBService().getEntitySet(
            "TimeRegistration",
            sqlCustom
          ),
          owParticipants = this.getDBService().getEntitySet("wParticipants"),
          ozoneData = this.getDBService().getEntitySet("zoneData");
        $.when(
          this.getDBService().getEntitySet("Participant"),
          oTimeRegistration,
          owParticipants,
          ozoneData
        )
          .done(
            jQuery.proxy(function (oData, timReg, wParticipants, zoneData) {
              let aLocalParticipantSet = [];
              for (var x = 0; x < oData.rows.length; x++) {
                aLocalParticipantSet.push(oData.rows.item(x));
              }
              if (timReg) {
                timReg = this.getHelper().rowsToArray(timReg);
              }
              if (wParticipants) {
                wParticipants = this.getHelper().rowsToArray(wParticipants);
              }
              if (zoneData) {
                zoneData = this.getHelper().rowsToArray(zoneData);
              }
              let zoneOutTime = this.getSharedModel().getProperty(
                  "/sapSettings/EXIT_TIME"
                ),
                toPush = [];
              aLocalParticipantSet.forEach(
                function (row) {
                  if (row.Pernr) {
                    let found = _.find(wParticipants, { amei: row.Pernr });
                    if (found && found.hash) {
                      let foundTimReg = _.find(timReg, { Pernr: row.Pernr });
                      if (foundTimReg && foundTimReg.InOut === "01") {
                        if (foundTimReg.TrZone) {
                          if (zoneOutTime) {
                            if (
                              new Date().getTime() - foundTimReg.Timestamp >
                              zoneOutTime
                            ) {
                              foundTimReg.TrAuto = "X";
                              foundTimReg.InOut = "02";
                              foundTimReg.Timestamp =
                                parseInt(foundTimReg.Timestamp) + zoneOutTime;
                              toPush.push(foundTimReg);
                            }
                          }
                        }
                      }
                    }
                  }
                }.bind(this)
              );
              if (toPush.length) {
                this.callTimeReg(toPush, noNetwork, false);
                d.resolve();
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              d.reject();
            }, this)
          );
      },

      maintainInOutTable: function (trs) {
        var newTr = [];

        trs.forEach(function (tr) {
          /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: 42
          seconds and milliseconds need not be considered in case of time registration checking with 
          Timesheet execution start and end. So seconds and milli seconds are removed from timeinout table*/
          let timestamp;
          if (tr.InOut === "01") {
            timestamp = new Date(tr.Timestamp).setSeconds(0, 0);
          } else {
            timestamp = tr.Timestamp;
          }
          /*END: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: 42*/

          newTr.push({
            TimeStamp: new Date(), //just for keeping a key
            Pernr: tr.Pernr,
            TrZone: tr.TrZone,
            TimeIn: tr.InOut === "01" ? timestamp : "",
            TimeOut: tr.InOut === "02" ? timestamp : "",
          });
        });
        //this._saveTableToDB(newTr,TimeInOut,'Replace');
        $.when(this.getDBService().maintainInOutTable(newTr))
          .done(
            function () {
              this.getInOutTable();
            }.bind(this)
          )
          .fail(
            function (error) {
              debugger;
              this.getInOutTable();
              if (error.message) {
                MToast.show(
                  "Error with syncing table TimeInout" + error.message
                );
              }
            }.bind(this)
          );
      },

      callTimeReg: function (data, noNetwork) {
        this.getView().setBusy(true);
        if (data && data.length === 0) {
          if (this.messageLog.length > 0) {
            this.getModel("local").setProperty("/messages", this.messageLog);
            this.getDialogManager().open(
              "fragments.MessageFragment",
              this.getView()
            );
          } else {
            if (!this.haveAForbiddenTR) {
              /*BEGIN: Date: 06/03/2024 AMID: A0866990 V13.1- MWX- Frontend-  Bug 48481 - MWX - Adjust confirmation when participant exits zone is in a 'running' confirmation 
              No need to have this error message when  someone is forbidden from exiting confirmation*/
              MBox.information(this.getText("NoTimeRegistrationsAdded"));
            }
          }

          //MBox.information('No Time Registrations were newly added');
          this.getView().setBusy(false);
          return;
        } else {
          this.maintainInOutTable(data);
        }
        var zonedBadges =
          this.getModel("local").getProperty("/zonedBadges") || [];
        for (let i = 0; i < data.length; i++) {
          if (data[i].InOut === "01" && !zonedBadges.includes(data[i].Pernr)) {
            zonedBadges.push(data[i].Pernr);
          } else if (
            data[i].InOut === "02" &&
            zonedBadges.includes(data[i].Pernr)
          ) {
            _.remove(zonedBadges, function (n) {
              return n === data[i].Pernr;
            });
          }
        }
        var tempData = JSON.parse(JSON.stringify(data));
        this.getDBService().multipleDataDb("TimeRegistration", tempData);
        if (noNetwork) {
          let metadataObj = this.getDBService()._getMetaObject();
          if (metadataObj) {
            let TimeReg = _.find(
              metadataObj.dataServices.schema[0].entityType,
              { name: "TimeRegistration" }
            );
            // var tempData1=JSON.parse(JSON.stringify(data));
            //this.getDBService().multipleDataDb("TimeRegistration",tempData1);
            this.getDBService().multipleDataDb(
              "TimeRegistration1",
              data,
              TimeReg
            );
          }
        } else {
          //after implmentation IN backend
          var tempData3 = JSON.parse(JSON.stringify(data));
          $.when(this.getService().setZonebadging(tempData3))
            .done(
              function (oData) {
                if (oData) {
                  let ForPartcipant = this.getText("ForParticipant"),
                    InZone = this.getText("InZone");
                  _.forEach(
                    oData.NavTimeRegistration.results,
                    function (row) {
                      if (row.Message) {
                        this.messageLog.push({
                          Message:
                            ForPartcipant +
                            " " +
                            row.Pernr +
                            " " +
                            InZone +
                            " " +
                            row.TrZone +
                            " " +
                            row.Message,
                          Severity: "Error",
                        });
                      }
                    }.bind(this)
                  );
                  if (this.messageLog.length > 0) {
                    this.getModel("local").setProperty(
                      "/messages",
                      this.messageLog
                    );
                    this.getDialogManager().open(
                      "fragments.MessageFragment",
                      this.getView()
                    );
                  } else {
                    MBox.success(this.getText("ZoneRegistrationSuccess"));
                    //MBox.success('Zone Registration success');
                  }
                }
              }.bind(this)
            )
            .fail(
              function (error) {
                MBox.error(this.getText("ZoneRegistrationError"));
              }.bind(this)
            );
        }
        // if(viewUpdate){
        this.getModel("local").setProperty("/zonedBadges", zonedBadges);
        this.getModel("local").refresh(true);
        // }
      },

      getInOutTable: function () {
        $.when(this.getDBService().getEntitySet("TimeInOut"))
          .done(
            function (oData) {
              this.getView().setBusy(false);
              this.getModel("local").setProperty(
                "/TimeInOut",
                this.getHelper().rowsToArray(oData)
              );
            }.bind(this)
          )
          .fail(
            function () {
              this.getView().setBusy(false);
              console.error("CPM:Table TimeInOut not updated.");
            }.bind(this)
          );
      },

      _getNotificationsFromDb: function () {
        $.when(
          this.getDBService().getEntitySet("PMNotification"),
          this.getDBService().getEntitySet("Confirmation")
        )
          .done(
            jQuery.proxy(function (oData, oConfirmations) {
              var oLocalModel = this.getView().getModel("local"),
                aLocalNotificationSet = this.getHelper().rowsToArray(oData),
                confirmations = this.getHelper().rowsToArray(oConfirmations);

              var aNotBoundNotifications = [];

              if (!oLocalModel.getProperty("/PMNotificationSet")) {
                oLocalModel.setProperty("/PMNotificationSet", []);
              }

              aLocalNotificationSet.forEach(function (oNotif) {
                for (var sProp in oNotif) {
                  if (
                    oNotif[sProp] === "true" ||
                    oNotif[sProp] === "false" ||
                    oNotif[sProp] === "X"
                  ) {
                    oNotif[sProp] =
                      oNotif[sProp] === "true" || oNotif[sProp] === "X";
                  }
                  if (
                    (sProp === "SendToGk" || sProp === "Msaus") &&
                    oNotif[sProp] === ""
                  ) {
                    oNotif[sProp] = false;
                  }
                }
                if (_.find(confirmations, { NotifHandle: oNotif.Handle })) {
                  oNotif.confirmationIsExisting = true;
                } else {
                  oNotif.confirmationIsExisting = false;
                }
                if (oNotif.Qmnum === "") {
                  aNotBoundNotifications.push(oNotif);
                }
              });

              oLocalModel.setProperty(
                "/NotBoundNotificationSet",
                aNotBoundNotifications
              );
              oLocalModel.setProperty(
                "/PMNotificationSet",
                aLocalNotificationSet
              );
            }, this)
          )
          .fail(jQuery.proxy(function (oError) {}, this));
      },

      createTreeForWCA: function (WCAOpeRisks) {
        const riskdata = { nodes: [] };
        WCAOpeRisks.forEach((item) => {
          const property = { name: item.Codegrpx, nodes: [] };
          const index = riskdata.nodes.findIndex(
            (node) => node.name === property.name
          );
          if (index === -1) {
            riskdata.nodes.push(property);
          }
        });

        WCAOpeRisks.forEach((item) => {
          const property2 = { name: item.Codex, nodes: [] };
          riskdata.nodes.forEach((node) => {
            if (
              node.name === item.Codegrpx &&
              !node.nodes.some((n) => n.name === property2.name)
            ) {
              node.nodes.push(property2);
            }
          });
        });

        WCAOpeRisks.forEach((item) => {
          const property3 = { name: item.ActionText, nodes: [] };
          riskdata.nodes.forEach((node) => {
            if (node.name === item.Codegrpx) {
              node.nodes.forEach((subNode) => {
                if (
                  subNode.name === item.Codex &&
                  !subNode.nodes.some((n) => n.name === property3.name)
                ) {
                  subNode.nodes.push(property3);
                }
              });
            }
          });
        });

        // V13.1 P555S - Bug 48589 - UAT issue 228 - WCM data - permits and 4th level is missing

        WCAOpeRisks.forEach((item) => {
          if (item.QtxtCode2) {
            const property4 = { name: item.QtxtCode2 };
            riskdata.nodes.forEach((node) => {
              if (node.name === item.Codegrpx) {
                node.nodes.forEach((subNode) => {
                  if (subNode.name === item.Codex) {
                    subNode.nodes.forEach((subNode2) => {
                      if (
                        subNode2.name === item.ActionText &&
                        !subNode2.nodes.some((n) => n.name === property4.name)
                      ) {
                        subNode2.nodes.push(property4);
                      }
                    });
                  }
                });
              }
            });
          }
        });

        // End 4th level missing
        return riskdata;
      },

      checkHigherFuncLocOrg: function (oObject, FuncOrg) {
        var oParentFloc = _.find(
          this.getSharedModel().getProperty("/techObjects"),
          jQuery.proxy(function (oFuncLoc) {
            return (
              oFuncLoc && oObject && oFuncLoc.TechObject === oObject.Parent
            );
          }, this)
        );

        if (oParentFloc) {
          var aFoundFuncLocOrg = FuncOrg.find(function (oFuncLocOrg) {
            return oParentFloc && oFuncLocOrg.Tplnr === oParentFloc.Strno;
          });

          if (aFoundFuncLocOrg.Ingrp && aFoundFuncLocOrg.Arbpl) {
            return aFoundFuncLocOrg;
          } else {
            return this.checkHigherFuncLocOrg(oParentFloc, FuncOrg);
          }
        }
      },

      /**
       * Remove all teh cached items after the app is reset. the GDL was kept as it is in this.oGdlApi
       * Issue 57 in 13.0
       * @memberOf mobilework.controller.BaseController
       * @public
       */

      // removeAllCache: function(){
      // 	this.oEventBus= null;
      // 	this.oRouter= null;
      // 	this.oScannerHandler= null;
      // 	this.oHelper= null;
      // 	this.oFormatter= Format,
      // 	this.oValidator= null;
      // 	this.oDBService= null;
      // 	this.oService= null;
      // 	this.oGdlApi= null;
      // },

      /**
       * Exapnd the tree for Damage, Cause, Activity, Task
       * @memberOf mobilework.controller.BaseController
       * @public
       */
      onExpandAllPress: function (oEvent) {
        let tree = this.getDialogManager()
          .getDialogEntry("fragments.NotifTree", this.getView())
          .getContent()[0]
          .getContent()[1];
        tree.expandToLevel(1);
      },

      /**
       * Collapse the tree for Damage, Cause, Activity, Task
       * @memberOf mobilework.controller.BaseController
       * @public
       */
      onCollapseAllPress: function (oEvent) {
        let tree = this.getDialogManager()
          .getDialogEntry("fragments.NotifTree", this.getView())
          .getContent()[0]
          .getContent()[1];
        tree.collapseAll();
      },

      /**
       * Release 130 - 39
       * Create the tree for Damage, Cause, Activity, Task
       * Header line means there is no code.We group the catlog with headers.
       * Adjust dropdown lists for e.g. cause to hierarchical view instead of flat list
       * @memberOf mobilework.controller.BaseController
       * @public
       */
      createTable: function (aCatalog, Codct) {
        // let header = this.getSharedModel().getProperty('/vh/headerLines');
        // let aGroup = _.groupBy(aCatalog, "Codgrr");
        //  header = _.filter(header, { Codct: Codct });
        // let data = JSON.parse(JSON.stringify(header));
        // data.filter(function (item) {
        // 	item.Children = aGroup[item.Codgrr] || [];
        // 	return item.Children.length;
        // });
        // return data;
        const header = this.getSharedModel().getProperty("/vh/headerLines");
        const aGroup = _.groupBy(aCatalog, "Codgrr");
        const filteredHeader = header.filter((item) => item.Codct === Codct);

        const data = filteredHeader
          .map((item) => {
            item.nodes = aGroup[item.Codgrr] || [];
            return item.nodes.length ? item : null;
          })
          .filter(Boolean);

        return data;
      },

      notifTreeTableCancel: function () {
        this.getDialogManager().close("fragments.NotifTree", this.getView());
      },

      handleValueHelp: function (oEvent) {
        let oVhModel = this.getView().getModel("vh"),
          type = oEvent.getSource().getId().slice(-5);
        if (type && oVhModel.getProperty("/Cat" + type).length) {
          this.getDialogManager().openWithModel(
            "fragments.NotifTree",
            this.getView(),
            new sap.ui.model.json.JSONModel({
              table: oVhModel.getProperty("/Cat" + type),
              title: this.getText(type),
            }),
            this
          );
        } else {
          MToast.show(this.getText("SelectQmart"));
        }
      },
      onProgressEscapePress: async function (oPromise) {
        console.error("Progress Dialog escape not allowed");
        oPromise.reject();
      },

      _checkLogin1: function (fromOnlineFn) {
        var d = jQuery.Deferred(),
          sUser = "",
          sPassword = "";
        if (this.getSharedModel().getProperty("/sapSettings"))
          var oSettings = this.getSharedModel().getProperty("/sapSettings");
        if (fromOnlineFn !== true && this.getModel("login").getData()) {
          if (this.getModel("login").getData()) {
            var login = this.getModel("login").getData();
          }
        }
        if (fromOnlineFn && oSettings) {
          sUser = oSettings.sapUser;
          sPassword = oSettings.sapPass;
        } else if (login) {
          sUser = this.getModel("login").getData().sapUser;
          sPassword = this.getModel("login").getData().sapPass;
        }
        if (
          this.getSharedModel().getProperty("/sapSettings") &&
          this.getSharedModel().getProperty("/sapSettings").host !== ""
        ) {
          // if (sUser && sPassword ) {
          if (this.getService() === null) {
            return d.resolve(
              this.getView()
                .getModel("i18n")
                .getResourceBundle()
                .getText("NoCredentialsFound") +
                ",\n" +
                this.getView()
                  .getModel("i18n")
                  .getResourceBundle()
                  .getText("LoginFirst")
            ); // "No credentials found,\nplease login first");
          }
          $.when(
            this.getService().connectionCheck(
              sUser,
              sPassword,
              this.getHelper().isDevModeActive(),
              this
            )
          )
            .done((oData) => {
              d.resolve(oData);
            })
            .fail(
              jQuery.proxy(function (oData) {
                // this.getModel('login').setProperty("/show-authorization-nok", true);
                if (
                  oData.getParameters &&
                  oData.getParameters() &&
                  oData.getParameters().statusCode === 401
                ) {
                  d.resolve(
                    this.getView()
                      .getModel("i18n")
                      .getResourceBundle()
                      .getText("IncorrectLogin") +
                      "\n" +
                      this.getView()
                        .getModel("i18n")
                        .getResourceBundle()
                        .getText("ConnectionCheck")
                  );
                } else {
                  d.resolve(
                    this.getView()
                      .getModel("i18n")
                      .getResourceBundle()
                      .getText("NoSAPSystemConnection")
                  );
                }
              }, this)
            );
        } else {
          d.resolve({
            settings: false,
          });
        }

        return d.promise();
      },

      onStatusIconPress: function (oEvent) {
        console.debug("On header status icon press");
        console.debug(oEvent);
        let oIcon = oEvent.getSource();
        oIcon.setBusy(true);

        $.when(this._checkLogin1(true))
          .done(
            jQuery.proxy(function (oData) {
              if (oData && oData.ConnectionCheck) {
                var sMessageType = oData.ConnectionCheck.Type;
                if (sMessageType === "S") {
                  this.genericSetDeviceIdColor("Green");
                  this.genericReplaceStyleClass(this.getView(), "Green");

                  let sMessage = oData.ConnectionCheck.Message;
                  setTimeout(function () {
                    oIcon.setBusy(false);
                  }, 2000);

                  MToast.show(sMessage);
                } else {
                  this.genericSetDeviceIdColor("Red");
                  this.genericReplaceStyleClass(this.getView(), "Red");

                  let sMessage = oData.ConnectionCheck.Message;
                  MToast.show(sMessage);
                  setTimeout(function () {
                    oIcon.setBusy(false);
                  }, 2000);
                }
              } else if (oData === "METADATA_REFRESH_TRIGGERED") {
                oIcon.setBusy(false);
              } else {
                this.genericSetDeviceIdColor("Red");
                this.genericReplaceStyleClass(this.getView(), "Red");

                MToast.show(oData);
                oIcon.setBusy(false);
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              this.genericSetDeviceIdColor("Red");
              this.genericReplaceStyleClass(this.getView(), "Red");

              oIcon.setBusy(false);
            }, this)
          );
      },

      genericSetDeviceIdColor: function (sColor) {
        if (sColor === "Green") {
          this.getSharedModel().setProperty(
            "/deviceIdColor",
            "deviceIdColourGreen"
          );
          this.getSharedModel().setProperty("/bOnline", true);
        } else if (sColor === "Red") {
          this.getSharedModel().setProperty(
            "/deviceIdColor",
            "deviceIdColourRed"
          );
          this.getSharedModel().setProperty("/bOnline", false);
        }
      },

      genericReplaceStyleClass: function (oView, sColor) {
        let fPaint = function (oView, sColor) {
          if (sColor === "Green") {
            oView.removeStyleClass("deviceIdColourRed");
            oView.addStyleClass("deviceIdColourGreen");
          } else if (sColor === "Red") {
            oView.removeStyleClass("deviceIdColourGreen");
            oView.addStyleClass("deviceIdColourRed");
          }
        };

        fPaint(oView, sColor);

        // if(	oView.getViewName().includes("mobilework.view.confirmations.") ||
        // 	oView.getViewName().includes("mobilework.view.dialogs.") ||
        // 	oView.getViewName().includes("mobilework.view.notifications.") ||
        // 	oView.getViewName().includes("mobilework.view.orders.") ||
        // 	oView.getViewName().includes("mobilework.view.participants.") ||
        // 	oView.getViewName().includes("mobilework.view.settings.") ||
        // 	oView.getViewName().includes("mobilework.view.synchronize.")
        // 	 ){
        // 	fPaint(oView.getParent().getParent(), sColor);
        // }

        fPaint(this.getOwnerComponent().getRootControl(), sColor);

        if (
          this.getOwnerComponent().getRootControl().getAggregation("content")
            .length > 0 &&
          this.getOwnerComponent()
            .getRootControl()
            .getAggregation("content")[0]
            .getAggregation("pages").length > 0
        ) {
          fPaint(
            this.getOwnerComponent()
              .getRootControl()
              .getAggregation("content")[0]
              .getAggregation("pages")[0],
            sColor
          );
        }

        // if(oView.getParent && oView.getParent() && oView.getParent().getParent && oView.getParent().getParent()){
        // 	let oRootView = oView.getParent().getParent();
        // 	fPaint(oRootView, sColor);
        // }
        // let sViewName = oView.getViewName();
        // console.log(sViewName);
        // if(sViewName === "mobilework.view.Main"){
        // 	let oParentView = oView.getParent().getParent().getParent().getParent();
        // 	fPaint(oParentView, sColor);
        // }
      },

      make_base_auth: function (user, password) {
        var tok = user + ":" + password;
        var hash = btoa(tok);
        return hash;
      },
      _calcExecStartFin: function (sActWork, sUnWork, PlDate) {
        var sUnWorkToAdd = "",
          oMoStart = new moment(PlDate),
          oMoFin = null,
          oReturn = {
            ExecStart: "",
            ExecFin: "",
          };

        switch (sUnWork) {
          case "DAY":
            sUnWorkToAdd = "d";
            break;
          case "HUR" || "HR":
            sUnWorkToAdd = "h";
            break;
          case "MIN":
            sUnWorkToAdd = "m";
        }
        sActWork = sActWork ? sActWork.toString() : sActWork;
        if (sUnWork === "DAY" && sActWork && sActWork.indexOf(".") !== -1) {
          var iActWorkDays = Number(sActWork.split(".")[0]),
            iActWorkHours =
              Number(
                sActWork.split(".")[1] /
                  Math.pow(10, sActWork.split(".")[1].length)
              ) * 24;

          oMoFin = new moment(oMoStart)
            .add(iActWorkDays, sUnWorkToAdd)
            .add(iActWorkHours, "h");
        } else {
          oMoFin = new moment(oMoStart).add(Number(sActWork), sUnWorkToAdd);
        }

        oReturn.ExecStart = oMoStart.format("YYYY-MM-DD HH:mm:ss");
        oReturn.ExecFin = oMoFin.format("YYYY-MM-DD HH:mm:ss");

        return oReturn;
      },

      getLastTimeReg: function () {
        return "SELECT a.* FROM TimeRegistration a INNER JOIN ( SELECT Pernr, MAX(Timestamp) AS last_time  FROM TimeRegistration GROUP BY Pernr ) b ON a.Pernr = b.Pernr AND a.Timestamp = b.last_time";
      },

      getPurchaseHelper: function (helper) {
        return this.getOwnerComponent().PurchaseHelper;
      },
    });
  }
);
