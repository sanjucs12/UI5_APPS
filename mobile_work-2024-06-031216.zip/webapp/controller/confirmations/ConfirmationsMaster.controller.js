/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/libs/lodash",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
  ],
  function (
    Controller,
    MBox,
    Mo,
    Lo,
    Filter,
    FilterOperator,
    JSONModel,
    Sorter
  ) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.confirmations.ConfirmationsMaster",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        /** @type sap.m.Dialog */
        oAddConfirmationDialog: null,

        /** @type sap.m.List */
        oMasterList: null,

        bFromOrderList: false,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ConfirmationsMaster
         */
        onInit: function () {
          this._initModels();

          this.getRouter()
            .getRoute("confirmationsMaster")
            .attachMatched(this.onRouteMatched, this);
          this.getRouter()
            .getRoute("createConfirmationFromOrder")
            .attachPatternMatched(this.onFromOrderMatched, this);
          this.getRouter()
            .getRoute("createConfirmationFromNotif")
            .attachPatternMatched(this.onFromNotifMatched, this);

          //subscribe to scanner
          this.getEventBus().subscribe(
            "scanner",
            "scannedConfirmationMaster",
            this.onExtScanSuccess,
            this
          );
          this.getEventBus().subscribe(
            "modularize",
            "CheckExistingOrderConf",
            this.addNonExistingOrderConf,
            this
          );
          this.getEventBus().subscribe(
            "modularize",
            "createNotifConf",
            this.doOnFromNotifMatched,
            this
          );
          const oPromGdlLinks = this.getDBService().getEntitySet("GdlLink"),
            self = this;
          Promise.all([oPromGdlLinks]).then((results) => {
            const GdlLinks = self.getHelper().rowsToArray(results[0]);
            this.getView().getModel("local").setProperty("/GdlLinks", GdlLinks);
          });
          if (this.appliedFilters) {
            this._applyFilterSearch(this.appliedFilters);
          }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ConfirmationsMaster
         */
        onExit: function () {
          // nothing yet
        },

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: async function (oEvent) {
          this.bFromOrderList = false;
          this.bFromNotif = false;
          this.filtersAdded = {
            FunctLoc: null,
            Equipment: null,
          };
          this.listItem = {
            FunctLoc: null,
            Equipment: null,
          };

          //set scanner location
          this.getScanHandler().setLocation("ConfirmationMaster");

          //set connection property
          this.getConnection();

          if (!this.oMasterList) {
            this.oMasterList = this.getView().byId("confirmationTreeTable");
          }

          await this.updateTreeTable(true);
          //this._getConfirmationsFromDb();
          this.changeColorOfDeviceId();
          if (this.appliedFilters) {
            this._applyFilterSearch(this.appliedFilters);
          }
        },

        onFromOrderMatched: function (oEvent, oEventData) {
          this.bFromOrderList = true;
          this.bFromNotif = false;
          //oEvent will be null when creating order/operation from Confirmation Screen
          if (oEvent) {
            var sAufnr = oEvent.getParameter("arguments").Aufnr,
              sVornr = oEvent.getParameter("arguments").Vornr,
              sSubActivity = oEvent.getParameter("arguments").SubActivity || "",
              sWorkCntr = oEvent.getParameter("arguments").WorkCntr,
              sPlant = oEvent.getParameter("arguments").Plant,
              sConfText = oEvent.getParameter("arguments").ConfText,
              sParentHandle = oEvent.getParameter("arguments").ParentHandle,
              persNo = oEvent.getParameter("arguments").PersNo,
              controlKey = oEvent.getParameter("arguments").ControlKey;
            this.bfromConfirmOrderlist =
              oEvent.getParameter("arguments").FromConfirmation;
          } else {
            var sAufnr = oEventData.Aufnr,
              sVornr = oEventData.Vornr,
              sSubActivity = oEventData.SubActivity,
              sWorkCntr = oEventData.WorkCntr,
              sPlant = oEventData.Plant,
              sConfText = oEventData.ConfText,
              sParentHandle = oEventData.ParentHandle,
              persNo = oEventData.PersNo,
              controlKey = oEventData.ControlKey;
          }
          var bSplit = false,
            bFromOrder = true,
            bFromOrderHeader = sVornr ? false : true,
            bHasParticipants = this.getView()
              .getModel("shared")
              .getProperty("/hasParticipants"),
            sUnWork;

          var oOrderProm = this.getDBService().getOrder(sAufnr);

          if (sSubActivity) {
            var oOperationProm =
              this.getDBService().getOperationWithSubActivity(
                sAufnr,
                sVornr,
                sSubActivity
              );
          } else {
            oOperationProm = this.getDBService().getOperation(sAufnr, sVornr);
          }

          if (!sUnWork) {
            if (
              this.getSharedModel().getProperty("/sapSettings/CONF_UNIT") ===
              "STD"
            ) {
              sUnWork = "HUR";
            } else {
              sUnWork = "MIN";
            }
          }
          if (persNo) {
            persNo = persNo.split(",");
            this.getView().getModel("newConf").setProperty("/PersNo", persNo);
            this.getView()
              .getModel("newConf")
              .setProperty("/ExecutantCnt", persNo.length);
          }
          // $.when(this.getDBService().getEntitySet("Confirmation")).done(jQuery.proxy(function (aConfirmations) {
          // 	var aConfirmationSet = this.getHelper().rowsToArray(aConfirmations);

          // 	_.each(aConfirmationSet, function (oConf) {
          // 		for (var sProp in oConf) {
          // 			if (oConf[sProp] === "true" || oConf[sProp] === "false") {
          // 				oConf[sProp] = oConf[sProp] === "true" ? true : false;
          // 			}
          // 		}
          // 	});

          // 	this.getView().getModel("local").setProperty("/ConfirmationSet", aConfirmationSet);

          // }, this));
          this._getConfirmationsFromDb();
          $.when(oOrderProm, oOperationProm).done(
            jQuery.proxy(function (oResultOrder, oResultOperation) {
              var aOrders = this.getHelper().rowsToArray(oResultOrder),
                aOperations = this.getHelper().rowsToArray(oResultOperation);

              var sOrderDescription = aOrders ? aOrders[0].ShortText : "",
                sOperationDescription = aOperations[0]
                  ? aOperations[0].Description
                  : "";

              if (
                (bHasParticipants && sAufnr && sAufnr !== "0") ||
                this.getSharedModel().getProperty(
                  "/sapSettings/persNoNotRequired"
                ) === true
              ) {
                $.when(this.getDBService().getEntitySet("Participant")).done(
                  jQuery.proxy(function (oParticipants) {
                    this._setParticipantSet(oParticipants);
                    $.when(
                      this._defaultNewConf(
                        sAufnr,
                        sVornr,
                        sSubActivity,
                        sUnWork,
                        sWorkCntr,
                        sConfText,
                        sOrderDescription,
                        sOperationDescription,
                        sParentHandle,
                        null,
                        bSplit,
                        bFromOrderHeader,
                        sPlant,
                        bFromOrder,
                        null,
                        controlKey
                      )
                    ).done(
                      $.proxy(function () {
                        this._manualCreateConfirmation(false);
                      }, this)
                    );
                  }, this)
                );
              } else {
                this._askCreateParticipant();
              }
            }, this)
          );
          this.changeColorOfDeviceId();
        },

        onFromNotifMatched: function (oEvent, oEventData) {
          this.bFromOrderList = false;
          if (oEvent) this.bFromNotif = true;
          //oEvent will be null when creating Notification from Confirmation Screen
          if (oEvent) {
            var sParentHandle = oEvent.getParameter("arguments").Handle,
              sWorkCntr = oEvent.getParameter("arguments").WorkCntr;
          } else {
            var sParentHandle = oEventData.Handle,
              sWorkCntr = oEventData.WorkCntr,
              sMnWkCtr = oEventData.MnWkCtr,
              persNo = oEventData.PersNo;
          }

          var oDialog = this._getAddConfirmationDialog(),
            bHasParticipants = this.getView()
              .getModel("shared")
              .getProperty("/hasParticipants"),
            UnWork;
          if (!UnWork) {
            if (
              this.getSharedModel().getProperty("/sapSettings/CONF_UNIT") ===
              "STD"
            ) {
              UnWork = "HUR";
            } else {
              UnWork = "MIN";
            }
          }
          if (persNo) {
            persNo = persNo.split(",");
            this.getView().getModel("newConf").setProperty("/PersNo", persNo);
            this.getView()
              .getModel("newConf")
              .setProperty("/ExecutantCnt", persNo.length);
          }
          this._getConfirmationsFromDb();
          if (bHasParticipants && sParentHandle) {
            $.when(this.getDBService().getEntitySet("Participant")).done(
              jQuery.proxy(function (oParticipants) {
                this._setParticipantSet(oParticipants);
                this._defaultNewConf(
                  null,
                  null,
                  null,
                  UnWork,
                  sWorkCntr,
                  null,
                  null,
                  null,
                  null,
                  sParentHandle,
                  null,
                  null,
                  null,
                  null,
                  sMnWkCtr,
                  null
                );
                oDialog.open();
              }, this)
            );
          } else {
            this._askCreateParticipant();
          }
          this.changeColorOfDeviceId();
        },

        onAddPress: function (oEvent) {
          var oDialog = this._getAddConfirmationDialog(),
            bHasParticipants = this.getView()
              .getModel("shared")
              .getProperty("/hasParticipants");

          if (
            bHasParticipants ||
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === true
          ) {
            this._defaultNewConf();
            oDialog.open();
          } else {
            this._askCreateParticipant();
          }
        },

        onMasterSelectionChange: function (oEvent) {
          var handle = null,
            i = 0,
            path = null,
            oBindingContext = oEvent.getParameters().rowContext;
          if (oBindingContext) {
            var oObject = oBindingContext.oModel.getProperty(
              oEvent.getParameters().rowContext.sPath
            );
            if (oObject && oObject.Orderid) {
              this.oMasterList.clearSelection();
              if (oBindingContext.sPath.indexOf("NavOperation") === -1)
                this.getRouter().navTo("ordersDetail", {
                  ID: oBindingContext.sPath.split("/")[2],
                });
              else {
                this.getRouter().navTo("ordersOperationsDetail", {
                  OrderID: oBindingContext.sPath.split("/")[2],
                  ID: oBindingContext.sPath.split("/")[4],
                });
              }
            } else {
              if (oObject.Hidden) {
                handle = oObject.ParentHndl;
              } else {
                handle = oObject.Handle;
              }
              _.filter(
                this.getView()
                  .getModel("local")
                  .getProperty("/ConfirmationSet"),
                jQuery.proxy(function (conf) {
                  if (conf) {
                    i++;
                    if (handle === conf.Handle) {
                      path = i;
                      return true;
                    }
                    return false;
                  }
                }, this)
              );
            }
          }
          if (path) {
            this.getRouter().navTo("confirmationsDetail", {
              ID: path - 1,
            });
          }
        },

        onNavBack: function () {
          // remove all non saved confirmations from local set
          var aLocalConfSet =
            this.getModel("local").getProperty("/ConfirmationSet");

          $.when(this.getDBService().getEntitySet("Confirmation")).done(
            jQuery.proxy(function (aConfirmations) {
              var aConfirmationSet =
                this.getHelper().rowsToArray(aConfirmations);

              _.each(aConfirmationSet, function (oConf) {
                for (var sProp in oConf) {
                  if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                    oConf[sProp] = oConf[sProp] === "true" ? true : false;
                  }
                }
              });

              // if (aConfirmationSet.length > 0) {
              _.each(
                aLocalConfSet,
                jQuery.proxy(function (oLocalConf) {
                  var oConfFound = _.find(
                    aConfirmationSet,
                    jQuery.proxy(function (oConf) {
                      return oConf.Handle === oLocalConf.Handle;
                    }, this)
                  );

                  if (!oConfFound) {
                    var aConfSet =
                      this.getModel("local").getProperty("/ConfirmationSet");

                    aConfSet = _.remove(
                      aConfSet,
                      jQuery.proxy(function (oConf) {
                        return oConf.Handle !== oLocalConf.Handle;
                      }, this)
                    );

                    this.getView()
                      .getModel("local")
                      .setProperty("/ConfirmationSet", aConfSet);
                  }
                }, this)
              );

              // }
            }, this)
          );
          this.clearFilters();
          this.getRouter().navTo("main");
        },

        onScanPress: function (oEvent) {
          var bHasParticipants = this.getView()
            .getModel("shared")
            .getProperty("/hasParticipants");

          if (bHasParticipants) {
            $.when(this.getScanHandler().scan())
              .done(jQuery.proxy(this.onScanSuccess, this))
              .fail(jQuery.proxy(function (oError) {}, this));
          } else {
            this._askCreateParticipant();
          }
        },

        onExtScanSuccess: function (sChannel, sEvent, oData) {
          var bHasParticipants = this.getView()
            .getModel("shared")
            .getProperty("/hasParticipants");

          if (!bHasParticipants) {
            this._askCreateParticipant();
            return;
          }

          if (!oData.result.error) {
            this.onScanSuccess({
              text: oData.result.barcode,
            });
          } else {
            MBox.error(oData.result.errorMessage);
          }
        },

        onScanSuccess: function (oData) {
          var oNewConfModel = this.getView().getModel("newConf");

          if (!oData.cancelled) {
            this._defaultNewConf();

            if (oData.text.indexOf("-") === -1) {
              let sInputAufnr = oData.text.slice(0, 12); // maxlength 12
              oNewConfModel.setProperty("/Aufnr", sInputAufnr);
            } else {
              let sInputAufnr = oData.text.split("-")[0].slice(0, 12); // maxlength 12
              let sInputVornr = oData.text.split("-")[1].slice(0, 4); // maxlength 4
              oNewConfModel.setProperty("/Aufnr", sInputAufnr);
              oNewConfModel.setProperty("/Vornr", sInputVornr);
            }

            this._getAddConfirmationDialog().open();
          }
        },

        onConfirmationCreated: function (res, oConfirmation, bValidate) {
          var oLocalModel = this.getView().getModel("local"),
            aLocalConfirmationSet = [];

          if (!oLocalModel.getProperty("/ConfirmationSet")) {
            oLocalModel.setProperty("/ConfirmationSet", []);
          }

          aLocalConfirmationSet = oLocalModel.getProperty("/ConfirmationSet");

          // $.when(this.getDBService().getEntitySet("PMOrder"), this.getDBService().getEntitySet("Operation"))
          // 	.done(jQuery.proxy(function (oOrders, oOperations) {
          // 		var aLocalOrderSet = this.getHelper().rowsToArray(oOrders),
          // 			aLocalOperationSet = this.getHelper().rowsToArray(oOperations);

          // 		if (!oLocalModel.getProperty("/ConfirmationSet")) {
          // 			oLocalModel.setProperty("/ConfirmationSet", []);
          // 		}

          // 		// aLocalConfirmationSet.forEach(function (oConf) {
          // 		// for (var sProp in oConf) {
          // 		// 	if (oConf[sProp] === "true" || oConf[sProp] === "false") {
          // 		// 		oConf[sProp] = oConf[sProp] === "true";
          // 		// 	}
          // 		// 	if ((sProp === "IsFinished" || sProp === "FinConf" || sProp === "Split") && oConf[sProp] === "") {
          // 		// 		oConf[sProp] = false;
          // 		// 	}
          // 		// }

          // 		var oFoundOrder = _.find(aLocalOrderSet, jQuery.proxy(function (oOrder) {
          // 			return oOrder.Orderid === oConfirmation.Aufnr;
          // 		}, this));

          // 		if (oFoundOrder) {
          // 			oConfirmation.OrderDescription = oFoundOrder.ShortText;
          // 		}

          // 		var oFoundOperation = _.find(aLocalOperationSet, jQuery.proxy(function (oOperation) {
          // 			return oOperation.Activity === oConfirmation.Vornr;
          // 		}, this));

          // 		if (oFoundOperation) {
          // 			oConfirmation.OperationDescription = oFoundOperation.Description;
          // 		}
          // 		// });

          // aLocalConfirmationSet = this._sortConfirmations(aLocalConfirmationSet);

          aLocalConfirmationSet.push(oConfirmation);
          oLocalModel.setProperty("/ConfirmationSet", aLocalConfirmationSet);

          // oLocalModel.setProperty("/ConfirmationSet/WorkCntr",this.getSharedModel().getProperty("/sapSettings/WorkCntr"));

          // oLocalModel.setProperty("/ConfirmationSet", aLocalConfirmationSet);

          if (this.oAddConfirmationDialog) {
            this.oAddConfirmationDialog.close();
          }
          this.getLogs().addLog(
            "New Confirmation Success",
            "INFO",
            "Confirmation"
          );
          this.updateTreeTable();
          if (!this.bfromConfirmOrderlist) {
            this.getRouter().navTo("confirmationsDetail", {
              ID: (aLocalConfirmationSet.length - 1).toString(),
              FromOrder: this.bFromOrderList === true,
              FromNotif: bValidate,
            });
          } else {
            this.bfromConfirmOrderlist = false;
            this.getRouter().navTo("confirmationsDetail", {
              ID: (aLocalConfirmationSet.length - 1).toString(),
              FromOrder: this.bFromOrderList === true,
              bfromConfirmOrderlist: true,
            });
          }
          // }, this))
          // .fail(jQuery.proxy(function (oError) {

          // }, this));
        },

        onExecStartChange: function (oEvent) {
          var oNewConfModel = this.getView().getModel("newConf"),
            sExecFin = oNewConfModel.getProperty("/ExecFin"),
            sExecStart = oEvent.getParameter("newValue"),
            moStart = new moment(sExecStart),
            moFin = new moment(sExecFin),
            oCalcData = this._calcActualWork(moStart, moFin);

          if (sExecFin) {
            if (oCalcData.bValid) {
              oNewConfModel.setProperty("/ActWork", oCalcData.ActWork);
              oNewConfModel.setProperty("/UnWork", oCalcData.UnWork);
            } else {
              oNewConfModel.setProperty("/ExecStart", "");
              oNewConfModel.setProperty("/ActWork", "");
              oNewConfModel.setProperty("/UnWork", "");
              MBox.error(this.getText("StartDateBeforeEndDate"));
            }
          }
        },

        onExecFinChange: function (oEvent) {
          var oNewConfModel = this.getView().getModel("newConf"),
            sExecFin = oEvent.getParameter("newValue"),
            sExecStart = oNewConfModel.getProperty("/ExecStart"),
            moStart = new moment(sExecStart),
            moFin = new moment(sExecFin),
            oCalcData = this._calcActualWork(moStart, moFin);

          if (sExecStart) {
            if (oCalcData.bValid) {
              oNewConfModel.setProperty("/ActWork", oCalcData.ActWork);
              oNewConfModel.setProperty("/UnWork", oCalcData.UnWork);
            } else {
              oNewConfModel.setProperty("/ExecFin", "");
              oNewConfModel.setProperty("/ActWork", "");
              oNewConfModel.setProperty("/UnWork", "");
              MBox.error(this.getText("EndDateAfterStartDate"));
            }
          }
        },

        onActWorkChange: function (oEvent) {
          var sActWork = oEvent.getParameter("newValue"),
            oNewConfModel = this.getView().getModel("newConf"),
            sUnWork = oNewConfModel.getProperty("/UnWork"),
            oCalcData = null;

          if (sUnWork) {
            oCalcData = this._calcExecStartFin(sActWork, sUnWork);
            oNewConfModel.setProperty("/ExecStart", oCalcData.ExecStart);
            oNewConfModel.setProperty("/ExecFin", oCalcData.ExecFin);
          }
        },

        onUnWorkChange: function (oEvent) {
          var sUnWork = oEvent.getSource().getSelectedKey(),
            oNewConfModel = this.getView().getModel("newConf"),
            sActWork = oNewConfModel.getProperty("/ActWork"),
            oCalcData = null;

          if (sActWork) {
            oCalcData = this._calcExecStartFin(sActWork, sUnWork);
            oNewConfModel.setProperty("/ExecStart", oCalcData.ExecStart);
            oNewConfModel.setProperty("/ExecFin", oCalcData.ExecFin);
          }
        },

        onParticipantChange: function (oEvent) {
          var iCurrCount = oEvent.getSource().getSelectedKeys().length,
            oNewConfModel = this.getView().getModel("newConf");

          oNewConfModel.setProperty("/ExecutantCnt", iCurrCount);
        },

        onPlantChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newConf")
              .setProperty("/Plant", sValue.toUpperCase());
          }
        },

        onWorkCenterChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newConf")
              .setProperty("/WorkCntr", sValue.toUpperCase());
          }
        },

        //====
        // for AddConfirmationDialog
        //====

        //Close the dialog
        onAddDialogCancelPress: function () {
          MBox.confirm(this.getText("CancelConfirmConfirm"), {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                this.getView().getModel("newConf").setProperty("/", {});
                this.oAddConfirmationDialog.close();
                if (this.bFromOrderList) {
                  this.getRouter().navTo("ordersMaster");
                } else {
                  if (this.bFromNotif) {
                    if (this.getSharedModel().getProperty("/currentNotifID")) {
                      var sNotifId =
                        this.getSharedModel().getProperty("/currentNotifID");

                      this.getSharedModel().setProperty("/currentNotifID", "");

                      this.getRouter().navTo("notificationsDetail", {
                        ID: sNotifId,
                      });
                    } else {
                      this.getRouter().navTo("notificationsMaster");
                    }
                  }
                }
              }
            }, this),
          });
        },

        //Event OK from dialog
        onAddDialogOkPress: function (oEvent) {
          let vornr = this.getView().getModel("newConf").getProperty("/Vornr");
          vornr &&
            this.getView()
              .getModel("newConf")
              .setProperty("/Vornr", vornr.padStart(4, 0));
          this._manualCreateConfirmation(true);
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        formatHeaderDate: function (sDateString) {
          if (sDateString) {
            return new moment(sDateString).format("DD/MM/YYYY HH:mm");
          } else {
            return "-";
          }
        },

        // formatUpperCase: function(sValue){
        // 	if(sValue){
        // 		return ((sValue.substring(0,1)).toUpperCase()+sValue.substring(1,sValue.length));
        // 	}
        // },
        //---------------------------//
        // PRIVATES
        //---------------------------//

        _getAddConfirmationDialog: function () {
          if (!this.oAddConfirmationDialog) {
            this.oAddConfirmationDialog = sap.ui.xmlfragment(
              "AddConfirmationDialog",
              "mobilework.view.confirmations.AddConfirmationDialog",
              this
            );
            this.getView().addDependent(this.oAddConfirmationDialog);
          }
          return this.oAddConfirmationDialog;
        },

        _initModels: function () {
          if (!this.getView().getModel("newConf")) {
            this.getView().setModel(new JSONModel(), "newConf");
          }
          if (!this.getView().getModel("filters")) {
            this.getView().setModel(new JSONModel(), "filters");
          }
        },

        _askCreateParticipant: function () {
          var oRouter = this.getRouter(),
            sYesText = this.getText("Yes"),
            sNoText = this.getText("No");

          MBox.show(this.getText("CreateParticNoExists"), {
            icon: MBox.Icon.WARNING,
            actions: [sYesText, sNoText],
            onClose: function (sAction) {
              if (sAction === sYesText) {
                oRouter.navTo("participantsMaster");
              }
            },
          });
        },

        _calcActualWork: function (oMomStart, oMomEnd) {
          var oReturn = {
              ActWork: 0,
              UnWork: "",
              bValid: true,
            },
            oDuration = moment.duration(oMomEnd.diff(oMomStart)),
            iDuration = 0,
            iDays = Math.round(oDuration.asDays() * 10) / 10,
            iHours = Math.round(oDuration.asHours() * 10) / 10,
            iMinutes = Math.round(oDuration.asMinutes() * 10) / 10;

          if (oDuration.asMilliseconds() < 0) {
            oReturn.bValid = false;
            return oReturn;
          }

          if (iDays % 1 !== 0 || iDays === 0) {
            if (iHours % 1 !== 0 || iHours === 0) {
              iDuration = iMinutes;
              oReturn.UnWork = "MIN";
            } else {
              iDuration = iHours;
              oReturn.UnWork = "HUR";
            }
          } else {
            iDuration = iDays;
            oReturn.UnWork = "DAY";
          }

          oReturn.ActWork = Math.round(iDuration);

          return oReturn;
        },

        _calcExecStartFin: function (sActWork, sUnWork) {
          var sUnWorkToAdd = "",
            oMoStart = new moment(),
            oMoFin = null,
            oReturn = {
              ExecStart: "",
              ExecFin: "",
            };

          switch (sUnWork) {
            case "DAY":
              sUnWorkToAdd = "d";
              break;
            case "HUR" || "HR":
              sUnWorkToAdd = "h";
              break;
            case "MIN":
              sUnWorkToAdd = "m";
          }

          oMoFin = new moment().add(Number(sActWork), sUnWorkToAdd);

          oReturn.ExecStart = oMoStart.format("YYYY-MM-DD HH:mm:ss");
          oReturn.ExecFin = oMoFin.format("YYYY-MM-DD HH:mm:ss");

          return oReturn;
        },

        _defaultNewConf: function (
          sAufnr,
          sVornr,
          sSubActivity,
          sUnWork,
          sWorkCntr,
          sConfText,
          sOrderDescription,
          sOperationDescription,
          sParentHandle,
          sNotifHandle,
          bSplit,
          bFromOrderHeader,
          sPlant,
          bFromOrder,
          sMnWkCtr,
          controlKey
        ) {
          var d = $.Deferred(),
            oSharedModel = this.getSharedModel(),
            oNewConfModel = this.getView().getModel("newConf"),
            sUUID = this.getHelper().getUUID();

          oNewConfModel.setProperty("/Handle", sUUID);
          oNewConfModel.setProperty("/IsFinished", false);

          $.when(this.getDBService().getSAPSettings()).done(
            $.proxy(function (_oSapSettings) {
              //	oNewConfModel.setProperty("/WorkCntr", _oSapSettings.ARBPL);

              if (sAufnr) {
                oNewConfModel.setProperty("/Aufnr", sAufnr);
              }

              if (sVornr) {
                oNewConfModel.setProperty("/Vornr", sVornr);
              }

              if (sSubActivity) {
                oNewConfModel.setProperty("/SubActivity", sSubActivity);
              }

              if (sUnWork) {
                oNewConfModel.setProperty("/UnWork", sUnWork);
              }

              // if (sWorkCntr) {
              // 	oNewConfModel.setProperty("/WorkCntr", sWorkCntr);
              // }

              if (sMnWkCtr) {
                oNewConfModel.setProperty("/MnWorkCntr", sMnWkCtr);
              } else {
                oNewConfModel.setProperty("/MnWorkCntr", _oSapSettings.ARBPL);
              }

              if (sConfText) {
                oNewConfModel.setProperty("/Prevlongtext", sConfText);
              }

              if (sOrderDescription) {
                oNewConfModel.setProperty(
                  "/OrderDescription",
                  sOrderDescription
                );
              }

              if (sOperationDescription) {
                oNewConfModel.setProperty(
                  "/OperationDescription",
                  sOperationDescription
                );
              }

              if (sParentHandle) {
                oNewConfModel.setProperty("/ParentHndl", sParentHandle);
              }

              if (sNotifHandle) {
                oNewConfModel.setProperty("/NotifHandle", sNotifHandle);
              }

              if (bSplit) {
                oNewConfModel.setProperty("/Split", bSplit);
              } else {
                oNewConfModel.setProperty("/Split", false);
              }

              // test
              // oNewConfModel.setProperty("/FinConf", false);

              if (bFromOrderHeader) {
                oNewConfModel.setProperty("/FromOrderHeader", bFromOrderHeader);
              } else {
                oNewConfModel.setProperty("/FromOrderHeader", false);
              }

              if (bFromOrder) {
                oNewConfModel.setProperty("/FromOrder", bFromOrder);
              } else {
                oNewConfModel.setProperty("/FromOrder", false);
              }
              if (sPlant) {
                oNewConfModel.setProperty("/Plant", sPlant.toString());
              } else if (_oSapSettings.ISTWERK) {
                oNewConfModel.setProperty(
                  "/Plant",
                  _oSapSettings.ISTWERK.toString()
                );
              } else {
                oNewConfModel.setProperty(
                  "/Plant",
                  _oSapSettings.SWERK.toString()
                );
              }
              if (!oNewConfModel.getProperty("/PersNo")) {
                if (oSharedModel.getProperty("/ParticipantSet").length === 1) {
                  oNewConfModel.setProperty(
                    "/PersNo",
                    oSharedModel.getProperty("/ParticipantSet")[0].sKey
                  );
                  oNewConfModel.setProperty("/ExecutantCnt", 1);
                } else {
                  if (
                    this.getSharedModel().getProperty(
                      "/sapSettings/persNoNotRequired"
                    ) === true
                  ) {
                    oNewConfModel.setProperty("/ExecutantCnt", 1);
                  } else {
                    oNewConfModel.setProperty("/ExecutantCnt", 0);
                  }
                }
              }

              let participants = oSharedModel.getProperty("/ParticipantSet"),
                user = _.find(participants, {
                  sKey: this.getSharedModel()
                    .getProperty("/sapSettings/sapUser")
                    .toString()
                    .padStart(8, "0"),
                });
              if (controlKey === "PMEX" && user && user.lifnr === false) {
                oNewConfModel.setProperty("/WorkCntr", sWorkCntr);
              } else if (_oSapSettings.ARBPL) {
                oNewConfModel.setProperty("/WorkCntr", _oSapSettings.ARBPL);
              } else if (sMnWkCtr) {
                oNewConfModel.setProperty("/WorkCntr", sMnWkCtr);
              } else if (sWorkCntr) {
                oNewConfModel.setProperty("/WorkCntr", sWorkCntr);
              }

              d.resolve();
            }, this)
          );

          return d.promise();
        },

        _getConfirmationsFromDb: function () {
          $.when(
            this.getDBService().getEntitySet("Confirmation"),
            this.getDBService().getEntitySet("Participant"),
            this.getDBService().getEntitySet("PMOrder"),
            this.getDBService().getEntitySet("Operation")
          )
            .done(
              jQuery.proxy(function (
                oData,
                oParticipants,
                oOrders,
                oOperations
              ) {
                let aLocalConfirmationSet = this.getHelper().rowsToArray(oData),
                  aLocalOrderSet = this.getHelper().rowsToArray(oOrders),
                  aLocalOperationSet =
                    this.getHelper().rowsToArray(oOperations);
                this.onGetConfirmation(
                  aLocalConfirmationSet,
                  aLocalOrderSet,
                  aLocalOperationSet,
                  oParticipants
                );
              },
              this)
            )
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        _manualCreateConfirmation: function (bValidate) {
          var oConfirmation = this.getView()
              .getModel("newConf")
              .getProperty("/"),
            oValidation = null,
            sIncFields = "",
            oPValidation = null;

          if (oConfirmation) {
            oValidation = this.getValidator().validateConfirmation(
              oConfirmation,
              this.getSharedModel(),
              bValidate
            );
            // if(this.getSharedModel().getProperty("/publicRelease")){
            // 	oPValidation = this.getValidator().validatePublicConfirmation(oConfirmation, this.getSharedModel(),this.getModel('local'));
            // }
            // if(oPValidation && oPValidation.isValid === false){
            // 	if(this.getSharedModel().getProperty('/sapSettings/TrCheckError')||oPValidation.isImportant){
            // 		if((this.bfromConfirmOrderlist!=="true" || this.bfromConfirmOrderlist!==true) && this.bFromOrderList){
            // 			this.getRouter().navTo("ordersMaster");
            // 		}
            // 		MBox.error(oPValidation.sMessage);
            // 		this.getView().getModel("newConf").setProperty('/',{});
            // 		return;
            // 	}else{
            // 		MBox.warning(oPValidation.sMessage);
            // 	}

            // }

            if ((oValidation && oValidation.isValid) || bValidate === false) {
              // $.when(this.getDBService().insertObject("Confirmation", oConfirmation))
              // .done(jQuery.proxy(function (res) {
              this.getView().getModel("newConf").setProperty("/", {});
              this.onConfirmationCreated(null, oConfirmation, bValidate);
              // }, this));
            } else {
              for (var sField in oValidation.aFields) {
                if (sIncFields === "") {
                  sIncFields += this.getText(oValidation.aFields[sField]);
                } else {
                  sIncFields +=
                    ", " + this.getText(oValidation.aFields[sField]);
                }
              }
              MBox.error(this.getText(oValidation.sMessage, sIncFields));
            }
          }
        },

        _setParticipantSet: function (oParticipantsDb) {
          var aParticipants = [];

          for (var y = 0; y < oParticipantsDb.rows.length; y++) {
            var sKey = "",
              sText = "",
              sName = "",
              lifnr = false,
              bPernr = false;

            if (oParticipantsDb.rows.item(y).Pernr) {
              sKey = oParticipantsDb.rows.item(y).Pernr;
              sText = oParticipantsDb.rows.item(y).Pernr;
              sName = oParticipantsDb.rows.item(y).Ename;
              if (oParticipantsDb.rows.item(y).Lifnr) {
                lifnr = true; //external
              }

              bPernr = true;

              aParticipants.push({
                sKey: sKey,
                sText: sText,
                sName: sName,
                bPernr: bPernr,
                lifnr: lifnr,
              });
            } else {
              sKey = oParticipantsDb.rows.item(y).Arbpl;
              sText = oParticipantsDb.rows.item(y).Arbpl;
              bPernr = false;

              aParticipants.push({
                sKey: sKey,
                sText: sText,
                bPernr: bPernr,
                lifnr: lifnr,
              });
            }
          }
          aParticipants = _.sortBy(aParticipants, ["sName", "sKey"]);
          this.getSharedModel().setProperty("/ParticipantSet", aParticipants);
        },

        _sortConfirmations: function (aConfirmations) {
          var _aTmp = aConfirmations;

          _aTmp.map(function (oItem) {
            var _oItem = oItem;

            if (oItem.ExecStart) {
              _oItem.ExecStart = new moment(oItem.ExecStart).toDate();
            } else {
              _oItem.ExecStart = null;
            }

            if (oItem.ExecFin) {
              _oItem.ExecFin = new moment(oItem.ExecFin).toDate();
            } else {
              _oItem.ExecFin = null;
            }

            return _oItem;
          });

          _aTmp = _.sortBy(_aTmp, ["Aufnr", "ExecStart", "ExecFin"]);

          _aTmp.map(function (oItem) {
            var _oItem = oItem;

            if (oItem.ExecStart && typeof oItem.ExecStart === "object") {
              _oItem.ExecStart = new moment(oItem.ExecStart).format(
                "YYYY-MM-DD HH:mm:ss"
              );
            } else {
              _oItem.ExecStart = null;
            }

            if (oItem.ExecFin && typeof oItem.ExecFin === "object") {
              _oItem.ExecFin = new moment(oItem.ExecFin).format(
                "YYYY-MM-DD HH:mm:ss"
              );
            } else {
              _oItem.ExecFin = null;
            }

            return _oItem;
          });

          return _aTmp;
        },

        updateTreeTable: function (first) {
          var oPromOrders = this.getDBService().getEntitySet("PMOrder"),
            oPromOperations = this.getDBService().getEntitySet("Operation"),
            oPromConfirmations =
              this.getDBService().getEntitySet("Confirmation"),
            oPromParticipants = this.getDBService().getEntitySet("Participant"),
            oPromNotification =
              this.getDBService().getEntitySet("PMNotification"),
            oPromComponents = this.getDBService().getEntitySet("Component"),
            oPromPRT = this.getDBService().getEntitySet("PRT"),
            d = $.Deferred();

          $.when(
            oPromOrders,
            oPromOperations,
            oPromConfirmations,
            oPromParticipants,
            oPromNotification,
            oPromComponents,
            oPromPRT
          )
            .done(
              jQuery.proxy(function (
                oDataOrder,
                oDataOperation,
                oConfirmations,
                oParticipants,
                oNotification,
                oDataComponent,
                oDataPRT
              ) {
                var oLocalModel = this.getView().getModel("local"),
                  aOrderSet = this.getHelper().rowsToArray(oDataOrder),
                  aOperationSet = this.getHelper().rowsToArray(oDataOperation),
                  aConfirmationSet =
                    this.getHelper().rowsToArray(oConfirmations),
                  oParticipantsSet =
                    this.getHelper().rowsToArray(oParticipants),
                  oNotificationSet =
                    this.getHelper().rowsToArray(oNotification),
                  aComponentSet = this.getHelper().rowsToArray(oDataComponent),
                  aPRTSet = this.getHelper().rowsToArray(oDataPRT);

                if (first)
                  this.onGetConfirmation(
                    aConfirmationSet,
                    aOrderSet,
                    aOperationSet,
                    oParticipants
                  );
                _.each(aConfirmationSet, function (oConf) {
                  for (var sProp in oConf) {
                    if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                      oConf[sProp] = oConf[sProp] === "true" ? true : false;
                    }
                  }
                });

                if (!oLocalModel.getProperty("/PMOrderSetDataWithConf")) {
                  oLocalModel.setProperty("/PMOrderSetDataWithConf", []);
                }
                if (!oLocalModel.getProperty("/PMNotificationSet")) {
                  oLocalModel.setProperty(
                    "/PMNotificationSet",
                    oNotificationSet
                  );
                }
                aConfirmationSet =
                  this._determineColorsConfirmation(aConfirmationSet);

                aOrderSet = this._linkforTreeTable(
                  aOrderSet,
                  aOperationSet,
                  aConfirmationSet,
                  oParticipantsSet,
                  oNotificationSet,
                  aComponentSet,
                  aPRTSet
                );
                //	aOrderSet.push([]);
                this.PMOrderSetDataWithConf = aOrderSet;
                oLocalModel.setProperty("/PMOrderSetDataWithConf", aOrderSet);

                d.resolve();
              },
              this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("OrderDBRetrieveFailed"));
                d.reject();
              }, this)
            );
          return d.promise();
        },

        _linkforTreeTable: function (
          aOrders,
          aOperations,
          aConfirmations,
          oParticipantsSet,
          oNotifications,
          aComponents,
          aPRTs
        ) {
          var _aOrders = aOrders,
            _aOperations = aOperations,
            _oNotifications = oNotifications;
          aConfirmations.forEach(function (oConf) {
            oConf.multiplePers = true;
            if (oConf.PersNo.split(",").length > 1) {
              oConf.PersName = "";
              oConf.PersNo.split(",").forEach(function (Persno) {
                for (var i = 0; i < oParticipantsSet.length; i++) {
                  if (Persno === oParticipantsSet[i].Pernr) {
                    oConf.PersName =
                      oConf.PersName + oParticipantsSet[i].Sname + ",";
                  }
                }
              });
              oConf.multiplePers = false;
              oConf.PersName = oConf.PersName.slice(0, -1);
            } else {
              for (var i = 0; i < oParticipantsSet.length; i++) {
                if (oConf.PersNo === oParticipantsSet[i].Pernr) {
                  oConf.PersName = oParticipantsSet[i].Sname;
                }
              }
            }
          });
          let newOrders = this._addNonExistingOrderConf(aConfirmations);
          _aOperations = _aOperations.concat(newOrders[1]);
          _aOrders = _aOrders.concat(newOrders[0]);
          _aOperations.forEach(
            jQuery.proxy(function (oOperation) {
              var Confirm = _.filter(aConfirmations, {
                Aufnr: oOperation.Orderid,
                Vornr: oOperation.Activity,
                SubActivity: oOperation.SubActivity,
                Split: false,
              });
              oOperation.Confirm = _.sortBy(Confirm, "ExecStart").reverse();
              if (oOperation.Confirm.length > 0) {
                oOperation.Color = this._determineColors(oOperation);
              } else if (oOperation.Activity) {
                var oCheckOperation = this.getHelper().checkOperationValid(
                  oOperation.Orderid,
                  oOperation
                );
                var cnfOperation = oOperation.ConfFinal === "X";
                if (
                  oCheckOperation.ControlKeyIsValid === false ||
                  oCheckOperation.PMEXValid === false ||
                  cnfOperation === true
                ) {
                  oOperation.Color = "red";
                } else {
                  oOperation.Color = "default";
                }
              }
              oOperation.NavComponent = _.filter(aComponents, {
                Orderid: oOperation.Orderid,
                Activity: oOperation.Activity,
              });

              oOperation.NavPRT = _.filter(aPRTs, {
                Orderid: oOperation.Orderid,
                Activity: oOperation.Activity,
              });
            }, this)
          );

          _aOrders.forEach(
            jQuery.proxy(function (oOrder) {
              var Confirm = _.filter(aConfirmations, {
                Aufnr: oOrder.Orderid,
                Vornr: "",
                Split: false,
              });
              oOrder.Confirm = _.sortBy(Confirm, "ExecStart").reverse();
              if (oOrder.Confirm.length > 0) {
                oOrder.Color = this._determineColors(oOrder);
              } else oOrder.Color = "default";
              oOrder.NavOperation = _.filter(_aOperations, {
                Orderid: oOrder.Orderid,
              });
              oOrder.NavLevelTree = [];
            }, this)
          );

          _oNotifications.forEach(
            jQuery.proxy(function (oNotif) {
              oNotif.Confirm = [];
              if (oNotif.Handle) {
                var oCorrespondingConf = aConfirmations.filter(function (
                  oConf
                ) {
                  return (
                    oNotif.Handle === oConf.NotifHandle &&
                    oNotif.Qmnum === "" &&
                    oConf.Split === false
                  );
                });
              }
              if (oCorrespondingConf) {
                oNotif.Confirm = _.sortBy(
                  oCorrespondingConf,
                  "ExecStart"
                ).reverse();
              }
              oNotif.NotifTypeText = this.getNotifTypeText(oNotif.Qmart);
            }, this)
          );
          _oNotifications = _.filter(oNotifications, function (oNotif) {
            return oNotif.Confirm.length;
          });
          _oNotifications.forEach(
            jQuery.proxy(function (notif) {
              notif.Color = this._determineColors(notif);
              _aOrders.unshift(notif);
            }, this)
          );
          return _aOrders;
        },

        _determineColorsConfirmation: function (aConfirmationSet) {
          _.each(
            aConfirmationSet,
            jQuery.proxy(function (aConf) {
              if (aConf.FinConf) {
                if (aConf.IsFinished) {
                  aConf.Color = "green";
                } else {
                  aConf.Color = "purple";
                }
              } else {
                if (aConf.IsFinished) {
                  aConf.Color = "blue";
                } else {
                  aConf.Color = "orange";
                }
              }
            }, this)
          );

          return aConfirmationSet;
        },

        _determineColors: function (aSet) {
          var colour = ["default", "orange", "blue", "purple", "green"];
          var ColourKey = 5,
            ColourIndex;
          aSet.Confirm.forEach(
            jQuery.proxy(function (oConf) {
              switch (oConf.Color) {
                case "orange":
                  ColourIndex = 1;
                  break;
                case "blue":
                  ColourIndex = 2;
                  break;
                case "purple":
                  ColourIndex = 3;
                  break;
                case "green":
                  ColourIndex = 4;
                  break;
                default:
                  ColourIndex = 0;
                  break;
              }
              if (ColourIndex) {
                ColourKey = ColourKey >= ColourIndex ? ColourIndex : ColourKey;
              }
            })
          );
          if (ColourIndex === 0 && ColourKey === 5) {
            return colour[ColourIndex];
          } else {
            return colour[ColourKey];
          }
        },

        getNotifTypeText: function (qmart) {
          if (qmart) {
            var sQmart = _.filter(
              this.getSharedModel().getProperty("/vh/Qmart"),
              {
                Key: qmart,
              }
            );
            // var sQmcod = _.filter(this.getSharedModel().getProperty("/vh/Catalog"),{
            // 	Qmart:qmart,
            // 	Code:qmcod
            // });
            if (sQmart.length > 0) return this.getText(sQmart[0].Description);
          }
        },

        onOpenViewSettings: function () {
          this.getFunctLocName(this.PMOrderSetDataWithConf);
        },

        onConfirmViewSettingsDialog: function (oEvent) {
          var aFilterItems = oEvent.getParameters().filterItems,
            aFilters = [],
            aCaptions = [];

          // update filter state:
          // combine the filter array and the filter string
          aFilterItems.forEach(function (oItem) {
            switch (oItem.getKey()) {
              case "FunctLoc":
                aFilters.push(
                  new Filter(
                    oItem.getKey(),
                    FilterOperator.Contains,
                    oItem.getText()
                  )
                );
                break;
              case "ShortText":
                aFilters.push(
                  new Filter(
                    oItem.getKey(),
                    FilterOperator.Contains,
                    oItem.getText()
                  )
                );
                break;
              // case "FinishedFinConf":
              // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "green"));
              // 	break;
              // case "FinConf":
              // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "purple"));
              // 	break;
              // case "IsFinished":
              // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "blue"));
              // 	break;
              // case "Ongoing":
              // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "orange"));
              // 	break;
              // case "NotStarted":
              // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "default"));
              default:
                break;
            }
          });
          let selectedPathsCS = oEvent
            .getSource()
            .getFilterItems()[0]
            .getCustomControl()
            .getSelectedContextPaths();
          var colors = "";
          _.forEach(
            selectedPathsCS,
            function (path) {
              colors =
                colors +
                "," +
                this.getView()
                  .getModel("filters")
                  .getProperty(path + "/color");
            }.bind(this)
          );
          if (colors)
            aFilters.push(new Filter("Color", FilterOperator.EQ, colors));
          if (this.filtersAdded && this.filtersAdded["Equipment"]) {
            aFilters.push(this.filtersAdded["Equipment"]);
          }
          if (this.filtersAdded && this.filtersAdded["FunctLoc"]) {
            aFilters.push(this.filtersAdded["FunctLoc"]);
          }
          this.appliedFilters = aFilters;
          this._applyFilterSearch(aFilters);
        },

        _createFilterModels: function (data) {
          // Functional location
          var filterFunctLoc = _.map(
            data,
            jQuery.proxy(function (row) {
              // if(this.findConfirmation(row).length){
              if (row.FunctLoc) {
                return { FunctLoc: row.FunctLoc, FunctionLocName: row.Pltxt };
              } else if (row.Tplnr) {
                return {
                  FunctLoc: row.Tplnr,
                  FunctionLocName: row.FunctionLocName,
                };
              } else return { FunctLoc: "" };
            }, this)
          );
          filterFunctLoc = _.remove(filterFunctLoc, function (row) {
            return row.FunctLoc !== "";
          });
          var uniqueFunctLocArray = _.uniqBy(filterFunctLoc, function (row) {
            if (row.FunctLoc) {
              return row.FunctLoc;
            }
          });
          // Order short text

          var filterShortText = _.map(
            data,
            jQuery.proxy(function (row) {
              // if(this.findConfirmation(row).length){
              if (row.ShortText) {
                return { ShortText: row.ShortText };
              } else if (row.Qmtxt) {
                return { ShortText: row.Qmtxt };
              } else return { ShortText: "" };
            }, this)
          );

          filterShortText = _.remove(filterShortText, function (row) {
            return row.ShortText !== "";
          });

          var uniqueShortTextArray = _.uniqBy(filterShortText, function (row) {
            if (row.ShortText) {
              return row.ShortText;
            }
            if (row.Qmtxt) {
              return row.Qmtxt;
            }
          });

          // Equipment
          var filterEQ = _.map(
            data,
            jQuery.proxy(function (row) {
              // if(this.findConfirmation(row).length){
              if (row.Equipment) {
                return { Equipment: row.Equipment, Eqktx: row.Eqktx };
              } else if (row.Equnr) {
                return { Equipment: row.Equnr, Eqktx: row.Eqktx };
              } else return { Equipment: "" };
            }, this)
          );
          filterEQ = _.remove(filterEQ, function (row) {
            return row && row.Equipment !== "";
          });
          var uniqueEQArray = _.uniqBy(filterEQ, function (row) {
            if (row.Equipment) {
              return row.Equipment;
            }
          });
          this.getView()
            .getModel("filters")
            .setProperty("/filterEqpmt", uniqueEQArray);
          this.getView()
            .getModel("filters")
            .setProperty("/filterShortText", uniqueShortTextArray);
          this.getView()
            .getModel("filters")
            .setProperty("/filterFunctLoc", uniqueFunctLocArray);
          if (this._getViewSettingsDialog()) {
            var confStatus = [
              {
                text: this.getText("FinishedFinalConfirmation"),
                color: "green",
              },
              { text: this.getText("FinalConfirmation"), color: "purple" },
              { text: this.getText("FinishedConfirmation"), color: "blue" },
              { text: this.getText("ConfirmationOngoing"), color: "orange" },
              {
                text: this.getText("ConfirmationNotStarted"),
                color: "default",
              },
            ];
            this.getView()
              .getModel("filters")
              .setProperty("/confStatus", confStatus);
          }
        },

        clearFilters: function () {
          var aFilters = [],
            aCaptions = [];
          this.filtersAdded = {
            FunctLoc: null,
            Equipment: null,
          };
          this.listItem = {
            FunctLoc: null,
            Equipment: null,
          };
          this.appliedFilters = undefined;
          if (sap.ui.getCore().byId("ViewSettingsDialog--flocList"))
            sap.ui
              .getCore()
              .byId("ViewSettingsDialog--flocList")
              .removeSelections(true);
          if (sap.ui.getCore().byId("ViewSettingsDialog--eqpmtList"))
            sap.ui
              .getCore()
              .byId("ViewSettingsDialog--eqpmtList")
              .removeSelections(true);
          if (sap.ui.getCore().byId("ViewSettingsDialog--colorList"))
            sap.ui
              .getCore()
              .byId("ViewSettingsDialog--colorList")
              .removeSelections(true);
          if (sap.ui.getCore().byId("ViewSettingsDialog"))
            sap.ui
              .getCore()
              .byId("ViewSettingsDialog")
              .getFilterItems()[0]
              .getCustomControl()
              .removeSelections();
          this._applyFilterSearch(aFilters);
        },

        _applyFilterSearch: function (aFilters) {
          ///	var aFilteredList=this.PMOrderSetDataWithConf;
          if (!this.PMOrderSetDataWithConf) {
            return;
          }
          var aFilteredList = JSON.parse(
            JSON.stringify(this.PMOrderSetDataWithConf)
          );
          var aData = JSON.parse(JSON.stringify(this.PMOrderSetDataWithConf));
          var aOperationFilters = [];
          if (aFilters.length > 0) {
            this.getView()
              .byId("filter")
              .setAggregation()
              .setType("Emphasized");
          } else {
            this.getView().byId("filter").setAggregation().setType("Default");
          }
          //this.getView().byId("orderMasterTreeTable").getBinding("rows").filter(aFilters, "Application");
          _.each(
            aFilters,
            jQuery.proxy(function (oFilter) {
              if (oFilter.sPath === "Color") {
                aData = _.filter(
                  aData,
                  jQuery.proxy(function (oFiltered) {
                    var header = false;
                    if (
                      this.confirmationFilterCheck(
                        oFiltered.Confirm,
                        oFilter.oValue1
                      )
                    ) {
                      header = true;
                      //return true;
                    }
                    if (oFiltered.Confirm.length > 0 && !header) {
                      oFiltered.Confirm = [];
                    }
                    if (
                      oFiltered.NavOperation &&
                      oFiltered.NavOperation.length
                    ) {
                      var value = _.filter(
                        oFiltered.NavOperation,
                        jQuery.proxy(function (oOperation) {
                          if (
                            this.confirmationFilterCheck(
                              oOperation.Confirm,
                              oFilter.oValue1
                            )
                          ) {
                            return true;
                          }
                        }, this)
                      );
                      oFiltered.NavOperation = value;
                      return header || value.length > 0;
                    }
                    return header;
                  }, this)
                );
                for (var q = 0; q < oFilter.oValue1.split(",").length; q++) {
                  if (oFilter.oValue1.split(",")[q] === "default") {
                    _.each(
                      aFilteredList,
                      jQuery.proxy(function (oFiltered) {
                        if (oFiltered.Color === "default") {
                          var oDefaultOperationFound = _.find(
                            oFiltered.NavOperation,
                            jQuery.proxy(function (oOperation) {
                              return oOperation.Color === "default";
                            }, this)
                          );
                          // aOperationFilters.push(oDefaultOperationFound);
                          if (oDefaultOperationFound) {
                            aData.push(oFiltered);
                          }
                        }
                      }, this)
                    );
                  }
                }
              } else {
                var atplnr = "Tplnr",
                  aqmtxt = "Qmtxt";
                aData = _.filter(
                  aData,
                  jQuery.proxy(function (row) {
                    // if(oFilter.oValue1&&this.findConfirmation(row).length){
                    if (oFilter.oValue1) {
                      return (
                        row[oFilter.sPath] === oFilter.oValue1 ||
                        row[atplnr] === oFilter.oValue1 ||
                        row[aqmtxt] === oFilter.oValue1
                      );
                    }
                  }, this)
                );
              }
            }, this)
          );
          this.getModel("local").setProperty("/PMOrderSetDataWithConf", aData);
        },

        findConfirmation: function (row) {
          if (row.Confirm && row.Confirm.length) {
            return row.Confirm;
          } else {
            var ChildConfirmation = _.filter(
              row.NavOperation,
              jQuery.proxy(function (oper) {
                return oper.Confirm.length > 0;
              }, this)
            );
            return ChildConfirmation;
          }
        },

        getFunctLocName: function (oData) {
          $.when(this.getDBService().getEntitySet("TechnicalObject")).done(
            jQuery.proxy(function (techObj) {
              var techObjSet = this.getHelper().rowsToArray(techObj);

              oData.map(
                jQuery.proxy(function (row) {
                  if (row.Qmart) {
                    //FollowUpNotifs
                    if (row.OrderHandle) {
                      var FunctLocData = _.filter(
                        oData,
                        jQuery.proxy(function (order) {
                          return row.OrderHandle === order.Orderid;
                        }, this)
                      );
                      if (
                        FunctLocData.length &&
                        row.Tplnr === FunctLocData[0].FunctLoc
                      ) {
                        row.FunctionLocName = FunctLocData[0].Pltxt;
                      } else {
                        let operationData = _.filter(
                          FunctLocData[0].NavOperation,
                          jQuery.proxy(function (operation) {
                            return row.Tplnr === operation.FunctLoc;
                          }, this)
                        );
                        if (operationData.length)
                          row.FunctionLocName = operationData[0].Pltxt;
                      }
                      if (
                        FunctLocData.length &&
                        row.Equnr === FunctLocData[0].Equipment
                      ) {
                        row.Eqktx = FunctLocData[0].Eqktx;
                      } else {
                        let operationData = _.filter(
                          operationData[0].NavOperation,
                          jQuery.proxy(function (operation) {
                            return row.Equnr === operation.Equipment;
                          }, this)
                        );
                        if (operationData.length)
                          row.Eqktx = operationData[0].Eqktx;
                      }
                      return row;
                    } else {
                      FunctLocData = _.filter(
                        techObjSet,
                        jQuery.proxy(function (oTech) {
                          return row.Tplnr === oTech.Tplnr;
                        }, this)
                      );
                      if (FunctLocData.length > 0)
                        row.FunctionLocName = FunctLocData[0].Ktx01;
                      let eqData = _.filter(
                        techObjSet,
                        jQuery.proxy(function (oTech) {
                          return row.Equnr === oTech.Equnr;
                        }, this)
                      );
                      if (eqData.length > 0) row.Eqktx = eqData[0].Ktx01;
                      return row;
                    }
                  }
                }, this)
              );
              this._createFilterModels(oData);
              this._getViewSettingsDialog().open();
            }, this)
          );
        },

        onSelectionChange: function (oEvent) {
          let filter = oEvent.getSource().getId().includes("flocList")
            ? "FunctLoc"
            : "Equipment";
          this.filtersAdded[filter] = new Filter(
            filter,
            FilterOperator.Contains,
            oEvent.getParameter("listItem").getProperty("title")
          );
          this.listItem[filter] = oEvent.getSource().getSelectedItem();
          sap.ui
            .getCore()
            .byId("ViewSettingsDialog--ViewSettingsDialog")
            ._detailResetButton.setEnabled(true);
        },

        _getViewSettingsDialog: function () {
          if (!this.getOwnerComponent().oViewSettingsDialog) {
            this.getOwnerComponent().oViewSettingsDialog = sap.ui.xmlfragment(
              "ViewSettingsDialog",
              "mobilework.view.fragments.ViewSettingsDialog",
              this
            );
            this.getView().addDependent(
              this.getOwnerComponent().oViewSettingsDialog
            );
          }
          return this.getOwnerComponent().oViewSettingsDialog;
        },

        onFinished: function (oEvent) {
          let filter = oEvent.getSource().getId().includes("flocList")
            ? "FunctLoc"
            : "Equipment";
          var oList = oEvent.getSource();
          oList.setSelectedItem(this.listItem[filter]);
          if (this.listItem && this.listItem.length && this.listItem[filter])
            this.filtersAdded[filter] = new Filter(
              filter,
              FilterOperator.Contains,
              this.listItem.getProperty("title")
            );
          sap.ui
            .getCore()
            .byId("ViewSettingsDialog--ViewSettingsDialog")
            ._detailResetButton.setEnabled(true);
        },

        confirmationFilterCheck: function (aConfirmation, oValue) {
          var aFilter = _.filter(aConfirmation, function (aConf) {
            return aConf.Color && oValue.includes(aConf.Color);
          });
          if (aFilter.length) {
            return true;
          } else return false;
        },

        onCollapseTreetable: function () {
          var oTreeTable = this.getView().byId("confirmationTreeTable");
          oTreeTable.collapseAll();
        },

        onExpandTreetable: function () {
          var oTreeTable = this.getView().byId("confirmationTreeTable");
          oTreeTable.expandToLevel(2);
        },

        onLegendPress: function () {
          var oData = {
            ColorData: [
              {
                text: this.getText("ConfirmationOngoing"),
                status: "orange",
              },
              {
                text: this.getText("FinishedConfirmation"),
                status: "blue",
              },
              {
                text: this.getText("FinalConfirmation"),
                status: "purple",
              },
              {
                text: this.getText("FinishedFinalConfirmation"),
                status: "green",
              },
              {
                text: this.getText("ConfirmationNotPossible"),
                status: "red",
              },
            ],
          };
          var oColorJsonModel = new JSONModel(oData);
          this.getView().setModel(oColorJsonModel, "colorModel");
          this._getLegendDialog().open();
        },

        onLegendDialogColse: function () {
          this._getLegendDialog().close();
        },

        _getLegendDialog: function () {
          if (!this.getOwnerComponent().oLegendDialog) {
            this.getOwnerComponent().oLegendDialog = sap.ui.xmlfragment(
              "LegendDialog",
              "mobilework.view.fragments.LegendDialog",
              this
            );
            this.getView().addDependent(this.getOwnerComponent().oLegendDialog);
          }
          return this.getOwnerComponent().oLegendDialog;
        },

        onCreateFromActivityPress: function (oEvent) {
          var oBindingContext = oEvent
            .getSource()
            .getParent()
            .getBindingContext("local");
          var sPath = oBindingContext.sPath;
          var oSelectedActivity = this.getModel("local").getProperty(sPath);
          var sSelectedActivity = oSelectedActivity.Activity,
            sSelectedSubActivity = oSelectedActivity.SubActivity;
          var oCorrespondingOrderPath = sPath.split("/NavOperation")[0];
          var oCorrespondingOrder = this.getModel("local").getProperty(
            oCorrespondingOrderPath
          );

          if (sSelectedActivity) {
            var oView = this.getView().setBusy(true),
              oPromConfirmations =
                this.getDBService().getEntitySet("Confirmation"),
              sAufnr = oCorrespondingOrder.Orderid,
              aOperations = oCorrespondingOrder.NavOperation;

            $.when(oPromConfirmations).done(
              jQuery.proxy(function (oConfirmations) {
                var aConfirmations =
                    this.getHelper().rowsToArray(oConfirmations),
                  oOperation = _.find(aOperations, {
                    Activity: sSelectedActivity,
                    SubActivity: sSelectedSubActivity,
                  });

                _.each(aConfirmations, function (oConf) {
                  for (var sProp in oConf) {
                    if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                      oConf[sProp] = oConf[sProp] === "true" ? true : false;
                    }
                  }
                });

                oView.setBusy(false);

                if (
                  !this.getHelper().checkFinalConfExists(
                    aConfirmations,
                    sAufnr,
                    oOperation.Activity,
                    sSelectedSubActivity
                  )
                ) {
                  var oCheckOperation = this.getHelper().checkOperationValid(
                    sAufnr,
                    oOperation
                  );
                  var cnfOperation = oOperation.ConfFinal === "X";
                  if (
                    oCheckOperation.ControlKeyIsValid === true &&
                    oCheckOperation.PMEXValid === true &&
                    cnfOperation === false
                  ) {
                    this.bfromConfirmOrderlist = true;
                    var oEventData = {
                      Aufnr: sAufnr,
                      WorkCntr: oOperation.WorkCntr,
                      Vornr: oOperation.Activity,
                      SubActivity: oOperation.SubActivity,
                      UnWork: oOperation.DurationNormalUnitIso,
                      Plant: oOperation.Plant,
                      ConfText: oOperation.ConfText,
                      ParentHandle: oOperation.Handle,
                      ControlKey: oOperation.ControlKey,
                    };
                    this.onFromOrderMatched(null, oEventData);
                  } else {
                    if (!oCheckOperation.ControlKeyIsValid === true) {
                      MBox.error(
                        this.getText("IncorrectControlKeyForConfCreation", [
                          oOperation.ControlKey,
                        ])
                      );
                    } else if (cnfOperation) {
                      MBox.error(this.getText("CNFOperation"));
                    } else {
                      MBox.error(this.getText("InvalidPMEXOperation"));
                    }
                  }
                } else {
                  if (
                    this.getHelper().checkFinalConfExistsOnOperation(
                      aConfirmations,
                      sAufnr,
                      oOperation.Activity,
                      sSelectedSubActivity
                    )
                  ) {
                    MBox.error(
                      this.getText("FinalConfirmationExistsOnOperation", [
                        sAufnr,
                        oOperation.Activity,
                      ])
                    );
                  } else {
                    MBox.error(
                      this.getText("FinalConfirmationExists", [sAufnr])
                    );
                  }
                }
              }, this)
            );
          } else {
            MBox.error(this.getText("SelectActivityFirst"));
          }
        },

        onCreateFromHeaderPress: function (oEvent) {
          var oView = this.getView().setBusy(true),
            oPromConfirmations = null,
            oBindingContext = oEvent
              .getSource()
              .getParent()
              .getBindingContext("local"),
            sAufnr = oBindingContext.getProperty("Orderid"),
            sMnWkCtr = oBindingContext.getProperty("MnWkCtr"),
            aOperations = oBindingContext.getProperty("NavOperation");

          // check if operations have same workcenter
          var sWorkCenter = aOperations[0].WorkCntr,
            aOperWorkCnt = _.filter(aOperations, {
              WorkCntr: sWorkCenter,
            });

          if (aOperations.length !== aOperWorkCnt.length) {
            oView.setBusy(false);
            MBox.error(this.getText("NotAllOperSameWorkCntr"));
          } else {
            oPromConfirmations =
              this.getDBService().getEntitySet("Confirmation");
            $.when(oPromConfirmations).done(
              jQuery.proxy(function (oConfirmations) {
                var aConfirmations =
                  this.getHelper().rowsToArray(oConfirmations);

                _.each(aConfirmations, function (oConf) {
                  for (var sProp in oConf) {
                    if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                      oConf[sProp] = oConf[sProp] === "true" ? true : false;
                    }
                  }
                });

                oView.setBusy(false);

                if (
                  !this.getHelper().checkFinalConfExists(aConfirmations, sAufnr)
                ) {
                  if (aOperations.length > 0) {
                    sMnWkCtr = aOperations[0].WorkCntr;
                  }

                  var oEventData = {
                    Aufnr: sAufnr,
                    WorkCntr: sMnWkCtr,
                  };
                  //For Navigating back to confirmation Master while creating confirmation on Confirmation OverView Screen
                  this.bfromConfirmOrderlist = true;
                  this.onFromOrderMatched(null, oEventData);
                } else {
                  MBox.error(this.getText("FinalConfirmationExists", [sAufnr]));
                }
              }, this)
            );
          }
        },

        onCreateConfPressNotif: function (oEvent) {
          var oBindingContext = oEvent
            .getSource()
            .getParent()
            .getBindingContext("local");
          var oNotification = oBindingContext.getProperty(
              oBindingContext.sPath
            ),
            sHandle = oNotification.Handle,
            MnWkCtr = oNotification.Arbpl
              ? oNotification.Arbpl
              : this.getSharedModel().getProperty("/sapSettings/GEWRK");
          if (!MnWkCtr) {
            MnWkCtr = this.getSharedModel().getProperty("/sapSettings/ARBPL");
          }
          var oEventData = {
            Handle: sHandle,
            WorkCntr: oNotification.Arbpl,
            MnWkCtr: MnWkCtr,
          };
          this.onFromNotifMatched(null, oEventData);
        },

        onSelectionChangeStatus: function () {
          sap.ui
            .getCore()
            .byId("ViewSettingsDialog--ViewSettingsDialog")
            ._detailResetButton.setEnabled(true);
        },

        onSort: function (oEvent) {
          var sorts = [],
            treetable = this.getView().byId("confirmationTreeTable");

          if (oEvent && oEvent.getSource()) {
            var sKey = oEvent.getSource().getSelectedItem().getKey();
          } else if (this.getSharedModel().getProperty("/sortKey")) {
            sKey = this.getSharedModel().getProperty("/sortKey");
          } else {
            sKey = "Default";
          }

          treetable.getBinding("rows").sort(null);

          if (sKey === "Default") {
            // sorts = this._createCustomSort();
            treetable.getBinding("rows").sort(null);
          } else if (sKey === "StartDateDt") {
            sorts.push(new Sorter(sKey, false));
            treetable.getBinding("rows").sort(sorts);
          } else if (sKey === "FunctLoc") {
            sorts.push(new Sorter(sKey, false));
            treetable.getBinding("rows").sort(sorts);
          }
        },

        onGetConfirmation: function (
          aLocalConfirmationSet,
          aLocalOrderSet,
          aLocalOperationSet,
          oParticipants
        ) {
          var oLocalModel = this.getView().getModel("local");
          if (!oLocalModel.getProperty("/ConfirmationSet")) {
            oLocalModel.setProperty("/ConfirmationSet", []);
          }

          aLocalConfirmationSet.forEach(function (oConf) {
            for (var sProp in oConf) {
              if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                oConf[sProp] = oConf[sProp] === "true";
              }
              if (
                (sProp === "IsFinished" ||
                  sProp === "FinConf" ||
                  sProp === "Split") &&
                oConf[sProp] === ""
              ) {
                oConf[sProp] = false;
              }
            }
            var oFoundOrder = _.find(
              aLocalOrderSet,
              jQuery.proxy(function (oOrder) {
                return oOrder.Orderid === oConf.Aufnr;
              }, this)
            );
            if (oFoundOrder) {
              oConf.OrderDescription = oFoundOrder.ShortText;
            } else {
              oConf.nonExistingOrder = oConf.NotifHandle ? false : true;
            }
            var oFoundOperation = _.find(
              aLocalOperationSet,
              jQuery.proxy(function (oOperation) {
                return (
                  oOperation.Activity === oConf.Vornr &&
                  oOperation.Handle === oConf.ParentHndl
                );
              }, this)
            );
            if (oFoundOperation) {
              oConf.OperationDescription = oFoundOperation.Description;
            }
          });
          oLocalModel.setProperty("/ConfirmationSet", aLocalConfirmationSet);
          this._setParticipantSet(oParticipants);
        },

        addNonExistingOrderConf: function (
          sChannelId,
          sEventId,
          aConfirmations
        ) {
          this._addNonExistingOrderConf(aConfirmations);
        },

        _addNonExistingOrderConf: function (aConfirmations) {
          const data = aConfirmations;
          const idNameMap = new Map();

          data.forEach((item) => {
            if (item.nonExistingOrder) {
              if (!idNameMap.has(item.Aufnr)) {
                idNameMap.set(item.Aufnr, new Set());
              }
              idNameMap.get(item.Aufnr).add(item.Vornr.toLowerCase());
            }
          });

          let orderset = [];
          let operationSet = [];

          idNameMap.forEach((opSet, Aufnr) => {
            const order = { Orderid: Aufnr, Activity: "", Deviceid: "device" };
            // const operation = Array.from(opSet).map((oper) => ({ Orderid: Aufnr, Activity: oper,SubActivity:'' }));
            const operation = Array.from(opSet)
              .filter((oper) => oper)
              .map((oper) => ({
                Orderid: Aufnr,
                Activity: oper,
                SubActivity: "",
              }));
            orderset.push(order);
            if (operation.length > 0)
              operationSet = operationSet.concat(operation);
          });
          this.getModel("local").setProperty("/nonExistingOrder", [
            orderset,
            operationSet,
          ]);
          return [orderset, operationSet];
        },

        doOnFromNotifMatched: function (sChannelId, sEventId, oEventData) {
          this.getView().getModel("newConf").setProperty("/", oEventData);
          this._manualCreateConfirmation(true);
        },

        // onToggleOpenState: function() {
        // 	this._fixTableScrollbarPosition();
        // },

        // _fixTableScrollbarPosition: function() {
        
        // 	let treeTable = this.getView().byId("confirmationTreeTable");
        // 	if (treeTable) {
        // 		if (treeTable.getColumns()[0].getWidth() === "30%") {
        // 			treeTable.getColumns()[0].setWidth("29%");
        // 		} else {
        // 			treeTable.getColumns()[0].setWidth("30%");
        // 		}
        // 	}

        // }
      }
    );
  }
);
