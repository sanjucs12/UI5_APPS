/*global Camera:true*/
/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
  ],
  function (Controller, MToast, MBox, Mo) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.confirmations.ConfirmationsDetail",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        _oPersonPopover: null,

        _oTimeDetailForm: null,

        _bFromOrderList: false,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ConfirmationsDetail
         */
        onInit: function () {
          this._initModels();

          this.getRouter()
            .getRoute("confirmationsDetail")
            .attachMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ConfirmationsDetail
         */
        onExit: function () {},

        onAfterRendering: function () {
          if (!this._oTimeDetailForm) {
            this._oTimeDetailForm = this.getView().byId(
              "confTimeTableDetailFrom"
            );
          }
        },

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        // When route is called, bind the confirmation ID to it
        onRouteMatched: function (oEvent) {
          //bind view
          var sID = oEvent.getParameter("arguments").ID,
            bFromOrder = oEvent.getParameter("arguments").FromOrder;
          this.bfromConfirmOrderlist =
            oEvent.getParameter("arguments").bfromConfirmOrderlist;
          this.FromNotif = oEvent.getParameter("arguments").FromNotif;

          //set connection property
          this.getConnection();

          this._getViewModel().setProperty("/ConfID", sID);

          //really shitty code to prevent bug where sometimes wrong fragment gets loaded into IconTabFilter "hint"
          this._getViewModel().setProperty("/tabKey", "photo");
          setTimeout(
            function () {
              var sBindingPath = "/ConfirmationSet/" + sID,
                oObject = this.getView()
                  .getModel("local")
                  .getProperty(sBindingPath);
              if (!oObject.Split) {
                this._getViewModel().setProperty("/tabKey", "hint");
              } else {
                this._getViewModel().setProperty("/tabKey", "time");

                var aPartic =
                    this.getSharedModel().getProperty("/ParticipantSet"),
                  aPersNo = this.getView().byId("persCombo").getSelectedKeys(),
                  aFinal = [];
                aPartic.forEach(function (oPartic) {
                  // if (aPersNo.indexOf(oPartic.sKey) !== -1) {
                  aFinal.push(oPartic);
                  // }
                });

                this._getViewModel().setProperty("/ParticipantSet", aFinal);
                if (this._oTimeDetailForm) {
                  this._oTimeDetailForm.unbindElement();
                  this._oTimeDetailForm.setVisible(false);
                }
              }

              var aSelected = this.getView()
                  .byId("persCombo")
                  .getSelectedItems(),
                sCurrPath = this.getView().getBindingContext("local").getPath();
              var sKeys = "";
              // var aKeys = [];
              _.each(aSelected, function (oSelected) {
                sKeys += oSelected.getProperty("key") + ",";
                // aKeys.push(oSelected.getProperty("key"));
              });

              sKeys = sKeys.slice(0, -1);

              //this.getView().getModel("local").setProperty(sCurrPath + "/PersNo", sKeys);
              //this.getView().getModel("local").setProperty(sCurrPath + "/ExecutantCnt", aSelected.length);
            }.bind(this)
          );

          // console.log(aKeys)

          //set scanner location
          this.getScanHandler().setLocation("ConfirmationDetail");

          //reset tab
          this._getViewModel().setProperty("/tabKey", "hint");

          this._bFromOrderList = bFromOrder === "true";
          this._bindView(sID);
          this.updateTreeTable();
          this.changeColorOfDeviceId();
          let oFuncLocOrg = this.getDBService().getEntitySet(
              "FuncLocOrg",
              "SELECT * from FuncLocOrg where TrZone is not ''"
            ),
            self = this;
          Promise.all([oFuncLocOrg]).then((results) => {
            let oFuncLocOrgs = self.getHelper().rowsToArray(results[0]);
            this.getModel("local").setProperty(
              "/PublicFuncLocOrg",
              oFuncLocOrgs
            );
          });
        },

        onTabSelect: function (oEvent) {
          var oShared = this.getSharedModel(),
            oViewModel = this._getViewModel(),
            aPersNo = this.getView().byId("persCombo").getSelectedKeys(),
            aPartic = oShared.getProperty("/ParticipantSet"),
            aFinal = [];

          if (oEvent.getParameter("key") === "time") {
            aPartic.forEach(function (oPartic) {
              //if (aPersNo.indexOf(oPartic.sKey) !== -1) {
              aFinal.push(oPartic);
              //}
            });
            oViewModel.setProperty("/ParticipantSet", aFinal);
            if (this._oTimeDetailForm) {
              this._oTimeDetailForm.unbindElement();
              this._oTimeDetailForm.setVisible(false);
            }
          }
        },

        onPictureUpload: function (oEvent) {
          var oFile = oEvent.getParameter("files")[0],
            oReader = new FileReader();

          oReader.onload = jQuery.proxy(function (oResult) {
            this.onPhotoTakenSuccess(oResult.target.result.split(",")[1]);
            this.getView().byId("ConfirmationDetailFileUploader").clear();
            var that = this;
            that.getView().byId("ConfDetailTabBar").setSelectedKey("hint");
            setTimeout(function () {
              that.getView().byId("ConfDetailTabBar").setSelectedKey("photo");
            }, 2000);
          }, this);

          if (oFile) {
            oReader.readAsDataURL(oFile);
          }
        },

        onEditPress: function () {
          var sPath = this.getView().getBindingContext("local").getPath(),
            oModel = this.getView().getModel("local");

          oModel.setProperty(sPath + "/IsFinished", false);
          // oModel.setProperty(sPath + "/ExecFin", null);

          this._saveToDb();
        },

        onPhotoAddPress: function () {
          navigator.camera.getPicture(
            jQuery.proxy(this.onPhotoTakenSuccess, this),
            jQuery.proxy(this.onPhotoTakenFail, this),
            {
              destinationType: Camera.DestinationType.DATA_URL,
              allowEdit: false,
              quality: 30,
            }
          );
        },

        onPhotoDeletePress: function (oEvent) {
          var oBindingContext = oEvent
              .getParameter("listItem")
              .getBindingContext("local"),
            sPicHandle = oBindingContext.getProperty("Handle");

          MBox.confirm(this.getText("ConfirmPicDelete"), {
            onClose: function (sAction) {
              if (sPicHandle && sAction === sap.m.MessageBox.Action.OK) {
                $.when(
                  this.getDBService().deleteObject(
                    "Picture",
                    oBindingContext.getObject()
                  )
                )
                  .done(
                    jQuery.proxy(function () {
                      this._getPhotosFromDatabase(
                        this.getView().getBindingContext("local").getObject()
                          .Handle
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      MBox.error(this.getText("PicDeleteError"));
                    }, this)
                  );
              }
            }.bind(this),
          });
        },

        _getRotateDialog: function () {
          /*BEGIN: Date: 31/01/2024 AMID: A0866990 13.1 Bug Number: No Bug
			if we first upload from notification detail and come here. Pcicture were not shown in the list*/
          if (!this.getOwnerComponent().oRotateDialogConf) {
            this.getOwnerComponent().oRotateDialogConf = sap.ui.xmlfragment(
              "RotateConf",
              "mobilework.view.notifications.RotateImage",
              this
            );
            this.getView().addDependent(
              this.getOwnerComponent().oRotateDialogConf
            );
          }

          return this.getOwnerComponent().oRotateDialogConf;
        },

        onRotateClose: function () {
          this._getRotateDialog().close();
        },

        onPhotoTakenSuccess: function (sBase64) {
          var image = "data:image/jpeg;base64," + sBase64;
          // this.getView().setModel(new sap.ui.model.json.JSONModel(), "newImage");
          this.getView()
            .getModel("newImage")
            .setProperty("/RotateImage", image);
          this._getRotateDialog().open();
        },

        onSuccessPics: function (sBase64) {
          this._getRotateDialog().close();
          var sHandle = "",
            sContent = "",
            sMimetype = "",
            sParentHandle = "",
            sName = "",
            oPhotoObject = {},
            sPicIndex = 0;

          sHandle = this.getHelper().getUUID();
          sParentHandle = this.getView()
            .getBindingContext("local")
            .getObject().Handle;
          sContent = sBase64;
          sMimetype = "image/jpeg";
          sName = "conf_" + new Date().getTime() + ".jpeg";

          if (this.getView().getBindingContext("local").getObject().Photos) {
            sPicIndex =
              this.getView().getBindingContext("local").getObject().Photos
                .length + 1;
          } else {
            sPicIndex = 1;
          }

          oPhotoObject = {
            Handle: sHandle,
            Parent: sParentHandle,
            PicName: sName,
            PicType: sMimetype,
            PicContent: sContent,
            Tag: "",
            PicIndex: sPicIndex,
            Description: "",
          };

          $.when(
            this.getDBService().insertObject("Picture", oPhotoObject)
          ).done(
            jQuery.proxy(function () {
              var oLocalModel = this.getView().getModel("local"),
                sPath = this.getView().getBindingContext("local").sPath,
                aPhotos = oLocalModel.getProperty(sPath + "/Photos");

              if (!aPhotos) {
                aPhotos = [];
              }

              aPhotos.push(oPhotoObject);

              oLocalModel.setProperty(sPath + "/Photos", aPhotos);
              oLocalModel.setProperty(sPath + "/PicCount", aPhotos.length);
              this.getView()
                .getModel("newImage")
                .setProperty("/PicCount", aPhotos.length);
            }, this)
          );
        },

        onLeftRotate: function (base64) {
          var sPath = this.getView().getBindingContext("local").sPath,
            canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (-90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((-90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/RotateImage", newurl);
          }, this);
        },

        onRightRotate: function (base64) {
          var canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("newImage")
              .setProperty("/RotateImage", newurl);
          }, this);
        },
        onEditDescription: function () {
          var editValue = this.getView()
            .getModel("newImage")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("newImage")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("newImage")
              .setProperty("/DescriptionEdit", false);
          }
        },

        onSaveDescription: function () {
          var oObject = this.getView().getBindingContext("local").getObject();
          var editValue = this.getView()
            .getModel("newImage")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("newImage")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("newImage")
              .setProperty("/DescriptionEdit", false);
          }
          var photos = oObject.Photos;
          photos.forEach(
            jQuery.proxy(function (oItem) {
              $.when(this.getDBService().updateObject("Picture", oItem))
                .done(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Success",
                      "INFO",
                      "ConfirmationDetail"
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Fail",
                      "ERROR",
                      "ConfirmationDetail"
                    );
                  }, this)
                );
            }, this)
          );
        },
        onDropUp: function (oEvent) {
          var oObject = this.getView().getBindingContext("local").getObject(),
            editValue = this.getView()
              .getModel("newImage")
              .getProperty("/DescriptionEdit"),
            sPath = this.getView().getBindingContext("local").sPath;
          if (editValue === false) {
            var indexDropUp = oEvent.getParameter("id").lastIndexOf("-"),
              idDropUp = parseInt(
                oEvent.getParameter("id").substring(indexDropUp + 1),
                10
              ),
              photos = oObject.Photos,
              tempItem = photos[idDropUp],
              tempIndex;
            photos[idDropUp] = photos[idDropUp - 1];
            photos[idDropUp - 1] = tempItem;
            tempIndex = photos[idDropUp].PicIndex;
            photos[idDropUp].PicIndex = photos[idDropUp - 1].PicIndex;
            photos[idDropUp - 1].PicIndex = tempIndex;
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Photos", photos);
          }
        },
        onDropDown: function (oEvent) {
          var oObject = this.getView().getBindingContext("local").getObject(),
            editValue = this.getView()
              .getModel("newImage")
              .getProperty("/DescriptionEdit"),
            sPath = this.getView().getBindingContext("local").sPath;
          if (editValue === false) {
            var indexDropDown = oEvent.getParameter("id").lastIndexOf("-"),
              idDropDown = parseInt(
                oEvent.getParameter("id").substring(indexDropDown + 1),
                10
              ),
              photos = oObject.Photos,
              tempItem = photos[idDropDown],
              tempIndex;
            photos[idDropDown] = photos[idDropDown + 1];
            photos[idDropDown + 1] = tempItem;
            tempIndex = photos[idDropDown].PicIndex;
            photos[idDropDown].PicIndex = photos[idDropDown + 1].PicIndex;
            photos[idDropDown + 1].PicIndex = tempIndex;
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Photos", photos);
          }
        },
        onUpdateFinished: function (oEvt) {
          if (oEvt.getSource().getAggregation("items").length === 2) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", true);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 1) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 0) {
          } else {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
            for (
              var i = 1;
              i < oEvt.getSource().getAggregation("items").length - 1;
              i++
            ) {
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[1]
                .getAggregation("items")[2]
                .getAggregation("items")[0]
                .setProperty("visible", true);
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[1]
                .getAggregation("items")[2]
                .getAggregation("items")[1]
                .setProperty("visible", true);
            }
          }
        },

        onPhotoTakenFail: function (oError) {
          MBox.error(oError.toString());
        },

        onSavePress: function () {
          var oLocalModel = this.getView().getModel("local"),
            oObject = this.getView().getBindingContext("local").getObject();

          if (this.getSharedModel().getProperty("/publicRelease")) {
            //Level 2 validation is required.
            if (oObject.PersNo) {
              oObject.PersNo = "";
            }
            var oValidation = this.getValidator().validatePublicConfirmation(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.PersNo.split(",")
            );
          }
          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
          }

          this._saveToDb();
        },

        onDeletePress: function () {
          var oObject = this.getView().getBindingContext("local").getObject(),
            aChildren =
              oObject && oObject.ChildConfirmations
                ? oObject.ChildConfirmations
                : [],
            aProm = [];

          MBox.confirm(this.getText("ConfirmDeleteConf"), {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                if (oObject.Aufnr) {
                  // Find order in database
                  $.when(this.getDBService().getOrder(oObject.Aufnr)).done(
                    jQuery.proxy(function (oResult) {
                      var aOrders = this.getHelper().rowsToArray(oResult);
                      var oOrder = aOrders[0];

                      // Clear malfunction end date on deleting confirmation.
                      if (oOrder.NotifNo) {
                        $.when(
                          this.getDBService().getNotificationWithQmnum(
                            oOrder.NotifNo
                          )
                        ).done(
                          jQuery.proxy(function (oRes) {
                            var aNotif = this.getHelper().rowsToArray(oRes);
                            if (aNotif.length) {
                              var oNotif = aNotif[0];
                              oNotif.AusbsDatetime = "";
                              this.getDBService().updateObject(
                                "PMNotification",
                                oNotif
                              );
                            }
                          }, this)
                        );
                      }
                    }, this)
                  );

                  // // Clear malfunction end date on deleting confirmation.
                  // $.when(this.getDBService().getNotificationWithHandle(oObject.NotifHandle)).done(jQuery.proxy(function(oNotifData) {
                  // 	var aNotif = this.getHelper().rowsToArray(oNotifData);

                  // 	aNotif[0].AusbsDatetime = "";

                  // 	this.getDBService().updateObject("PMNotification", aNotif[0]);
                  // }, this));
                }

                $.when(
                  this.getDBService().deleteObject("Confirmation", oObject)
                )
                  .done(
                    jQuery.proxy(function () {
                      if (aChildren && aChildren.length > 0) {
                        aChildren.forEach(
                          jQuery.proxy(function (oChild) {
                            aProm.push(
                              this.getDBService().deleteObject(
                                "Confirmation",
                                oChild
                              )
                            );
                          }, this)
                        );
                        $.when.apply($, aProm).done(
                          jQuery.proxy(function () {
                            this.getRouter().navTo("confirmationsMaster");
                          }, this)
                        );
                      } else {
                        this.getRouter().navTo("confirmationsMaster");
                      }
                    }, this)
                  )
                  .fail(jQuery.proxy(function () {}, this));
              }
            }, this),
          });
        },

        onCancelPress: function () {
          var oConfirmation = this.getView()
            .getBindingContext("local")
            .getObject();
          $.when(this.getDBService().getEntitySet("Confirmation")).done(
            jQuery.proxy(function (aConfirmations) {
              var aConfirmationSet =
                this.getHelper().rowsToArray(aConfirmations);

              _.each(aConfirmationSet, function (oConf) {
                for (var sProp in oConf) {
                  if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                    oConf[sProp] = oConf[sProp] === "true" ? true : false;
                  }
                }
              });

              // if (aConfirmationSet.length > 0) {
              var oConfFound = _.find(
                aConfirmationSet,
                jQuery.proxy(function (oConf) {
                  return (
                    oConf.Handle ===
                    this.getView().getBindingContext("local").getObject().Handle
                  );
                }, this)
              );

              if (!oConfFound) {
                var aConfSet = this.getView()
                  .getModel("local")
                  .getProperty("/ConfirmationSet");

                aConfSet = _.remove(
                  aConfSet,
                  jQuery.proxy(function (oConf) {
                    return (
                      oConf.Handle !==
                      this.getView().getBindingContext("local").getObject()
                        .Handle
                    );
                  }, this)
                );

                this.getView()
                  .getModel("local")
                  .setProperty("/ConfirmationSet", aConfSet);
              }
              // }
            }, this)
          );

          this.getRouter().navTo("confirmationsMaster");
        },

        onExecStartChange: function (oEvent) {
          //Start Execution
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            sExecFin = oLocalModel.getProperty(sCurrPath + "/ExecFin"),
            sExecStart = oEvent.getParameter("newValue"),
            moStart = new moment(sExecStart),
            moFin = new moment(sExecFin),
            oCalcData = this._calcActualWork(moStart, moFin),
            oObject = oLocalModel.getProperty(sCurrPath);

          if (
            (!oLocalModel.getProperty(sCurrPath + "/PersNo") ||
              (oLocalModel.getProperty(sCurrPath + "/PersNo") &&
                oLocalModel.getProperty(sCurrPath + "/PersNo").length === 0)) &&
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === false
          ) {
            oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
            oLocalModel.setProperty(sCurrPath + "/ActWork", "");
            MBox.error(this.getText("SelectPartcipant"));
          } else {
            if (this.getSharedModel().getProperty("/publicRelease")) {
              if (oObject.Split) {
                var childPath = oEvent
                  .getSource()
                  .getParent()
                  .getParent()
                  .getBindingContextPath("local");
                var oValidation =
                  this.getValidator().validatePublicConfirmation(
                    oLocalModel.getProperty(childPath),
                    this.getSharedModel(),
                    oLocalModel,
                    ""
                  );
              } else {
                if (!oObject.PersNo) {
                  oObject.PersNo = "";
                }
                var oValidation =
                  this.getValidator().validatePublicConfirmation(
                    oObject,
                    this.getSharedModel(),
                    oLocalModel,
                    oObject.PersNo.split(",")
                  );
              }
              //Level 2 validation is required.
            }
            if (oValidation && oValidation.isValid === false) {
              if (
                this.getSharedModel().getProperty(
                  "/sapSettings/TrCheckError"
                ) ||
                oValidation.isImportant
              ) {
                if (oObject.Split) {
                  oLocalModel.setProperty(childPath + "/ExecStart", "");
                }
                oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                MBox.error(oValidation.sMessage);
                return;
              } else {
                MBox.warning(oValidation.sMessage);
              }
            }

            if (sExecFin) {
              if (oCalcData.bValid) {
                oLocalModel.setProperty(
                  sCurrPath + "/ActWork",
                  oCalcData.ActWork
                );
                oLocalModel.setProperty(
                  sCurrPath + "/UnWork",
                  oCalcData.UnWork
                );
              } else {
                oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                oLocalModel.setProperty(sCurrPath + "/UnWork", "");
                MBox.error(this.getText("StartDateBeforeEndDate"));
              }
            } else {
              // Execution should be started after checking in confirmation blocker
              oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
              //issue 96 11.2 Issue tracker - Confirmation blocker from date time picker for split conf called number of times
              if (oObject.Split) {
                var childPath = oEvent
                  .getSource()
                  .getParent()
                  .getParent()
                  .getBindingContextPath("local");
                oObject = oLocalModel.getProperty(childPath);
                sCurrPath = childPath;
                oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
              }
              this.confirmationBlocker(
                oLocalModel,
                sCurrPath,
                oObject,
                moStart.format("YYYY-MM-DD HH:mm:ss")
              );
            }
          }
        },

        onExecFinChange: function (oEvent) {
          var sCurrPath = this.getView().getBindingContext("local").getPath(),
            oLocalModel = this.getView().getModel("local"),
            sExecFin = oEvent.getParameter("newValue"),
            sExecStart = oLocalModel.getProperty(sCurrPath + "/ExecStart"),
            moStart = new moment(sExecStart),
            moFin = new moment(sExecFin),
            oCalcData = this._calcActualWork(moStart, moFin);

          if (
            (!oLocalModel.getProperty(sCurrPath + "/PersNo") ||
              (oLocalModel.getProperty(sCurrPath + "/PersNo") &&
                oLocalModel.getProperty(sCurrPath + "/PersNo").length === 0)) &&
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === false
          ) {
            oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
            oLocalModel.setProperty(sCurrPath + "/ActWork", "");
            MBox.error(this.getText("SelectPartcipant"));
          } else {
            if (sExecStart) {
              if (oCalcData.bValid) {
                oLocalModel.setProperty(
                  sCurrPath + "/ActWork",
                  oCalcData.ActWork
                );
                oLocalModel.setProperty(
                  sCurrPath + "/UnWork",
                  oCalcData.UnWork
                );
              } else {
                oLocalModel.setProperty(sCurrPath + "/ExecFin", "");
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                oLocalModel.setProperty(sCurrPath + "/UnWork", "");
                MBox.error(this.getText("EndDateAfterStartDate"));
              }
            }
          }
        },

        onActWorkChange: function (oEvent) {
          this._setConfirmationTimeStamp();
        },

        onUnWorkChange: function (oEvent) {
          this._setConfirmationTimeStamp();
        },

        onParticipantChange: function (oEvent) {
          var aSelectedKeys = oEvent.getSource().getSelectedKeys(),
            iCurrCount = _.filter(aSelectedKeys, function (sValue) {
              return sValue !== "";
            }).length,
            oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oValidation = null;
          // if(this.getSharedModel().getProperty("/publicRelease")){
          // 	oValidation=this.getValidator().validatePublicConfirmation(this.getView().getBindingContext("local").getObject(), this.getSharedModel(),oLocalModel,aSelectedKeys,true,false);
          // }

          var temp = oLocalModel.getProperty(sCurrPath + "/PersNo") || "";
          if (
            oLocalModel.getProperty(sCurrPath + "/Split") === true &&
            iCurrCount === 0
          ) {
            oLocalModel.setProperty(sCurrPath + "/PersNo", temp);
            this.getView().byId("persCombo").setSelectedKeys(temp.split(","));
            MBox.error(this.getText("MissingParticipants"));
            return;
          }
          // if(oValidation && oValidation.isValid === false){
          // 	if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){
          // 		if(aSelectedKeys.length){
          // 			oLocalModel.setProperty(sCurrPath + "/PersNo", temp);
          // 			this.getView().byId("persCombo").setSelectedKeys(temp.split(","));
          // 		}else{
          // 			oLocalModel.setProperty(sCurrPath + "/PersNo", []);
          // 		}
          // 		MBox.error(oValidation.sMessage);
          // 		return;
          // 	}else{
          // 		MBox.warning(oValidation.sMessage);
          // 	}

          // }

          if (aSelectedKeys.length > 0) {
            if (oLocalModel.getProperty(sCurrPath + "/ExecStart")) {
              oLocalModel.setProperty(
                sCurrPath + "/PersNo",
                aSelectedKeys.join(",")
              );

              if (
                aSelectedKeys.join(",") !== "" &&
                this.confirmationBlocker(
                  oLocalModel,
                  sCurrPath,
                  oLocalModel.getProperty(sCurrPath),
                  null,
                  aSelectedKeys
                )
              ) {
                oLocalModel.setProperty(sCurrPath + "/PersNo", temp);
                this.getView()
                  .byId("persCombo")
                  .setSelectedKeys(temp.split(","));
                return;
              }
            }

            // _.each(aSelectedKeys, jQuery.proxy(function (oSelectedKey) {
            // 	_.find(this.getModel("shared").getProperty("/ParticipantSet"), function (oParticipant) {
            // 		return oParticipant.sKey === oSelectedKey;
            // 	});
            // }, this));
            oLocalModel.setProperty(sCurrPath + "/PersNo", aSelectedKeys);

            if (oLocalModel.getProperty(sCurrPath + "/Split") === true) {
              this._clearSubConfirmations();
              this._createSubConfirmations();
            } else {
              this._clearSubConfirmations();
            }
          } else {
            oLocalModel.setProperty(sCurrPath + "/PersNo", []);
            if (oLocalModel.getProperty(sCurrPath + "/Split") === true) {
              this._clearSubConfirmations();
            }
          }

          var aSelected = oLocalModel.getProperty(sCurrPath + "/PersNo");

          _.remove(aSelected, function (sVal) {
            return sVal === "";
          });

          oLocalModel.setProperty(sCurrPath + "/ExecutantCnt", iCurrCount);
          this._saveToDb();
        },

        onStartPress: function (oEvent) {
          //Start Execution
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oObject = oLocalModel.getProperty(sCurrPath),
            oValidation = null;

          if (
            (!oLocalModel.getProperty(sCurrPath + "/PersNo") ||
              (oLocalModel.getProperty(sCurrPath + "/PersNo") &&
                oLocalModel.getProperty(sCurrPath + "/PersNo").length === 0)) &&
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === false
          ) {
            oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
            oLocalModel.setProperty(sCurrPath + "/ActWork", "");
            MBox.error(this.getText("SelectPartcipant"));
          } else {
            if (this.getSharedModel().getProperty("/publicRelease")) {
              //Level 2 validation is required.
              if (!oObject.PersNo) {
                oObject.PersNo = "";
              }
              var oValidation = this.getValidator().validatePublicConfirmation(
                oObject,
                this.getSharedModel(),
                oLocalModel,
                oObject.PersNo.split(","),
                "onStartPress"
              );
            }
            if (oValidation && oValidation.isValid === false) {
              if (
                this.getSharedModel().getProperty(
                  "/sapSettings/TrCheckError"
                ) ||
                oValidation.isImportant
              ) {
                oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                MBox.error(oValidation.sMessage);
                return;
              } else {
                MBox.warning(oValidation.sMessage);
              }
            }

            this.confirmationBlocker(oLocalModel, sCurrPath, oObject);
          }
        },

        onStopPress: function (oEvent) {
          //Stop Execution
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oObject = this.getView().getBindingContext("local").getObject();
          // Issue 115 & 116 in V13.0
          if (oObject.Plant ? false : true) {
            var plantField = this.getText("Plant");
            MBox.error(this.getText("FillInRequiredFields", plantField));
            return;
          } else if (
            this.getSharedModel().getProperty("/sapSettings/FILL_CONFT") === "X"
              ? true
              : false
          ) {
            if (oObject.ConfText ? false : true) {
              var ConfTextField = this.getText("ConfText");
              MBox.error(this.getText("FillInRequiredFields", ConfTextField));
              return;
            }
          }

          if (
            (!oLocalModel.getProperty(sCurrPath + "/PersNo") ||
              (oLocalModel.getProperty(sCurrPath + "/PersNo") &&
                oLocalModel.getProperty(sCurrPath + "/PersNo").length === 0)) &&
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === false
          ) {
            oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
            oLocalModel.setProperty(sCurrPath + "/ActWork", "");
            MBox.error(this.getText("SelectPartcipant"));
          } else {
            if (this.getSharedModel().getProperty("/publicRelease")) {
              //Level 2 validation is required.
              if (!oObject.PersNo) {
                oObject.PersNo = "";
              }
              var oValidation = this.getValidator().validatePublicConfirmation(
                oObject,
                this.getSharedModel(),
                oLocalModel,
                oObject.PersNo.split(","),
                "onStopPress"
              );
              //Code written to check auto exit /sapSettings/EXIT_TIME
              this.exitTimeCheck(false);
            }

            if (oValidation && oValidation.isValid === false) {
              if (
                this.getSharedModel().getProperty(
                  "/sapSettings/TrCheckError"
                ) ||
                oValidation.isImportant
              ) {
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                MBox.error(oValidation.sMessage);
                return;
              } else {
                MBox.warning(oValidation.sMessage);
              }
            }
            if (this._checkExecStartDate()) {
              MBox.confirm(
                this.getText("FinalizeConfirm"),
                jQuery.proxy(function (sAction) {
                  if (sAction === sap.m.MessageBox.Action.OK) {
                    $.when(this._finalizeConfirmation())
                      .done(
                        jQuery.proxy(function (res) {
                          this._saveToDb();
                        }, this)
                      )
                      .fail(jQuery.proxy(function (error) {}, this));
                  }
                }, this)
              );
            }
          }
        },
        onAddPersonPress: function (oEvent) {
          if (!this._oPersonPopover) {
            this._oPersonPopover = sap.ui.xmlfragment(
              "AddConfirmationDialog",
              "mobilework.view.confirmations.ConfirmationDetailTimeTablePopover",
              this
            );
            this.getView().addDependent(this._oPersonPopover);
          }
          this._oPersonPopover.openBy(oEvent.getSource());
        },

        onDeletePersonPress: function (oEvent) {
          var oLocalModel = this.getView().getModel("local"),
            sPath = oEvent
              .getSource()
              .getParent()
              .getParent()
              .getBindingContextPath("local"),
            oObject = oLocalModel.getProperty(sPath),
            sParentPath = this.getView().getBindingContext("local").getPath(),
            aChildren = oLocalModel.getProperty(
              sParentPath + "/ChildConfirmations"
            );

          $.when(this.getDBService().deleteObject("Confirmation", oObject))
            .done(
              jQuery.proxy(function () {
                var aCorrectedSelection = _.filter(
                  this.getView().byId("persCombo").getSelectedKeys(),
                  function (oKey) {
                    return oKey !== oObject.PersNo;
                  }
                );

                this.getView()
                  .byId("persCombo")
                  .setSelectedKeys(aCorrectedSelection);
                oLocalModel.setProperty(
                  sParentPath + "/PersNo",
                  aCorrectedSelection.toString()
                );
                oLocalModel.setProperty(
                  sParentPath + "/ExecutantCnt",
                  oLocalModel.getProperty(sParentPath + "/ExecutantCnt") - 1
                );
                _.remove(aChildren, {
                  Handle: oObject.Handle,
                });
                oLocalModel.setProperty(
                  sParentPath + "/ChildConfirmations",
                  aChildren
                );
                if (aChildren.length === 0) {
                  var parent = _.remove(
                    this.getView()
                      .getModel("local")
                      .getProperty("/ConfirmationSet"),
                    {
                      Handle: oObject.ParentHndl,
                    }
                  );
                  this.getDBService().deleteObject("Confirmation", parent[0]);
                  this.getRouter().navTo("confirmationsMaster");
                } else {
                  this._saveToDb();
                  _.remove(
                    this.getView()
                      .getModel("local")
                      .getProperty("/ConfirmationSet"),
                    {
                      Handle: oObject.Handle,
                    }
                  );
                }
                oLocalModel.refresh(true);
                var path = this.findPath(oObject.ParentHndl);
                if (path) {
                  this.getView().bindElement({
                    path: "/ConfirmationSet/" + path,
                    model: "local",
                  });
                }
                if (this._oTimeDetailForm) {
                  this._oTimeDetailForm.setVisible(false);
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("ConfirmDeleteError"));
              }, this)
            );
        },

        onPersonAcceptPress: function () {
          //TBDVS validation
          var oLocalModel = this.getView().getModel("local"),
            oViewModel = this._getViewModel(),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oParentConfirm = oLocalModel.getProperty(sCurrPath),
            sSelectedPerson = oViewModel.getProperty("/SelectedPerson"),
            aCurrPersons =
              oLocalModel.getProperty(sCurrPath + "/ChildConfirmations") || [],
            oNewConf = {},
            aConfirmations = oLocalModel.getProperty("/ConfirmationSet");

          if (!sSelectedPerson) {
            return;
          }
          // if(this.getSharedModel().getProperty("/publicRelease")){
          // 	//Level 2 validation is required.
          // 	var oValidation = this.getValidator().validatePublicConfirmation(oParentConfirm, this.getSharedModel(),oLocalModel,sSelectedPerson.split(','),true,true,false);
          // }
          // if(oValidation && oValidation.isValid === false){
          // 	if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){
          // 		MBox.error(oValidation.sMessage);
          // 		return;
          // 	}else{
          // 		MBox.warning(oValidation.sMessage);
          // 	}

          // }

          if (
            _.find(aCurrPersons, {
              PersNo: sSelectedPerson,
              IsFinished: false,
            })
          ) {
            MBox.error(
              this.getText("ConfirmationPersonExists", [sSelectedPerson])
            );
            return;
          } else {
            //oParentConfirm.PersNo.push(sSelectedPerson);
            this.getView().byId("persCombo").addSelectedKeys(sSelectedPerson);
            oParentConfirm.PersNo = this.getView()
              .byId("persCombo")
              .getSelectedKeys()
              .toString();
            oParentConfirm.ExecutantCnt = oParentConfirm.ExecutantCnt + 1;
            this._saveToDb();
          }

          for (var sProp in oParentConfirm) {
            oNewConf[sProp] = oParentConfirm[sProp];
          }

          var oFoundParticipant = _.find(
            this.getSharedModel().getProperty("/ParticipantSet"),
            jQuery.proxy(function (oPartic) {
              return oPartic.sKey === sSelectedPerson;
            }, this)
          );

          oNewConf.Handle = this.getHelper().getUUID();
          oNewConf.PersNo = sSelectedPerson;
          oNewConf.PersName = oFoundParticipant ? oFoundParticipant.sName : "";
          oNewConf.ExecStart = "";
          oNewConf.ExecFin = "";
          oNewConf.ActWork = "";
          // oNewConf.FinConf = "";
          oNewConf.IsFinished = false;
          oNewConf.Hidden = true;
          oNewConf.ParentHndl = oParentConfirm.Handle;
          oNewConf.Split = false;
          oNewConf.ExecutantCnt = 1; // IMPORTANT - Otherwise causes bugs in backend
          delete oNewConf.ChildConfirmations;

          aCurrPersons.push(oNewConf);

          oViewModel.setProperty("/SelectedPerson", "");
          oLocalModel.setProperty(
            sCurrPath + "/ChildConfirmations",
            aCurrPersons
          );

          this.getDBService().insertObject("Confirmation", oNewConf);

          aConfirmations.push(oNewConf);
          oLocalModel.setProperty("/ConfirmationSet", aConfirmations);

          this._oPersonPopover.close();
        },

        onStartPersonPress: function (oEvent) {
          var oLocalModel = this.getView().getModel("local"),
            sPath = oEvent
              .getSource()
              .getParent()
              .getParent()
              .getBindingContextPath("local"),
            oObject = oLocalModel.getProperty(sPath);
          if (this.getSharedModel().getProperty("/publicRelease")) {
            if (!oObject.PersNo) {
              oObject.PersNo = "";
            }
            var oValidation = this.getValidator().validatePublicConfirmation(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.PersNo.split(","),
              "onStartPersonPress"
            );
          }
          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
          }

          this.confirmationBlocker(oLocalModel, sPath, oObject);
        },

        onStopPersonPress: function (oEvent) {
          var oLocalModel = this.getView().getModel("local"),
            sPath = oEvent
              .getSource()
              .getParent()
              .getParent()
              .getBindingContextPath("local"),
            oObject = oLocalModel.getProperty(sPath),
            oParentObject = this.getView()
              .getBindingContext("local")
              .getObject();
          // Issue 115 & 116 in V13.0
          if (
            (oObject.Plant ? false : true) &&
            (oParentObject.Plant ? false : true)
          ) {
            var plantField = this.getText("Plant");
            MBox.error(this.getText("FillInRequiredFields", plantField));
            return;
          } else if (
            this.getSharedModel().getProperty("/sapSettings/FILL_CONFT") === "X"
              ? true
              : false
          ) {
            if (
              (oObject.ConfText ? false : true) &&
              (oParentObject.ConfText ? false : true)
            ) {
              var ConfTextField = this.getText("ConfText");
              MBox.error(this.getText("FillInRequiredFields", ConfTextField));
              return;
            }
          }
          var aOtherChildren = oParentObject.ChildConfirmations,
            aUnfinishedChildren = _.filter(aOtherChildren, {
              IsFinished: false,
            }),
            oMomStart = new moment(oObject.ExecStart),
            oMomEnd = new moment(new Date()),
            oActWork = this._calcActualWork(oMomStart, oMomEnd),
            fnDoUpdate = jQuery.proxy(function () {
              oLocalModel.setProperty(
                sPath + "/ExecFin",
                new moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
              );
              oLocalModel.setProperty(sPath + "/IsFinished", true);
              oLocalModel.setProperty(sPath + "/ActWork", oActWork.ActWork);
              oLocalModel.setProperty(sPath + "/UnWork", oActWork.UnWork);
              oLocalModel.setProperty(
                sPath + "/ConfText",
                oParentObject.ConfText
              );
              oLocalModel.setProperty(sPath + "/Text", oParentObject.Text);
              this._saveToDb();
            }, this);
          if (this.getSharedModel().getProperty("/publicRelease")) {
            if (!oObject.PersNo) {
              oObject.PersNo = "";
            }
            //Level 2 validation is required.
            var oValidation = this.getValidator().validatePublicConfirmation(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.PersNo.split(","),
              "onStopPersonPress"
            );
          }
          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
          }

          if (new Date() < new Date(oObject.ExecStart)) {
            MBox.error(this.getText("NoFinalizeStartInFuture"));
          } else {
            // check if current person is last to be finished
            // if so, check if all data has been provided on parent
            if (
              aUnfinishedChildren.length === 1 &&
              aUnfinishedChildren[0].Handle === oObject.Handle
            ) {
              var oValidation =
                this.getValidator().validateConfirmationFinalize(
                  oParentObject,
                  this.getSharedModel()
                );
              if (!oValidation.isValid) {
                MBox.error(this.getText("FillRequiredOnParentConf"));
              } else {
                if (oActWork.bValid) {
                  //oParentObject.IsFinished="true";//For 98 12.1
                  oParentObject.ActWork = "true";
                  oParentObject.ExecFin = new moment(new Date()).format(
                    "YYYY-MM-DD HH:mm:ss"
                  );
                  fnDoUpdate();
                }
              }
              oLocalModel.setProperty(sPath + "/FinalConfirmButton", true);
            } else {
              if (oActWork.bValid) {
                fnDoUpdate();
              }
            }
          }
        },

        onPersonPress: function (oEvent) {
          var sPath = oEvent.getSource().getBindingContextPath("local"),
            sPersNo = this.getView()
              .getModel("local")
              .getProperty(sPath + "/PersNo");

          if (!this._oTimeDetailForm) {
            this._oTimeDetailForm = this.getView().byId(
              "confTimeTableDetailFrom"
            );
            this._oTimeDetailForm.setVisible(true);
          }

          this._oTimeDetailForm.bindElement({
            path: sPath,
            model: "local",
          });
          // We do this because otherwise we have a bug in create conf from order
          this._oTimeDetailForm.setTitle(sPersNo);
          this._oTimeDetailForm.setVisible(true);
        },

        onSplitSelected: function (oEvent) {
          if (oEvent.getParameters().selected) {
            this._createSubConfirmations();
          } else {
            this._clearSubConfirmations();
          }
          this._saveToDb();
        },

        onNavBack: function () {
          var oConfirmation = this.getView()
            .getBindingContext("local")
            .getObject();
          $.when(this.getDBService().getEntitySet("Confirmation")).done(
            jQuery.proxy(function (aConfirmations) {
              var aConfirmationSet =
                this.getHelper().rowsToArray(aConfirmations);

              _.each(aConfirmationSet, function (oConf) {
                for (var sProp in oConf) {
                  if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                    oConf[sProp] = oConf[sProp] === "true" ? true : false;
                  }
                }
              });

              // if (aConfirmationSet.length > 0) {
              var oConfFound = _.find(
                aConfirmationSet,
                jQuery.proxy(function (oConf) {
                  return (
                    oConf.Handle ===
                    this.getView().getBindingContext("local").getObject().Handle
                  );
                }, this)
              );

              if (!oConfFound) {
                var aConfSet = this.getView()
                  .getModel("local")
                  .getProperty("/ConfirmationSet");

                aConfSet = _.remove(
                  aConfSet,
                  jQuery.proxy(function (oConf) {
                    return (
                      oConf.Handle !==
                      this.getView().getBindingContext("local").getObject()
                        .Handle
                    );
                  }, this)
                );

                this.getView()
                  .getModel("local")
                  .setProperty("/ConfirmationSet", aConfSet);
              }
              // }
            }, this)
          );

          if (!this._bFromOrderList) {
            this.getRouter().navTo("confirmationsMaster");
          } else if (this.bfromConfirmOrderlist) {
            this._bFromOrderList = false;
            this.bfromConfirmOrderlist = false;
            this.getRouter().navTo("confirmationsMaster");
          } else {
            this._bFromOrderList = false;
            this.getRouter().navTo("ordersMaster");
          }
        },

        onFinalizeConfirmationPress: function (oEvent) {
          $.when(this._finalizeConfirmation()).done(
            jQuery.proxy(function () {
              this._saveToDb();
            }, this)
          );
        },

        onPlantChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");
          var sPath = this.getView().getBindingContext("local").sPath;

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Plant", sValue.toUpperCase());
          }
        },

        onWorkCntrChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          var sPath = this.getView().getBindingContext("local").sPath;

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/WorkCntr", sValue.toUpperCase());
          }
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        cleanBoolean: function (vBoolean) {
          switch (typeof vBoolean) {
            case "boolean":
              return vBoolean;
            case "string":
              return vBoolean === "true";
          }

          return false;
        },

        enableSplitTime: function (sVornr, bIsFinished, sPersNo, NotifHandle) {
          if (!sVornr && !NotifHandle) {
            return false;
          } else if (bIsFinished === true || bIsFinished === "true") {
            return false;
          } else if (
            (!sPersNo ||
              sPersNo === "" ||
              (sPersNo &&
                typeof sPersNo === "object" &&
                sPersNo.length === 0)) &&
            this.getSharedModel().getProperty(
              "/sapSettings/persNoNotRequired"
            ) === true
          ) {
            return false;
          } else {
            return true;
          }
        },

        formatHeaderDate: function (sDateString) {
          if (sDateString) {
            return new moment(sDateString).format("DD/MM/YYYY HH:mm");
          }

          return "-";
        },

        persNoSelectedKeys: function (sPerNo) {
          if (sPerNo && sPerNo.indexOf(",") !== -1) {
            return sPerNo.split(",");
          } else {
            return sPerNo;
          }
        },

        showStartButton: function (oExecStart, bSplit) {
          if (!oExecStart && !bSplit) {
            this.getSharedModel().setProperty("/WidthofLabelS", 10);
            this.getSharedModel().setProperty("/WidthofLabelL", 7);
            this.getSharedModel().setProperty("/WidthofLabelM", 7);
            return true;
          } else {
            this.getSharedModel().setProperty("/WidthofLabelS", 10);
            this.getSharedModel().setProperty("/WidthofLabelL", 7);
            this.getSharedModel().setProperty("/WidthofLabelM", 7);
            return false;
          }
        },

        showStopButton: function (oExecStart, bSplit, ActWork) {
          if (oExecStart && !bSplit && !ActWork) {
            this.getSharedModel().setProperty("/WidthofLabelS", 10);
            this.getSharedModel().setProperty("/WidthofLabelL", 7);
            this.getSharedModel().setProperty("/WidthofLabelM", 7);
            return true;
          } else {
            if (oExecStart) {
              this.getSharedModel().setProperty("/WidthofLabelS", 12);
              this.getSharedModel().setProperty("/WidthofLabelL", 9);
              this.getSharedModel().setProperty("/WidthofLabelM", 9);
            }
            return false;
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "newImage"
          );
          if (!this.getView().getModel("viewModel")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel(),
              "viewModel"
            );
          }
        },

        _bindView: function (sID) {
          var sBindingPath = "/ConfirmationSet/" + sID,
            oObject = this.getView()
              .getModel("local")
              .getProperty(sBindingPath),
            sPersNo = "";

          if (oObject) {
            // get values from Operation
            if (oObject.NotifHandle) {
              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/ConfLinkedNotif", true);
              $.when(
                this.getDBService().getNotificationWithHandle(
                  oObject.NotifHandle
                )
              ).done(
                jQuery.proxy(function (oResult) {
                  var oNotification = this.getHelper().rowsToArray(oResult);
                  this.getView()
                    .getModel("local")
                    .setProperty(
                      sBindingPath + "/NotifTextType",
                      this.getNotifTypeText(oNotification[0].Qmart)
                    );
                  this.getView()
                    .getModel("local")
                    .setProperty(
                      sBindingPath + "/Qmtxt",
                      oNotification[0].Qmtxt
                    );
                }, this)
              );
            }
            if (oObject.Aufnr) {
              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/ConfLinkedNotif", false);
            }
            this.getView()
              .getModel("newImage")
              .setProperty("/DescriptionEdit", true);

            // get values from order/operation
            $.when(
              this.getDBService().getOperation(oObject.Aufnr, oObject.Vornr)
            ).done(
              jQuery.proxy(function (oResult) {
                var aOperationSet = this.getHelper().rowsToArray(oResult);
                if (aOperationSet.length > 0) {
                  this.getView()
                    .getModel("local")
                    .setProperty(
                      sBindingPath + "/StartDate",
                      aOperationSet[0].EarlSchedStartDateDt
                    );
                  this.getView()
                    .getModel("local")
                    .setProperty(
                      sBindingPath + "/EndDate",
                      aOperationSet[0].EarlSchedFinDateDt
                    );
                  this.getView()
                    .getModel("local")
                    .setProperty(
                      sBindingPath + "/ControlKey",
                      aOperationSet[0].ControlKey
                    );
                } else {
                  var aOrder = _.filter(
                    this.getView()
                      .getModel("local")
                      .getProperty("/PMOrderSetDataWithConf"),
                    {
                      Orderid: oObject.Aufnr,
                    }
                  );
                  if (aOrder.length > 0) {
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/StartDate",
                        aOrder[0].StartDateDt
                      );
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/EndDate",
                        aOrder[0].FinishDateDt
                      );
                  } else {
                    this.getView()
                      .getModel("local")
                      .setProperty(sBindingPath + "/StartDate", null);
                    this.getView()
                      .getModel("local")
                      .setProperty(sBindingPath + "/EndDate", null);
                  }
                }
                if (!oObject.UnWork) {
                  if (aOperationSet.length > 0) {
                    oObject.UnWork = aOperationSet[0].DurationNormalUnitIso;
                  } else {
                    oObject.UnWork = "MIN";
                  }
                }
              }, this)
            );

            if (
              oObject.PersNo &&
              typeof oObject.PersNo !== "string" &&
              oObject.PersNo.length > 0
            ) {
              for (var sPernr in oObject.PersNo) {
                sPersNo += oObject.PersNo[sPernr] + ",";
              }
              sPersNo = sPersNo.slice(0, -1);
              oObject.PersNo = sPersNo;
            }

            if (oObject && (!oObject.FinConf || oObject.FinConf === "")) {
              oObject.FinConf = false;
            }

            this.getView().bindElement({
              path: sBindingPath,
              model: "local",
            });
            if (this.FromNotif) {
              this._saveToDb();
            }
            $.when(this._updatePrevLongText(oObject, sID)).done(
              jQuery.proxy(function (oConfirmation) {
                this.getModel("local").setProperty(sBindingPath, oConfirmation);
              }, this)
            );

            // this._rebindPersNoBox(oObject.PersNo);

            this._getPhotosFromDatabase(oObject.Handle);
            this._getChildConfirmations();
            if (
              !this.getHelper().checkFinalConfExists(
                this.getModel("local").getProperty("/ConfirmationSet"),
                oObject.Aufnr,
                oObject.Vornr,
                oObject.SubActivity
              )
            ) {
              this.getModel("local").setProperty(
                sBindingPath + "/newConfirmationButton",
                false
              );
            } else {
              this.getModel("local").setProperty(
                sBindingPath + "/newConfirmationButton",
                true
              );
            }
          }
        },

        _setConfirmationTimeStamp: function () {
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oObject = this.getView().getBindingContext("local").getObject(),
            sActWork = oLocalModel.getProperty(sCurrPath + "/ActWork"),
            sUnWork = oLocalModel.getProperty(sCurrPath + "/UnWork"),
            oCalcData = null;

          if (sUnWork && sActWork) {
            oCalcData = this._calcExecStartFin(sActWork, sUnWork);
            if (new Date(oCalcData.ExecFin) > new Date()) {
              oLocalModel.setProperty(sCurrPath + "/IsFinished", false);
              oLocalModel.setProperty(sCurrPath + "/ExecFin", "");
              oLocalModel.setProperty(sCurrPath + "/ActWork", "");
              MBox.error(this.getText("PNotInZoneCurrent"));
              return;
            }
            oLocalModel.setProperty(sCurrPath + "/ExecFin", oCalcData.ExecFin);
            if (this.getSharedModel().getProperty("/publicRelease")) {
              //Level 2 validation is required.
              if (!oObject.PersNo) {
                oObject.PersNo = "";
              }
              var oValidation = this.getValidator().validatePublicConfirmation(
                oObject,
                this.getSharedModel(),
                oLocalModel,
                oObject.PersNo.split(","),
                false
              );
              //Code written to check auto exit /sapSettings/EXIT_TIME
              this.exitTimeCheck(false);
            }
            if (oValidation && oValidation.isValid === false) {
              if (
                this.getSharedModel().getProperty(
                  "/sapSettings/TrCheckError"
                ) ||
                oValidation.isImportant
              ) {
                oLocalModel.setProperty(sCurrPath + "/ExecFin", "");
                oLocalModel.setProperty(sCurrPath + "/ActWork", "");
                MBox.error(oValidation.sMessage);
                return;
              } else {
                MBox.warning(oValidation.sMessage);
              }
            } else {
              oLocalModel.setProperty(
                sCurrPath + "/ExecStart",
                oCalcData.ExecStart
              );
              oLocalModel.setProperty(
                sCurrPath + "/ExecFin",
                oCalcData.ExecFin
              );
            }
          } else {
            oLocalModel.setProperty(sCurrPath + "/IsFinished", false);
            // oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
            oLocalModel.setProperty(sCurrPath + "/ExecFin", "");
          }
        },

        _calcActualWork: function (oMomStart, oMomEnd) {
          /*BEGIN: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
          return this.getHelper().calcActualWork(oMomStart, oMomEnd);
          /*END: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
        },

        _calcExecStartFin: function (sActWork, sUnWork) {
          var sUnWorkToAdd = "",
            oBindingContext = this.getView().getBindingContext("local"),
            oMoStart = oBindingContext.getProperty("ExecStart")
              ? new moment(oBindingContext.getProperty("ExecStart"))
              : new moment(),
            oMoFin = null,
            oReturn = {
              ExecStart: "",
              ExecFin: "",
            };

          switch (sUnWork) {
            case "DAY":
              sUnWorkToAdd = "d";
              break;
            case "HUR" || "HR":
              sUnWorkToAdd = "h";
              break;
            case "MIN":
              sUnWorkToAdd = "m";
          }

          if (sUnWork === "DAY" && typeof sActWork === "string" && sActWork.indexOf(".") !== -1) {
            var iActWorkDays = Number(sActWork.split(".")[0]),
              iActWorkHours =
                Number(
                  sActWork.split(".")[1] /
                    Math.pow(10, sActWork.split(".")[1].length)
                ) * 24;

            oMoFin = new moment(oMoStart)
              .add(iActWorkDays, sUnWorkToAdd)
              .add(iActWorkHours, "h");
          } else {
            oMoFin = new moment(oMoStart).add(Number(sActWork), sUnWorkToAdd);
          }

          oReturn.ExecStart = oMoStart.format("YYYY-MM-DD HH:mm:ss");
          oReturn.ExecFin = oMoFin.format("YYYY-MM-DD HH:mm:ss");

          return oReturn;
        },

        _checkExecStartDate: function () {
          var sExecStart = this.getView()
            .getBindingContext("local")
            .getProperty("ExecStart");
          if (new Date() < new Date(sExecStart)) {
            MBox.error(this.getText("NoFinalizeStartInFuture"));
            return false;
          } else {
            return true;
          }
        },

        _finalizeConfirmation: function () {
          var oLocalModel = this.getView().getModel("local"),
            oConfirmation,
            sCurrPath,
            oConf;
          oConfirmation = this.getView().getBindingContext("local").getObject();
          sCurrPath = this.getView().getBindingContext("local").getPath();
          oConf = oLocalModel.getProperty(sCurrPath);
          oConfirmation.PersNo = this.getView()
            .byId("persCombo")
            .getSelectedKeys()
            .join(",");
          var oMoStart = new moment(
              oLocalModel.getProperty(sCurrPath + "/ExecStart")
            ),
            oMoFin = null,
            oCalcData = null,
            oValidation = null,
            sIncFields = "",
            oPromNotif = this.getDBService().getEntitySet("PMNotification"),
            oPromOrder = this.getDBService().getOrder(oConfirmation.Aufnr),
            d = $.Deferred();

          oValidation = this.getValidator().validateConfirmationFinalize(
            oConf,
            this.getSharedModel()
          );

          $.when(oPromNotif, oPromOrder).done(
            jQuery.proxy(function (oNotifs, oOrder) {
              var aNotifications = this.getHelper().rowsToArray(oNotifs),
                aOrders = this.getHelper().rowsToArray(oOrder),
                oBoundOrder = aOrders[0];

              var oCorrespondingNotif = _.find(
                aNotifications,
                function (oNotif) {
                  return (
                    oNotif.Handle === oConf.NotifHandle && oNotif.Qmnum === ""
                  );
                }
              );
              var oNotifBoundToOrder, sBoundIndex, toPmNotif;
              if (oBoundOrder) {
                oNotifBoundToOrder = _.find(aNotifications, function (oNotif) {
                  return (
                    oNotif.Qmnum === oBoundOrder.NotifNo &&
                    oBoundOrder.NotifNo !== ""
                  );
                });
              }

              var oSapSetting =
                  this.getSharedModel().getProperty("/sapSettings"),
                sFieldsRequired = "";

              if (
                oCorrespondingNotif &&
                (oConfirmation.FinConf === true ||
                  oConfirmation.FinConf === "true")
              ) {
                toPmNotif = oCorrespondingNotif;
                sBoundIndex = _.findIndex(aNotifications, function (oNotif) {
                  return (
                    oNotif.Handle === oConf.NotifHandle && oNotif.Qmnum === ""
                  );
                });

                if (
                  !oCorrespondingNotif.Fecod &&
                  oSapSetting.CONF_M_DMG === "X" &&
                  (oCorrespondingNotif.Qmart === "30,DEFE" ||
                    oCorrespondingNotif.Qmart === "30,IMME" ||
                    oCorrespondingNotif.Qmart === "40,RED")
                ) {
                  sFieldsRequired += this.getText("Fecod") + ", ";
                }

                if (
                  !oCorrespondingNotif.Urcod &&
                  oSapSetting.CONF_M_CSE === "X" &&
                  (oCorrespondingNotif.Qmart === "30,DEFE" ||
                    oCorrespondingNotif.Qmart === "30,IMME" ||
                    oCorrespondingNotif.Qmart === "40,RED")
                ) {
                  sFieldsRequired += this.getText("Urcod") + ", ";
                }

                if (
                  !oCorrespondingNotif.AusbsDatetime &&
                  oSapSetting.CONF_M_BRD === "X" &&
                  (oCorrespondingNotif.Qmart === "30,DEFE" ||
                    oCorrespondingNotif.Qmart === "30,IMME")
                ) {
                  sFieldsRequired += this.getText("AusbsDatetime") + ", ";
                }

                sFieldsRequired = sFieldsRequired.slice(0, -2);
              } else if (
                oNotifBoundToOrder &&
                (oConfirmation.FinConf === true ||
                  oConfirmation.FinConf === "true")
              ) {
                toPmNotif = oNotifBoundToOrder;
                sBoundIndex = _.findIndex(aNotifications, function (oNotif) {
                  return (
                    oNotif.Qmnum === oBoundOrder.NotifNo &&
                    oBoundOrder.NotifNo !== ""
                  );
                });
                let qmart =
                  oNotifBoundToOrder.Qmart + "," + oNotifBoundToOrder.Qmcod;
                if (
                  !oNotifBoundToOrder.Fecod &&
                  (oBoundOrder.ConfMDmg === "true" ||
                    oBoundOrder.ConfMDmg === true) &&
                  (qmart === "30,DEFE" ||
                    qmart === "30,IMME" ||
                    qmart === "40,RED")
                ) {
                  sFieldsRequired += this.getText("Fecod") + ", ";
                }

                if (
                  !oNotifBoundToOrder.Urcod &&
                  (oBoundOrder.ConfMCse === "true" ||
                    oBoundOrder.ConfMCse === true) &&
                  (qmart === "30,DEFE" ||
                    qmart === "30,IMME" ||
                    qmart === "40,RED")
                ) {
                  sFieldsRequired += this.getText("Urcod") + ", ";
                }

                if (
                  !oNotifBoundToOrder.AusbsDatetime &&
                  (oBoundOrder.ConfMBrd === "true" ||
                    oBoundOrder.ConfMBrd === true) &&
                  (qmart === "30,DEFE" || qmart === "30,IMME")
                ) {
                  sFieldsRequired += this.getText("AusbsDatetime") + ", ";
                }

                sFieldsRequired = sFieldsRequired.slice(0, -2);

                if (
                  (oNotifBoundToOrder.AusbsDatetime === "" ||
                    !oNotifBoundToOrder.AusbsDatetime) &&
                  (oConfirmation.IsFinished === false ||
                    oConfirmation.IsFinished === "false")
                ) {
                  var oDate = new Date();

                  var sAusbsString =
                    "" +
                    oDate.getFullYear() +
                    "-" +
                    (parseInt(oDate.getMonth()) + 1) +
                    "-" +
                    oDate.getDate() +
                    " " +
                    oDate.getHours() +
                    ":" +
                    oDate.getMinutes();

                  oNotifBoundToOrder.AusbsDatetime = sAusbsString;
                }
              }
              if (
                oConfirmation.FinConf === true ||
                oConfirmation.FinConf === "true"
              ) {
                if (oNotifBoundToOrder || oCorrespondingNotif) {
                  $.when(
                    this.getDBService().updateObject(
                      "PMNotification",
                      toPmNotif
                    )
                  )
                    .done(
                      jQuery.proxy(function (oData) {
                        if (sFieldsRequired !== "") {
                          MBox.error(
                            this.getText(
                              "FinalConfirmationMissingData",
                              sFieldsRequired
                            )
                          );
                          this.getRouter().navTo(
                            "notificationsDetailFromConf",
                            {
                              ID: sBoundIndex,
                              ConfID:
                                this._getViewModel().getProperty("/ConfID"),
                              FromConf: true,
                              Confdmg: oBoundOrder
                                ? oBoundOrder.ConfMDmg
                                : oSapSetting.CONF_M_DMG
                                ? true
                                : false,
                              Confcse: oBoundOrder
                                ? oBoundOrder.ConfMCse
                                : oSapSetting.CONF_M_CSE
                                ? true
                                : false,
                              Confbrd: oBoundOrder
                                ? oBoundOrder.ConfMBrd
                                : oSapSetting.CONF_M_BRD
                                ? true
                                : false,
                            }
                          );
                          d.resolve();
                        } else {
                          d.resolve();
                        }
                      }, this)
                    )
                    .fail(jQuery.proxy(function (oError) {}, this));
                } else if (oCorrespondingNotif) {
                  if (sFieldsRequired !== "") {
                    MBox.error(
                      this.getText(
                        "FinalConfirmationMissingData",
                        sFieldsRequired
                      )
                    );
                    d.resolve();
                  }
                }
              }

              // } else {
              // 	$.when(this.getDBService().updateObject("PMNotification", oNotifBoundToOrder))
              // 		.done(jQuery.proxy(function (oData) {
              // 			d.resolve();
              // 		}, this))
              // 		.fail(jQuery.proxy(function (oError) {

              // 		}, this));
              // }

              if (oValidation.isValid && sFieldsRequired === "") {
                if (oLocalModel.getProperty(sCurrPath + "/ExecFin")) {
                  oMoFin = new moment(
                    oLocalModel.getProperty(sCurrPath + "/ExecFin")
                  );
                } else {
                  oMoFin = new moment(new Date());
                }

                if (!oConf.ActWork || !oConf.UnWork) {
                  oCalcData = this._calcActualWork(oMoStart, oMoFin);
                } else {
                  oCalcData = this._calcExecStartFin(
                    oConf.ActWork,
                    oConf.UnWork
                  );
                }

                oLocalModel.setProperty(
                  sCurrPath + "/ExecFin",
                  oMoFin.format("YYYY-MM-DD HH:mm:ss")
                );

                if (oCalcData.bValid) {
                  oLocalModel.setProperty(
                    sCurrPath + "/ActWork",
                    oCalcData.ActWork
                  );
                  oLocalModel.setProperty(
                    sCurrPath + "/UnWork",
                    oCalcData.UnWork
                  );
                } else {
                  oLocalModel.setProperty(
                    sCurrPath + "/ExecStart",
                    oCalcData.ExecStart
                  );
                  oLocalModel.setProperty(
                    sCurrPath + "/ExecFin",
                    oCalcData.ExecFin
                  );
                }

                oLocalModel.setProperty(sCurrPath + "/IsFinished", true);
                var finalConfirmation = oLocalModel.getProperty(
                  sCurrPath + "/FinConf"
                );
                if (
                  !this.getHelper().checkFinalConfExists(
                    this.getModel("local").getProperty("/ConfirmationSet"),
                    oConfirmation.Aufnr,
                    oConfirmation.Vornr,
                    oConfirmation.SubActivity
                  )
                ) {
                  oLocalModel.setProperty(
                    sCurrPath + "/newConfirmationButton",
                    finalConfirmation
                  );
                } else {
                  this.getModel("local").setProperty(
                    sCurrPath + "/newConfirmationButton",
                    true
                  );
                }
              } else {
                for (var sField in oValidation.aFields) {
                  if (sIncFields === "") {
                    sIncFields += this.getText(oValidation.aFields[sField]);
                  } else {
                    sIncFields +=
                      ", " + this.getText(oValidation.aFields[sField]);
                  }
                }
                if (sIncFields !== "") {
                  MBox.error(this.getText(oValidation.sMessage, [sIncFields]));
                }
              }
              if (oValidation.isValid && sFieldsRequired === "") {
                d.resolve();
              } else {
                d.reject();
              }
            }, this)
          );

          return d.promise();
        },

        _getChildConfirmations: function () {
          var oLocalModel = this.getView().getModel("local"),
            aConfirmations = oLocalModel.getProperty("/ConfirmationSet"),
            sPath = this.getView().getBindingContext("local").sPath,
            oParent = this.getView().getBindingContext("local").getObject(),
            aChildren = [];

          if (!oParent) {
            return;
          }

          aChildren = _.filter(aConfirmations, {
            Hidden: true,
            Aufnr: oParent.Aufnr,
            Vornr: oParent.Vornr,
            ParentHndl: oParent.Handle,
          });

          _.each(
            aChildren,
            jQuery.proxy(function (oChild) {
              var oFoundParticipant = _.find(
                this.getSharedModel().getProperty("/ParticipantSet"),
                jQuery.proxy(function (oPartic) {
                  return oPartic.sKey === oChild.PersNo;
                }, this)
              );

              oChild.PersName = oFoundParticipant
                ? oFoundParticipant.sName
                : "";
            }, this)
          );

          this.getView()
            .getModel("local")
            .setProperty(sPath + "/ChildConfirmations", aChildren);

          if (aChildren && aChildren.length > 0 && this._oTimeDetailForm) {
            this._oTimeDetailForm.bindElement({
              path: sPath + "/ChildConfirmations/0",
              model: "local",
            });
            // We do this because otherwise we have a bug in create conf from order
            this._oTimeDetailForm.setTitle(aChildren[0].PersNo);
          } else {
            if (this._oTimeDetailForm) {
              this._oTimeDetailForm.unbindElement();
              this._oTimeDetailForm.setTitle("");
            }
          }
        },

        _getPhotosFromDatabase: function (sParentHandle) {
          $.when(this.getDBService().getPhotoNamesById(sParentHandle)).done(
            jQuery.proxy(function (oData) {
              var oLocalModel = this.getView().getModel("local"),
                sPath = this.getView().getBindingContext("local").sPath,
                aPhotos = [];

              // for (var i = 0; i < oData.rows.length; i++) {
              // 	aPhotos.push({
              // 		PicName: oData.rows.item(i).PicName,
              // 		Handle: oData.rows.item(i).Handle
              // 	});
              // }
              aPhotos = this.getHelper().rowsToArray(oData);
              aPhotos = _.sortBy(aPhotos, "PicIndex");

              oLocalModel.setProperty(sPath + "/Photos", aPhotos);
              oLocalModel.setProperty(sPath + "/PicCount", aPhotos.length);
              this.getView()
                .getModel("newImage")
                .setProperty("/PicCount", aPhotos.length);
              oLocalModel.refresh(true);
            }, this)
          );
        },

        _getViewModel: function () {
          return this.getView().getModel("viewModel");
        },

        // _rebindPersNoBox: function (sPersNo) {
        // 	var oBox = this.getView().byId("persCombo"),
        // 		aPersNo = [];

        // 	if (sPersNo && oBox) {
        // 		if (sPersNo.indexOf(",") !== -1) {
        // 			aPersNo = sPersNo.split(",");
        // 		} else {
        // 			aPersNo.push(sPersNo);
        // 		}

        // 		oBox.setSelectedKeys(aPersNo);
        // 	}
        // },

        _getCorrespondingOperation: function (sAufnr, sVornr, sSubActivity) {
          var //oConfirmation = this.getView().getBindingContext("local").getObject(),
            d = $.Deferred();

          $.when(this.getDBService().getOperation(sAufnr, sVornr)).done(
            jQuery.proxy(function (oOperation) {
              //can only find one.
              var aOperationsList = this.getHelper().rowsToArray(oOperation);

              d.resolve(aOperationsList[0]);
            }, this)
          );

          return d.promise();
        },

        _updatePrevLongText: function (oCurrentObject, sID) {
          var sLongText = "";
          var d = $.Deferred();

          oCurrentObject.Prevlongtext = sLongText;

          $.when(
            this._getCorrespondingOperation(
              oCurrentObject.Aufnr,
              oCurrentObject.Vornr,
              ""
            )
          ).done(
            jQuery.proxy(function (oOperation) {
              if (oOperation) {
                if (oOperation.ConfText) {
                  oCurrentObject.Prevlongtext = oOperation.ConfText;
                }

                $.when(
                  this.getDBService().getConfirmationsWithParams(
                    oOperation.Orderid,
                    oOperation.Activity
                  )
                ).done(
                  jQuery.proxy(function (aConfirmations) {
                    var aConfirmationSet =
                      this.getHelper().rowsToArray(aConfirmations);

                    var aMainConfirmations = _.filter(
                      aConfirmationSet,
                      function (oConfirmation) {
                        return (
                          oConfirmation.Hidden === false ||
                          (oConfirmation.Hidden === "" &&
                            oConfirmation.Handle !== oCurrentObject.Handle)
                        );
                      }
                    );

                    _.each(
                      aMainConfirmations,
                      jQuery.proxy(function (oConfirmation) {
                        // 	var aChildConfirmations = _.filter(aConfirmationSet, function (oConf) {
                        // 		return (oConf.Hidden === true || oConf.Hidden === "true") && oConf.ParentHndl === oConfirmation.Handle;
                        // 	});

                        // 	if (aChildConfirmations.length > 0) {
                        // 		_.each(aChildConfirmations, jQuery.proxy(function (oChildConfirmation) {

                        // 			if (oChildConfirmation && oChildConfirmation.Text) {
                        // 				sLongText += oChildConfirmation.Text + "\n";
                        // 			}
                        // 		}, this));

                        // 	} else {
                        if (oConfirmation && oConfirmation.Text) {
                          sLongText += oConfirmation.Text + "\n";
                        }
                        // }
                        sLongText = sLongText.slice(0, -1);
                      }, this)
                    );

                    if (oCurrentObject.Prevlongtext === "") {
                      oCurrentObject.Prevlongtext += sLongText;
                    } else {
                      oCurrentObject.Prevlongtext += "\n" + sLongText;
                    }

                    d.resolve(oCurrentObject);
                  }, this)
                );
              }

              // if (oOperation) {
              // 	oCurrentObject.Prevlongtext = oOperation.ConfText;

              // 	for (var sId = 0; sId < sID; sId++) {
              // 		var sBindingPath = "/ConfirmationSet/" + sId,
              // 			oObject = this.getView().getModel("local").getProperty(sBindingPath);
              // 		if ((oObject.ParentHndl === oOperation.Handle)) {
              // 			if (oObject.ChildConfirmations.length > 0) {
              // 				_.each(oObject.ChildConfirmations, jQuery.proxy(function (oChildConfirmation) {

              // 					if (oChildConfirmation && oChildConfirmation.Text) {
              // 						sLongText += oChildConfirmation.Text + "\n";
              // 					}
              // 				}, this));

              // 				sLongText = sLongText.slice(0, -1);
              // 			} else {
              // 				if (oObject && oObject.Text) {
              // 					if (sId === sID - 1) {
              // 						sLongText += oObject.Text;
              // 					} else {
              // 						sLongText += oObject.Text + "\n";
              // 					}
              // 				}
              // 			}

              // 		}
              // 	}
              // }
              // if (oCurrentObject.Prevlongtext === "") {
              // 	oCurrentObject.Prevlongtext += sLongText;
              // } else {
              // 	oCurrentObject.Prevlongtext += "\n" + sLongText;
              // }
            }, this)
          );

          return d.promise();
        },

        _saveToDb: function () {
          var oLocal = this.getView().getModel("local"),
            oConfirmation = this.getView()
              .getBindingContext("local")
              .getObject(),
            sPath = this.getView().getBindingContext("local").getPath();
          if (
            this.getView().byId("persCombo") &&
            this.getView().byId("persCombo").getSelectedKeys()
          ) {
            oConfirmation.PersNo = this.getView()
              .byId("persCombo")
              .getSelectedKeys()
              .join(",");
          }
          if (oConfirmation.Split === true && oConfirmation.PersNo === "") {
            MBox.error(this.getText("MissingParticipants"));
            return;
          }
          var aChildren = oConfirmation.ChildConfirmations,
            bSplit = oConfirmation.Split,
            oValidation = null,
            sIncFields = "",
            aProm = [];
          if (!aChildren) aChildren = [];
          // var plant=oConfirmation.Plant.toString();
          // if(plant&&plant.length<4){
          // 	while (	plant.length < 4) plant = "0" + plant;
          // }
          // oConfirmation.Plant=plant;
          oValidation = this.getValidator().validateConfirmation(
            oConfirmation,
            this.getSharedModel()
          );

          if (oValidation && oValidation.isValid) {
            if (
              !this.getHelper().checkFinalConfExists(
                oLocal.getProperty("/ConfirmationSet"),
                oConfirmation.Aufnr,
                oConfirmation.Vornr,
                oConfirmation.SubActivity
              )
            ) {
              oLocal.setProperty(
                sPath + "/newConfirmationButton",
                oConfirmation.FinConf
              );
            } else {
              oLocal.setProperty(sPath + "/newConfirmationButton", true);
            }
            $.when(
              this.getDBService().replaceObject("Confirmation", oConfirmation)
            )
              .done(
                jQuery.proxy(function (oData) {
                  if (!bSplit && aChildren && aChildren.length > 0) {
                    aChildren.forEach(
                      jQuery.proxy(function (oChild) {
                        aProm.push(
                          this.getDBService().deleteObject(
                            "Confirmation",
                            oChild
                          )
                        );
                      }, this)
                    );

                    this.updateTreeTable();

                    $.when.apply($, aProm).done(
                      jQuery.proxy(function () {
                        oLocal.setProperty(sPath + "/ChildConfirmations", []);
                        MToast.show(this.getText("ConfUpdated"));
                        this.getLogs().addLog(
                          this.getText("ConfUpdated"),
                          "INFO",
                          "ConfirmationDetail"
                        );
                      }, this)
                    );
                  } else {
                    if (aChildren.length === 0) {
                      this.updateTreeTable();
                    }
                    aChildren.forEach(
                      jQuery.proxy(function (oChild) {
                        for (var sProp in oConfirmation) {
                          switch (sProp) {
                            case "ConfText":
                            case "FinConf":
                            case "Text":
                              oChild[sProp] = oConfirmation[sProp];
                              break;
                          }
                        }
                        aProm.push(
                          this.getDBService().updateObject(
                            "Confirmation",
                            oChild
                          )
                        );
                      }, this)
                    );
                    $.when
                      .apply($, aProm)
                      .done(
                        jQuery.proxy(function () {
                          MToast.show(this.getText("ConfUpdated"));
                          this.getLogs().addLog(
                            this.getText("ConfUpdated"),
                            "INFO",
                            "ConfirmationDetail"
                          );
                          this.updateTreeTable();
                        }, this)
                      )
                      .fail(
                        function () {
                          this.updateTreeTable();
                        }.bind(this)
                      );
                  }
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  MBox.error(this.getText("ConfUpdateFail"));
                  this.getLogs().addLog(
                    this.getText("ConfUpdateFail"),
                    "ERROR",
                    "ConfirmationDetail"
                  );
                }, this)
              );
          } else {
            for (var sField in oValidation.aFields) {
              if (sIncFields === "") {
                sIncFields += this.getText(oValidation.aFields[sField]);
              } else {
                sIncFields += ", " + this.getText(oValidation.aFields[sField]);
              }
            }
            MBox.error(this.getText(oValidation.sMessage, [sIncFields]));
            this.getLogs().addLog(
              this.getText(oValidation.sMessage, [sIncFields]),
              "ERROR",
              "ConfirmationDetail"
            );
          }
        },

        _copyLongTextToOperation: function (oConfirmation) {
          var sVornr = oConfirmation.Vornr,
            sAufnr = oConfirmation.Aufnr,
            sLongText = oConfirmation.Text,
            sPrevLongText = oConfirmation.PrevLongText;

          $.when(this.getDBService().getEntitySet("Operation")).done(
            jQuery.proxy(function (aOperations) {
              var aOperationsList = this.getHelper().rowsToArray(aOperations);

              var oFoundOperation = _.find(
                aOperationsList,
                jQuery.proxy(function (oOperation) {
                  return (
                    oOperation.Activity === sVornr &&
                    oOperation.Orderid === sAufnr
                  );
                }, this)
              );

              if (oFoundOperation) {
                oFoundOperation.ConfText = sPrevLongText + " " + sLongText;

                $.when(
                  this.getDBService().updateObject("Operation", oFoundOperation)
                ).done(
                  jQuery.proxy(function () {
                    //nothing yet
                  }, this)
                );
              }
            }, this)
          );
        },

        _createSubConfirmations: function () {
          var oLocalModel = this.getView().getModel("local"),
            oViewModel = this._getViewModel(),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oParentConfirm = oLocalModel.getProperty(sCurrPath),
            aConfParticipants,
            perNos = oLocalModel.getProperty(sCurrPath).PersNo,
            // sSelectedPerson = oViewModel.getProperty("/SelectedPerson"),
            aCurrPersons =
              oLocalModel.getProperty(sCurrPath + "/ChildConfirmations") || [],
            aConfirmations = oLocalModel.getProperty("/ConfirmationSet");
          if (perNos && typeof perNos === "string") {
            aConfParticipants = perNos.split(",").filter(Boolean);
          } else if (perNos) {
            aConfParticipants = perNos.filter(Boolean);
          }
          _.each(
            aConfParticipants,
            jQuery.proxy(function (oParticipant) {
              var oNewConf = {};

              for (var sProp in oParentConfirm) {
                oNewConf[sProp] = oParentConfirm[sProp];
              }

              var oFoundParticipant = _.find(
                this.getSharedModel().getProperty("/ParticipantSet"),
                jQuery.proxy(function (oPartic) {
                  return oPartic.sKey === oParticipant;
                }, this)
              );

              oNewConf.Handle = this.getHelper().getUUID();
              oNewConf.PersNo = oParticipant;
              oNewConf.PersName = oFoundParticipant
                ? oFoundParticipant.sName
                : "";
              // oNewConf.ExecStart = "";
              oNewConf.ExecFin = "";
              oNewConf.ActWork = "";
              // oNewConf.FinConf = oParentConfirm.FinConf;
              oNewConf.IsFinished = false;
              oNewConf.Hidden = true;
              oNewConf.ParentHndl = oParentConfirm.Handle;
              oNewConf.Split = false;
              oNewConf.ExecutantCnt = 1; // IMPORTANT - Otherwise causes bugs in backend
              delete oNewConf.ChildConfirmations;

              aCurrPersons.push(oNewConf);

              oViewModel.setProperty("/SelectedPerson", "");
              oLocalModel.setProperty(
                sCurrPath + "/ChildConfirmations",
                aCurrPersons
              );

              this.getDBService().insertObject("Confirmation", oNewConf);

              aConfirmations.push(oNewConf);
            }, this)
          );
          oLocalModel.setProperty("/ConfirmationSet", aConfirmations);
        },

        _clearSubConfirmations: function () {
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oParentConfirm = oLocalModel.getProperty(sCurrPath),
            aChildConfirmations = oParentConfirm.ChildConfirmations;

          oParentConfirm.ChildConfirmations = [];

          _.each(
            aChildConfirmations,
            jQuery.proxy(function (oChildConf) {
              this.getDBService().deleteObject("Confirmation", oChildConf);
            }, this)
          );

          this.getDBService().updateObject("Confirmation", oParentConfirm);
        },

        onCreateNotificationConfirmPress: function () {
          //this._saveToDb();
          var orderTypeModel = new sap.ui.model.json.JSONModel();
          this.orderFound = _.find(
            this.getView()
              .getModel("local")
              .getProperty("/PMOrderSetDataWithConf"),
            jQuery.proxy(function (oOrder) {
              return (
                oOrder.Orderid ===
                this.getView().getBindingContext("local").getObject().Aufnr
              );
            }, this)
          );

          var orderType = this.orderFound.OrderType;
          this.getView().setModel(orderTypeModel, "orderTypeModel");
          $.when(this.getHelper().getNotificationTypeOrderTypeLinkage())
            .done(
              jQuery.proxy(function (oResult) {
                oResult.OrderType[orderType].forEach(
                  jQuery.proxy(function (oRes) {
                    oRes.Description = this.getText(oRes.Description);
                  }, this)
                );
                orderTypeModel.setProperty(
                  "/NotifType",
                  oResult.OrderType[orderType]
                );
                //orderTypeModel.setProperty("/NotifType", oResult.OrderType['P010']);
                //Qmcod is only needed at sending data to backend. So using it to store order type of Follow Up notification
                orderTypeModel.setProperty("/Qmcod", orderType);
                this.getDialogManager().open(
                  "notifications.NotificationTypePopUp",
                  this.getView()
                );
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                console.debug("Error: " + oError);
              }, this)
            );
        },

        onNotificationTypeSelected: function (oEvent) {
          this.getDialogManager().close(
            "notifications.NotificationTypePopUp",
            this.getView()
          );
          var orderTypeModel = this.getView().getModel("orderTypeModel");
          if (this.getView().getBindingContext("local").getObject().Vornr) {
            var oOperation = _.find(
              this.orderFound.NavOperation,
              jQuery.proxy(function (oOrder) {
                return (
                  oOrder.Activity ===
                  this.getView().getBindingContext("local").getObject().Vornr
                );
              }, this)
            );
            if (oOperation.FunctLoc) {
              orderTypeModel.setProperty("/Tplnr", oOperation.FunctLoc);
            } else {
              orderTypeModel.setProperty("/Tplnr", this.orderFound.FunctLoc);
            }
            if (oOperation.Equipment) {
              orderTypeModel.setProperty("/Equnr", oOperation.Equipment);
            } else {
              orderTypeModel.setProperty("/Equnr", this.orderFound.Equipment);
            }
          } else {
            orderTypeModel.setProperty("/Equnr", this.orderFound.Equipment);
            orderTypeModel.setProperty("/Tplnr", this.orderFound.FunctLoc);
          }

          var notifPath = oEvent.getSource().getSelectedItem().getId();
          notifPath = notifPath.slice(notifPath.lastIndexOf("-") + 1);
          var notifData = orderTypeModel.getData().NotifType[notifPath];
          //orderTypeModel.setProperty("/Text", notifData.Description + " number " + this.orderFound.Orderid);
          orderTypeModel.setProperty(
            "/Text",
            this.getText("FollowUpNotifDesc", [this.orderFound.Orderid])
          );
          orderTypeModel.setProperty("/Qmtxt", this.orderFound.ShortText);
          orderTypeModel.setProperty("/Qmgrp", notifData.CodeGrp);
          //QMARTCombine
          orderTypeModel.setProperty(
            "/Qmart",
            notifData.Type + "," + notifData.Code
          );
          orderTypeModel.setProperty("/Codgrr", notifData.CodeGrp);
          //orderTypeModel.setProperty("/Qmcod", notifData.Code);
          //orderTypeModel.setProperty("/Qmcod", notifData.Code);
          orderTypeModel.setProperty("/OrderHandle", this.orderFound.Orderid);
          orderTypeModel.setProperty("/DisabledForNotifFromOrder", false);
          if (notifData.Type === "30,DEFE") {
            orderTypeModel.setProperty("/Msaus", true);
          }
          if (this._bFromOrderList) {
            orderTypeModel.setProperty(
              "/ConfId",
              this._getViewModel().getProperty("/ConfID")
            );
          } else {
            orderTypeModel.setProperty("/ConfId", false);
          }
          this.getView()
            .getModel("local")
            .setProperty("/NotBoundNotifFromOrder", orderTypeModel.getData());
          //this.getView().getModel("orderTypeModel").setProperty("/","");
          this.getRouter().navTo("CreateNotificationFromOrder");
        },

        onNotificationTypePopUpCancelPress: function () {
          this.getDialogManager().close(
            "notifications.NotificationTypePopUp",
            this.getView()
          );
        },

        updateTreeTable: function () {
          var oPromOrders = this.getDBService().getEntitySet("PMOrder"),
            oPromOperations = this.getDBService().getEntitySet("Operation"),
            oPromConfirmations =
              this.getDBService().getEntitySet("Confirmation"),
            oPromParticipants = this.getDBService().getEntitySet("Participant"),
            oPromNotification =
              this.getDBService().getEntitySet("PMNotification");

          $.when(
            oPromOrders,
            oPromOperations,
            oPromConfirmations,
            oPromParticipants,
            oPromNotification
          )
            .done(
              jQuery.proxy(function (
                oDataOrder,
                oDataOperation,
                oConfirmations,
                oParticipants,
                oNotification
              ) {
                var oLocalModel = this.getView().getModel("local"),
                  aOrderSet = this.getHelper().rowsToArray(oDataOrder),
                  aOperationSet = this.getHelper().rowsToArray(oDataOperation),
                  aConfirmationSet =
                    this.getHelper().rowsToArray(oConfirmations),
                  oParticipantsSet =
                    this.getHelper().rowsToArray(oParticipants),
                  oNotificationSet =
                    this.getHelper().rowsToArray(oNotification),
                  oFoundOrder;
                _.each(aConfirmationSet, function (oConf) {
                  for (var sProp in oConf) {
                    if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                      oConf[sProp] = oConf[sProp] === "true" ? true : false;
                    }
                  }
                  oFoundOrder = _.find(
                    aOrderSet,
                    jQuery.proxy(function (oOrder) {
                      return oOrder.Orderid === oConf.Aufnr;
                    }, this)
                  );
                  if (!oFoundOrder) {
                    oConf.nonExistingOrder = oConf.NotifHandle ? false : true;
                  }
                });

                if (!oLocalModel.getProperty("/PMOrderSetDataWithConf")) {
                  oLocalModel.setProperty("/PMOrderSetDataWithConf", []);
                }
                // if (!oLocalModel.getProperty("/PMOrderSet")) {
                // 	oLocalModel.setProperty("/PMOrderSet", []);
                // }
                aConfirmationSet =
                  this._determineColorsConfirmation(aConfirmationSet);
                aOrderSet = this._linkforTreeTable(
                  aOrderSet,
                  aOperationSet,
                  aConfirmationSet,
                  oParticipantsSet,
                  oNotificationSet
                );
                aOrderSet.push([]);
                //	var aOrderSet1 = this._linknotiftoConfirmations(aNotificationSet, aConfirmationSet, oParticipantsSet);

                this.aOrderSet = aOrderSet;
                oLocalModel.setProperty("/PMOrderSetDataWithConf", aOrderSet);
                //oLocalModel.setProperty("/PMOrderSet", aOrderSet);
              },
              this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("OrderDBRetrieveFailed"));
              }, this)
            );
        },

        _linkforTreeTable: function (
          aOrders,
          aOperations,
          aConfirmations,
          oParticipantsSet,
          oNotifications
        ) {
          var _aOrders = aOrders,
            _aOperations = aOperations,
            _oNotifications = oNotifications;

          aConfirmations.forEach(function (oConf) {
            oConf.multiplePers = true;
            if (oConf.PersNo.split(",").length > 1) {
              oConf.PersName = "";
              oConf.PersNo.split(",").forEach(function (Persno) {
                for (var i = 0; i < oParticipantsSet.length; i++) {
                  if (Persno === oParticipantsSet[i].Pernr) {
                    oConf.PersName =
                      oConf.PersName + oParticipantsSet[i].Sname + ",";
                  }
                }
              });
              oConf.multiplePers = false;
              oConf.PersName = oConf.PersName.slice(0, -1);
            } else {
              for (var i = 0; i < oParticipantsSet.length; i++) {
                if (oConf.PersNo === oParticipantsSet[i].Pernr) {
                  oConf.PersName = oParticipantsSet[i].Sname;
                }
              }
            }
          });
          this.getEventBus().publish(
            "modularize",
            "CheckExistingOrderConf",
            aConfirmations
          );

          var newOrders =
            this.getModel("local").getProperty("/nonExistingOrder");
          _aOperations = _aOperations.concat(newOrders[1]);
          _aOrders = _aOrders.concat(newOrders[0]);
          _aOperations.forEach(
            jQuery.proxy(function (oOperation) {
              var Confirm = _.filter(aConfirmations, {
                Aufnr: oOperation.Orderid,
                Vornr: oOperation.Activity,
                SubActivity: oOperation.SubActivity,
                Split: false,
              });
              oOperation.Confirm = _.sortBy(Confirm, "ExecStart").reverse();
              if (oOperation.Confirm.length > 0) {
                oOperation.Color = this._determineColors(oOperation);
              } else if (oOperation.Activity) {
                var oCheckOperation = this.getHelper().checkOperationValid(
                  oOperation.Orderid,
                  oOperation
                );
                var cnfOperation = oOperation.ConfFinal === "X";
                if (
                  oCheckOperation.ControlKeyIsValid === false ||
                  oCheckOperation.PMEXValid === false ||
                  cnfOperation === true
                ) {
                  oOperation.Color = "red";
                } else {
                  oOperation.Color = "default";
                }
              }
            }, this)
          );
          _aOrders.forEach(
            jQuery.proxy(function (oOrder) {
              var Confirm = _.filter(aConfirmations, {
                Aufnr: oOrder.Orderid,
                Vornr: "",
                Split: false,
              });
              oOrder.Confirm = _.sortBy(Confirm, "ExecStart").reverse();
              if (oOrder.Confirm.length > 0) {
                oOrder.Color = this._determineColors(oOrder);
              } else oOrder.Color = "default";
              oOrder.NavOperation = _.filter(_aOperations, {
                Orderid: oOrder.Orderid,
              });
            }, this)
          );

          _oNotifications.forEach(
            jQuery.proxy(function (oNotif) {
              oNotif.Confirm = [];
              if (oNotif.Handle) {
                var oCorrespondingConf = aConfirmations.filter(function (
                  oConf
                ) {
                  return (
                    oNotif.Handle === oConf.NotifHandle &&
                    oNotif.Qmnum === "" &&
                    oConf.Split === false
                  );
                });
              }
              if (oCorrespondingConf) {
                oNotif.Confirm = _.sortBy(
                  oCorrespondingConf,
                  "ExecStart"
                ).reverse();
              }
              //qmartcombine
              oNotif.NotifTypeText = this.getNotifTypeText(
                oNotif.Qmart,
                oNotif.Qmcod
              );
            }, this)
          );
          _oNotifications = _.filter(oNotifications, function (oNotif) {
            return oNotif.Confirm.length;
          });
          _oNotifications.forEach(
            jQuery.proxy(function (notif) {
              notif.Color = this._determineColors(notif);
              _aOrders.unshift(notif);
            }, this)
          );
          return _aOrders;
        },

        confirmationBlocker: function (
          oLocalModel,
          sPath,
          oObject,
          dateTimePicker,
          participantChange
        ) {
          var runningConfirmations;
          var oConfirmations = _.filter(
            this.getView().getModel("local").getProperty("/ConfirmationSet"),
            { Split: false }
          );
          runningConfirmations = _.filter(
            oConfirmations,
            jQuery.proxy(function (conf) {
              if (conf && oObject.Handle !== conf.Handle) {
                if (
                  conf.ExecStart &&
                  !conf.ExecFin &&
                  this.checkIncluded(oObject.PersNo, conf.PersNo)
                ) {
                  return true;
                }
                return false;
              }
            }, this)
          );
          //	path="/ConfirmationSet/"+path;
          if (runningConfirmations.length > 0) {
            for (var i = 0; i < runningConfirmations.length; i++) {
              var personDisplayed = "",
                PersName = "";
              if (oObject.PersNo) {
                var persNoArray = oObject.PersNo.split(",");
                if (persNoArray.length > 0) {
                  persNoArray.forEach(
                    jQuery.proxy(function (person) {
                      if (
                        person &&
                        runningConfirmations[i].PersNo.includes(person)
                      ) {
                        if (personDisplayed)
                          personDisplayed = personDisplayed + "," + person;
                        else personDisplayed = person;
                        var partcipants = _.filter(
                          this.getSharedModel().getProperty("/ParticipantSet"),
                          {
                            sKey: person,
                          }
                        );
                        if (PersName) {
                          PersName = PersName + "," + partcipants[0].sName;
                        } else PersName = partcipants[0].sName;
                      }
                    }, this)
                  );
                }
              }
              var slashText = runningConfirmations[i].Vornr ? "/" : "";
              if (!runningConfirmations[i].Vornr)
                runningConfirmations[i].Vornr = "";
              MBox.error(
                this.getText("ConfirmationBlockText", [
                  personDisplayed,
                  PersName,
                  runningConfirmations[i].Aufnr,
                  slashText,
                  runningConfirmations[i].Vornr,
                ])
              );
            }
            //To Stop Confirmation Time Start button from starting
            if (dateTimePicker) {
              oLocalModel.setProperty(sPath + "/ExecStart", "");
            }
            if (participantChange) {
              return true;
            }
          } else {
            if (participantChange) {
              return false;
            }
            if (dateTimePicker) {
              oLocalModel.setProperty(sPath + "/ExecStart", dateTimePicker);
            } else {
              oLocalModel.setProperty(
                sPath + "/ExecStart",
                new moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
              );
              this.getDBService().updateObject("Confirmation", oObject);
            }
          }
        },

        createConfirmationPress: function () {
          var oLocalModel = this.getView().getModel("local"),
            sCurrPath = this.getView().getBindingContext("local").getPath(),
            oObject = oLocalModel.getProperty(sCurrPath);
          if (oObject.PersNo && oObject.PersNo.trim()) {
            if (oObject.Aufnr) {
              this.getRouter().navTo("createConfirmationFromOrder", {
                Aufnr: oObject.Aufnr,
                Vornr: oObject.Vornr,
                SubActivity: oObject.SubActivity,
                ConfText: oObject.ConfText,
                PersNo: oObject.PersNo,
                WorkCntr: oObject.WorkCntr,
                FromConfirmation: true,
              });
            } else {
              let MnWkCtr = oObject.WorkCntr
                ? oObject.WorkCntr
                : this.getSharedModel().getProperty("/sapSettings/GEWRK");
              if (!MnWkCtr) {
                MnWkCtr =
                  this.getSharedModel().getProperty("/sapSettings/ARBPL");
              }
              const oEventData = {
                NotifHandle: oObject.NotifHandle,
                WorkCntr: oObject.WorkCntr,
                MnWkCtr: MnWkCtr,
                PersNo: oObject.PersNo,
                Handle: this.getHelper().getUUID(),
                IsFinished: false,
                UnWork: oObject.UnWork,
                Split: false,
                // FromOrderHeader: false,
                // FromOrder: false,
                Plant: oObject.Plant,
                ExecutantCnt: oObject.ExecutantCnt,
                WorkCntr: oObject.WorkCntr,
                Pmacttype: oObject.Pmacttype,
              };
              if (oObject.ConfText) {
                oEventData.ConfText = oObject.ConfText;
              }
              this.getEventBus().publish(
                "modularize",
                "createNotifConf",
                oEventData
              );
            }
          } else {
            MBox.error(this.getText("PernrSelect"));
          }
        },

        _determineColorsConfirmation: function (aConfirmationSet) {
          _.each(
            aConfirmationSet,
            jQuery.proxy(function (aConf) {
              if (aConf.FinConf) {
                if (aConf.IsFinished) {
                  aConf.Color = "green";
                } else {
                  aConf.Color = "purple";
                }
              } else {
                if (aConf.IsFinished) {
                  aConf.Color = "blue";
                } else {
                  aConf.Color = "orange";
                }
              }
            }, this)
          );

          return aConfirmationSet;
        },

        _determineColors: function (aSet) {
          var colour = ["default", "orange", "blue", "purple", "green"];
          var ColourKey = 5,
            ColourIndex;
          aSet.Confirm.forEach(
            jQuery.proxy(function (oConf) {
              switch (oConf.Color) {
                case "orange":
                  ColourIndex = 1;
                  break;
                case "blue":
                  ColourIndex = 2;
                  break;
                case "purple":
                  ColourIndex = 3;
                  break;
                case "green":
                  ColourIndex = 4;
                  break;
                default:
                  ColourIndex = 0;
                  break;
              }
              if (ColourIndex) {
                ColourKey = ColourKey >= ColourIndex ? ColourIndex : ColourKey;
              }
            })
          );
          if (ColourIndex === 0 && ColourKey === 5) {
            return colour[ColourIndex];
          } else {
            return colour[ColourKey];
          }
        },

        getNotifTypeText: function (qmart) {
          if (qmart) {
            var sQmart = _.filter(
              this.getSharedModel().getProperty("/vh/Qmart"),
              {
                Key: qmart,
              }
            );
            // var sQmcod = _.filter(this.getSharedModel().getProperty("/vh/Catalog"),{
            // 	Qmart:qmart,
            // 	Code:qmcod
            // });
            if (sQmart.length > 0) return this.getText(sQmart[0].Description);
          }
        },

        checkIncluded: function (main, row) {
          var persNoArray;
          if (main) {
            persNoArray = persNoArray = main.split(",");
            if (persNoArray.length == 1) {
              return row.includes(main);
            } else {
              if (
                persNoArray.find(function (person) {
                  if (person && row.includes(person)) {
                    return true;
                  }
                })
              ) {
                return true;
              }
            }
          }
          return false;
        },

        findPath: function (handle) {
          var i = 0,
            path = null;
          _.filter(
            this.getView().getModel("local").getProperty("/ConfirmationSet"),
            jQuery.proxy(function (conf) {
              if (conf) {
                i++;
                if (handle === conf.Handle) {
                  path = i;
                  return true;
                }
                return false;
              }
            }, this)
          );
          return path - 1;
        },

        closeMessageLog: function () {
          this.getDialogManager().close(
            "fragments.MessageFragment",
            this.getView()
          );
        },
      }
    );
  }
);
