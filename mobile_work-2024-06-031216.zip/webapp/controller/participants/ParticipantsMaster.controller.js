/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "mobilework/model/wParticipants",
    "mobilework/model/zoneData",
    "mobilework/model/tables/TimeInOut",
  ],
  function (Controller, MToast, MBox, wParticipants, zoneData, TimeInOut) {
    "use strict";
    /**
     *
     * @namespace mobilework.controller.participants.ParticpantMaster
     * @param {mobilework.controller.BaseController} Controller - Base Controller
     * @param {mobilework.util.Formatter} Format - Sap Core Controller
     * @param {sap.m.MessageBox} MBox - Sap Message Box Control
     * @param {mobilework.model.wParticipants} wParticipants - Public Partcpants table structure returned by WAI
     * @param {mobilework.model.wParticipants} zoneData - Public zoneData table structure returned by WAI
     * @param {mobilework.model.tables.TimeInOut} TimeInOut - A table structure to verify time registration  to confirmations start and end
     * @returns {mobilework.controller.participants.ParticipantsMaster} The instance of the App controller class.
     */
    return Controller.extend(
      "mobilework.controller.participants.ParticipantsMaster",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        /** @type sap.m.Dialog */
        oAddParticipantDialog: null,

        /** @type sap.m.Dialog */
        oBarcodeConfirmDialog: null,

        /** @type sap.m.List */
        oMasterList: null,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onInit: function () {
          this.getRouter()
            .getRoute("participantsMaster")
            .attachMatched(this.onRouteMatched, this);
          //subscribe to scanner
          this.getEventBus().subscribe(
            "scanner",
            "scannedParticpantMaster",
            this.onExtScanSuccess,
            this
          );

          this._initModels();
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function (oEvent) {
          //set scanner location
          this.getScanHandler().setLocation("ParticpantMaster");

          //set connection property
          this.getConnection();

          if (!this.oMasterList) {
            this.oMasterList = this.getView().byId("particMasterList");
          }
          this.oMasterList.removeSelections(true);
          this._getParticipantsFromDb();
          this.changeColorOfDeviceId();
          this.getOngoingCnfPartcipants();
        },

        onAddPress: function (oEvent) {
          var oDialog = this._getAddParticipantDialog();

          this.getSharedModel().setProperty("/fieldEntered", "");
          oDialog.open();
        },

        onNavBack: function () {
          this.getRouter().navTo("main", true);
        },

        onItemDeletePress: function (oEvent) {
          var oObject = oEvent
            .getParameter("listItem")
            .getBindingContext("local")
            .getObject();

          this.oObject = oObject;

          if (
            this.getSharedModel().getProperty("/publicRelease") &&
            oObject.TrZone
          ) {
            //MBox.error(oObject.Pernr + " can't delete as the particpant is already in zone "+oObject.TrZone);
            MBox.error(
              this.getText("PCantBeDeleted", [oObject.Pernr, oObject.TrZone])
            );
            return;
          }
          $.when(this.getDBService().deleteObject("Participant", oObject))
            .done(
              jQuery.proxy(function () {
                var oPromDeleteHash;
                if (this.getSharedModel().getProperty("/publicRelease")) {
                  oPromDeleteHash = this.getDBService().deleteObject(
                    "wParticipants",
                    { amei: oObject.Pernr },
                    wParticipants.key.propertyRef
                  );
                }
                $.when(oPromDeleteHash)
                  .done(
                    jQuery.proxy(function () {
                      this._getParticipantsFromDb();
                      if (this.oObject.Arbpl) {
                        MToast.show(this.getText("ArbplDeleted"));
                      } else {
                        MToast.show(this.getText("ParticDeleted"));
                      }
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      this._getParticipantsFromDb();
                      if (this.oObject.Arbpl) {
                        MToast.show(this.getText("ArbplDeleted"));
                      } else {
                        MToast.show(this.getText("ParticDeleted"));
                      }
                    }, this)
                  );
              }, this)
            )
            .fail(jQuery.proxy(function () {}, this));
        },

        onDeleteAllPress: function () {
          if (this.getSharedModel().getProperty("/publicRelease")) {
            let zoned = _.find(
              this.getModel("local").getProperty("/ParticipantSet"),
              function (obj) {
                return obj.TrZone;
              }.bind(this)
            );
            if (zoned) {
              //MBox.error("Some participants are in the zone. Please exit the zones before deleting.")
              MBox.error(this.getText("ExitZonesBeforeDeleting"));
              return;
            }
          }
          MBox.confirm(this.getText("ConfirmDeleteAllPartic"), {
            onClose: jQuery.proxy(this.onDeleteAllConfirm, this),
          });
        },

        onDeleteAllConfirm: function (sAction) {
          if (sAction === "OK") {
            $.when(this.getDBService().deleteAllObjects("Participant"))
              .done(
                jQuery.proxy(function () {
                  this._getParticipantsFromDb();
                  MToast.show(this.getText("AllParticDeleted"));
                }, this)
              )
              .fail(jQuery.proxy(function () {}, this));
          }
        },

        onParticipantCreated: function (res, oParticipant) {
          var oLocalModel = this.getView().getModel("local"),
            oSharedModel = this.getSharedModel(),
            aLocalParticipantSet = [];

          if (!oLocalModel.getProperty("/ParticipantSet")) {
            oLocalModel.setProperty("/ParticipantSet", []);
          }

          oSharedModel.setProperty("/hasParticipants", true);

          aLocalParticipantSet = oLocalModel.getProperty("/ParticipantSet");
          aLocalParticipantSet.push(oParticipant);
          aLocalParticipantSet = _.sortBy(
            aLocalParticipantSet,
            "Ename",
            "Pernr"
          );
          oLocalModel.setProperty("/ParticipantSet", aLocalParticipantSet);

          $.when(this._getParticipantsFromDb()).done(
            jQuery.proxy(function () {
              this.onGetInfoPress();
              console.debug("stored");
            }, this)
          );
          if (this.oAddParticipantDialog) {
            this.oAddParticipantDialog.close();
          }
          if (this.oBarcodeConfirmDialog) {
            this.oBarcodeConfirmDialog.close();
          }
        },

        onScanPress: function (oEvent) {
          var publicRelease =
            this.getModel("shared").getProperty("/publicRelease");
          if (publicRelease) {
            this._onPublicScan();
          } else {
            $.when(this.getScanHandler().scan())
              .done(jQuery.proxy(this.onScanSuccess, this))
              .fail(
                jQuery.proxy(function (oError) {
                  MToast.show(this.getText("ScanIssue"));
                }, this)
              );
          }
        },

        onExtScanSuccess: function (sChannel, sEvent, oData) {
          if (!oData.result.error) {
            this.onScanSuccess({
              text: oData.result.barcode,
            });
          } else {
            MBox.error(oData.result.errorMessage);
          }
        },
        /**
         * Issue 58 in 13.0
         *
         * Field 'Personnel number' in screen 'New participants is limited to 8 characters.
         * This makes it impossible to read a set of participants using a barcode.
         * The slice of 8 characters is removed- Thus for adding multiple participants is possible
         * @memberOf mobilework.controller.participants.ParticpantMaster
         * @public
         */
        onScanSuccess: function (oData) {
          if (!oData.cancelled) {
            var oBarcodeModel = this.getView().getModel("barcode"),
              oDialog = this._getBarcodeConfirmDialog();

            oBarcodeModel.setProperty("/value", oData.text); // Maxlength 8

            oDialog.open();
          }
        },

        onRfidMandPress: function (oEvent) {
          MBox.alert(this.getText("rfidMandMessage"));
        },

        //====
        // for AddParticipantDialog
        //====

        onAddDialogConfirmPress: function (oEvent) {
          this._manualCreateParticipant();
        },

        onAddDialogCancelPress: function (oEvent) {
          this.getView().getModel("newPartic").setProperty("/Pernr", "");
          this.getView().getModel("newPartic").setProperty("/Arbpl", "");

          this.oAddParticipantDialog.close();
        },

        onParticipantArbplChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oNewParticModel = this.getView().getModel("newPartic");

          if (sValue) {
            oNewParticModel.setProperty("/Arbpl", sValue.toUpperCase());
          }
        },

        //===
        // for BarcodeConfDialog
        //===

        onBarcodeConfirmPress: function (oEvent) {
          var oNewParticModel = this.getView().getModel("newPartic"),
            oBarcodeModel = this.getView().getModel("barcode");

          oNewParticModel.setProperty("/", {});

          if (oBarcodeModel.getProperty("/selectedType") === "pernr") {
            oNewParticModel.setProperty(
              "/Pernr",
              oBarcodeModel.getProperty("/value")
            );
            oNewParticModel.setProperty("/Arbpl", "");
          } else {
            oNewParticModel.setProperty(
              "/Arbpl",
              oBarcodeModel.getProperty("/value")
            );
            oNewParticModel.setProperty("/Pernr", "");
          }

          this._manualCreateParticipant();
        },

        onBarcodeCancelPress: function (oEvent) {
          this.oBarcodeConfirmDialog.close();
        },

        onGetInfoPress: function (oEvent, publicParticipants) {
          var aParticipants =
              this.getModel("local").getProperty("/ParticipantSet"),
            aIncorrectList = [],
            aFilters = [],
            d = jQuery.Deferred();

          if (
            this.getSharedModel().getProperty("/publicRelease") &&
            publicParticipants
          ) {
            aParticipants = aParticipants.concat(publicParticipants);
          }
          for (var i in aParticipants) {
            if (aParticipants[i].Pernr) {
              aFilters.push(
                new sap.ui.model.Filter({
                  path: "Pernr",
                  operator: sap.ui.model.FilterOperator.EQ,
                  value1: aParticipants[i].Pernr,
                })
              );
            } else {
              aFilters.push(
                new sap.ui.model.Filter({
                  path: "Arbpl",
                  operator: sap.ui.model.FilterOperator.EQ,
                  value1: aParticipants[i].Arbpl,
                })
              );
              aFilters.push(
                new sap.ui.model.Filter({
                  path: "Swerk",
                  operator: sap.ui.model.FilterOperator.EQ,
                  value1:
                    this.getSharedModel().getProperty("/sapSettings/SWERK"),
                })
              );
            }
          }

          $.when(this.getService().getParticipantData(aFilters))
            .done(
              jQuery.proxy(function (oParticipantData) {
                if (
                  oParticipantData &&
                  oParticipantData.results &&
                  (oParticipantData.results.length > 0 ||
                    oParticipantData.results.length === 0)
                ) {
                  // Valid pernr entered.

                  //for each existing participant in frontend.
                  _.each(
                    this.getModel("local").getProperty("/ParticipantSet"),
                    jQuery.proxy(function (oParticipant) {
                      //if (oParticipant && oParticipant.Pernr) {
                      //find corresponding participant data retrieved from backend.
                      var oExistParticipant = _.find(
                        oParticipantData.results,
                        jQuery.proxy(function (oFoundParticipant) {
                          return (
                            parseInt(oFoundParticipant.Pernr) ===
                              parseInt(oParticipant.Pernr) ||
                            (oFoundParticipant.Pernr === "00000000" &&
                              oFoundParticipant.Arbpl === oParticipant.Arbpl)
                          );
                        }, this)
                      );

                      // if oExistParticipant doesn't exist, pernr is incorrect.
                      if (!oExistParticipant) {
                        if (oParticipant.Pernr) {
                          aIncorrectList.push(oParticipant.Pernr);
                        } else {
                          aIncorrectList.push(oParticipant.Arbpl);
                        }

                        $.when(
                          this.getDBService().deleteObject(
                            "Participant",
                            oParticipant
                          )
                        )
                          .done(jQuery.proxy(function () {}, this))
                          .fail(jQuery.proxy(function () {}, this));
                      }
                      //}
                    }, this)
                  );

                  var sMsg = "";
                  for (var y in aIncorrectList) {
                    if (sMsg === "") {
                      sMsg = aIncorrectList[y];
                    } else if (parseInt(y) === aIncorrectList.length - 1) {
                      sMsg += ", " + aIncorrectList[y];
                    } else {
                      sMsg += ", " + aIncorrectList[y];
                    }
                  }

                  if (aIncorrectList.length > 0) {
                    MBox.error(
                      this.getText("IncorrectParticipantsDeleted", sMsg)
                    );
                  }

                  if (oParticipantData.results.length > 0) {
                    $.when(
                      this.getDBService().updateParticipants(
                        "Participant",
                        oParticipantData.results,
                        this.getModel("local").getProperty("/ParticipantSet")
                      )
                    )
                      .done(
                        jQuery.proxy(function (oData) {
                          this._getParticipantsFromDb(d);
                          this.getLogs().addLog(
                            "Participants Updated",
                            "INFO",
                            "ParticipantsMaster"
                          );
                        }, this)
                      )
                      .fail(function () {
                        d.reject();
                      });
                  } else {
                    this._getParticipantsFromDb(d);
                  }

                  if (this.getSharedModel().getProperty("/publicRelease")) {
                    var publicParticipants = this.getView()
                      .getModel("local")
                      .getProperty("/publicParticipants");

                    if (publicParticipants && publicParticipants.length) {
                      var notAdded = "";
                      publicParticipants.filter(function (row) {
                        if (
                          !_.find(oParticipantData.results, {
                            Pernr: row.Pernr,
                          })
                        ) {
                          notAdded = notAdded
                            ? notAdded + ", " + row.oValue1
                            : row.Pernr;
                        }
                      });
                      if (notAdded) {
                        MBox.error(this.getText("ValidParticipants", notAdded));
                        //MBox.error(notAdded+ ' is not available in SAP.Please provide valid particpants');
                      }
                      this.getModel("local").setProperty(
                        "/publicParticipants",
                        []
                      );
                    }
                  }
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                if (oError.offline === true) {
                  MBox.error(this.getText("NoNetwork"));
                  this.getLogs().addLog(
                    this.getText("NoNetwork"),
                    "ERROR",
                    "ParticipantsMaster"
                  );
                  this.getView().setBusy(false);
                } else if (oError.connection === false) {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                  this.getLogs().addLog(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap"),
                    "ERROR",
                    "ParticipantsMaster"
                  );
                  this.getView().setBusy(false);
                }
                d.reject();
              }, this)
            );
          return d.promise();
        },

        onInputLiveChange: function (oEvent) {
          if (
            oEvent.getSource().getId().indexOf("pernr") !== -1 &&
            oEvent.getParameters().newValue !== ""
          ) {
            this.getSharedModel().setProperty("/fieldEntered", "PERNR");
          } else if (
            oEvent.getSource().getId().indexOf("arbpl") !== -1 &&
            oEvent.getParameters().newValue !== ""
          ) {
            this.getSharedModel().setProperty("/fieldEntered", "ARBPL");
          } else {
            this.getSharedModel().setProperty("/fieldEntered", "");
          }
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//et

        getMasterItemIcon: function (sPernr, sColor, aZonedBadges, zonedTime) {
          //Dev: 1015320 | V2024- MWX- Frontend- Different the participant registered in a zone | Issue 35 in tracker MWX 13.1
          if (this.getSharedModel().getProperty("/publicRelease")) {
            if (aZonedBadges) {
              if (sPernr) {
                if (sColor === "#008000") {
                  if (zonedTime !== "" && zonedTime !== undefined) {
                    return "sap-icon://employee-approvals";
                  } else if (sPernr) {
                    return "sap-icon://employee";
                  } else {
                    return "sap-icon://collaborate";
                  }
                } else if (sPernr) {
                  return "sap-icon://employee";
                } else {
                  return "sap-icon://collaborate";
                }
              }
            } else if (sPernr) {
              return "sap-icon://employee";
            } else {
              return "sap-icon://collaborate";
            }
          }
          // V2024- MWX- Frontend- Different the participant registered in a zone ***Ends***
          else {
            if (sPernr) {
              return "sap-icon://employee";
            } else {
              return "sap-icon://collaborate";
            }
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _checkUnqiue: function (oParticipant) {
          var oLocalModel = this.getView().getModel("local"),
            aParticipants = oLocalModel.getProperty("/ParticipantSet"),
            sValueToFind = oParticipant.Pernr || oParticipant.Arbpl,
            oObjectToFind = oParticipant.Pernr
              ? {
                  Pernr: sValueToFind,
                }
              : {
                  Arbpl: sValueToFind,
                  Pernr: "",
                },
            oResult = _.find(aParticipants, oObjectToFind);

          if (!oResult) {
            oResult = _.find(aParticipants, function (oPartic) {
              return parseInt(oPartic.Pernr) === parseInt(oObjectToFind.Pernr);
            });
          }
          if (oResult) {
            if (oResult.Arbpl) {
              MBox.error(this.getText("ErrorArbplExists"));
            } else {
              MBox.error(this.getText("ErrorParticipantExists"));
            }
            return false;
          } else {
            return true;
          }
        },

        _getAddParticipantDialog: function () {
          if (!this.oAddParticipantDialog) {
            this.oAddParticipantDialog = sap.ui.xmlfragment(
              "addParticipantDialog",
              "mobilework.view.participants.AddParticipantDialog",
              this
            );
            this.getView().addDependent(this.oAddParticipantDialog);
          }

          return this.oAddParticipantDialog;
        },

        _getBarcodeConfirmDialog: function () {
          if (!this.oBarcodeConfirmDialog) {
            this.oBarcodeConfirmDialog = sap.ui.xmlfragment(
              "barcodeConfirmDialog",
              "mobilework.view.participants.ParticipantBarcodeConfDialog",
              this
            );
            this.getView().addDependent(this.oBarcodeConfirmDialog);
          }

          return this.oBarcodeConfirmDialog;
        },

        _initModels: function () {
          if (!this.getView().getModel("newPartic")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel(),
              "newPartic"
            );
          }
          if (!this.getView().getModel("barcode")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel({
                selectedType: "pernr",
              }),
              "barcode"
            );
          }
        },

        _getParticipantsFromDb: function (d) {
          if (!d) {
            d = jQuery.Deferred();
          }
          var oTimeRegistration, owParticipants;
          if (this.getSharedModel().getProperty("/publicRelease")) {
            var sqlCustom = this.getLastTimeReg(),
              oTimeRegistration = this.getDBService().getEntitySet(
                "TimeRegistration",
                sqlCustom
              ),
              owParticipants =
                this.getDBService().getEntitySet("wParticipants"),
              ozoneData = this.getDBService().getEntitySet("zoneData");
          }
          $.when(
            this.getDBService().getEntitySet("Participant"),
            oTimeRegistration,
            owParticipants,
            ozoneData
          )
            .done(
              jQuery.proxy(function (oData, timReg, wParticipants, zoneData) {
                var oLocalModel = this.getView().getModel("local"),
                  oSharedModel = this.getSharedModel(),
                  aLocalParticipantSet = [];

                if (!oLocalModel.getProperty("/ParticipantSet")) {
                  oLocalModel.setProperty("/ParticipantSet", []);
                }

                for (var x = 0; x < oData.rows.length; x++) {
                  aLocalParticipantSet.push(oData.rows.item(x));
                }

                if (aLocalParticipantSet.length > 0) {
                  oSharedModel.setProperty("/hasParticipants", true);
                } else {
                  oSharedModel.setProperty("/hasParticipants", false);
                }
                aLocalParticipantSet = _.sortBy(
                  aLocalParticipantSet,
                  "Ename",
                  "Pernr"
                );
                if (this.getSharedModel().getProperty("/publicRelease")) {
                  if (timReg) {
                    timReg = this.getHelper().rowsToArray(timReg);
                    oLocalModel.setProperty("/timReg", timReg);
                  }
                  if (wParticipants) {
                    wParticipants = this.getHelper().rowsToArray(wParticipants);
                    oLocalModel.setProperty("/wParticipants", wParticipants);
                  }
                  if (zoneData) {
                    zoneData = this.getHelper().rowsToArray(zoneData);
                    oLocalModel.setProperty("/zoneData", zoneData);
                  }
                  var zonedBadges;
                  if (!oLocalModel.getProperty("/zonedBadges")) {
                    zonedBadges = [];
                  } else {
                    zonedBadges =
                      this.getModel("local").getProperty("/zonedBadges");
                  }
                  //Automatic deactivate after this much time
                  let deactTime = this.getSharedModel().getProperty(
                    "/sapSettings/DEACT_TIME"
                  );
                  //Automatic zone out is possible after this much time
                  let zoneOutTime = this.getSharedModel().getProperty(
                      "/sapSettings/EXIT_TIME"
                    ),
                    toPush = [];

                  aLocalParticipantSet.forEach(
                    function (row) {
                      if (row.Pernr) {
                        let found = _.find(wParticipants, { amei: row.Pernr });
                        if (found && found.hash) {
                          //Automatic deactivate - Yes becomes no
                          if (
                            deactTime &&
                            new Date().getTime() -
                              new Date(found.scannedOn).getTime() >
                              deactTime
                          ) {
                            row.color = "#ff0000";
                          } else {
                            row.color = "#008000";
                          }
                          let foundTimReg = _.find(timReg, {
                            Pernr: row.Pernr,
                          });
                          if (foundTimReg && foundTimReg.InOut === "01") {
                            row.TrZone = foundTimReg.TrZone;
                            let name = _.find(zoneData, {
                              zoneCode: foundTimReg.TrZone,
                            });
                            row.zoneName = name ? name.zoneName : "";
                            row.trTime = new moment(
                              parseInt(foundTimReg.Timestamp)
                            ).format("DD/MM/YY HH:mm");
                            if (foundTimReg.TrZone) {
                              if (!zoneOutTime) {
                                if (!zonedBadges.includes(row.Pernr)) {
                                  zonedBadges.push(row.Pernr);
                                }
                              } else {
                                //Automatic zone out after 	zoneOutTime
                                if (
                                  new Date().getTime() - foundTimReg.Timestamp <
                                  zoneOutTime
                                ) {
                                  if (!zonedBadges.includes(row.Pernr)) {
                                    zonedBadges.push(row.Pernr);
                                  }
                                } else {
                                  foundTimReg.TrAuto = "X";
                                  foundTimReg.InOut = "02";
                                  foundTimReg.Timestamp =
                                    parseInt(foundTimReg.Timestamp) +
                                    zoneOutTime;
                                  toPush.push(foundTimReg);
                                  row.TrZone = "";
                                  row.zoneName = "";
                                  row.trTime = "";
                                }
                              }
                            }
                          }
                        } else {
                          row.color = "";
                        }
                      }
                    }.bind(this)
                  );
                  this.getModel("local").setProperty(
                    "/zonedBadges",
                    zonedBadges
                  );
                  if (toPush.length) this.callTimeReg(toPush, false, true);
                }
                oLocalModel.setProperty(
                  "/ParticipantSet",
                  aLocalParticipantSet
                );
                oSharedModel.setProperty(
                  "/ParticipantSet",
                  aLocalParticipantSet
                );
                d.resolve();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                var oLocalModel = this.getView().getModel("local");
                if (!oLocalModel.getProperty("/ParticipantSet")) {
                  oLocalModel.setProperty("/ParticipantSet", []);
                }
                d.reject();
              }, this)
            );
        },

        _manualCreateParticipant: function () {
          var oParticipant = this.getView()
              .getModel("newPartic")
              .getProperty("/"),
            aFilters = [];

          this.index = 0;

          if (
            oParticipant &&
            oParticipant.Pernr &&
            oParticipant.Pernr.indexOf(";") !== -1
          ) {
            this.aParticipants = oParticipant.Pernr.split(";");

            if (this.aParticipants) {
              this.createMultipleParticipants();

              if (this.oAddParticipantDialog) {
                this.oAddParticipantDialog.close();
              }
              if (this.oBarcodeConfirmDialog) {
                this.oBarcodeConfirmDialog.close();
              }

              this.getView().getModel("newPartic").setProperty("/", {});
            }
          } else {
            //Check SAP Backend for details of the entered participant.

            if (
              oParticipant &&
              ((oParticipant.Pernr && !isNaN(parseInt(oParticipant.Pernr))) ||
                oParticipant.Arbpl)
            ) {
              if (oParticipant && this._checkUnqiue(oParticipant)) {
                oParticipant.Arbpl = oParticipant.Arbpl || "";
                oParticipant.ArbplDescription =
                  oParticipant.ArbplDescription || "";
                oParticipant.Area = oParticipant.Area || "";
                oParticipant.AreaText = oParticipant.AreaText || "";
                oParticipant.Ename = oParticipant.Ename || "";
                oParticipant.Ingrp = oParticipant.Ingrp || "";
                oParticipant.Iwerk = oParticipant.Iwerk || "";
                oParticipant.Lifnr = oParticipant.Lifnr || "";
                oParticipant.LifnrText = oParticipant.LifnrText || "";
                oParticipant.Nachn = oParticipant.Nachn || "";
                oParticipant.Sname = oParticipant.Sname || "";
                oParticipant.Swerk = oParticipant.Swerk || "";
                oParticipant.Vorna = oParticipant.Vorna || "";
                oParticipant.Workhandle = oParticipant.Workhandle || "";

                $.when(
                  this.getDBService().insertObject("Participant", oParticipant)
                ).done(
                  jQuery.proxy(function (res) {
                    this.getView().getModel("newPartic").setProperty("/", {});
                    this.onParticipantCreated(res, oParticipant);
                  }, this)
                );
              }
            } else {
              if (!oParticipant.Pernr) {
                MBox.error(this.getText("InvalidPernrEmpty"));
              } else {
                MBox.error(this.getText("InvalidPernr", oParticipant.Pernr));
              }
            }
          }
        },

        createMultipleParticipants: function () {
          var oParticipant = this.aParticipants[this.index],
            oNewParticipant = {},
            aFilters = [];

          var oTestPernr = parseInt(oParticipant);
          // oParticipant = parseInt(oParticipant);
          if (!isNaN(oTestPernr)) {
            aFilters.push(
              new sap.ui.model.Filter({
                path: "Pernr",
                operator: sap.ui.model.FilterOperator.EQ,
                value1: oParticipant,
              })
            );

            oNewParticipant.Pernr = oParticipant;
            oNewParticipant.Arbpl = "";
            oNewParticipant.ArbplDescription = "";
            oNewParticipant.Area = "";
            oNewParticipant.AreaText = "";
            oNewParticipant.Ename = "";
            oNewParticipant.Ingrp = "";
            oNewParticipant.Iwerk = "";
            oNewParticipant.Lifnr = "";
            oNewParticipant.LifnrText = "";
            oNewParticipant.Nachn = "";
            oNewParticipant.Sname = "";
            oNewParticipant.Swerk = "";
            oNewParticipant.Vorna = "";
            oNewParticipant.Workhandle = "";

            if (oNewParticipant && this._checkUnqiue(oNewParticipant)) {
              $.when(
                this.getDBService().insertObject("Participant", oNewParticipant)
              ).done(
                jQuery.proxy(function (res) {
                  var oLocalModel = this.getView().getModel("local"),
                    oSharedModel = this.getSharedModel(),
                    aLocalParticipantSet = [];

                  if (!oLocalModel.getProperty("/ParticipantSet")) {
                    oLocalModel.setProperty("/ParticipantSet", []);
                  }

                  oSharedModel.setProperty("/hasParticipants", true);

                  aLocalParticipantSet =
                    oLocalModel.getProperty("/ParticipantSet");
                  aLocalParticipantSet.push(oNewParticipant);
                  aLocalParticipantSet = _.sortBy(
                    aLocalParticipantSet,
                    "Ename",
                    "Pernr"
                  );
                  oLocalModel.setProperty(
                    "/ParticipantSet",
                    aLocalParticipantSet
                  );
                  var index = this.index;
                  $.when(this._getParticipantsFromDb()).done(
                    jQuery.proxy(function () {
                      if (index === this.aParticipants.length - 1) {
                        this.onGetInfoPress();
                      }
                    }, this)
                  );
                  if (this.index !== this.aParticipants.length - 1) {
                    this.index++;
                    this.createMultipleParticipants();
                  }
                }, this)
              );
            }
          } else {
            if (this.index !== this.aParticipants.length - 1) {
              this.index++;
              this.createMultipleParticipants();
            }
          }
        },

        _formatExtraData: function (sEname, sIngrp, sArbpl, sSwerk) {
          if (sEname) {
            if (sIngrp || sArbpl || sSwerk) {
              if (sIngrp && !sArbpl && !sSwerk) {
                // only sIngrp exist
                return sIngrp;
              }

              if (!sIngrp && sArbpl && !sSwerk) {
                // only sArbpl exist
                return sArbpl;
              }

              if (!sIngrp && !sArbpl && sSwerk) {
                // only sSwerk exist
                return sSwerk;
              }

              if (sIngrp && sArbpl && !sSwerk) {
                // sIngrp and sArbpl exist
                return sIngrp + ", " + sArbpl;
              }

              if (sIngrp && !sArbpl && sSwerk) {
                // sIngrp and sSwerk exist
                return sIngrp + ", " + sSwerk;
              }

              if (!sIngrp && sArbpl && sSwerk) {
                // sArbpl and sSwerk exist
                return sArbpl + ", " + sSwerk;
              }

              if (sIngrp && sArbpl && sSwerk) {
                // all exist
                return sIngrp + ", " + sArbpl + ", " + sSwerk;
              }
            }
          }
        },
        _onPublicScan: function () {
          $.when(this.connectionCheckTogiveColour())
            .done(
              jQuery.proxy(function () {
                $.when(this.getOwnerComponent().tokenService.addParticipants())
                  .done(
                    jQuery.proxy(function (oData) {
                      this.onPublicScanSuccess(oData);
                    }, this)
                  )
                  .fail(jQuery.proxy(function (oError) {}, this));
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("ParticipantOnline"));
                //MBox.error("A participant can only be scanned when online. ");
              }, this)
            );
        },

        onPublicScanSuccess: function (oData) {
          var d = jQuery.Deferred(),
            particpants,
            oLocalModel = this.getView().getModel("local"),
            toAdd = [],
            added = [],
            zonedBadges = [];
          var particpantsinDb = oLocalModel.getProperty("/ParticipantSet");
          try {
            particpants = this.adjustParticipant(oData);
          } catch (_e) {
            particpants = oData;
          }
          particpants.forEach(
            jQuery.proxy(function (participant) {
              if (!particpantsinDb) {
                oLocalModel.setProperty("/ParticipantSet", []);
                particpantsinDb = [];
              }

              let present = particpantsinDb.find(function (row) {
                return row.Pernr === participant.amei;
              });
              if (!present) {
                toAdd.push({ Pernr: participant.amei });
              } else {
                added.push({ Pernr: participant.amei });
              }
            }, this)
          );
          this.getView()
            .getModel("local")
            .setProperty("/publicParticipants", toAdd);
          $.when(this.onGetInfoPress(null, toAdd))
            .done(
              jQuery.proxy(function (oData) {
                d.resolve();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                d.reject();
              }, this)
            );
          //Don't have to add participant without hash
          particpants = particpants.filter(function (row) {
            return row.hash;
          });
          this._saveTableToDB(particpants, wParticipants, "Replace");
          return d.promise();
        },
        //this has become complex separate in and out
        onZoneBadgeIn: function () {
          this.messageLog = [];

          $.when(this.connectionCheckTogiveColour())
            .done(
              jQuery.proxy(function () {
                this._onZoneBadgeIn();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this._onZoneBadgeIn(true);
                // MBox.error("Your password has expired.  Please logon again.");
              }, this)
            );
        },

        _onZoneBadgeIn: async function (noNetwork) {
          this.getView().setBusy(true);
          this.haveAForbiddenTR = false;
          var type = "01";
          $.when(
            this.getDBService().getEntitySet("wParticipants"),
            this.getDBService().getEntitySet("TimeRegistration")
          )
            .done(
              jQuery.proxy(function (wai, timeReg) {
                var toBeadded = [],
                  trToBeSentAfterAdding = [],
                  trToBeSent = [],
                  oLocalModel = this.getView().getModel("local"),
                  particpantsinDb = oLocalModel.getProperty("/ParticipantSet"),
                  trData = [],
                  zonedBadges = [];
                wai = this.getHelper().rowsToArray(wai);
                timeReg = this.getHelper().rowsToArray(timeReg);
                $.when(
                  this.getOwnerComponent().tokenService.onZoneBadge(
                    true,
                    "ScanZoneTagAndParticipants",
                    noNetwork
                  )
                )
                  .done(
                    jQuery.proxy(async function (oData) {
                      if (oData === "CANCEL") {
                        MBox.error(this.getText("NodataretrivedfromWAI"));
                        //MBox.error('No data retrived from WAI');
                        this.getView().setBusy(false);
                        return;
                      }

                      var zone = JSON.parse(oData[0]),
                        zonePart = this.adjustParticipant(oData[1]),
                        deactTime = this.getSharedModel().getProperty(
                          "/sapSettings/DEACT_TIME"
                        ),
                        confOnBadges =
                          this.getModel("local").getProperty("/confOnBadges");
                      if (zone) {
                        this.getView().setBusy(false);
                        this._saveTableToDB(zone, zoneData);
                        for (let oZonePart of zonePart) {
                          //_.forEach(zonePart,async function(oZonePart){
                          let oHash = _.find(wai, { hash: oZonePart.hash });
                          if (!oZonePart.amei) {
                            if (oHash && oHash.hash) {
                              oZonePart.amei = oHash.amei;
                            } else {
                              // this.messageLog.push({
                              // 	"Message": "The badge you scanned does not exist in the application. Please add the participant online.",
                              // 	"Severity": "Error"
                              // });
                            }
                          }
                          let oPart = _.find(particpantsinDb, {
                              Pernr: oZonePart.amei,
                            }),
                            tr;
                          if (
                            deactTime &&
                            oHash &&
                            oHash.hash &&
                            new Date().getTime() -
                              new Date(oHash.scannedOn).getTime() >
                              deactTime
                          ) {
                            let name = oPart ? oPart.Ename : "";
                            this.messageLog.push({
                              Message: this.getText(
                                "Pdeactive",
                                name || oZonePart.amei || ""
                              ),
                              Severity: "Error",
                            });
                            if (oPart) oPart.color = "#ff0000";
                          } else if (!oPart) {
                            //create particpant
                            toBeadded.push(oZonePart);
                            tr = this.createTRData(
                              oPart,
                              zone,
                              oZonePart,
                              type
                            );
                            if (tr) trToBeSentAfterAdding.push(tr);
                            //This condition irreverlant.having hash gives colour
                            //	}else if(oPart.color==="#008000"){
                          } else if (oZonePart && oZonePart.hash) {
                            tr = this.createTRData(
                              oPart,
                              zone,
                              oZonePart,
                              type
                            );
                            let oldTr = _.filter(timeReg, {
                              Pernr: tr.Pernr,
                            }).pop();
                            if (oldTr && oldTr.InOut === "01") {
                              if (oldTr.TrZone === zone.zoneCode) {
                                this.messageLog.push({
                                  Message: this.getText("PInZoneExit", [
                                    oldTr.Pernr,
                                    zone.zoneName,
                                    zone.zoneName,
                                  ]),
                                  Severity: "Error",
                                });
                              } else if (
                                this.getSharedModel().getProperty(
                                  "/sapSettings/EXIT_AUTO"
                                )
                              ) {
                                if (confOnBadges.includes(oPart.Pernr)) {
                                  /*BEGIN: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
                                  let current = this.checkModeandAction(oPart);
                                  /*END: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
                                  await new Promise((resolve, reject) => {
                                    MBox[current.type](current.message, {
                                      actions: [
                                        MBox.Action.OK,
                                        MBox.Action.CANCEL,
                                      ],
                                      emphasizedAction: MBox.Action.OK,
                                      onClose: function (sAction) {
                                        if (current.mode === "DONT_ALLOW") {
                                          this.haveAForbiddenTR = true;
                                          return;
                                        }
                                        resolve(sAction);
                                      },
                                    });
                                  }).then((sAction) => {
                                    if (sAction === MBox.Action.OK) {
                                      if (current.mode === "DONT_ALLOW") {
                                        this.haveAForbiddenTR = true;
                                        return;
                                      }
                                      oPart.TrZone = zone.zoneCode;
                                      oPart.zoneName = zone.zoneName;
                                      oPart.trTime = new moment(
                                        new Date()
                                      ).format("DD/MM/YY HH:mm");
                                      oPart.color = "#008000";
                                      oldTr.InOut = "02";
                                      oldTr.Timestamp = new Date(
                                        tr.Timestamp - 1000
                                      ).getTime();
                                      trToBeSent.push(oldTr);
                                      trToBeSent.push(tr);
                                      this.modifyConfirmation(
                                        current.mode,
                                        current.currentConf,
                                        oPart
                                      );
                                    } else {
                                      if (current.mode === "DONT_ALLOW") {
                                        this.haveAForbiddenTR = true;
                                      }
                                    }
                                  });
                                } else {
                                  oPart.TrZone = zone.zoneCode;
                                  oPart.zoneName = zone.zoneName;
                                  oPart.trTime = new moment(new Date()).format(
                                    "DD/MM/YY HH:mm"
                                  );
                                  oPart.color = "#008000";
                                  oldTr.InOut = "02";
                                  oldTr.Timestamp = new Date(
                                    tr.Timestamp - 1000
                                  ).getTime();
                                  trToBeSent.push(oldTr);
                                  trToBeSent.push(tr);
                                }
                              } else {
                                this.messageLog.push({
                                  Message: this.getText("PInZoneExit", [
                                    oldTr.Pernr,
                                    zone.zoneName,
                                    zone.zoneName,
                                  ]),
                                  //" Participant "+ oldTr.Pernr +" is in zone "+oPart.zoneName+".  Please exit the zone"+oPart.zoneName+" first before entering a new zone.",
                                  Severity: "Error",
                                });
                              }
                            } else {
                              oPart.TrZone = zone.zoneCode;
                              oPart.zoneName = zone.zoneName;
                              oPart.trTime = new moment(new Date()).format(
                                "DD/MM/YY HH:mm"
                              );
                              oPart.color = "#008000";
                              trToBeSent.push(tr);
                            }
                          } else {
                            //Give no hash error
                            this.messageLog.push({
                              Message: this.getText("PNoHash", oTr.Pernr),
                              //oTr.Pernr + " has no hash.",
                              Severity: "Error",
                            });
                          }

                          //This condition irreverlant.having hash gives colour
                          // else{
                          // 	//same error will there
                          // 	if(oZonePart.hash){
                          // 		tr=this.createTRData(oPart,zone,oZonePart,type);
                          // 		oPart.TrZone=zone.zoneCode;
                          // 		oPart.zoneName=zone.zoneName;
                          // 		oPart.trTime=new moment(new Date()).format("DD/MM/YY hh:mm A");
                          // 		oPart.color='#008000';
                          // 		trToBeSent.push(tr);
                          // 	}
                          // }
                        }
                        //}.bind(this));

                        this.getView().setBusy(true);
                        if (toBeadded.length > 0) {
                          if (noNetwork) {
                            // MBox.error("Participant is not known/activated.  Please add/activate the participant before scanning the zone.");
                            MBox.error(
                              this.getText("ParticipantNotFound", [""])
                            );
                            if (trToBeSent.length > 0) {
                              this.callTimeReg(trToBeSent, noNetwork, true);
                            } else {
                              this.getView().setBusy(false);
                            }
                            return;
                          }
                          if (
                            this.getSharedModel().getProperty(
                              "/sapSettings/Connected"
                            )
                          ) {
                            $.when(this.onPublicScanSuccess(oData[1]))
                              .done(
                                function () {
                                  var participants = this.getView()
                                    .getModel("local")
                                    .getProperty("/ParticipantSet");
                                  trToBeSent = trToBeSent.concat(
                                    trToBeSentAfterAdding
                                  );
                                  _.forEach(
                                    trToBeSent,
                                    function (row) {
                                      var selected = _.find(participants, {
                                        Pernr: row.Pernr,
                                      });
                                      if (selected) {
                                        selected.TrZone = row.TrZone;
                                        selected.zoneName = row.zoneName;
                                        selected.trTime = new moment(
                                          new Date()
                                        ).format("DD/MM/YY HH:mm");
                                        if (!row.Lifnr) {
                                          row.Lifnr = selected.Lifnr;
                                        }
                                      }
                                    }.bind(this)
                                  );

                                  this.callTimeReg(trToBeSent, noNetwork, true);
                                }.bind(this)
                              )
                              .fail(
                                function (error) {
                                  this.getView().setBusy(false);
                                }.bind(this)
                              );
                          } else {
                            let value = toBeadded
                              .map((obj) => obj.amei)
                              .join(",");
                            MBox.error(
                              this.getText("ParticipantNotFound", value)
                            );
                            //MBox.error("Participant "+ value +" is not known/activated.  Please add/activate the participant before scanning the zone.");
                            if (trToBeSent.length > 0) {
                              this.callTimeReg(trToBeSent, noNetwork, true);
                            } else {
                              this.getView().setBusy(false);
                            }
                            // this.messageLog.push({
                            // 			"Message": "Participant "+ value +" is not known/activated.  Please add/activate the participant before scanning the zone.",
                            // 			"Severity": "Error"
                            // 		});
                          }
                        } else {
                          this.callTimeReg(
                            trToBeSent.concat(trToBeSentAfterAdding),
                            noNetwork,
                            true
                          );
                          if (trToBeSent.length > 0) {
                            let savePart = zonePart.filter(function (row) {
                              return row.hash;
                            });
                            this._saveTableToDB(
                              savePart,
                              wParticipants,
                              "Replace"
                            );
                          }
                        }
                      } else {
                        if (oData[1]) {
                          $.when(this.onPublicScanSuccess(oData[1]))
                            .done(
                              function () {
                                let value = oData[1]
                                  .map((obj) => obj.Pernr)
                                  .join(",");

                                //MBox.success(value+ " were  added.");
                                MBox.success(this.getText("PWereAdded", value));
                                this.getView().setBusy(false);
                              }.bind(this)
                            )
                            .fail(
                              function (error) {
                                let value = oData[1]
                                  .map((obj) => obj.Pernr)
                                  .join(",");
                                // this.messageLog.push({
                                // 	"Message": value+ " were not added.",
                                // 	"Severity": "Error"
                                // });
                                //MBox.error(value+ " were not added.");
                                MBox.error(
                                  this.getText("PWereNotAdded", value)
                                );
                                this.getView().setBusy(false);
                              }.bind(this)
                            );
                        } else {
                          //MBox.error("No zone or badge data retreived");
                          MBox.error(this.getText("NoDataRetreived"));
                          this.getView().setBusy(false);
                        }
                      }
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function (oError) {
                      this.getView().setBusy(false);
                      MBox.error(this.getText("ZoneBadgeinFailed"));
                      //MBox.error("Zone Badge in has failed");
                    }, this)
                  );
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("ErrorRereivingData"));
                this.getView().setBusy(false);
                //MBox.error("Error Rereiving data for timeregistration and participants");
              }, this)
            );
        },

        onZoneBadgeOut: function () {
          $.when(this.connectionCheckTogiveColour())
            .done(
              jQuery.proxy(function () {
                this._onZoneBadgeOut();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this._onZoneBadgeOut(true);
                MBox.error(
                  this.getText("ConnectionUnknown") +
                    "\n" +
                    this.getText("NoConnectionToSap")
                );
              }, this)
            );
        },

        _onZoneBadgeOut: function (noNetwork) {
          this.getView().setBusy(true);
          this.haveAForbiddenTR = false;
          var ZoneBadgingType,
            type = "02";
            //TODO
          if (this.getSharedModel().getProperty("/sapSettings/EXIT_BADGE")) {
            ZoneBadgingType = "ScanParticipants";
          } else {
            ZoneBadgingType = "ScanZoneTagAndParticipants";
          }
          this.messageLog = [];
          let sqlCustom = this.getLastTimeReg(),
            oPromZoneBadge = this.getOwnerComponent().tokenService.onZoneBadge(
              false,
              ZoneBadgingType,
              noNetwork
            ),
            oPromParticipants =
              this.getDBService().getEntitySet("wParticipants"),
            oPromTr = this.getDBService().getEntitySet(
              "TimeRegistration",
              sqlCustom
            );
          $.when(oPromZoneBadge, oPromParticipants, oPromTr)
            .done(
              jQuery.proxy(async function (oData, wai, timeReg) {
                if (oData === "CANCEL") {
                  MBox.error(this.getText("NodataretrivedfromWAI"));
                  this.getView().setBusy(false);
                  return;
                }
                var zonePart = this.adjustParticipant(oData[1]),
                  oLocalModel = this.getView().getModel("local"),
                  particpantsinDb = oLocalModel.getProperty("/ParticipantSet"),
                  trData = [],
                  zone = JSON.parse(oData[0]),
                  confOnBadges =
                    this.getModel("local").getProperty("/confOnBadges");
                wai = this.getHelper().rowsToArray(wai);
                timeReg = this.getHelper().rowsToArray(timeReg);
                // _.forEach(zonePart,function(oZonePart){
                for (let oZonePart of zonePart) {
                  this.getView().setBusy(false);
                  if (oZonePart.hash) {
                    let oHash = _.find(wai, { hash: oZonePart.hash });
                    if (!oZonePart.amei) {
                      if (oHash && oHash.hash) {
                        oZonePart.amei = oHash.amei;
                      } else {
                        this.messageLog.push({
                          Message: this.getText("NonExistentBadge"), //"The badge you scanned does not exist in the application. Please add the participant online.",
                          Severity: "Error",
                        });
                      }
                    }
                    let oldTr = _.find(timeReg, { Pernr: oZonePart.amei });
                    let particpant = _.find(particpantsinDb, {
                      Pernr: oZonePart.amei,
                    });
                    if (oldTr && oldTr.InOut === "01") {
                      if (zone) {
                        if (zone.zoneCode !== oldTr.TrZone) {
                          this.messageLog.push({
                            Message: this.getText("PNotInZone", [
                              oZonePart.amei,
                              zone.zoneCode,
                            ]), //oZonePart.amei+ " is not in zone "+ zone.zoneCode,
                            Severity: "Success",
                          });
                          break;
                        }
                      }
                      if (!particpant) {
                        this.messageLog.push({
                          Message: this.getText("NonExistentBadge", [
                            oZonePart.amei,
                          ]),
                          Severity: "Success",
                        });
                        break;
                      }
                      if (
                        particpant.Pernr &&
                        confOnBadges.includes(particpant.Pernr)
                      ) {
                        let current = this.checkModeandAction(particpant);
                        await new Promise((resolve, reject) => {
                          MBox[current.type](current.message, {
                            actions: [MBox.Action.OK, MBox.Action.CANCEL],
                            emphasizedAction: MBox.Action.OK,
                            onClose: function (sAction) {
                              resolve(sAction);
                            },
                          });
                        }).then((sAction) => {
                          if (sAction === MBox.Action.OK) {
                            if (current.mode === "DONT_ALLOW") {
                              this.haveAForbiddenTR = true;
                              return;
                            }
                            oldTr.InOut = "02";
                            oldTr.Timestamp = new Date().getTime();
                            trData.push(oldTr);
                            this.messageLog.push({
                              Message: this.getText("PExitedZone", [
                                oZonePart.amei,
                                particpant.zoneName,
                              ]),
                              // oZonePart.amei+ " is exited from "+ particpant.zoneName,
                              Severity: "Success",
                            });
                            if (particpant) {
                              particpant.TrZone = "";
                              particpant.zoneName = "";
                              particpant.trTime = "";
                            }

                            this.modifyConfirmation(
                              current.mode,
                              current.currentConf,
                              particpant
                            );
                          } else {
                            if (current.mode === "DONT_ALLOW") {
                              this.haveAForbiddenTR = true;
                            }
                          }
                        });
                      } else {
                        oldTr.InOut = "02";
                        oldTr.Timestamp = new Date().getTime();
                        trData.push(oldTr);
                        this.messageLog.push({
                          Message: this.getText("PExitedZone", [
                            oZonePart.amei,
                            particpant.zoneName,
                          ]),
                          // oZonePart.amei+ " is exited from "+ particpant.zoneName,
                          Severity: "Success",
                        });
                        if (particpant) {
                          particpant.TrZone = "";
                          particpant.zoneName = "";
                          particpant.trTime = "";
                        }
                      }
                    } else {
                      this.messageLog.push({
                        Message: this.getText("PNotInZone", [
                          oZonePart.amei,
                          "",
                        ]),
                        //oZonePart.amei+ " need not be exited.Its not in the zone",
                        Severity: "Error",
                      });
                    }
                  } else {
                    this.messageLog.push({
                      Message: this.getText("PNoHash", oZonePart.amei), //oZonePart.amei+ " doesn't has hash",
                      Severity: "Error",
                    });
                  }
                }
                this.getView().setBusy(true);
                this.callTimeReg(trData, noNetwork, true);
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this.getView().setBusy(false);
              }, this)
            );
        },

        onMassExit: function (oEvent) {
          $.when(this.connectionCheckTogiveColour())
            .done(
              jQuery.proxy(function () {
                this._onMassExit();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this._onMassExit(true);
                MBox.error(
                  this.getText("ConnectionUnknown") +
                    "\n" +
                    this.getText("NoConnectionToSap")
                );
              }, this)
            );
        },

        _onMassExit: function (noNetwork) {
          this.haveAForbiddenTR = false;
          var type = "02";
          let //sqlCustom = this.getLastTimeReg();
            oPromZoneBadge = this.getOwnerComponent().tokenService.onZoneBadge(
              false,
              "ScanZoneTag",
              noNetwork
            ),
            oPromParticipants =
              this.getDBService().getEntitySet("wParticipants");
          // oPromTr=this.getDBService().getEntitySet("TimeRegistration",sqlCustom);
          this.messageLog = [];
          $.when(oPromZoneBadge, oPromParticipants)
            .done(
              jQuery.proxy(async function (oData, wai) {
                if (oData === "CANCEL") {
                  MBox.error(this.getText("NoZoneDataRetrivedWAI"));
                  return;
                }
                wai = this.getHelper().rowsToArray(wai);
                var zone = JSON.parse(oData[0]),
                  oLocalModel = this.getView().getModel("local"),
                  particpantsinDb = oLocalModel.getProperty("/ParticipantSet"),
                  trData = [],
                  deactTime = this.getSharedModel().getProperty(
                    "/sapSettings/DEACT_TIME"
                  ),
                  confOnBadges =
                    this.getModel("local").getProperty("/confOnBadges");
                //_.forEach(particpantsinDb,async function(oPart){
                for (let oPart of particpantsinDb) {
                  if (oPart.TrZone === zone.zoneCode) {
                    if (confOnBadges.includes(oPart.Pernr)) {
                      this.haveAForbiddenTR = true;
                      /*BEGIN: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
                      let current = this.checkModeandAction(oPart);
                      /*END: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 20*/

                      await new Promise((resolve, reject) => {
                        MBox[current.type](current.message, {
                          actions: [MBox.Action.OK, MBox.Action.CANCEL],
                          emphasizedAction: MBox.Action.OK,
                          onClose: function (sAction) {
                            resolve(sAction);
                          },
                        });
                      }).then((sAction) => {
                        if (sAction === MBox.Action.OK) {
                          if (current.mode === "DONT_ALLOW") {
                            return;
                          }
                          let tr = this.createTRData(oPart, zone, {}, type);
                          if (tr) {
                            trData.push(tr);
                          }
                          oPart.TrZone = "";
                          oPart.zoneName = "";
                          oPart.trTime = "";
                          this.modifyConfirmation(
                            current.mode,
                            current.currentConf,
                            oPart
                          );
                        } else {
                          if (current.mode === "DONT_ALLOW") {
                            this.haveAForbiddenTR = true;
                          }
                        }
                      });
                    } else {
                      let tr = this.createTRData(oPart, zone, {}, type);
                      if (tr) {
                        trData.push(tr);
                      }
                      oPart.TrZone = "";
                      oPart.zoneName = "";
                      oPart.trTime = "";
                    }
                  }
                }
                this.callTimeReg(trData, noNetwork, true);
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("NoZoneDataRetrivedWAI"));
              }, this)
            );
        },

        createTRData: function (part, zone, hashData, code) {
          let date, plant;
          if (hashData.scannedOn) {
            date = new Date(hashData.scannedOn).getTime();
          } else {
            date = new Date().getTime();
          }
          if (this.getSharedModel().getProperty("/sapSettings/SWERK")) {
            plant = this.getSharedModel()
              .getProperty("/sapSettings/SWERK")
              .toString();
          } else {
            plant = this.getSharedModel()
              .getProperty("/sapSettings/plant")
              .toString();
          }

          var object = {
            Werks: plant,
            Pernr: part ? part.Pernr : hashData.amei,
            Lifnr: part ? part.Lifnr : "",
            Ebelp: "",
            InOut: code,
            TrZone: zone.zoneCode,
            zoneName: zone.zoneName,
            Timestamp: date,
            Ebeln: "",
          };
          return object;
        },

        // onSwitchChange: function (oEvent) {
        //   var index = oEvent
        //       .getParameter("id")
        //       .slice(oEvent.getParameter("id").lastIndexOf("-") + 1),
        //     oPromDeleteHash;
        //   if (index) {
        //     //Should not be possible change it to true manually
        //     // if (oEvent.getSource().getState()) {
        //     //   oEvent.getSource().setState(false);
        //     // }
        //     var participant = this.getView()
        //       .getModel("local")
        //       .getProperty("/ParticipantSet")[index];
        //     if (this.getSharedModel().getProperty("/publicRelease")) {
        //       oPromDeleteHash = this.getDBService().deleteObject(
        //         "wParticipants",
        //         { amei: participant.Pernr },
        //         wParticipants.key.propertyRef
        //       );
        //     }

        //     $.when(oPromDeleteHash, participant)
        //       .done(
        //         jQuery.proxy(function (oEvent, participant) {
        //           MToast.show(this.getText("DeactivatedHash"));
        //           //MToast.show('Successfully deactivated the Hash');
        //           participant.color = "";
        //           this.getView().getModel("local").refresh(true);
        //         }, this)
        //       )
        //       .fail(
        //         jQuery.proxy(function () {
        //           MBox.error(this.getText("HashNotDeleted"));
        //         }, this)
        //       );
        //   }
        // },
        onSwitchChange: function (oEvent) {
          var index = oEvent
            .getParameter("id")
            .slice(oEvent.getParameter("id").lastIndexOf("-") + 1);
          // zone = this.getModel("local").getData().ParticipantSet[index].TrZone
          // oPromDeleteHash;

          if (index) {
            // Shoul not be possible change it to true manually
            // if (oEvent.getSource().getState()) {
            //   oEvent.getSource().setState(false);
            // }

            if (!oEvent.getSource().getState()) {
              var participant = this.getView()
                .getModel("local")
                .getProperty("/ParticipantSet")[index];
              if (this.getSharedModel().getProperty("/publicRelease")) {
                var oPromDeleteHash = this.getDBService().deleteObject(
                  "wParticipants",
                  { amei: participant.Pernr },
                  wParticipants.key.propertyRef
                );
              }
              $.when(oPromDeleteHash, participant)
                .done(
                  jQuery.proxy(function (oEvent, participant) {
                    // oEvent.getSource().setState(false);
                    MToast.show(this.getText("DeactivatedHash"));
                    //MToast.show('Successfully deactivated the Hash');
                    participant.color = "";
                    this.getView().byId("switch").setState(false);
                    this.getView().getModel("local").refresh(true);
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    // this.getView().byId("switch").setState(true);
                    MBox.error(this.getText("HashNotDeleted"));
                  }, this)
                );
            } else {
              var that = this;
              that.onScanPress();
              // Should not be possible change it to true manually
              if (oEvent.getSource().getState()) {
                oEvent.getSource().setState(false);
              }
            }
          }
        },

        // callTimeReg: function(data,noNetwork){
        // 	if(data&& data.length===0){
        // 		if(this.messageLog.length>0){
        // 			this.getModel('local').setProperty('/messages',	this.messageLog);
        // 			this.getDialogManager().open("fragments.MessageFragment", this.getView());
        // 		}else{
        // 			MBox.error('No Time Registrations were newly added');
        // 		}

        // 		//MBox.information('No Time Registrations were newly added');
        // 		return;
        // 	}else{
        // 		this.maintainInOutTable(data);
        // 	}
        // 	var zonedBadges=this.getModel('local').getProperty("/zonedBadges");
        // 	var progress=data.length;
        // 	for (let i=0;i<data.length;i++){
        // 		if(data[i].InOut==='01'&&!zonedBadges.includes(data[i].Pernr)){
        // 			zonedBadges.push(data[i].Pernr);
        // 		}else if(data[i].InOut==='02'&&zonedBadges.includes(data[i].Pernr)){
        // 			 _.remove(zonedBadges, function(n) { return n  === data[i].Pernr;});
        // 		}

        // 	}
        // 	var tempData=JSON.parse(JSON.stringify(data));
        // 	this.getDBService().multipleDataDb("TimeRegistration",tempData);
        // 	if(noNetwork){
        // 		let metadataObj=this.getDBService()._getMetaObject();
        // 		if(metadataObj){
        // 			let TimeReg=_.find(metadataObj.dataServices.schema[0].entityType,{name:'TimeRegistration'});
        // 			var tempData1=JSON.parse(JSON.stringify(data));
        // 			this.getDBService().multipleDataDb("TimeRegistration",tempData1);					this.getDBService().multipleDataDb("TimeRegistration1",data,TimeReg);
        // 		}
        // 	}else{

        // 	//after implmentation IN backend
        // 	var tempData3=JSON.parse(JSON.stringify(data));
        // 	$.when(this.getService().setZonebadging(tempData3)).done(function(oData){
        // 		if(oData){
        // 			_.forEach(oData.NavTimeRegistration.results,function(row){
        // 				if(row.Message){
        // 					this.messageLog.push({
        // 						"Message": "For Participant "+row.Pernr+" in zone "+row.TrZone+ " " +row.Message,
        // 						"Severity": "Error"
        // 					});
        // 				}

        // 			}.bind(this));
        // 			if(this.messageLog.length>0){
        // 				this.getModel('local').setProperty('/messages',	this.messageLog);
        // 				this.getDialogManager().open("fragments.MessageFragment", this.getView());
        // 			}else{
        // 				MBox.success(this.getText('ZoneRegistrationSuccess'));
        // 				//MBox.success('Zone Registration success');
        // 			}
        // 		}

        // 	}.bind(this)).fail(function(error){
        // 		MBox.error(this.getText('ZoneRegistrationError'));
        // 	}.bind(this));
        // }

        // 	this.getModel('local').setProperty("/zonedBadges",zonedBadges);
        // 	this.getModel('local').refresh(true);

        // },

        closeMessageLog: function () {
          this.getDialogManager().close(
            "fragments.MessageFragment",
            this.getView()
          );
        },

        adjustParticipant: function (data) {
          data = JSON.parse(data);
          _.forEach(data, function (row) {
            if (row.amei && !isNaN(row.amei)) {
              row.amei = row.amei.toString().padStart(8, "0");
            }
          });
          return data;
        },

        // maintainInOutTable: function(trs){
        // 	var newTr=[];
        // 	trs.forEach(function(tr){
        // 		newTr.push({
        // 			TimeStamp: new Date(),//just for keeping a key
        // 			Pernr : tr.Pernr,
        // 			TrZone: tr.TrZone,
        // 			TimeIn: tr.InOut==="01"? tr.Timestamp: "",
        // 			TimeOut: tr.InOut==="02"? tr.Timestamp: "",

        // 		});
        // 	});
        // 	//this._saveTableToDB(newTr,TimeInOut,'Replace');
        // 	$.when(this.getDBService().maintainInOutTable(newTr)).done(function(){
        // 		this.getInOutTable();
        // 	}.bind(this)).fail(function(){
        // 		this.getInOutTable();
        // 	}.bind(this));
        // },

        getOngoingCnfPartcipants: function () {
          var oConfirmations =
            this.getModel("local").getProperty("/ConfirmationSet");
          if (oConfirmations) {
            this._getOngoingCnfPartcipants(oConfirmations);
          } else {
            $.when(this.getDBService().getEntitySet("Confirmation")).done(
              jQuery.proxy(function (oData) {
                oConfirmations = this.getHelper().rowsToArray(oData);
                this.getModel("local").setProperty(
                  "/ConfirmationSet",
                  oConfirmations
                );
                this._getOngoingCnfPartcipants(oConfirmations);
              }, this)
            );
          }
        },

        _getOngoingCnfPartcipants: function (aConfirmations) {
          var sParticipants = [],
            onGoing = [];
          aConfirmations = _.forEach(aConfirmations, function (conf) {
            if (
              (conf.IsFinished === "false" || conf.IsFinished === false) &&
              (conf.Split === "false" || !conf.Split) &&
              conf.ExecStart
            ) {
              if (conf.PersNo) {
                /*BEGIN: Date: 05/02/2024 AMID: A0866990 13.1 MWX Bug Number: 28*/
                sParticipants = sParticipants.concat(conf.PersNo.split(","));
                /*BEGIN: Date: 05/02/2024 AMID: A0866990 13.1 MWX Bug Number: 28*/
              }
              // onGoing.push(conf)
            }
          });
          this.getModel("local").setProperty("/confOnBadges", sParticipants);
          // this.getModel('local').setProperty('/onGoingConf',onGoing);
        },
        /*BEGIN: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
        modifyConfirmation: function (mode, oCurrent, particpant) {
          switch (mode) {
            case "SPLIT_IT":
              this.splitConfirmation(oCurrent, particpant);
              break;
            case "STOP_IT":
              this.stopConfirmation(oCurrent, particpant);
              break;
            case "LEAVE_IT_BE":
              break;
            case "DONT_ALLOW":
              break;
          }
        },
        // splitOrStop: function(oCurrent,particpant){
        // 	switch(oCurrent.Split){
        // 		case false:
        // 			this.splitConfirmation(oCurrent,particpant)
        // 			break;
        // 		case true:
        // 			this.stopConfirmation(oCurrent,particpant)
        // 			break;

        // 	}
        // },
        stopConfirmation: function (oCurrent, particpant) {
          let oMomStart = new moment(oCurrent.ExecStart),
            oMomEnd = new moment(new Date()),
            oActWork = this.getHelper().calcActualWork(oMomStart, oMomEnd),
            aConfirmations =
              this.getModel("local").getProperty("/ConfirmationSet"),
            oParent = aConfirmations.find((aConf) => {
              return aConf.Handle === oCurrent.ParentHndl;
            });
          // if(particpant.Pernr === oParticipant){
          oCurrent.ExecFin = new moment(new Date()).format(
            "YYYY-MM-DD HH:mm:ss"
          );
          oCurrent.IsFinished = true;
          oCurrent.ActWork = oActWork.ActWork;
          oCurrent.UnWork = oActWork.UnWork;
          if (oParent) {
            oCurrent.Text = oParent.Text;
            oCurrent.ConfText = oParent.ConfText;
          }

          // }
          this.getDBService().updateObject("Confirmation", oCurrent);
        },

        splitConfirmation: function (oCurrent, particpant) {
          var // oLocalModel = this.getView().getModel("local"),
            //oViewModel = this._getViewModel(),
            //sCurrPath = this.getView().getBindingContext("local").getPath(),
            oParentConfirm = oCurrent,
            aConfParticipants,
            perNos = oCurrent.PersNo,
            aConfirmations =
              this.getModel("local").getProperty("/ConfirmationSet"),
            // sSelectedPerson = oViewModel.getProperty("/SelectedPerson"),
            aCurrPersons = [];
          // oLocalModel.getProperty(sCurrPath + "/ChildConfirmations") || [],

          if (perNos && typeof perNos === "string") {
            aConfParticipants = perNos.split(",").filter(Boolean);
          } else if (perNos) {
            aConfParticipants = perNos.filter(Boolean);
          }

          _.each(
            aConfParticipants,
            jQuery.proxy(function (oParticipant) {
              var oNewConf = {};

              for (var sProp in oParentConfirm) {
                oNewConf[sProp] = oParentConfirm[sProp];
              }
              oNewConf.Handle = this.getHelper().getUUID();
              oNewConf.PersNo = oParticipant;
              oNewConf.ExecFin = "";
              oNewConf.ActWork = "";
              oNewConf.IsFinished = false;
              oNewConf.Hidden = true;
              oNewConf.ParentHndl = oParentConfirm.Handle;
              oNewConf.Split = false;
              oNewConf.ExecutantCnt = 1;
              delete oNewConf.ChildConfirmations;

              let oMomStart = new moment(oParentConfirm.ExecStart),
                oMomEnd = new moment(new Date()),
                oActWork = this.getHelper().calcActualWork(oMomStart, oMomEnd);
              if (particpant.Pernr === oParticipant) {
                oNewConf.ExecFin = new moment(new Date()).format(
                  "YYYY-MM-DD HH:mm:ss"
                );
                oNewConf.IsFinished = true;
                oNewConf.ActWork = oActWork.ActWork;
                oNewConf.UnWork = oActWork.UnWork;
              }
              aConfirmations.push(oNewConf);
              this.getDBService().insertObject("Confirmation", oNewConf);
            }, this)
          );
          oParentConfirm.Split = true;
          this.getDBService().updateObject("Confirmation", oParentConfirm);
        },

        checkModeandAction: function (particpant) {
          let aConfirmations =
              this.getModel("local").getProperty("/ConfirmationSet"),
            onGoing = [];
          let currentConf = aConfirmations.find((aConf) => {
            if (aConf.PersNo) {
              if (
                (aConf.IsFinished === "false" || aConf.IsFinished === false) &&
                (aConf.Split === "false" || !aConf.Split) &&
                aConf.ExecStart
              ) {
                return aConf.PersNo.split(",").includes(particpant.Pernr);
              }
              // if(aConf.PersNo.split(',').includes(particpant.Pernr)){
              // 	return !aConf.Split
              // };
            }
          });
          let partcipants = currentConf.PersNo.split(",").filter((a) => {
            return a;
          });
          if (!(currentConf.Hidden === "false" || !currentConf.Hidden)) {
            onGoing = aConfirmations.filter((aConf) => {
              return (
                aConf.ParentHndl === currentConf.ParentHndl &&
                (aConf.IsFinished === "false" || aConf.IsFinished === false)
              );
            });
          }

          /*
			currentConf will only contain either split confirmation or the main confirmation.
			It will not have the parent one. Split =true will not be available
			if ongoing present means it a split.
		*/

          let message, type, mode;
          // if ongoing>1 present means it a split.
          if (onGoing.length > 1) {
            message = this.getText("POpenConfirmationExit", particpant.Ename);
            type = "warning";
            mode = "STOP_IT";
            // in child confirmation pernr will be of length 1. So greater than 1 means it not yet splitted. So split it.
          } else if (partcipants.length > 1) {
            message = this.getText("POpenConfirmationExit", particpant.Ename);
            type = "warning";
            mode = "SPLIT_IT";
            //
          } else if (onGoing.length === 1) {
            message = this.getModel("i18n")
              .getResourceBundle()
              .getText("POpenConfirmationForbidden", particpant.Ename);
            type = "error";
            mode = "DONT_ALLOW";
          } else {
            message = this.getText("POpenConfirmation", particpant.Ename);
            type = "warning";
            mode = "LEAVE_IT_BE";
          }
          return {
            message: message,
            mode: mode,
            type: type,
            currentConf: currentConf,
          };
        },

        /*END: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
      }
    );
  }
);
