/* global _:true */
/*global Camera:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
    "mobilework/model/FollowUpNotif",
  ],
  function (Controller, MToast, Filter, Lo, MBox, FollowUpNotif) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.notifications.NotificationsDetail",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        /** @type sap.m.Select */
        oQmcodSelect: null,

        /** @type sap.m.Select */
        oFecodSelect: null,

        /** @type sap.m.Select */
        oUrcodSelect: null,

        /** @type sap.m.Select */
        oMfcodSelect: null,

        /** @type sap.m.Select */
        oMncodSelect: null,

        /** @type sap.m.IconTabBar */
        oIconBarNotif: null,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onInit: function () {
          this._initModels();
          this.getRouter()
            .getRoute("notificationsDetail")
            .attachPatternMatched(this.onRouteMatched, this);
          this.getRouter()
            .getRoute("notificationsDetailFromConf")
            .attachPatternMatched(this.onFromConfMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function (oEvent) {
          //set scanner location
          this.getScanHandler().setLocation("NotificationDetail");

          var sID = oEvent.getParameter("arguments").ID;
          var oOrderDetails = {};

          oOrderDetails.FrontendNotif = true;
          oOrderDetails.Confcse = false;
          oOrderDetails.Confdmg = false;
          oOrderDetails.Confbrd = false;

          this.getSharedModel().setProperty(
            "/connected",
            this.getHelper().isOnline()
          );

          //set shared properties - connection & orderdetails
          this.getConnection();

          this.getSharedModel().setProperty("/OrderDetails", oOrderDetails);

          if (!this.oIconBarNotif) {
            this.oIconBarNotif = this.getView().byId("iconBarNotif");
          }
          this.oIconBarNotif.setSelectedKey("info");
          this._bindView("/NotBoundNotificationSet/", sID);
          this.changeColorOfDeviceId();
        },

        onFromConfMatched: function (oEvent) {
          //set scanner location
          this.getScanHandler().setLocation("NotificationDetail");

          var sID = oEvent.getParameter("arguments").ID;
          var oOrderDetails = {};
          this.getView()
            .getModel("vh")
            .setData(this.getSharedModel().getProperty("/vh"));
          oOrderDetails.FrontendNotif =
            oEvent.getParameter("arguments").FromConf === "true" ? false : true;
          oOrderDetails.ConfID = oEvent.getParameter("arguments").ConfID;
          oOrderDetails.Confcse =
            oEvent.getParameter("arguments").Confcse === "true" ? true : false;
          oOrderDetails.Confdmg =
            oEvent.getParameter("arguments").Confdmg === "true" ? true : false;
          oOrderDetails.Confbrd =
            oEvent.getParameter("arguments").Confbrd === "true" ? true : false;

          this.getSharedModel().setProperty("/OrderDetails", oOrderDetails);

          $.when(this._getNotificationsFromDb()).done(
            jQuery.proxy(function () {
              if (!this.oIconBarNotif) {
                this.oIconBarNotif = this.getView().byId("iconBarNotif");
              }
              this.oIconBarNotif.setSelectedKey("info");
              var ausbs = this.getView()
                .getModel("local")
                .getProperty("/PMNotificationSet/" + sID + "/AusbsDatetime");
              // this.getView().byId("Ausbs").setEnabled(true);
              this.getView()
                .getModel("local")
                .setProperty(
                  "/PMNotificationSet/" + sID + "/endDateIsEnabled",
                  true
                );
              if (oOrderDetails.Confbrd & !ausbs) {
                this.getView().byId("Ausbs").setDateValue(new Date());
              }
              this._bindView("/PMNotificationSet/", sID);
              this._checkFLSpecificData();
            }, this)
          );
          if (
            this.getSharedModel() &&
            this.getSharedModel().getProperty("/deviceIdColor")
          ) {
            this.getView().addStyleClass(
              this.getSharedModel().getProperty("/deviceIdColor")
            );
          }
        },

        onQmartSelect: function (oEvent) {
          var oSelectedObject = oEvent
              .getParameter("selectedItem")
              .getBindingContext("vh")
              .getObject(),
            sQmartKey = oSelectedObject.Key;
          this._setField("Qmart", sQmartKey);
          this._filterSelects(
            sQmartKey,
            null,
            this.getView().getBindingContext("local").getObject().FollowUp
          );

          if (
            this.getView().getBindingContext("local").getObject().Craft &&
            this.getView().getBindingContext("local").getObject().Qmart
          ) {
            this._getAICCustomizing();
          }
          if (sQmartKey === "30,DEFE" || sQmartKey === "30,IMME") {
            this.getView().byId("Ausvn").setDateValue(new Date());
          } else {
            this._setField("AusvnDatetime", "");
          }
          let sGrp = oSelectedObject.CodeGrp;
          this._setField("Qmgrp", sGrp);

          this.findFunctionLocOrg();
        },

        // onQmcodSelect: function (oEvent) {
        // 	var oObject = oEvent.getSource().getSelectedItem().getBindingContext("vh").getObject(),
        // 		notifObject = this.getView().getBindingContext("local").getObject(),
        // 		sGrp = oObject.Codgrr;
        // 	this._setField("Qmgrp", sGrp);
        // 	if (notifObject.Craft) {
        // 		this._getAICCustomizing();
        // 	}
        // 	this.findFunctionLocOrg();
        // },

        onOteilSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr,
            oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath;

          this._setField("Otgrp", sGrp);
          oLocalModel.setProperty(
            sPath + "/Otkat",
            this.getHelper().getCatalogKey("oteil")
          );
        },

        onFecodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setField("Fegrp", sGrp);
        },

        onUrcodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setField("Urgrp", sGrp);
        },

        onMfcodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setField("Mfgrp", sGrp);
        },

        onMncodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setField("Mngrp", sGrp);
        },

        onCancelPress: function (oEvent) {
          this.getRouter().navTo("notificationsMaster");
        },

        onPictureUpload: function (oEvent) {
          var oFile = oEvent.getParameter("files")[0],
            oReader = new FileReader();

          oReader.onload = jQuery.proxy(function (oResult) {
            this.onPhotoTakenSuccess(oResult.target.result.split(",")[1]);
            this.getView().byId("NotificationDetailFileUploader").clear();
            var that = this;
            that.getView().byId("iconBarNotif").setSelectedKey("info");
            setTimeout(function () {
              that.getView().byId("iconBarNotif").setSelectedKey("photo");
            }, 2000);
          }, this);

          if (oFile) {
            oReader.readAsDataURL(oFile);
          }
        },

        onPhotoAddPress: function (oEvent) {
          navigator.camera.getPicture(
            jQuery.proxy(this.onPhotoTakenSuccess, this),
            jQuery.proxy(this.onPhotoTakenFail, this),
            {
              destinationType: Camera.DestinationType.DATA_URL,
              allowEdit: false,
              quality: 30,
            }
          );
        },

        onPhotoDeletePress: function (oEvent) {
          var oBindingContext = oEvent
              .getParameter("listItem")
              .getBindingContext("local"),
            sPicHandle = oBindingContext.getProperty("Handle");

          MBox.confirm(this.getText("ConfirmPicDelete"), {
            onClose: function (sAction) {
              if (sPicHandle && sAction === sap.m.MessageBox.Action.OK) {
                $.when(
                  this.getDBService().deleteObject(
                    "Picture",
                    oBindingContext.getObject()
                  )
                )
                  .done(
                    jQuery.proxy(function () {
                      this._getPhotosFromDatabase(
                        this.getView().getBindingContext("local").getObject()
                          .Handle
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      MBox.error(this.getText("PicDeleteError"));
                    }, this)
                  );
              }
            }.bind(this),
          });
        },

        onPhotoTakenSuccess: function (sBase64) {
          var image = "data:image/jpeg;base64," + sBase64;
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "newImage"
          );
          this.getView()
            .getModel("newImage")
            .setProperty("/RotateImage", image);
          this._getRotateDialog().open();
        },

        onSuccessPics: function (sBase64) {
          this._getRotateDialog().close();
          var sHandle = "",
            sContent = "",
            sMimetype = "",
            sParentHandle = "",
            sName = "",
            oPhotoObject = {},
            sPicIndex = 0;
          var oObject = this.getView().getBindingContext("local").getObject();
          sHandle = this.getHelper().getUUID();
          sParentHandle = oObject.Handle;
          sContent = sBase64;
          sMimetype = "image/jpeg";
          sName = "notif_" + new Date().getTime() + ".jpeg";
          if (oObject.Photos) {
            sPicIndex = oObject.Photos.length + 1;
          } else {
            sPicIndex = 1;
          }

          oPhotoObject = {
            Tag: "",
            Handle: sHandle,
            PicIndex: sPicIndex,
            Description: "",
            Parent: sParentHandle,
            PicName: sName,
            PicType: sMimetype,
            PicContent: sContent,
          };

          $.when(
            this.getDBService().insertObject("Picture", oPhotoObject)
          ).done(
            jQuery.proxy(function () {
              var oLocalModel = this.getView().getModel("local"),
                sPath = this.getView().getBindingContext("local").sPath,
                aPhotos = oLocalModel.getProperty(sPath + "/Photos");
              if (!aPhotos) {
                aPhotos = [];
              }
              aPhotos.push(oPhotoObject);
              oLocalModel.setProperty(sPath + "/Photos", aPhotos);
              oLocalModel.setProperty(sPath + "/PicCount", aPhotos.length);
              this.getView()
                .getModel("selectedNotification")
                .setProperty("/PicCount", aPhotos.length);
            }, this)
          );
        },

        onPhotoTakenFail: function (oError) {
          MBox.error(oError.toString());
        },

        onSavePress: function (oEvent, reset) {
          var oNotification = this.getView()
              .getBindingContext("local")
              .getObject(),
            oValidation = null,
            sMandDamage = this.getSharedModel().getProperty(
              "/sapSettings/MAND_DAMAG"
            ),
            sMandCause = this.getSharedModel().getProperty(
              "/sapSettings/MAND_CAUSE"
            ),
            sMandActiv = this.getSharedModel().getProperty(
              "/sapSettings/MAND_ACTIV"
            ),
            sIncFields = "";

          // if ((this.getSharedModel().getProperty("/sapSettings/IWERK") === "1000" || this.getSharedModel().getProperty("/sapSettings/IWERK") ===
          // 		1000 || this.getSharedModel().getProperty("/sapSettings/IWERK") ===
          // 		"BEA0") && (!oNotification.Fecod || !oNotification.Oteil) && ((oNotification.Qmcod === "RED" && oNotification.Qmart === "40") ||
          // 		oNotification.Qmart === "30") &&
          // 	oNotification.Craft === "FA") {
          // 	MBox.warning(this.getText("NotificationMissingData"));
          // } else {
          if (
            this.getSharedModel().getProperty("/OrderDetails/FrontendNotif") ===
              false ||
            this.getSharedModel().getProperty("/OrderDetails/FrontendNotif") ===
              "false"
          ) {
            if (!oNotification.RepByWc)
              oNotification.RepByWc = oNotification.Arbpl;
          }
          if (!reset) {
            this._setField("SendToGk", "");
            this._setField("Complete", "");
          }
          if (oNotification) {
            oValidation = this.getValidator().validateNotification(
              oNotification,
              sMandCause,
              sMandDamage,
              sMandActiv,
              this.getSharedModel().getProperty("/")
            );

            if (oValidation.isValid) {
              $.when(
                this.getDBService().updateObject(
                  "PMNotification",
                  oNotification
                )
              )
                .done(
                  jQuery.proxy(function (oData) {
                    MToast.show(this.getText("NotifUpdated"));
                    this.getLogs().addLog(
                      this.getText("NotifUpdated"),
                      "INFO",
                      "NotificationDetail"
                    );
                    if (
                      this.getSharedModel().getProperty(
                        "/OrderDetails/FrontendNotif"
                      ) === false ||
                      this.getSharedModel().getProperty(
                        "/OrderDetails/FrontendNotif"
                      ) === "false"
                    ) {
                      this.getRouter().navTo("confirmationsDetail", {
                        ID: this.getSharedModel().getProperty(
                          "/OrderDetails/ConfID"
                        ),
                      });
                    }
                  }, this)
                )
                .fail(jQuery.proxy(function (oError) {}, this));
            } else {
              for (var sField in oValidation.aFields) {
                if (sIncFields === "") {
                  sIncFields += this.getText(oValidation.aFields[sField]);
                } else {
                  sIncFields +=
                    ", " + this.getText(oValidation.aFields[sField]);
                }
              }
              this.getLogs().addLog(
                this.getText("FillInRequiredFields", sIncFields),
                "ERROR",
                "NotificationDetail"
              );
              MBox.error(this.getText("FillInRequiredFields", sIncFields));
            }
          }
        },

        onDeletePress: function () {
          var oObject = this.getView().getBindingContext("local").getObject(),
            oFollowUpData = {
              Handle: oObject.Handle,
            },
            oFollowUp = [
              {
                name: "Handle",
              },
            ];

          MBox.confirm(this.getText("ConfirmDeleteNotif"), {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                this.getSharedModel().setProperty("/changed", true);
                $.when(this.getDBService().deleteNotification(oObject.Handle))
                  .done(
                    jQuery.proxy(function () {
                      this.getLogs().addLog(
                        "Notification Deleted Success",
                        "INFO",
                        "NotificationDetail"
                      );
                      $.when(
                        this.getDBService().deletePicturesFromParent(
                          oObject.Handle
                        ),
                        this.getDBService().deleteObject(
                          "FollowUpNotif",
                          oFollowUpData,
                          oFollowUp
                        )
                      ).done(
                        jQuery.proxy(function () {
                          this.getRouter().navTo("notificationsMaster");
                        }, this)
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      this.getLogs().addLog(
                        "Notification Delete Failed",
                        "INFO",
                        "NotificationDetail"
                      );
                    }, this)
                  );
              }
            }, this),
          });
        },

        onCreateConfPress: function (oEvent) {
          var oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath,
            sHandle = oLocalModel.getProperty(sPath + "/Handle"),
            oNotification = this.getView()
              .getBindingContext("local")
              .getObject(),
            MnWkCtr = oNotification.Arbpl
              ? oNotification.Arbpl
              : this.getSharedModel().getProperty("/sapSettings/GEWRK");
          if (!MnWkCtr) {
            MnWkCtr = this.getSharedModel().getProperty("/sapSettings/ARBPL");
          }

          $.when(
            this.getDBService().updateObject("PMNotification", oNotification)
          )
            .done(
              jQuery.proxy(function (oData) {
                this.getRouter().navTo("createConfirmationFromNotif", {
                  Handle: sHandle,
                  WorkCntr: oNotification.Arbpl,
                  MnWkCtr: MnWkCtr,
                });
              }, this)
            )
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        onNavBack: function () {
          if (
            this.getSharedModel().getProperty("/OrderDetails/FrontendNotif") ===
            false
          ) {
            // this.getRouter().navTo("confirmationsMaster");
            this.getRouter().navTo("confirmationsDetail", {
              ID: this.getSharedModel().getProperty("/OrderDetails/ConfID"),
            });
          } else {
            this.getRouter().navTo("notificationsMaster", true);
          }
        },

        onInstallationTreeRequest: function () {
          //Issue 75 FL Tree Table not having value while Scanning Notifcations
          // if (this.getView().getModel("selectedNotification").getProperty("/Scanid")) {
          // 	this._getInstallationTreeDialog().open();
          // } else {
          $.when(this._onInstallationTreeRequest())
            .done(
              jQuery.proxy(function () {
                this._getInstallationTreeDialog().open();
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                MBox.error("InstallationTreeError");
              }, this)
            );
          // }
        },

        _onInstallationTreeRequest: function () {
          var d = $.Deferred();
          $.when(
            this.getDBService().getEntitySet("TechnicalObject"),
            this.getDBService().getEntitySet("FuncLocOrg")
          )
            .done(
              jQuery.proxy(function (oData, funcLocOrg) {
                var aTechnicalObjectSet = this.getHelper().rowsToArray(oData),
                  aFuncLocOrg = this.getHelper().rowsToArray(funcLocOrg);
                aTechnicalObjectSet = _.filter(
                  aTechnicalObjectSet,
                  function (oTechnicalObject) {
                    return (
                      oTechnicalObject &&
                      oTechnicalObject.TechObjectType !== "PA"
                    );
                  }
                );
                aTechnicalObjectSet = this.divideFunctionLocParent(
                  aTechnicalObjectSet,
                  "Parent"
                );
                this.getSharedModel().setProperty(
                  "/techObjects",
                  this.getHelper().rowsToArray(oData)
                );
                //coil handling not picking up
                this.getSharedModel().setProperty(
                  "/techObjectsFiltered",
                  aTechnicalObjectSet.filter(function (oTech) {
                    return (
                      oTech.Ktx01 &&
                      (oTech.TechObjectType === "FL" ||
                        oTech.TechObjectType === "EQ" ||
                        oTech.TechObjectType === "IF")
                    );
                  })
                );
                this.getSharedModel().setProperty("/FuncLocOrg", aFuncLocOrg);
                var flData = this.getHelper().createTree(
                  aTechnicalObjectSet,
                  "TechObject",
                  "Parent",
                  "Children",
                  "sort",
                  "TechObjectType"
                );
                flData.forEach(
                  jQuery.proxy(function (locGrp) {
                    if (locGrp && locGrp.Groupname) {
                      locGrp.Children = this.sortFunctionLocationGroup(
                        locGrp.Children,
                        "Posnr",
                        "Tplnr"
                      );
                      if (locGrp.Children) {
                        var withoutSeqno = locGrp.Children.filter(function (
                            row
                          ) {
                            return !row.Seqno;
                          }),
                          withSeqno = locGrp.Children.filter(function (row) {
                            return row.Seqno;
                          });
                        withSeqno = _.sortBy(withSeqno, "Seqno");
                        withoutSeqno = _.sortBy(withoutSeqno, "Ktx01");
                        locGrp.Children = withSeqno.concat(withoutSeqno);
                      }
                    } else if (locGrp) {
                      locGrp.Children = this.sortFunctionLocationGroup(
                        locGrp.Children,
                        "Posnr"
                      );
                    }
                  }, this)
                );
                this.getSharedModel().setProperty("/tree", flData);
                d.resolve();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                d.reject();
              }, this)
            );
          return d.promise();
        },

        onInstallationSelected: function (oEvent) {
          var oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath,
            oObject;
          try {
            oObject = oEvent.getParameter("rowContext").getObject();
          } catch (e) {
            oObject = oEvent;
          }

          if (oObject.TechObjectType === "EQ") {
            oLocalModel.setProperty(sPath + "/Equnr", oObject.Equnr);
            oLocalModel.setProperty(sPath + "/EqnurKtx01", oObject.Ktx01);
            var oFoundFloc = _.find(
              this.getSharedModel().getProperty("/techObjects"),
              jQuery.proxy(function (oFuncLoc) {
                return (
                  oFuncLoc.TechObject === oObject.Parent &&
                  oFuncLoc.TechObjectType !== "PA"
                );
              }, this)
            );
            var oFoundFL = _.find(
              this.getSharedModel().getProperty("/techObjects"),
              jQuery.proxy(function (oFuncLoc) {
                return oFuncLoc.TechObject === oObject.TechObject;
              }, this)
            );
            oLocalModel.setProperty(sPath + "/TechObject", oFoundFL.TechObject);
            if (oFoundFloc) {
              oLocalModel.setProperty(sPath + "/Tplnr", oFoundFloc.Strno);
              oLocalModel.setProperty(sPath + "/Ktx01", oFoundFloc.Ktx01);

              var aFoundFuncLocCraft = _.filter(
                this.getSharedModel().getProperty("/FuncLocCraft"),
                jQuery.proxy(function (oFuncLocCraft) {
                  return oFoundFloc && oFuncLocCraft.Tplnr === oFoundFloc.Strno;
                }, this)
              );
            }
          } else if (
            oObject.TechObjectType === "FL" ||
            oObject.TechObjectType === "IF"
          ) {
            oLocalModel.setProperty(sPath + "/Equnr", "");
            oLocalModel.setProperty(sPath + "/Tplnr", oObject.Strno);
            oLocalModel.setProperty(sPath + "/Ktx01", oObject.Ktx01);
            oLocalModel.setProperty(sPath + "/EqnurKtx01", "");

            this._checkFLSpecificData();

            // search craftcodes for selected func loc
            aFoundFuncLocCraft = _.filter(
              this.getSharedModel().getProperty("/FuncLocCraft"),
              jQuery.proxy(function (oFuncLocCraft) {
                return oObject && oFuncLocCraft.Tplnr === oObject.Strno;
              }, this)
            );

            var aFoundHigherFuncLocCraft =
              this._checkHigherFuncLocCraft(oObject);

            aFoundFuncLocCraft = _.concat(
              aFoundFuncLocCraft,
              aFoundHigherFuncLocCraft
            );
          } else {
            MBox.error(this.getText("GRInstallNotPossible"));
            return;
          }

          // // no craft codes found for selected func loc, search for craft codes on higher func loc
          // if (aFoundFuncLocCraft.length === 0) {

          // }

          if (aFoundFuncLocCraft && aFoundFuncLocCraft[0]) {
            if (aFoundFuncLocCraft.length > 0) {
              _.each(
                aFoundFuncLocCraft,
                jQuery.proxy(function (oFuncLocCraft) {
                  var oFoundCraft = _.find(
                    this.getModel("vh").getProperty("/Craft"),
                    function (oCraft) {
                      return (
                        oFuncLocCraft && oCraft.VhKey === oFuncLocCraft.Craft
                      );
                    }
                  );

                  oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                }, this)
              );

              var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
              var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");
              aCraftCodeList = this.addEmptyLineToTable(aCraftCodeList);
              aFoundFuncLocCraft = this.addEmptyLineToTable(aFoundFuncLocCraft);
              aWorkCenterList = this.addEmptyLineToTable(aWorkCenterList);

              this.getSharedModel().setProperty(
                "/CraftCodeList",
                aCraftCodeList
              );
              this.getSharedModel().setProperty(
                "/PlannerGroupList",
                aFoundFuncLocCraft
              );
              this.getSharedModel().setProperty(
                "/WorkCenterList",
                aWorkCenterList
              );
            }
          } else {
            oLocalModel.setProperty(sPath + "/Craft", "");
            this.getSharedModel().setProperty("/CraftCodeList", "");
            this.getSharedModel().setProperty("/PlannerGroupList", []);
          }
          this.findFunctionLocOrg();
          this._getInstallationTreeDialog().close();
        },

        onInstallationDialogCancelPress: function (oEvent) {
          this._getInstallationTreeDialog().close();
        },

        onCraftSelectionChange: function (oEvent) {
          // model: sharedModel: property -> flocCraft
          this._checkFLSpecificData();

          if (this.getModel("selectedNotification").getProperty("/Craft")) {
            var oFoundFuncLocCraft = _.find(
              this.getSharedModel().getProperty("/FuncLocCraft"),
              jQuery.proxy(function (oFuncLocCraft) {
                return (
                  this.getModel("selectedNotification").getProperty(
                    "/Craft"
                  ) === oFuncLocCraft.Craft &&
                  oFuncLocCraft.Tplnr ===
                    this.getModel("selectedNotification").getProperty("/Tplnr")
                );
              }, this)
            );
            if (oFoundFuncLocCraft) {
              this.getModel("selectedNotification").setProperty(
                "/CraftIngpr",
                oFoundFuncLocCraft.Ingrp
              );
              this.getModel("selectedNotification").setProperty(
                "/CraftArbpl",
                oFoundFuncLocCraft.Gewrk
              );
              this.getModel("selectedNotification").setProperty(
                "/GEWRK",
                oFoundFuncLocCraft.Gewrk
              );
            } else {
              var oFoundFloc = _.find(
                this.getSharedModel().getProperty("/techObjects"),
                jQuery.proxy(function (oFuncLoc) {
                  return (
                    oFuncLoc &&
                    oFuncLoc.Tplnr ===
                      this.getModel("selectedNotification").getProperty(
                        "/Tplnr"
                      )
                  );
                }, this)
              );

              if (oFoundFloc) {
                var aFoundFuncLocCraft =
                  this._checkHigherFuncLocCraft(oFoundFloc);
              }

              if (aFoundFuncLocCraft.length > 0) {
                aFoundFuncLocCraft = _.filter(
                  aFoundFuncLocCraft,
                  jQuery.proxy(function (oFuncLocCraft) {
                    return (
                      this.getModel("selectedNotification").getProperty(
                        "/Craft"
                      ) === oFuncLocCraft.Craft
                    );
                  }, this)
                );

                _.each(
                  aFoundFuncLocCraft,
                  jQuery.proxy(function (oFuncLocCraft) {
                    var oFoundCraft = _.find(
                      this.getModel("vh").getProperty("/Craft"),
                      function (oCraft) {
                        return (
                          oFuncLocCraft && oCraft.VhKey === oFuncLocCraft.Craft
                        );
                      }
                    );

                    oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                  }, this)
                );

                var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
                var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");

                this.getModel("selectedNotification").setProperty(
                  "/Craft",
                  aCraftCodeList[0].Craft
                );
                this.getModel("selectedNotification").setProperty(
                  "/CraftArbpl",
                  aWorkCenterList[0].Gewrk
                );
                this.getModel("selectedNotification").setProperty(
                  "/CraftIngpr",
                  aFoundFuncLocCraft[0].Ingrp
                );
                this.getModel("selectedNotification").setProperty(
                  "/GEWRK",
                  aWorkCenterList[0].Gewrk
                );

                if (aFoundFuncLocCraft.length > 1) {
                  this.getSharedModel().setProperty(
                    "/plannerGroupsList",
                    aFoundFuncLocCraft
                  );
                }
              }
            }
            if (this.getModel("selectedNotification").getProperty("/Qmart")) {
              this._getAICCustomizing();
            }
          } else {
          }
          this.getModel("selectedNotification").refresh();
          this.findFunctionLocOrg();
        },

        onIngprChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty("/Ingpr", sValue.toUpperCase());
            this.getView()
              .getModel("local")
              .setProperty("/FinalIngrpFrom", "UserAdded");
          }
        },

        onArbplChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            sPath = this.getView().getBindingContext("local").sPath;

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Arbpl", sValue.toUpperCase());
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/FinalArbplFrom", "UserAdded");
          }
        },

        onQmnamChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty("/Qmnam", sValue.toUpperCase());
          }
        },

        onTplnrChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty("/Tplnr", sValue.toUpperCase());
            this._checkFLSpecificData();
          }
          this.findFunctionLocOrg();
        },

        onRepByWcChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            sPath = this.getView().getBindingContext("local").sPath;

          if (sValue) {
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/RepByWc", sValue.toUpperCase());
          }
        },

        onPlannerGroupRequest: function () {
          this._getPlannerGroupDialog().open();
        },

        onWorkCenterRequest: function () {
          this._getWorkCenterDialog().open();
        },

        onPlannerGroupDialogCancelPress: function () {
          this._getPlannerGroupDialog().close();
        },

        onWorkCenterDialogCancelPress: function () {
          this._getWorkCenterDialog().close();
        },

        onPlannerGroupSelected: function (oEvent) {
          var sPath = oEvent
              .getParameter("listItem")
              .getBindingContext("shared").sPath,
            oObject = this.getSharedModel().getProperty(sPath),
            oLocalModel = this.getView().getModel("local"),
            sLocalPath = this.getView().getBindingContext("local").sPath;

          oLocalModel.setProperty(sLocalPath + "/Ingpr", oObject.Ingrp);
          oLocalModel.setProperty(sLocalPath + "/FinalIngrpFrom", "UserAdded");
          this._getPlannerGroupDialog().close();
        },

        onWorkCenterSelected: function (oEvent) {
          var sPath = oEvent
              .getParameter("listItem")
              .getBindingContext("shared").sPath,
            oObject = this.getSharedModel().getProperty(sPath),
            oLocalModel = this.getView().getModel("local"),
            sLocalPath = this.getView().getBindingContext("local").sPath;

          oLocalModel.setProperty(sLocalPath + "/RepByWc", oObject.Gewrk);
          oEvent.getSource().removeSelections(true);
          this._getWorkCenterDialog().close();
        },

        onSyncNotifPress: function () {
          this.getView().byId("syncButtonInNotif").setEnabled(false);
          setTimeout(
            jQuery.proxy(function () {
              this.getView().byId("syncButtonInNotif").setEnabled(true);
            }, this),
            5000
          );
          var oNotification = this.getView()
            .getBindingContext("local")
            .getObject();
          var oFollowUpData = {
              Handle: oNotification.Handle,
            },
            oFollowUp = [
              {
                name: "Handle",
              },
            ];
          $.when(
            this.getDBService().getNotificationWithHandle(oNotification.Handle),
            this.getDBService().getConfirmationsBoundToNotification(
              oNotification.Handle
            ),
            this.getDBService().getPicturesBoundToNotification(
              oNotification.Handle
            )
          ).done(
            jQuery.proxy(function (
              oNotifData,
              oConfirmationData,
              oPictureData
            ) {
              var aNotif = this.getHelper().rowsToArray(oNotifData),
                aConfirmations =
                  this.getHelper().rowsToArray(oConfirmationData),
                aPictures = this.getHelper().rowsToArray(oPictureData);

              if (aConfirmations.length === 0) {
                if (!this.getService()) {
                  MBox.error(this.getText("ConnectionUnknown"));
                  return 0;
                }

                $.when(this.getService().sync(aNotif, [], [], aPictures))
                  .done(
                    jQuery.proxy(function () {
                      console.debug("notification synchronised");
                      $.when(
                        this.getDBService().deleteNotification(
                          aNotif[0].Handle
                        ),
                        this.getDBService().deletePicturesBoundToNotification(
                          aNotif[0].Handle
                        ),
                        this.getDBService().deleteObject(
                          "FollowUpNotif",
                          oFollowUpData,
                          oFollowUp
                        )
                      ).done(
                        jQuery.proxy(function () {
                          MBox.success(this.getText("SyncSuccess"));
                          this.getRouter().navTo("main", true);
                        }, this)
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function (oData) {
                      this.getView().setBusy(false);
                      MBox.error(oData.message);
                    }, this)
                  );
              } else {
                MBox.error(
                  this.getText("NoSyncPossibleWithNotifConfirmations")
                );
              }
            },
            this)
          );
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        getQmartText: function (sQmartCode) {
          return this._getQmartText(sQmartCode);
        },

        getQmcodText: function (sQmartCode, a) {
          return sQmartCode === "30,DEFE"
            ? a
              ? "30,IMME"
              : sQmartCode
            : sQmartCode;
        },

        isAusDTPEnabled: function (bMsaus, endDate) {
          if (bMsaus || endDate) {
            return true;
          } else {
            return false;
          }
        },

        isBreakDownVisible: function (sQmart, SQmcod) {
          let oQmart;
          if (sQmart && SQmcod) {
            oQmart =
              sQmart.indexOf(",") !== -1 ? sQmart : sQmart + "," + SQmcod;
          } else {
            oQmart = sQmart;
          }
          return (
            (oQmart === "30,DEFE" || oQmart === "30,IMME") &&
            ((this.getSharedModel().getProperty(
              "/OrderDetails/FrontendNotif"
            ) &&
              this.getSharedModel().getProperty(
                "/sapSettings/notifFields/Msaus"
              )) ||
              this.getSharedModel().getProperty("/OrderDetails/Confbrd"))
          );
        },

        isScanidProvided: function (sScanid) {
          if (!sScanid) {
            return false;
          } else {
            return true;
          }
        },

        // isSendToGkVisible: function (sQmart, sQmcod) {
        // 	var odata = [
        // 		{ "sQmart": "10", "sQmcod": "TBMP" },
        // 		{ "sQmart": "20", "sQmcod": "1TIM" },
        // 		{ "sQmart": "20", "sQmcod": "INRR" },
        // 		{ "sQmart": "30", "sQmcod": "DEFE" },
        // 		{ "sQmart": "40", "sQmcod": "RED" },
        // 		{ "sQmart": "50", "sQmcod": "RED" },
        // 		{ "sQmart": "60" },
        // 		{ "sQmart": "70" }
        // 	];
        // 	return this.visibiltyFilter(sQmart, sQmcod, odata);
        // },

        isBreakDownSeleceted: function (sQmart) {
          if ((sQmart === "30,DEFE", sQmart === "30,IMME")) {
            var sPath = this.getView().getBindingContext("local").sPath;
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Msaus", true);
            return true;
          } else {
            if (this.getView().getBindingContext("local")) {
              sPath = this.getView().getBindingContext("local").sPath;
              this.getView()
                .getModel("local")
                .setProperty(sPath + "/Msaus", false);
            }
          }
          return false;
        },

        visibiltyFilter: function (sQmart, data) {
          if (sQmart) {
            var odata = data.filter(function (row) {
              if (sQmart === row.sQmart) {
                // if (row.sQmcod) {
                // 	return sQmcod === row.sQmcod;
                // } else
                return true;
              }
            });
            if (odata.length > 0) {
              return true;
            }
          }
          return false;
        },

        isCompleteVisible: function (sQmart) {
          var odata = [
            { sQmart: "40,BLUE" },
            { sQmart: "50,BLUE" },
            { sQmart: "60,GENE" },
          ];
          let returnValue = this.visibiltyFilter(sQmart, odata);
          if (!returnValue && sQmart) {
            var oLocalModel = this.getView().getModel("local");
            if (this.getView().getBindingContext("local")) {
              var sPath = this.getView().getBindingContext("local").sPath;
              oLocalModel.setProperty(sPath + "/Complete", "");
            }
          }
          return returnValue;
        },

        setInstallationIcon: function (sType) {
          if (sType) {
            switch (sType.toUpperCase()) {
              case "FL":
                return "sap-icon://functional-location";
              case "IF":
                return "sap-icon://functional-location";
              case "EQ":
                return "sap-icon://technical-object";
              case "GR":
                return "sap-icon://group-2";
              case "MA":
                return "sap-icon://product"; //"sap-icon://suitcase" "sap-icon://product"
              default:
                return "sap-icon://question-mark";
            }
          } else {
            return "sap-icon://question-mark";
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "selectedNotification"
          );

          if (!this.getView().getModel("vh")) {
            var oSharedModel = this.getSharedModel(),
              oVHModel = new sap.ui.model.json.JSONModel();

            oVHModel.setSizeLimit(2500);
            oVHModel.setData(oSharedModel.getProperty("/vh"));

            this.getView().setModel(oVHModel, "vh");
          }
        },

        _checkFLSpecificData: function () {
          var oVhModel = this.getView().getModel("vh"),
            oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath,
            aCatalog = oVhModel.getProperty("/Catalog"),
            aTechnicalObjects =
              this.getSharedModel().getProperty("/techObjects"),
            sQmartKey = oLocalModel.getProperty(sPath + "/Qmart");
          if (sQmartKey) sQmartKey = sQmartKey.split(",")[0];
          if (oLocalModel.getProperty(sPath + "/Tplnr")) {
            var oFoundTechObject = _.find(
              aTechnicalObjects,
              jQuery.proxy(function (oTechObject) {
                return (
                  oLocalModel &&
                  oTechObject.Tplnr ===
                    oLocalModel.getProperty(sPath + "/Tplnr")
                );
              }, this)
            );
            if (oFoundTechObject)
              this.getModel("local").setProperty(
                sPath + "/TechObject",
                oFoundTechObject.TechObject
              );
          }

          var aFecodVh = [],
            cFecod = this.getHelper().getCatalogKey("fecod");
          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aFecodVh = _.filter(aCatalog, {
              Codct: cFecod,
              Rbnr: oFoundTechObject.Rbnr,
            });
          }

          if (aFecodVh.length > 0) {
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          } else {
            if (sQmartKey) {
              aFecodVh = _.filter(aCatalog, {
                Qmart: sQmartKey,
                Codct: cFecod,
              });
            }
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          }
          oLocalModel.setProperty(
            sPath + "/Fekat",
            this.getHelper().getCatalogKey("fecod")
          );
          //Oteil
          var aOteilVh = [],
            cOteil = this.getHelper().getCatalogKey("oteil");

          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aOteilVh = _.filter(aCatalog, {
              // Qmart: sQmartKey,
              Codct: cOteil,
              Rbnr: oFoundTechObject.Rbnr,
            });
            oVhModel.setProperty(
              "/CatOteil",
              this.createTable(aOteilVh, cOteil)
            );

            if (aOteilVh.length === 1) {
              oLocalModel.setProperty(sPath + "/Otkat", cOteil);
              oLocalModel.setProperty(sPath + "/Otgrp", aOteilVh[0].Codgrr);
              oLocalModel.setProperty(sPath + "/Oteil", aOteilVh[0].Code);
              oLocalModel.setProperty(
                sPath + "/Oteiltxt",
                aOteilVh[0].Kurztext
              );
            }
          }
          this.getSharedModel().setProperty(
            "/OteilVisible",
            aOteilVh.length > 0
          );
          this.getSharedModel().setProperty(
            "/OteilEnabled",
            aOteilVh.length > 1
          );

          //Urcod
          var aUrcodVh = [],
            cUrcod = this.getHelper().getCatalogKey("urcod");
          aUrcodVh = _.filter(aCatalog, {
            Qmart: sQmartKey,
            Codct: cUrcod,
          });
          oVhModel.setProperty("/CatUrcod", this.createTable(aUrcodVh, cUrcod));
          oLocalModel.setProperty(sPath + "/Urkat", cUrcod);
        },

        _bindView: function (sPath, sID) {
          var sBindingPath = sPath + sID,
            sQmartKey = "",
            sHandle = "",
            oObject = this.getView()
              .getModel("local")
              .getProperty(sBindingPath),
            oSharedModel = this.getSharedModel();
          //aMnWkCtr = "";
          this.getView()
            .getModel("selectedNotification")
            .setProperty("/", oObject);
          if (oObject) {
            if (
              oObject.Msaus === undefined ||
              oObject.Msaus === "" ||
              oObject.Msaus === false
            ) {
              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/Msaus", false);
            } else {
              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/Msaus", true);
            }
            this.getView()
              .getModel("selectedNotification")
              .setProperty("/DescriptionEdit", true);
            this.getView().bindElement({
              path: sBindingPath,
              model: "local",
            });
            this.adjustQmart();
            if (oObject.AusvnDatetime) {
              var oDate = new Date(oObject.AusvnDatetime);

              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/AusvnDatetime", null);

              this.getView().byId("Ausvn").setDateValue(oDate);
            }

            if (oObject.AusbsDatetime) {
              var oDate2 = new Date(oObject.AusbsDatetime);

              this.getView()
                .getModel("local")
                .setProperty(sBindingPath + "/AusbsDatetime", null);

              this.getView().byId("Ausbs").setDateValue(oDate2);
            }

            this._getAICCustomizing();

            sQmartKey = oObject.Qmart;
            sHandle = oObject.Handle;

            $.when(this.getDBService().getEntitySet("Participant")).done(
              jQuery.proxy(function (oData) {
                var aParticipants = this.getHelper().rowsToArray(oData);

                var oPartic = _.find(aParticipants, function (oParticipant) {
                  return (
                    oParticipant &&
                    oParticipant.Pernr !== "00000000" &&
                    oParticipant.Pernr
                  );
                });

                var sVal = "";
                if (oPartic) {
                  sVal = oPartic.Pernr;
                }

                // oNewNotifModel.setProperty("/Qmnam", sVal);

                if (!oSharedModel.getProperty("/notfications")) {
                  oSharedModel.setProperty("/notfications", {});
                }
                oSharedModel.setProperty("/pernrValues", aParticipants);

                // oSharedModel.setProperty("/notfications/defaultPernr", sVal);
              }, this)
            );
            //For Filtering QMCOD for Frontend Notification
            $.when(this.getDBService().getEntitySet("FollowUpNotif"))
              .done(
                jQuery.proxy(function (oData) {
                  var data = this._rowsToData(oData.rows);
                  this.oFollowUp = _.find(data, function (oFollow) {
                    return oFollow.Handle === oObject.Handle;
                  });
                  if (this.oFollowUp) {
                    this._filterSelects(
                      sQmartKey,
                      true,
                      this.oFollowUp.FollowUp
                    );
                    if (
                      this.oFollowUp.FollowUp &&
                      this.oFollowUp.FollowUp !== "undefined"
                    ) {
                      this.getView()
                        .getModel("local")
                        .setProperty(sBindingPath + "/FollowUp", true);
                      this.getView()
                        .getModel("local")
                        .setProperty(
                          sBindingPath + "/DisabledForNotifFromOrder",
                          false
                        );
                    }
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/FinalArbplFrom",
                        this.oFollowUp.FinalArbplFrom
                      );
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/FinalIngrpFrom",
                        this.oFollowUp.FinalIngrpFrom
                      );
                  } else {
                    //For Notification Missing Data from Confirmation
                    this._filterSelects(sQmartKey, true, false);
                  }
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  this._filterSelects(sQmartKey, true, false);
                }, this)
              );
            //this._filterSelects(sQmartKey, true);
            if (sHandle !== "") {
              this._getPhotosFromDatabase(sHandle);
            }

            this.getSharedModel().setProperty("/tree", null);
            $.when(this.getDBService().getEntitySet("TechnicalObject")).done(
              jQuery.proxy(function (oData) {
                var aTechnicalObjectSet = this.getHelper().rowsToArray(oData);
                aTechnicalObjectSet = _.filter(
                  aTechnicalObjectSet,
                  function (oTechnicalObject) {
                    return (
                      oTechnicalObject &&
                      oTechnicalObject.TechObjectType !== "PA"
                    );
                  }
                );
                if (oObject.Tplnr) {
                  // Added by 1015320 for Notification Decription 29/11/2022
                  var Ktx01 = _.filter(
                    aTechnicalObjectSet,
                    function (oTechnicalObject) {
                      return (
                        oTechnicalObject &&
                        oTechnicalObject.Tplnr === oObject.Tplnr
                      );
                    }
                  );
                  if (Ktx01.length > 0)
                    this.getView()
                      .getModel("local")
                      .setProperty(sBindingPath + "/Ktx01", Ktx01[0].Ktx01);
                }
                if (oObject.Equnr) {
                  var EqnurKtx01 = _.filter(
                    aTechnicalObjectSet,
                    function (oTechnicalObject) {
                      return (
                        oTechnicalObject &&
                        oTechnicalObject.Equnr === oObject.Equnr
                      );
                    }
                  );
                  // Addition Completes 29/11/2022
                  if (EqnurKtx01.length > 0)
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/EqnurKtx01",
                        EqnurKtx01[0].Ktx01
                      );
                }
                this.getSharedModel().setProperty(
                  "/techObjects",
                  this.getHelper().rowsToArray(oData)
                );
                this.getSharedModel().setProperty(
                  "/techObjectsFiltered",
                  aTechnicalObjectSet.filter(function (oTech) {
                    return (
                      oTech.Ktx01 &&
                      (oTech.TechObjectType === "FL" ||
                        oTech.TechObjectType === "EQ" ||
                        oTech.TechObjectType === "IF")
                    );
                  })
                );
                var oFoundFloc = _.find(
                  this.getSharedModel().getProperty("/techObjects"),
                  jQuery.proxy(function (oFuncLoc) {
                    return (
                      oFuncLoc && oObject && oFuncLoc.Strno === oObject.Tplnr
                    );
                  }, this)
                );

                if (oFoundFloc) {
                  this._checkFLSpecificData();
                  this.getModel("local").setProperty(
                    sBindingPath + "/TechObject",
                    oFoundFloc.TechObject
                  );
                }

                var aFoundFuncLocCraft = _.filter(
                  this.getSharedModel().getProperty("/FuncLocCraft"),
                  jQuery.proxy(function (oFuncLocCraft) {
                    return oObject && oFuncLocCraft.Tplnr === oObject.Tplnr;
                  }, this)
                );

                var aFoundHigherFuncLocCraft =
                  this._checkHigherFuncLocCraft(oFoundFloc);

                aFoundFuncLocCraft = _.concat(
                  aFoundFuncLocCraft,
                  aFoundHigherFuncLocCraft
                );

                if (aFoundFuncLocCraft) {
                  _.each(
                    aFoundFuncLocCraft,
                    jQuery.proxy(function (oFuncLocCraft) {
                      var oFoundCraft = _.find(
                        this.getModel("vh").getProperty("/Craft"),
                        function (oCraft) {
                          return (
                            oFuncLocCraft &&
                            oCraft.VhKey === oFuncLocCraft.Craft
                          );
                        }
                      );

                      if (oFoundCraft) {
                        oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                      }
                    }, this)
                  );

                  var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
                  var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");

                  _.each(aFoundFuncLocCraft, function (oFoundFuncLocCraft) {
                    if (oFoundFuncLocCraft) {
                      oFoundFuncLocCraft.Ingpr = oFoundFuncLocCraft.Ingrp;
                    }
                  });

                  aCraftCodeList = this.addEmptyLineToTable(aCraftCodeList);
                  aFoundFuncLocCraft =
                    this.addEmptyLineToTable(aFoundFuncLocCraft);
                  aWorkCenterList = this.addEmptyLineToTable(aWorkCenterList);

                  this.getSharedModel().setProperty(
                    "/CraftCodeList",
                    aCraftCodeList
                  );
                  this.getSharedModel().setProperty(
                    "/PlannerGroupList",
                    aFoundFuncLocCraft
                  );
                  this.getSharedModel().setProperty(
                    "/WorkCenterList",
                    aWorkCenterList
                  );
                }
              }, this)
            );

            this.getView().setBusy(true);

            $.when(
              this.getDBService().getInstallationTreeByScanId(oObject.Scanid)
            )
              .done(
                jQuery.proxy(function (oData) {
                  this.getSharedModel().setProperty(
                    "/tree",
                    this.getHelper().createTree(
                      this.getHelper().rowsToArray(oData),
                      "Tplnr",
                      "Tplma",
                      "Children"
                    )
                  );
                  this.getView().setBusy(false);
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  this.getView().setBusy(false);
                  MBox.error(this.getText("InstallationTreeError"));
                }, this)
              );
            $.when(
              this.getDBService().getConfirmationsBoundToNotification(
                oObject.Handle
              )
            )
              .done(
                jQuery.proxy(function (oConfirmationData) {
                  if (this.getHelper().rowsToArray(oConfirmationData).length) {
                    this.getView()
                      .getModel("local")
                      .setProperty(
                        sBindingPath + "/confirmationIsExisting",
                        true
                      );
                  }
                }, this)
              )
              .fail(jQuery.proxy(function () {}, this));
          }
        },

        _getInstallationTreeDialog: function () {
          if (!this.getOwnerComponent().oInstallationTreeDialogDetail) {
            this.getOwnerComponent().oInstallationTreeDialogDetail =
              sap.ui.xmlfragment(
                "installationTreeDetail",
                "mobilework.view.notifications.InstallationTreeDialog",
                this
              );
            this.getView().addDependent(
              this.getOwnerComponent().oInstallationTreeDialogDetail
            );
          }

          return this.getOwnerComponent().oInstallationTreeDialogDetail;
        },

        _getAICCustomizing: function () {
          $.when(
            this.getDBService().getAICByCraft(
              this.getView().getBindingContext("local").getObject().Craft
            )
          ).done(
            jQuery.proxy(function (oAic) {
              var aAICSet = this.getHelper().rowsToArray(oAic);
              var oQmart = this.getView()
                .getBindingContext("local")
                .getObject().Qmart;
              if (oQmart) {
                oQmart = oQmart.split(",");
              } else {
                oQmart = ["", ""];
              }

              var oAICFound = _.find(
                aAICSet,
                jQuery.proxy(function (oData) {
                  return (
                    (oData.Qmart === oQmart[0] && oData.Qmcod === oQmart[1]) ||
                    (oData.Qmart === oQmart[0] && !oData.Qmcod) ||
                    (oData.Qmart === "" && oData.Qmcod === "")
                  );
                }, this)
              );

              if (oAICFound) {
                this.getSharedModel().setProperty("/AICFound", true);
              } else {
                this.getSharedModel().setProperty("/AICFound", false);
              }
            }, this)
          );
        },

        _getQmartText: function (sQmartCode) {
          var aVHQmart = this.getView().getModel("vh").getProperty("/Qmart"),
            oFind = _.find(aVHQmart, {
              Key: sQmartCode,
            });

          if (oFind) {
            return this.getText(oFind.Description);
          } else {
            return sQmartCode;
          }
        },

        _getNotificationsFromDb: function () {
          var d = $.Deferred();

          $.when(this.getDBService().getEntitySet("PMNotification"))
            .done(
              jQuery.proxy(function (oData) {
                var oLocalModel = this.getView().getModel("local"),
                  aLocalNotificationSet = this.getHelper().rowsToArray(oData);

                var aNotBoundNotifications = [];

                if (!oLocalModel.getProperty("/PMNotificationSet")) {
                  oLocalModel.setProperty("/PMNotificationSet", []);
                }

                aLocalNotificationSet.forEach(function (oNotif) {
                  for (var sProp in oNotif) {
                    if (
                      oNotif[sProp] === "true" ||
                      oNotif[sProp] === "false" ||
                      oNotif[sProp] === "X"
                    ) {
                      oNotif[sProp] =
                        oNotif[sProp] === "true" || oNotif[sProp] === "X";
                    }
                    if (
                      (sProp === "SendToGk" || sProp === "Msaus") &&
                      oNotif[sProp] === ""
                    ) {
                      oNotif[sProp] = false;
                    }
                  }
                  // if (_.find(confirmations, { NotifHandle: oNotif.Handle })) {
                  // 	oNotif.confirmationIsExisting = true;
                  // } else {
                  // 	oNotif.confirmationIsExisting = false;
                  // }

                  if (oNotif.Qmnum === "") {
                    aNotBoundNotifications.push(oNotif);
                  }
                });

                oLocalModel.setProperty(
                  "/NotBoundNotificationSet",
                  aNotBoundNotifications
                );
                oLocalModel.setProperty(
                  "/PMNotificationSet",
                  aLocalNotificationSet
                );

                d.resolve();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                d.resolve();
              }, this)
            );

          return d.promise();
        },

        // _getQmcodText: function (sQmartCode, sQmcodCode) {
        // 	var aVHQmcod = this.getView().getModel("vh").getProperty("/Catalog"),
        // 		oFind = _.find(aVHQmcod, {
        // 			Qmart: sQmartCode,
        // 			Code: sQmcodCode
        // 		});

        // 	if (oFind) {
        // 		return oFind.Kurztext;
        // 	} else {
        // 		return sQmartCode + "-" + sQmcodCode;
        // 	}
        // },

        _getPhotosFromDatabase: function (sParentHandle) {
          $.when(this.getDBService().getPhotoNamesById(sParentHandle)).done(
            jQuery.proxy(function (oData) {
              var sPath = this.getView().getBindingContext("local").sPath,
                aPhotos = [];
              aPhotos = this.getHelper().rowsToArray(oData);
              aPhotos = _.sortBy(aPhotos, "PicIndex");
              this.getView()
                .getModel("local")
                .setProperty(sPath + "/Photos", aPhotos);
              this.getView()
                .getModel("local")
                .setProperty(sPath + "/PicCount", aPhotos.length);
              this.getView()
                .getModel("selectedNotification")
                .setProperty("/PicCount", aPhotos.length);
              this.getView().getModel("local").refresh(true);
              this.getView().getModel("selectedNotification").refresh(true);
            }, this)
          );
        },
        _filterSelects: function (sQmartKey, bBindView, followUp) {
          var oVhModel = this.getView().getModel("vh"),
            oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath,
            aCatalog = oVhModel.getProperty("/Catalog"),
            aTechnicalObjects =
              this.getSharedModel().getProperty("/techObjects"),
            aQmart;
          if (sQmartKey) {
            sQmartKey = sQmartKey.split(",")[0];
          }

          if (oLocalModel.getProperty(sPath + "/Tplnr")) {
            var oFoundTechObject = _.find(
              aTechnicalObjects,
              jQuery.proxy(function (oTechObject) {
                return (
                  oLocalModel &&
                  oTechObject.Tplnr ===
                    oLocalModel.getProperty(sPath + "/Tplnr")
                );
              }, this)
            );
          }

          //Qmcod
          // if (!bBindView) { //only do this if the selection is changed by the end user
          // 	oLocalModel.setProperty(sPath + "/Qmcod", "");
          // }
          //Qmart Filter
          //aQmart = this.getView().getModel("vh").getProperty("/Qmart");
          // if (followUp !== "true") {
          // 	aQmart = _.filter(aQmart, jQuery.proxy(function (qmart) {
          // 		if (qmart) {
          // 			return (qmart.VhKey !== '10');
          // 		}
          // 	}, this));
          // 	oVhModel.setProperty("/QmartForFrontendNotif", aQmart);
          // } else {
          // 	oVhModel.setProperty("/QmartForFrontendNotif", this.getView().getModel("vh").getProperty("/Qmart"));
          // }

          // var aQmcodVh = [];

          // aQmcodVh = _.filter(aCatalog, {
          // 	Qmart: sQmartKey,
          // 	Codct: this.getHelper().getCatalogKey("qmcod")
          // });

          // if (followUp !== "true") {
          // 	aQmcodVh = _.filter(aQmcodVh, jQuery.proxy(function (qmcod) {
          // 		return (qmcod.Code !== "INRR") && (qmcod.Code !== "INRB");
          // 	}, this));
          // }
          // oVhModel.setProperty("/CatQmcod", aQmcodVh);

          // if (aQmcodVh.length === 1) {
          // 	oLocalModel.setProperty(sPath + "/Qmcod", aQmcodVh[0].Code);
          // 	this._setField("Qmgrp", aQmcodVh[0].Codgrr);
          // 	this.findFunctionLocOrg();
          // }

          const cMncod = this.getHelper().getCatalogKey("mncod"),
            cFecod = this.getHelper().getCatalogKey("fecod"),
            cUrcod = this.getHelper().getCatalogKey("urcod"),
            cMfcod = this.getHelper().getCatalogKey("mfcod"),
            cOteil = this.getHelper().getCatalogKey("oteil");
          let sharedSettings = this.getSharedModel().getProperty(
            "/sapSettings/notifFields"
          );
          //Fecod
          var aFecodVh = [];
          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aFecodVh = _.filter(aCatalog, {
              Codct: cFecod,
              Rbnr: oFoundTechObject.Rbnr,
            });
          }

          if (aFecodVh.length > 0) {
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          } else {
            aFecodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cFecod,
            });
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          }
          if (oLocalModel.getProperty(sPath + "/Fecod")) {
            let item = aFecodVh.find((oCatalog) => {
              return (
                oLocalModel.getProperty(sPath + "/Fecod") === oCatalog.Code
              );
            });
            oLocalModel.setProperty(sPath + "/Fecodtxt", item.Kurztext);
          }

          oLocalModel.setProperty(sPath + "/Fekat", cFecod);

          //Urcod
          if (sharedSettings.Urcod) {
            var aUrcodVh = [];

            aUrcodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cUrcod,
            });
            oVhModel.setProperty(
              "/CatUrcod",
              this.createTable(aUrcodVh, cUrcod)
            );
            if (oLocalModel.getProperty(sPath + "/Urcod")) {
              let item = aUrcodVh.find((oCatalog) => {
                return (
                  oLocalModel.getProperty(sPath + "/Urcod") === oCatalog.Code
                );
              });
              oLocalModel.setProperty(sPath + "/Urcodtxt", item.Kurztext);
            }
          }
          oLocalModel.setProperty(sPath + "/Urkat", cUrcod);

          //Mfcod
          if (sharedSettings.Mfcod) {
            var aMfcodVh = [];

            aMfcodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cMfcod,
            });
            oVhModel.setProperty(
              "/CatMfcod",
              this.createTable(aMfcodVh, cMfcod)
            );
            if (oLocalModel.getProperty(sPath + "/Mfcod")) {
              let item = aMfcodVh.find((oCatalog) => {
                return (
                  oLocalModel.getProperty(sPath + "/Mfcod") === oCatalog.Code
                );
              });
              oLocalModel.setProperty(sPath + "/Mfcodtxt", item.Kurztext);
            }
          }
          oLocalModel.setProperty(sPath + "/Mfkat", cMfcod);

          //Mncod
          if (sharedSettings.Mncod) {
            var aMncodVh = [];

            aMncodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: this.getHelper().getCatalogKey("mncod"),
            });
            oVhModel.setProperty(
              "/CatMncod",
              this.createTable(aMncodVh, cMncod)
            );
            if (oLocalModel.getProperty(sPath + "/Mncod")) {
              let item = aMncodVh.find((oCatalog) => {
                return (
                  oLocalModel.getProperty(sPath + "/Mncod") === oCatalog.Code
                );
              });
              oLocalModel.setProperty(sPath + "/Mncodtxt", item.Kurztext);
            }
          }
          oLocalModel.setProperty(sPath + "/Mnkat", cMncod);

          //Oteil
          var aOteilVh = [];

          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aOteilVh = _.filter(aCatalog, {
              // Qmart: sQmartKey,
              Codct: cOteil,
              Rbnr: oFoundTechObject.Rbnr,
            });
            oVhModel.setProperty(
              "/CatOteil",
              this.createTable(aOteilVh, cOteil)
            );

            if (aOteilVh.length === 1) {
              oLocalModel.setProperty(sPath + "/Otkat", cOteil);
              oLocalModel.setProperty(sPath + "/Otgrp", aOteilVh[0].Codgrr);
              oLocalModel.setProperty(sPath + "/Oteil", aOteilVh[0].Code);
              oLocalModel.setProperty(
                sPath + "/Oteiltxt",
                aOteilVh[0].Kurztext
              );
            }
            if (oLocalModel.getProperty(sPath + "/Oteil")) {
              let item = aOteilVh.find((oCatalog) => {
                return (
                  oLocalModel.getProperty(sPath + "/Oteil") === oCatalog.Code
                );
              });
              oLocalModel.setProperty(sPath + "/Oteiltxt", item.Kurztext);
            }
          }

          // Add empty line to all of the catalogs
          var aArray = [];
          aArray.push(this.addEmptyLine(oVhModel.getProperty("/CatFecod")));

          if (
            oVhModel.getProperty("/CatFecod") &&
            oVhModel.getProperty("/CatFecod").length > 0
          ) {
            oVhModel.setProperty(
              "/CatFecod",
              _.concat(aArray, oVhModel.getProperty("/CatFecod"))
            );
          }
          if (
            oVhModel.getProperty("/CatUrcod") &&
            oVhModel.getProperty("/CatUrcod").length > 0
          ) {
            oVhModel.setProperty(
              "/CatUrcod",
              _.concat(aArray, oVhModel.getProperty("/CatUrcod"))
            );
          }
          if (
            oVhModel.getProperty("/CatMfcod") &&
            oVhModel.getProperty("/CatMfcod").length > 0
          ) {
            oVhModel.setProperty(
              "/CatMfcod",
              _.concat(aArray, oVhModel.getProperty("/CatMfcod"))
            );
          }
          if (
            oVhModel.getProperty("/CatMncod") &&
            oVhModel.getProperty("/CatMncod").length > 0
          ) {
            oVhModel.setProperty(
              "/CatMncod",
              _.concat(aArray, oVhModel.getProperty("/CatMncod"))
            );
          }
          if (
            oVhModel.getProperty("/CatOteil") &&
            oVhModel.getProperty("/CatOteil").length > 0
          ) {
            oVhModel.setProperty(
              "/CatOteil",
              _.concat(aArray, oVhModel.getProperty("/CatOteil"))
            );
          }
          aArray = [];

          //Check Gatekeeper
          // if (sQmartKey !== "40" && sQmartKey !== "30") {
          // 	oLocalModel.setProperty(sPath + "/SendToGk", false);
          // }
        },

        _setField: function (sField, sValue) {
          var sPath = this.getView().getBindingContext("local").sPath;
          this.getView()
            .getModel("local")
            .setProperty(sPath + "/" + sField, sValue);
        },

        _checkHigherFuncLocCraft: function (oObject) {
          var oParentFloc = _.find(
            this.getSharedModel().getProperty("/techObjects"),
            jQuery.proxy(function (oFuncLoc) {
              return (
                oFuncLoc && oObject && oFuncLoc.TechObject === oObject.Parent
              );
            }, this)
          );

          if (oParentFloc) {
            var aFoundFuncLocCraft = _.filter(
              this.getSharedModel().getProperty("/FuncLocCraft"),
              jQuery.proxy(function (oFuncLocCraft) {
                return oParentFloc && oFuncLocCraft.Tplnr === oParentFloc.Strno;
              }, this)
            );

            if (aFoundFuncLocCraft.length > 0) {
              return aFoundFuncLocCraft;
            } else {
              return this._checkHigherFuncLocCraft(oParentFloc);
            }
          }
        },

        _getPlannerGroupDialog: function () {
          if (!this.getOwnerComponent().oPlannerGroupDialogIndetail) {
            this.getOwnerComponent().oPlannerGroupDialogIndetail =
              sap.ui.xmlfragment(
                "plannerGroupIndetail",
                "mobilework.view.notifications.PlannerGroupDialog",
                this
              );
            this.getView().addDependent(
              this.getOwnerComponent().oPlannerGroupDialogIndetail
            );
          }

          return this.getOwnerComponent().oPlannerGroupDialogIndetail;
        },

        _getWorkCenterDialog: function () {
          if (!this.getOwnerComponent().oWorkCenterDialogDetail) {
            this.getOwnerComponent().oWorkCenterDialogDetail =
              sap.ui.xmlfragment(
                "WorkCenterDetail",
                "mobilework.view.notifications.WorkCenterDialog",
                this
              );
            this.getView().addDependent(
              this.getOwnerComponent().oWorkCenterDialogDetail
            );
          }

          return this.getOwnerComponent().oWorkCenterDialogDetail;
        },

        _rowsToData: function (rows) {
          var data = [];
          for (var i = 0; i < rows.length; i++) {
            if (rows.item(i)) data.push(rows.item(i));
          }
          return data;
        },

        onSendToGkPress: function () {
          var sBindingPath = this.getView().getBindingContext("local").sPath;
          this.getView()
            .getModel("local")
            .setProperty(sBindingPath + "/SendToGk", true);
          this.getView()
            .getModel("local")
            .setProperty(sBindingPath + "/Complete", "");
          this.onSavePress(null, true);
        },

        isCreateConfirmationVisible: function (sQmart, sComplete) {
          if (sQmart && !sComplete) {
            switch (sQmart.toUpperCase()) {
              case "20,1TIM":
                return true;
              case "40,BLUE":
                return true;
              case "30,IMME":
                return true;
              case "30,DEFE":
                return true;
              default:
                return false;
            }
          } else {
            return false;
          }
        },

        _getRotateDialog: function () {
          if (!this.getOwnerComponent().oRotateDialogDetail) {
            this.getOwnerComponent().oRotateDialogDetail = sap.ui.xmlfragment(
              "Rotate",
              "mobilework.view.notifications.RotateImage",
              this
            );
            this.getView().addDependent(
              this.getOwnerComponent().oRotateDialogDetail
            );
          }

          return this.getOwnerComponent().oRotateDialogDetail;
        },

        onRightRotate: function (base64) {
          var canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("newImage")
              .setProperty("/RotateImage", newurl);
          }, this);
        },
        onRotateClose: function () {
          this._getRotateDialog().close();
        },

        onLeftRotate: function (base64) {
          var sPath = this.getView().getBindingContext("local").sPath,
            canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (-90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((-90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/RotateImage", newurl);
          }, this);
        },

        onEditDescription: function () {
          var editValue = this.getView()
            .getModel("selectedNotification")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("selectedNotification")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("selectedNotification")
              .setProperty("/DescriptionEdit", false);
          }
        },

        onSaveDescription: function () {
          var oObject = this.getView().getBindingContext("local").getObject();
          var editValue = this.getView()
            .getModel("selectedNotification")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("selectedNotification")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("selectedNotification")
              .setProperty("/DescriptionEdit", false);
          }
          var photos = oObject.Photos;
          photos.forEach(
            jQuery.proxy(function (oItem) {
              $.when(this.getDBService().updateObject("Picture", oItem))
                .done(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Success",
                      "INFO",
                      "NotificationDetail"
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Fail",
                      "ERROR",
                      "NotificationDetail"
                    );
                  }, this)
                );
            }, this)
          );
        },

        onUpdateFinished: function (oEvt) {
          if (oEvt.getSource().getAggregation("items").length === 2) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", true);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 1) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 0) {
          } else {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[1]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
            for (
              var i = 1;
              i < oEvt.getSource().getAggregation("items").length - 1;
              i++
            ) {
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[1]
                .getAggregation("items")[2]
                .getAggregation("items")[0]
                .setProperty("visible", true);
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[1]
                .getAggregation("items")[2]
                .getAggregation("items")[1]
                .setProperty("visible", true);
            }
          }
        },
        onDropUp: function (oEvent) {
          var oObject = this.getView().getBindingContext("local").getObject(),
            editValue = this.getView()
              .getModel("selectedNotification")
              .getProperty("/DescriptionEdit"),
            sPath = this.getView().getBindingContext("local").sPath;
          if (editValue === false) {
            var indexDropUp = oEvent.getParameter("id").lastIndexOf("-"),
              idDropUp = parseInt(
                oEvent.getParameter("id").substring(indexDropUp + 1),
                10
              ),
              photos = oObject.Photos,
              tempItem = photos[idDropUp],
              tempIndex;
            photos[idDropUp] = photos[idDropUp - 1];
            photos[idDropUp - 1] = tempItem;
            tempIndex = photos[idDropUp].PicIndex;
            photos[idDropUp].PicIndex = photos[idDropUp - 1].PicIndex;
            photos[idDropUp - 1].PicIndex = tempIndex;
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Photos", photos);
          }
        },
        onDropDown: function (oEvent) {
          var oObject = this.getView().getBindingContext("local").getObject(),
            editValue = this.getView()
              .getModel("selectedNotification")
              .getProperty("/DescriptionEdit"),
            sPath = this.getView().getBindingContext("local").sPath;
          if (editValue === false) {
            var indexDropDown = oEvent.getParameter("id").lastIndexOf("-"),
              idDropDown = parseInt(
                oEvent.getParameter("id").substring(indexDropDown + 1),
                10
              ),
              photos = oObject.Photos,
              tempItem = photos[idDropDown],
              tempIndex;
            photos[idDropDown] = photos[idDropDown + 1];
            photos[idDropDown + 1] = tempItem;
            tempIndex = photos[idDropDown].PicIndex;
            photos[idDropDown].PicIndex = photos[idDropDown + 1].PicIndex;
            photos[idDropDown + 1].PicIndex = tempIndex;
            this.getView()
              .getModel("local")
              .setProperty(sPath + "/Photos", photos);
          }
        },

        onImagePress: function (Url) {
          var img = new Image(),
            me = this;
          img.src = Url;
          img.onload = function () {
            me.imageWidth = img.naturalWidth;
            me.imageHeight = img.naturalHeight;
          };
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "newImage"
          );
          this.getView().getModel("newImage").setProperty("/RotateImage", Url);
          this.getDialogManager().open(
            "notifications.OpenImage",
            this.getView()
          );
          sap.ui.getCore().byId("sliderInOpenImage").setValue(50);
        },

        onResizeCarouselContainer: function (oEvent) {
          var iValue = oEvent.getParameter("value"),
            oCarouselContainer = sap.ui.getCore().byId("carouselOpenImage"),
            iNewHeight = Math.floor((this.imageHeight * iValue) / 98),
            iNewWidth = Math.floor((this.imageWidth * iValue) / 98);

          oCarouselContainer.setWidth(iNewWidth + "px");
          oCarouselContainer.setHeight(iNewHeight + "px");
        },
        onCloseImage: function () {
          this.getDialogManager().close(
            "notifications.OpenImage",
            this.getView()
          );
        },

        onCompleteNotificationPress: function () {
          var oLocalModel = this.getView().getModel("local");
          var sPath = this.getView().getBindingContext("local").sPath;
          oLocalModel.setProperty(sPath + "/Complete", "X");
          oLocalModel.setProperty(sPath + "/SendToGk", "");
          this.onSavePress(null, true);
        },

        checkForRequiredInStartMalFn: function (sQmart) {
          if (sQmart) return sQmart === "30,DEFE" || sQmart === "30,IMME";
          else return false;
        },

        checkForOverWriteArbpl: function (sQmart) {
          var odata = [{ sQmart: "40,BLUE" }, { sQmart: "50,BLUE" }];
          return this.visibiltyFilter(sQmart, odata);
        },
        findFunctionLocOrg: function () {
          var oLocalModel = this.getView().getModel("local"),
            sPath = this.getView().getBindingContext("local").sPath,
            oNotification = oLocalModel.getProperty(sPath),
            ingrp,
            arbpl;
          if (oNotification.FinalArbplFrom === "UserAdded") {
            arbpl = true;
          }
          if (oNotification.FinalIngrpFrom === "UserAdded") {
            ingrp = true;
          }
          $.when(this.getDBService().getEntitySet("FuncLocOrg")).done(
            jQuery.proxy(function (funcLocOrg) {
              var aFuncLocOrg = this.getHelper().rowsToArray(funcLocOrg),
                oFoundFlocOrg =
                  _.find(
                    aFuncLocOrg,
                    jQuery.proxy(function (oFuncLoc) {
                      return oFuncLoc && oFuncLoc.Tplnr === oNotification.Tplnr;
                    }, this)
                  ) || {};

              if (!oFoundFlocOrg.Ingrp || !oFoundFlocOrg.Arbpl) {
                oFoundFlocOrg = _.find(
                  this.getSharedModel().getProperty("/techObjects"),
                  jQuery.proxy(function (oFuncLoc) {
                    return oFuncLoc && oFuncLoc.Tplnr === oNotification.Tplnr;
                  }, this)
                );
                oFoundFlocOrg = this.checkHigherFuncLocOrg(
                  oFoundFlocOrg,
                  aFuncLocOrg
                );
              }
              if (!ingrp) {
                if (oNotification.Craft) {
                  oNotification.Ingpr = oNotification.CraftIngpr;
                } else if (oFoundFlocOrg && oFoundFlocOrg.Ingrp) {
                  oNotification.Ingpr = oFoundFlocOrg.Ingrp;
                } else {
                  oNotification.Ingpr =
                    this.getSharedModel().getProperty("/sapSettings/INGRP");
                }
              }
              if (!arbpl) {
                if (
                  oNotification.Qmart === "30,IMME" ||
                  (oNotification.Qmart === "30,DEFE" &&
                    oNotification.confirmationIsExisting)
                ) {
                  if (oNotification.Craft) {
                    oNotification.Arbpl = oNotification.CraftArbpl;
                  } else {
                    oNotification.Arbpl =
                      this.getSharedModel().getProperty("/sapSettings/GEWRK");
                  }
                } else if (this.checkForOverWriteArbpl(oNotification.Qmart)) {
                  oNotification.Arbpl =
                    this.getSharedModel().getProperty("/sapSettings/GEWRK");
                } else {
                  if (oNotification.Craft) {
                    oNotification.Arbpl = oNotification.CraftArbpl;
                  } else if (oFoundFlocOrg && oFoundFlocOrg.Arbpl) {
                    oNotification.Arbpl = oFoundFlocOrg.Arbpl;
                  } else {
                    oNotification.Arbpl =
                      this.getSharedModel().getProperty("/sapSettings/GEWRK");
                  }
                }
              }
              oLocalModel.refresh();
              var oFollowUp = {
                  Handle: oNotification.Handle,
                  FollowUp: oNotification.FollowUp,
                  DisabledForNotifFromOrder:
                    oNotification.DisabledForNotifFromOrder,
                  FinalArbplFrom: oNotification.FinalArbplFrom,
                  FinalIngrpFrom: oNotification.FinalIngrpFrom,
                },
                key = [
                  {
                    Handle: oNotification.Handle,
                  },
                ];
              this.getDBService().replaceObject(
                "FollowUpNotif",
                oFollowUp,
                FollowUpNotif,
                key
              );
            }, this)
          );
        },

        onBomTreeSelected: function (oEvent) {
          var oObject = oEvent.getParameter("rowContext").getObject();
          if (!oObject.Matnr) {
            MToast.show(this.getText("NoBomForFlEQ"));
            return;
          }
          $.when(this.getDBService().getEntitySet("BomData"))
            .done(
              jQuery.proxy(function (oData) {
                var data = this.getHelper().rowsToArray(oData);
                var bomData = _.find(data, {
                  Parent: oObject.Parent,
                  Matnr: oObject.Matnr,
                });
                if (bomData) {
                  this.getDialogManager().open(
                    "notifications.BomInfo",
                    this.getView()
                  );
                  this.getModel("local").setProperty("/BomData", bomData);
                } else MToast.show(this.getText("MaterialNotFound", oObject.Ktx01));
              }, this)
            )
            .fail(jQuery.proxy(function () {}, this));
        },

        onIconBarSelect: function (oEvent) {
          var sKey = oEvent.getParameter("key"),
            bomTree,
            oNotification = this.getView()
              .getBindingContext("local")
              .getObject();
          if (sKey === "bomTree") {
            $.when(this._onInstallationTreeRequest())
              .done(
                jQuery.proxy(function () {
                  if (oNotification.Equnr) {
                    bomTree = this.getHelper().findChildTree(
                      this.getSharedModel().getProperty("/tree"),
                      oNotification,
                      "Equnr"
                    );
                  } else {
                    bomTree = this.getHelper().findChildTree(
                      this.getSharedModel().getProperty("/tree"),
                      oNotification,
                      "Tplnr"
                    );
                  }
                  this.getSharedModel().setProperty("/bomTree", [bomTree]);
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  MBox.error("InstallationTreeError");
                }, this)
              );
          } else if (sKey === "Impacts") {
            if (oNotification.FollowUp) {
              $.when(this._onInstallationTreeRequest())
                .done(
                  jQuery.proxy(function () {
                    this.setFLImpact();
                  }, this)
                )
                .fail(jQuery.proxy(function () {}, this));
            } else {
              this.setFLImpact();
            }
          }
        },

        onBomDataColse: function () {
          this.getDialogManager().close(
            "notifications.BomInfo",
            this.getView()
          );
        },

        onSearchOpenPress: function () {
          this.getDialogManager().open(
            "notifications.FunctionLocationSearch",
            this.getView()
          );
        },

        onSearchCancelPress: function (oEvent) {
          oEvent.getSource().getBinding("items").filter([]);
        },

        onSearchFLPress: function (oEvent) {
          var sValue = oEvent.getParameters().value,
            aFilters = [];
          if (sValue) {
            aFilters = [
              new Filter(
                [
                  new Filter("Ktx01", function (sText) {
                    return (
                      (sText || "")
                        .toUpperCase()
                        .indexOf(sValue.toUpperCase()) > -1
                    );
                  }),
                ],
                false
              ),
            ];
          }
          oEvent.getSource().getBinding("items").filter(aFilters);
        },

        onConfirmFLSearch: function (oEvent) {
          let selected = oEvent.getParameter("selectedContexts");
          if (selected.length > 0) {
            let selectedData = this.getSharedModel().getProperty(
              selected[0].getPath()
            );
            this.onInstallationSelected(selectedData);
            this._getInstallationTreeDialog().close();
            oEvent.getSource().getBinding("items").filter([]);
          }
        },

        setFLImpact: function () {
          $.when(this.getDBService().getEntitySet("FuncLocImpact"))
            .done(
              jQuery.proxy(function (oData, oObject) {
                oData = this.getHelper().rowsToArray(oData);
                var oLocalModel = this.getView().getModel("local"),
                  sPath = this.getView().getBindingContext("local").sPath,
                  oNotification = oLocalModel.getProperty(sPath);
                if (oNotification.Equnr) {
                  var techObject = _.find(
                    this.getSharedModel().getProperty("/techObjects"),
                    { Equnr: oNotification.Equnr }
                  );
                } else {
                  var techObject = _.find(
                    this.getSharedModel().getProperty("/techObjects"),
                    { Tplnr: oNotification.Tplnr }
                  );
                }
                let impacts = this.findImpacts(techObject, oData);
                if (impacts) {
                  oLocalModel.setProperty(sPath + "/QuotCoP", impacts.QuotCoP);
                  oLocalModel.setProperty(sPath + "/QuotEvP", impacts.QuotEvP);
                  oLocalModel.setProperty(sPath + "/QuotPrP", impacts.QuotPrP);
                  oLocalModel.setProperty(sPath + "/QuotQaP", impacts.QuotQaP);
                  oLocalModel.setProperty(sPath + "/QuotSaP", impacts.QuotSaP);
                  oLocalModel.setProperty(sPath + "/QuotDeP", impacts.QuotDeP);
                  oLocalModel.setProperty(sPath + "/QuotWcP", impacts.QuotWcP);
                } else {
                  oLocalModel.setProperty("/QuotCoP", "");
                  oLocalModel.setProperty("/QuotEvP", "");
                  oLocalModel.setProperty("/QuotPrP", "");
                  oLocalModel.setProperty("/QuotQaP", "");
                  oLocalModel.setProperty("/QuotSaP", "");
                  oLocalModel.setProperty("/QuotDeP", "");
                  oLocalModel.setProperty("/QuotWcP", "");
                }
              }, this)
            )
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        qmartLangu: function (desc) {
          return this.getText(desc);
        },
        adjustQmart: function () {
          var qmart = this.getView().getModel("vh").getProperty("/Qmart"),
            oQmart = [];
          if (qmart) {
            var orderType = this.getView()
              .getBindingContext("local")
              .getObject().Qmcod;
            if (orderType) {
              qmart = qmart.filter(function (row) {
                return (
                  row.Key !== "20,1TIM" &&
                  row.Key !== "70,PROD" &&
                  row.Key !== "60,GENE"
                );
              });
            }
            if (orderType === "P010" || orderType === "P005") {
              oQmart = qmart.filter(function (row) {
                return row.Key !== "20,INRB" && row.Key !== "20,INRR";
              });
            } else if (orderType === "P020" || orderType === "P030") {
              oQmart = qmart.filter(function (row) {
                return row.Key !== "10,TBMP";
              });
            } else {
              oQmart = qmart.filter(function (row) {
                return (
                  row.Key !== "10,TBMP" &&
                  row.Key !== "20,INRB" &&
                  row.Key !== "20,INRR"
                );
              });
            }
          }
          this.getView().getModel("vh").setProperty("/oQmart", oQmart);
        },

        onSelected: function (oEvent) {
          const path = oEvent.getSource().getSelectedContextPaths();
          const oSelectedItem = oEvent
            .getSource()
            .getModel()
            .getProperty(path[0]);
          const sPath = this.getView().getBindingContext("local").sPath;
          const oLocalModel = this.getModel("local");

          if (oSelectedItem.Code) {
            switch (oSelectedItem.Codct) {
              case "C":
                oLocalModel.setProperty(`${sPath}/Fecod`, oSelectedItem.Code);
                oLocalModel.setProperty(
                  `${sPath}/Fecodtxt`,
                  oSelectedItem.Kurztext
                );
                oLocalModel.setProperty(`${sPath}/Fegrp`, oSelectedItem.Codgrr);
                break;
              case "5":
                oLocalModel.setProperty(`${sPath}/Urcod`, oSelectedItem.Code);
                oLocalModel.setProperty(
                  `${sPath}/Urcodtxt`,
                  oSelectedItem.Kurztext
                );
                oLocalModel.setProperty(`${sPath}/Urgrp`, oSelectedItem.Codgrr);
                break;
              case "2":
                oLocalModel.setProperty(`${sPath}/Mncod`, oSelectedItem.Code);
                oLocalModel.setProperty(
                  `${sPath}/Mncodtxt`,
                  oSelectedItem.Kurztext
                );
                oLocalModel.setProperty(`${sPath}/Mngrp`, oSelectedItem.Codgrr);
                break;
              case "A":
                oLocalModel.setProperty(`${sPath}/Mfcod`, oSelectedItem.Code);
                oLocalModel.setProperty(
                  `${sPath}/Mfcodtxt`,
                  oSelectedItem.Kurztext
                );
                oLocalModel.setProperty(`${sPath}/Mfgrp`, oSelectedItem.Codgrr);
                break;
              case "B":
                oLocalModel.setProperty(`${sPath}/Oteil`, oSelectedItem.Code);
                oLocalModel.setProperty(
                  `${sPath}/Oteiltxt`,
                  oSelectedItem.Kurztext
                );
                oLocalModel.setProperty(`${sPath}/Otgrp`, oSelectedItem.Codgrr);
                break;
              default:
                break;
            }
            this.notifTreeTableCancel();
          } else {
            sap.m.MessageBox.error(this.getText("InvalidEntry"));
          }
        },

        /**
         * Release 130 - 39
         * Fegrp, MnGrp etc need to be deleted based on type. So took first 2 char.
         */

        onClearInput: function (oEvent) {
          const type = oEvent.getSource().getId().slice(-5),
            sPath = this.getView().getBindingContext("local").getPath(),
            oLocalModel = this.getView().getModel("local");
          if (!oEvent.getParameter("value")) {
            oLocalModel.setProperty(`${sPath}/${type}`, "");
            oLocalModel.setProperty(`${sPath}/${type}txt`, "");
            if (type)
              oLocalModel.setProperty(`${sPath}/${type.slice(0, 2)}grp`, "");
          }
        },
      }
    );
  }
);
