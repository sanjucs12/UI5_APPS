/*global _:true*/
/*global moment:true*/
/*global Camera:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/ui/core/routing/History",
    "sap/ui/model/Filter",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/model/FollowUpNotif",
    "sap/m/MessageToast",
  ],
  function (Controller, History, Filter, Lo, MBox, Mo, FollowUpNotif, MToast) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.notifications.NotificationsMaster",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//F

        /** @type sap.m.Dialog */
        oAddNotificationDialog: null,

        /** @type sap.m.List */
        oMasterList: null,

        /** @type sap.m.Select */
        oQmcodSelect: null,

        /** @type sap.m.Select */
        oFecodSelect: null,

        /** @type sap.m.Select */
        oUrcodSelect: null,

        /** @type sap.m.Select */
        oMfcodSelect: null,

        /** @type sap.m.Select */
        oMncodSelect: null,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.NotificationsMaster
         */
        onInit: function () {
          this._initModels();
          this.getRouter()
            .getRoute("notificationsMaster")
            .attachMatched(this.onRouteMatched, this);
          this.getRouter()
            .getRoute("CreateNotificationFromOrder")
            .attachMatched(this.onNotifFromOrderMatched, this);
          //subscribe to scanner
          this.getEventBus().subscribe(
            "scanner",
            "scannedNotifcationMaster",
            this.onExtScanSuccess,
            this
          );
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.NotificationsMaster
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function (oEvent) {
          //set scanner location
          this.getScanHandler().setLocation("NotifcationMaster");

          //set connection property
          this.getConnection();

          if (!this.oMasterList) {
            this.oMasterList = this.getView().byId("notifMasterList");
          }

          this.oMasterList.removeSelections(true);

          this._getNotificationsFromDb();

          if (!this._checkVHModel()) {
            this._getValueHelpFromDb();
          }

          this.getSharedModel().setProperty("/OteilVisible", false);

          this._getFlocCraftFromDb();
          this.changeColorOfDeviceId();
        },

        onNotifFromOrderMatched: function (oEvent) {
          var oNewNotifModel = this.getView().getModel("newNotif");
          oNewNotifModel.setProperty(
            "/",
            this.getView()
              .getModel("local")
              .getProperty("/NotBoundNotifFromOrder")
          );
          oNewNotifModel.setProperty("/FollowUp", true);
          this.onRouteMatched();
          this.adjustQmart();
          this.getView()
            .getModel("local")
            .setProperty("/NotBoundNotifFromOrder", []);
          this.confId = null;
          this.confId = oNewNotifModel.getProperty("/ConfId");
          var //Qmcod = oNewNotifModel.getProperty("/Qmcod"),
            followUp = oNewNotifModel.getProperty("/FollowUp");
          var oDialog = this._getAddNotificationDialog();
          this.getSharedModel().setProperty("/IconBarNotifkey", "info");
          this.addDescription();
          if (
            oNewNotifModel.getProperty("/Qmart") === "30,DEFE" ||
            oNewNotifModel.getProperty("/Qmart") === "30,IMME"
          ) {
            sap.ui.core.Fragment.byId(
              "addNotificationDialog",
              "newNotifAusvn"
            ).setDateValue(new Date());
          } else {
            this.getModel("newNotif").setProperty("/AusvnDatetime", "");
          }

          this._defaultNewNotif();
          $.when(
            this._filterSelects(oNewNotifModel.getProperty("/Qmart"), followUp)
          ).done(
            jQuery.proxy(function () {
              //this.getView().getModel("newNotif").setProperty("/Qmcod", Qmcod);
              oDialog.open();
            }, this)
          );

          this.changeColorOfDeviceId();
        },

        onAddPress: function (oEvent) {
          var oDialog = this._getAddNotificationDialog();

          this.confId = null;
          if (
            this._getInstallationTreeDialog()
              .getAggregation("content")[0]
              .getId()
              .indexOf("InstallTree") !== -1
          ) {
            this._getInstallationTreeDialog()
              .getAggregation("content")[0]
              .collapseAll();
          }

          this.getSharedModel().setProperty("/OteilVisible", false);
          this.getSharedModel().setProperty("/IconBarNotifkey", "info");
          /*Issue 41-13.0 Tracker Notification details screen - Redesign of notification type - Coding field has to be removed.
			var aQmart = this.getView().getModel("vh").getProperty("/Qmart");
			aQmart = _.filter(aQmart, jQuery.proxy(function (qmart) {
				
				if (qmart) {
					return (qmart.VhKey !== '10');
				}
			}, this));
			this.getView().getModel("vh").setProperty("/aQmart", aQmart);
			*/

          this.adjustQmart();
          this._defaultNewNotif();

          if (this._checkVHModel()) {
            // Issue 128 in V13.0 tracker
            // oDialog.open();
            $.when(this._getValueHelpFromDb()).done(function () {
              oDialog.open();
            });
          } else {
            $.when(this._getValueHelpFromDb()).done(function () {
              oDialog.open();
            });
          }
        },

        onVhDataRetreived: function (
          oQmartData,
          oCatalogData,
          oShiftData,
          oLanguData,
          oCraftData,
          _oPmenvrData,
          _oPmqualData,
          _oPmsafeData,
          _oQuotCoRData,
          _oQuotDeRData,
          _oQuotPrRData,
          _oQuotWcRData,
          oPromImpactObl,
          oNotifcationType
        ) {
          var oVHModel = this.getView().getModel("vh"),
            aQmart = [],
            aCatalog = [],
            aShift = [],
            aLangu = [],
            aCraft = [],
            aPmqual = [],
            aPmsafe = [],
            aQuotCoR = [],
            aQuotDeR = [],
            aQuotPrR = [],
            aQuotWcR = [],
            aPmenvr = [],
            aImpactObl = [];

          aQmart.push(null);

          // for (var i = 0; i < oQmartData.rows.length; i++) {
          // 	aQmart.push(oQmartData.rows.item(i));
          // }

          for (var j = 0; j < oCatalogData.rows.length; j++) {
            aCatalog.push(oCatalogData.rows.item(j));
          }

          for (var k = 0; k < oShiftData.rows.length; k++) {
            aShift.push(oShiftData.rows.item(k));
          }

          for (var l = 0; l < oLanguData.rows.length; l++) {
            aLangu.push(oLanguData.rows.item(l));
          }

          for (var m = 0; m < oCraftData.rows.length; m++) {
            aCraft.push(oCraftData.rows.item(m));
          }
          for (var o = 0; o < _oPmenvrData.rows.length; o++) {
            aPmenvr.push(_oPmenvrData.rows.item(o));
          }
          for (var o = 0; o < _oPmqualData.rows.length; o++) {
            aPmqual.push(_oPmqualData.rows.item(o));
          }
          for (var o = 0; o < _oPmsafeData.rows.length; o++) {
            aPmsafe.push(_oPmsafeData.rows.item(o));
          }
          for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
            aQuotCoR.push(_oQuotCoRData.rows.item(o));
          }
          for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
            aQuotDeR.push(_oQuotDeRData.rows.item(o));
          }
          for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
            aQuotPrR.push(_oQuotPrRData.rows.item(o));
          }
          for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
            aQuotWcR.push(_oQuotWcRData.rows.item(o));
          }
          for (var o = 0; o < oPromImpactObl.rows.length; o++) {
            aImpactObl.push(oPromImpactObl.rows.item(o));
          }

          // Issue no. 110 in V13.0
          aPmenvr.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aPmqual.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aPmsafe.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aQuotCoR.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aQuotDeR.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aQuotPrR.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aQuotWcR.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });
          aImpactObl.sort((a, b) => {
            return a.VhKey - b.VhKey;
          });

          oVHModel.setProperty("/Qmart", oNotifcationType.Types);
          oVHModel.setProperty("/Catalog", aCatalog);
          oVHModel.setProperty("/Shift", aShift);
          oVHModel.setProperty("/Langu", aLangu);
          oVHModel.setProperty("/Craft", aCraft);
          oVHModel.setProperty("/Pmenvr", aPmenvr);
          oVHModel.setProperty("/Pmqual", aPmqual);
          oVHModel.setProperty("/Pmsafe", aPmsafe);
          oVHModel.setProperty("/QuotCoR", aQuotCoR);
          oVHModel.setProperty("/QuotDeR", aQuotDeR);
          oVHModel.setProperty("/QuotPrR", aQuotPrR);
          oVHModel.setProperty("/QuotWcR", aQuotWcR);
          oVHModel.setProperty("/ImpactObl", aImpactObl);
          oVHModel.setProperty(
            "/vh/headerLines",
            aCatalog.filter((aCat) => {
              return aCat.Code === "";
            })
          );
        },

        onScanPress: function (oEvent) {
          $.when(this.getScanHandler().scan())
            .done(jQuery.proxy(this.onScanSuccess, this))
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        onExtScanSuccess: function (sChannel, sEvent, oData) {
          if (!oData.result.error) {
            this.onScanSuccess({
              text: oData.result.barcode,
            });
          } else {
            MBox.error(oData.result.errorMessage);
          }
        },

        onScanSuccess: function (oData) {
          var oNewNotifModel = this.getView().getModel("newNotif"),
            sScanId = oData.text.slice(0, 30), // Max length 30
            oSharedModel = this.getSharedModel();

          oSharedModel.setProperty("/tree", null);
          this.getView().setBusy(true);

          $.when(
            this.getDBService().getScanId(sScanId),
            this.getDBService().getEntitySet("TechnicalObject")
          )
            .done(
              jQuery.proxy(function (oDBResultId, TechnicalObject) {
                if (oDBResultId.rows.length > 0) {
                  // Installation Tree is already in DB: get from DB
                  $.when(
                    this.getDBService().getInstallationTreeByScanId(sScanId)
                  )
                    .done(
                      jQuery.proxy(function (oDataTreeDb) {
                        var aDataTree =
                          this.getHelper().rowsToArray(oDataTreeDb);

                        if (aDataTree.length > 0) {
                          // oSharedModel.setProperty("/tree", this.getHelper().createTree(aDataTree, "Tplnr", "Tplma",
                          // 	"Children"));
                          this.adjustQmart();
                          this._defaultNewNotif();
                          oNewNotifModel.setProperty("/Scanid", sScanId);
                          //Issue 22 in Armp 12.0
                          if (aDataTree[0].Strno) {
                            oNewNotifModel.setProperty(
                              "/Tplnr",
                              aDataTree[0].Strno
                            );
                          } else {
                            //oNewNotifModel.setProperty("/Equnr", aDataTree[0].Equnr);
                            this.getSharedModel().setProperty(
                              "/techObjects",
                              this.getHelper().rowsToArray(TechnicalObject)
                            );
                            this.getSharedModel().setProperty(
                              "/techObjectsFiltered",
                              this.getHelper()
                                .rowsToArray(TechnicalObject)
                                .filter(function (oTech) {
                                  return (
                                    oTech.Ktx01 &&
                                    (oTech.TechObjectType === "FL" ||
                                      oTech.TechObjectType === "IF" ||
                                      oTech.TechObjectType === "EQ")
                                  );
                                })
                            );
                            this._onInstallationSelected(aDataTree[0]);
                          }
                          this._getAddNotificationDialog().open();
                        } else {
                          MBox.error(this.getText("NoFlFoundForID"));
                        }
                        this.getView().setBusy(false);
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function () {
                        this.getView().setBusy(false);
                        MBox.error(this.getText("InstallationTreeError"));
                      }, this)
                    );
                } else {
                  // If Tree not in DB we set Tplnr = scanned raw value
                  // this._defaultNewNotif();
                  // oNewNotifModel.setProperty("/Tplnr", sScanId);
                  // this._getAddNotificationDialog().open();
                  // this.getView().setBusy(false);

                  MBox.error(this.getText("NoFlFoundForID"));
                  this.getView().setBusy(false);
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                this.getView().setBusy(false);
                MBox.error(this.getText("InstallationTreeError"));
              }, this)
            );
        },

        onMasterSelectionChange: function (oEvent) {
          var oBindingContext = oEvent
            .getParameter("listItem")
            .getBindingContext("local");

          this.getSharedModel().setProperty(
            "/currentNotifID",
            oBindingContext.sPath.split("/")[2]
          );

          this.getRouter().navTo("notificationsDetail", {
            ID: oBindingContext.sPath.split("/")[2],
          });
        },

        onSearch: function (oEvent) {},

        onNavBack: function () {
          this.getRouter().navTo("main", true);
        },

        onNotificationCreated: function (res, oNotification) {
          var oLocalModel = this.getView().getModel("local"),
            aLocalNotificationSet = [],
            aNotBoundNotificationsSet = [];

          if (!oLocalModel.getProperty("/PMNotificationSet")) {
            oLocalModel.setProperty("/PMNotificationSet", []);
          }
          if (!oLocalModel.getProperty("/NotBoundNotificationSet")) {
            oLocalModel.setProperty("/NotBoundNotificationSet", []);
          }

          aLocalNotificationSet = oLocalModel.getProperty("/PMNotificationSet");
          aLocalNotificationSet.push(oNotification);
          oLocalModel.setProperty("/PMNotificationSet", aLocalNotificationSet);

          aNotBoundNotificationsSet = oLocalModel.getProperty(
            "/NotBoundNotificationSet"
          );
          aNotBoundNotificationsSet.push(oNotification);
          oLocalModel.setProperty(
            "/NotBoundNotificationSet",
            aNotBoundNotificationsSet
          );

          this.oAddNotificationDialog.close();

          this.getSharedModel().setProperty(
            "/currentNotifID",
            (aLocalNotificationSet.length - 1).toString()
          );
          if (this.confId) {
            this.getRouter().navTo("confirmationsDetail", {
              ID: parseInt(this.confId).toString(),
            });
          } else {
            this.getRouter().navTo("notificationsDetail", {
              ID: (aNotBoundNotificationsSet.length - 1).toString(),
            });
          }
        },

        //====
        // for AddNotificationDialog
        //====

        onAddDialogCancelPress: function (oEvent) {
          MBox.confirm(this.getText("CancelNotifConfirm"), {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                this.getSharedModel().setProperty("/AICFound", false);
                this.getView().getModel("newNotif").setProperty("/", {});
                this._clearPlannerGroupsList();
                this.oAddNotificationDialog.close();
              }
            }, this),
          });
        },

        onInstallationTreeRequest: function (oEvent) {
          // if (this.getView().getModel("newNotif").getProperty("/Scanid")) {
          // 	this._getInstallationTreeDialog().open();
          // } else {
          $.when(this._onInstallationTreeRequest())
            .done(
              jQuery.proxy(function () {
                this._getInstallationTreeDialog().open();
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                MBox.error("InstallationTreeError");
              }, this)
            );
          // }
        },

        onPlannerGroupRequest: function () {
          this._getPlannerGroupDialog().open();
        },

        onWorkCenterRequest: function () {
          this._getWorkCenterDialog().open();
        },

        onAddDialogConfirmPress: function (oEvent, reset) {
          var oNotification = this.getView()
            .getModel("newNotif")
            .getProperty("/");
          if (oNotification) {
            //while clicking save, both are reset
            if (!reset) {
              this.getView().getModel("newNotif").setProperty("/SendToGk", "");
              this.getView().getModel("newNotif").setProperty("/Complete", "");
            }
            var oMsg =
              this.getValidator().validateNotificationBreakdown(oNotification);

            oNotification.Shift = this.getShiftValue(
              this.getSharedModel().getProperty("/sapSettings")
            ); // ONBOARDING

            if (oMsg) {
              MBox.error(this.getText(oMsg));
            } else {
              this._clearPlannerGroupsList();
              this._manualCreateNotification();
            }
          }
        },

        onTplnrChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/Tplnr", sValue.toUpperCase());

            $.when(this.getDBService().getEntitySet("TechnicalObject"))
              .done(
                jQuery.proxy(function (oData) {
                  var aTechnicalObjectSet = this.getHelper().rowsToArray(oData);
                  aTechnicalObjectSet = _.filter(
                    aTechnicalObjectSet,
                    function (oTechnicalObject) {
                      return oTechnicalObject.TechObjectType !== "PA";
                    }
                  );
                  this.getSharedModel().setProperty(
                    "/techObjects",
                    this.getHelper().rowsToArray(oData)
                  );
                  this.getSharedModel().setProperty(
                    "/techObjectsFiltered",
                    aTechnicalObjectSet.filter(function (oTech) {
                      return (
                        oTech.Ktx01 &&
                        (oTech.TechObjectType === "FL" ||
                          oTech.TechObjectType === "EQ" ||
                          oTech.TechObjectType === "IF")
                      );
                    })
                  );
                  var flData = this.getHelper().createTree(
                    aTechnicalObjectSet,
                    "TechObject",
                    "Parent",
                    "Children",
                    "sort",
                    "TechObjectType"
                  );
                  flData.forEach(
                    jQuery.proxy(function (locGrp) {
                      if (locGrp && locGrp.Groupname) {
                        locGrp.Children = this.sortFunctionLocationGroup(
                          locGrp.Children,
                          "Posnr",
                          "Tplnr"
                        );
                        if (locGrp.Children) {
                          var withoutSeqno = locGrp.Children.filter(function (
                              row
                            ) {
                              return !row.Seqno;
                            }),
                            withSeqno = locGrp.Children.filter(function (row) {
                              return row.Seqno;
                            });
                          withSeqno = _.sortBy(withSeqno, "Seqno");
                          withoutSeqno = _.sortBy(withoutSeqno, "Tplnr");
                          locGrp.Children = withSeqno.concat(withoutSeqno);
                        }
                      } else if (locGrp) {
                        locGrp.Children = this.sortFunctionLocationGroup(
                          locGrp.Children,
                          "Posnr",
                          "Tplnr"
                        );
                      }
                    }, this)
                  );
                  this.getSharedModel().setProperty("/tree", flData);
                  this._checkFLSpecificData();
                  this._getCraftCodesForFl();
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  MBox.error("InstallationTreeError");
                }, this)
              );
            this.findFunctionLocOrg();
          }
        },

        onIngprChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/Ingpr", sValue.toUpperCase());
            this.getView()
              .getModel("newNotif")
              .setProperty("/FinalIngrpFrom", "UserAdded");
          }
        },

        onIwerkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/Iwerk", sValue.toUpperCase());
          }
        },

        onArbplChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/Arbpl", sValue.toUpperCase());
          }
        },

        onGewrkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/Arbpl", sValue.toUpperCase());
            this.getView()
              .getModel("newNotif")
              .setProperty("/FinalArbplFrom", "UserAdded");
          }
        },
        onRepByWcChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue");

          if (sValue) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/RepByWc", sValue.toUpperCase());
          }
        },

        onQmartSelect: function (oEvent) {
          var oSelectedObject = oEvent
              .getParameter("selectedItem")
              .getBindingContext("vh")
              .getObject(),
            sQmartKey = oSelectedObject.Key;

          this._filterSelects(
            sQmartKey,
            this.getModel("newNotif").getProperty("/FollowUp")
          );

          if (
            this.getModel("newNotif").getProperty("/Craft") &&
            this.getModel("newNotif").getProperty("/Qmcod")
          ) {
            this._getAICCustomizing();
          } else {
            this.getSharedModel().setProperty("/AICFound", false);
          }
          if (sQmartKey === "30,DEFE" || sQmartKey === "30,IMME") {
            sap.ui.core.Fragment.byId(
              "addNotificationDialog",
              "newNotifAusvn"
            ).setDateValue(new Date());
          } else {
            this.getModel("newNotif").setProperty("/AusvnDatetime", "");
          }
          var sGrp = oSelectedObject.CodeGrp;
          this._setGrpField("Qmgrp", sGrp);
          this.findFunctionLocOrg();
        },

        onOteilSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr,
            oNewNotifModel = this.getView().getModel("newNotif");

          this._setGrpField("Otgrp", sGrp);
          oNewNotifModel.setProperty(
            "/Otkat",
            this.getHelper().getCatalogKey("oteil")
          );
        },

        // onQmcodSelect: function (oEvent) {
        // 	var oObject = oEvent.getSource().getSelectedItem().getBindingContext("vh").getObject(),
        // 		sGrp = oObject.Codgrr;
        // 	this._setGrpField("Qmgrp", sGrp);
        // 	if (this.getModel("newNotif").getProperty("/Craft")) {
        // 		this._getAICCustomizing();
        // 	} else {
        // 		this.getSharedModel().setProperty("/AICFound", false);
        // 	}
        // 	this.findFunctionLocOrg();
        // },

        onFecodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;
          this._setGrpField("Fegrp", sGrp);
        },

        onUrcodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setGrpField("Urgrp", sGrp);
        },

        onMfcodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setGrpField("Mfgrp", sGrp);
        },

        onMncodSelect: function (oEvent) {
          var oObject = oEvent
              .getSource()
              .getSelectedItem()
              .getBindingContext("vh")
              .getObject(),
            sGrp = oObject.Codgrr;

          this._setGrpField("Mngrp", sGrp);
        },

        //====
        // for InstallationTreeDialog
        //====

        onInstallationSelected: function (oEvent, customEvent) {
          if (
            oEvent &&
            oEvent.getParameter("rowContext") &&
            oEvent.getParameter("rowContext").getObject()
          ) {
            var oObject = oEvent.getParameter("rowContext").getObject();
            /*if (oObject.TechObjectType === "GR" || oObject.TechObjectType) {
					MBox.error(this.getText("GRInstallNotPossible"));
					return;
				}*/
            this._onInstallationSelected(oObject);
          }

          this._getInstallationTreeDialog().close();
        },

        onPlannerGroupSelected: function (oEvent) {
          var sPath = oEvent
              .getParameter("listItem")
              .getBindingContext("shared").sPath,
            oObject = this.getSharedModel().getProperty(sPath),
            oNewNotifModel = this.getView().getModel("newNotif");

          oNewNotifModel.setProperty("/Ingpr", oObject.Ingrp);
          oNewNotifModel.setProperty("/FinalIngrpFrom", "UserAdded");

          this._getPlannerGroupDialog().close();
        },

        onWorkCenterSelected: function (oEvent) {
          var sPath = oEvent
              .getParameter("listItem")
              .getBindingContext("shared").sPath,
            oObject = this.getSharedModel().getProperty(sPath),
            oNewNotifModel = this.getView().getModel("newNotif");
          oNewNotifModel.setProperty("/RepByWc", oObject.Gewrk);
          oEvent.getSource().removeSelections(true);
          this._getWorkCenterDialog().close();
        },

        onInstallationDialogCancelPress: function (oEvent) {
          this._getInstallationTreeDialog().close();
        },

        onCraftSelectionChange: function (oEvent) {
          var oSettingsIngrp =
            this.getSharedModel().getProperty("/sapSettings").INGRP || "";
          // model: sharedModel: property -> flocCraft

          this._checkFLSpecificData();

          this.getSharedModel().setProperty("/plannerGroupsList", []);
          if (this.getModel("newNotif").getProperty("/Craft")) {
            var aFoundFuncLocCraft = _.filter(
              this.getSharedModel().getProperty("/CraftCodeList"),
              jQuery.proxy(function (oFuncLocCraft) {
                return (
                  this.getModel("newNotif").getProperty("/Craft") ===
                  oFuncLocCraft.Craft
                );
              }, this)
            );

            if (aFoundFuncLocCraft && aFoundFuncLocCraft[0]) {
              this.getModel("newNotif").setProperty(
                "/CraftIngpr",
                aFoundFuncLocCraft[0].Ingrp
              );
              this.getModel("newNotif").setProperty(
                "/CraftArbpl",
                aFoundFuncLocCraft[0].Gewrk
              );
              this.getModel("newNotif").setProperty(
                "/GEWRK",
                aFoundFuncLocCraft[0].Gewrk
              );

              if (aFoundFuncLocCraft.length > 1) {
                this.getSharedModel().setProperty(
                  "/plannerGroupsList",
                  aFoundFuncLocCraft
                );
              }
            } else {
              var oFoundFloc = _.find(
                this.getSharedModel().getProperty("/techObjects"),
                jQuery.proxy(function (oFuncLoc) {
                  return (
                    oFuncLoc &&
                    oFuncLoc.Tplnr ===
                      this.getModel("newNotif").getProperty("/Tplnr")
                  );
                }, this)
              );

              if (oFoundFloc) {
                aFoundFuncLocCraft = this._checkHigherFuncLocCraft(oFoundFloc);
              }

              if (aFoundFuncLocCraft.length > 0) {
                var aFoundFuncLocCraft = _.filter(
                  aFoundFuncLocCraft,
                  jQuery.proxy(function (oFuncLocCraft) {
                    return (
                      this.getModel("newNotif").getProperty("/Craft") ===
                      oFuncLocCraft.Craft
                    );
                  }, this)
                );

                _.each(
                  aFoundFuncLocCraft,
                  jQuery.proxy(function (oFuncLocCraft) {
                    var oFoundCraft = _.find(
                      this.getModel("vh").getProperty("/Craft"),
                      function (oCraft) {
                        return oCraft.VhKey === oFuncLocCraft.Craft;
                      }
                    );

                    oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                  }, this)
                );

                var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
                var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");

                this.getModel("newNotif").setProperty(
                  "/Craft",
                  aCraftCodeList[0].Craft
                );

                if (aWorkCenterList[0].Gewrk) {
                  this.getModel("newNotif").setProperty(
                    "/CraftArbpl",
                    aWorkCenterList[0].Gewrk
                  );
                  this.getModel("newNotif").setProperty(
                    "/GEWRK",
                    aWorkCenterList[0].Gewrk
                  );
                }

                this.getModel("newNotif").setProperty(
                  "/CraftIngpr",
                  aFoundFuncLocCraft[0].Ingrp
                );

                if (aFoundFuncLocCraft.length > 1) {
                  this.getSharedModel().setProperty(
                    "/plannerGroupsList",
                    aFoundFuncLocCraft
                  );
                }
              }
            }
            if (this.getModel("newNotif").getProperty("/Qmart")) {
              this._getAICCustomizing();
            } else {
              this.getSharedModel().setProperty("/AICFound", false);
            }
          } else {
            this.getSharedModel().setProperty("/AICFound", false);
          }
          this.findFunctionLocOrg();
        },

        onPlannerGroupDialogCancelPress: function () {
          this._getPlannerGroupDialog().close();
        },

        onWorkCenterDialogCancelPress: function () {
          this._getWorkCenterDialog().close();
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        getQmartText: function (sQmartCode) {
          return this._getQmartText(sQmartCode);
        },

        getQmcodText: function (sQmartCode, a) {
          return sQmartCode === "30,DEFE"
            ? a
              ? "30,IMME"
              : sQmartCode
            : sQmartCode;
        },

        isCatalogSelectEnabled: function (sQmart) {
          if (sQmart) {
            return true;
          }

          return false;
        },

        isAusDTPEnabled: function (bMsaus) {
          if (bMsaus) {
            return true;
          } else {
            return false;
          }
        },

        isScanidProvided: function (sScanid) {
          if (!sScanid) {
            return false;
          } else {
            return true;
          }
        },

        isBreakDownVisible: function (sQmart) {
          return (
            (sQmart === "30,DEFE" || sQmart === "30,IMME") &&
            this.getSharedModel().getProperty("/sapSettings/notifFields/Msaus")
          );
        },

        isBreakDownSeleceted: function (sQmart) {
          if (sQmart === "30,DEFE" || sQmart === "30,IMME") {
            this.getView().getModel("newNotif").setProperty("/Msaus", true);
            return true;
          } else {
            this.getView().getModel("newNotif").setProperty("/Msaus", false);
          }
          return false;
        },

        visibiltyFilter: function (sQmart, data) {
          if (sQmart) {
            var odata = data.filter(function (row) {
              if (sQmart === row.sQmart) {
                // if (row.sQmcod) {
                // 	return sQmcod === row.sQmcod;
                // } else
                return true;
              }
            });
            if (odata.length > 0) {
              return true;
            }
          }
          return false;
        },

        isCompleteVisible: function (sQmart) {
          var odata = [
            { sQmart: "40,BLUE" },
            { sQmart: "50,BLUE" },
            { sQmart: "60,GENE" },
          ];
          let returnValue = this.visibiltyFilter(sQmart, odata);
          if (!returnValue && sQmart) {
            var oNotifModel = this.getView().getModel("newNotif");
            oNotifModel.setProperty("/Complete", "");
          }
          return returnValue;
        },

        setInstallationIcon: function (sType) {
          if (sType) {
            switch (sType.toUpperCase()) {
              case "FL":
                return "sap-icon://functional-location";
              case "IF":
                return "sap-icon://functional-location";
              case "EQ":
                return "sap-icon://technical-object";
              case "GR":
                return "sap-icon://group-2";
              case "MA":
                return "sap-icon://product"; //"sap-icon://suitcase" "sap-icon://product"
              default:
                return "sap-icon://question-mark";
            }
          } else {
            return "sap-icon://question-mark";
          }
        },

        checkRequired: function (sQmart, sCraft, sMandatory) {
          if (sMandatory && sMandatory === "X") {
            return true;
          }

          if (
            this.getSharedModel().getProperty("/sapSettings/IWERK") ===
              "1000" ||
            this.getSharedModel().getProperty("/sapSettings/IWERK") === 1000 ||
            this.getSharedModel().getProperty("/sapSettings/IWERK") === "BEA0"
          ) {
            if (
              sQmart &&
              (sQmart === "50,RED" || sQmart === "40,RED") &&
              sCraft &&
              sCraft === "FA"
            ) {
              return true;
            } else {
              return false;
            }
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {
          if (!this.getView().getModel("newNotif")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel(),
              "newNotif"
            );
          }
          if (!this.getView().getModel("vh")) {
            var oVHModel = new sap.ui.model.json.JSONModel(),
              oSharedModel = this.getSharedModel();

            oVHModel.setSizeLimit(2500);
            if (oSharedModel.getProperty("/vh"))
              oVHModel.setData(oSharedModel.getProperty("/vh"));

            this.getView().setModel(oVHModel, "vh");
          }
        },

        _askCreateParticipant: function () {
          var oRouter = this.getRouter(),
            sYesText = this.getText("Yes"),
            sNoText = this.getText("No");

          MBox.show(this.getText("CreateParticNoExists"), {
            icon: MBox.Icon.WARNING,
            actions: [sYesText, sNoText],
            onClose: function (sAction) {
              if (sAction === sYesText) {
                oRouter.navTo("participantsMaster");
              }
            },
          });
        },

        _getAICCustomizing: function () {
          var oNewNotifModel = this.getView().getModel("newNotif");

          $.when(
            this.getDBService().getAICByCraft(
              this.getModel("newNotif").getProperty("/Craft")
            )
          ).done(
            jQuery.proxy(function (oAic) {
              var aAICSet = this.getHelper().rowsToArray(oAic);
              var oQmart = this.getModel("newNotif").getProperty("/Qmart");
              if (oQmart) {
                oQmart = oQmart.split(",");
              } else {
                oQmart = ["", ""];
              }
              var oAICFound = _.find(
                aAICSet,
                jQuery.proxy(function (oData) {
                  return (
                    (oData.Qmart === oQmart[0] && oData.Qmcod === oQmart[1]) ||
                    (oData.Qmart === oQmart[0] && !oData.Qmcod) ||
                    (oData.Qmart === "" && oData.Qmcod === "")
                  );
                }, this)
              );

              if (oAICFound) {
                // 	aOteilVh = _.filter(aCatalog, {
                // 		// Qmart: sQmartKey,
                // 		Codct: this.getHelper().getCatalogKey("oteil"),
                // 		Rbnr: oFoundTechObject.Rbnr
                // 	});
                // oVhModel.setProperty("/CatOteil", aOteilVh);

                oNewNotifModel.setProperty(
                  "/Otkat",
                  this.getHelper().getCatalogKey("oteil")
                );
                oNewNotifModel.setProperty("/Otgrp", oAICFound.Otgrp);
                // oNewNotifModel.setProperty("/Oteil", oAICFound.Oteil);

                if (
                  this.getView().getModel("vh").getProperty("/CatOteil")
                    .length === 1
                ) {
                  oNewNotifModel.setProperty(
                    "/Otkat",
                    this.getHelper().getCatalogKey("oteil")
                  );
                  oNewNotifModel.setProperty(
                    "/Otgrp",
                    this.getView().getModel("vh").getProperty("/CatOteil")[0]
                      .Codgrr
                  );
                  oNewNotifModel.setProperty(
                    "/Oteil",
                    this.getView().getModel("vh").getProperty("/CatOteil")[0]
                      .Code
                  );
                } else {
                  oNewNotifModel.setProperty("/Otgrp", "");
                  oNewNotifModel.setProperty("/Oteil", "");
                }

                this.getSharedModel().setProperty("/AICFound", true);
              } else {
                this.getSharedModel().setProperty("/AICFound", false);
              }
            }, this)
          );
        },

        _checkFLSpecificData: function () {
          var oVhModel = this.getView().getModel("vh"),
            oNewNotifModel = this.getView().getModel("newNotif"),
            aCatalog = oVhModel.getProperty("/Catalog"),
            aTechnicalObjects =
              this.getSharedModel().getProperty("/techObjects");

          if (oNewNotifModel.getProperty("/Tplnr")) {
            var oFoundTechObject = _.find(
              aTechnicalObjects,
              jQuery.proxy(function (oTechObject) {
                return (
                  oTechObject.Tplnr === oNewNotifModel.getProperty("/Tplnr")
                );
              }, this)
            );
            if (oFoundTechObject)
              oNewNotifModel.setProperty(
                "/TechObject",
                oFoundTechObject.TechObject
              );
          }

          //Fecod
          var aFecodVh = [],
            cFecod = this.getHelper().getCatalogKey("fecod");
          if (oNewNotifModel.getProperty("/Qmart") && oFoundTechObject.Rbnr) {
            aFecodVh = _.filter(aCatalog, {
              Codct: cFecod,
              Rbnr: oFoundTechObject.Rbnr,
            });
            if (aFecodVh.length > 0) {
              oVhModel.setProperty(
                "/CatFecod",
                this.createTable(aFecodVh, cFecod)
              );
            }

            oNewNotifModel.setProperty("/Fekat", cFecod);
          }

          //Oteil
          var aOteilVh = [];

          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aOteilVh = _.filter(aCatalog, {
              // Qmart: sQmartKey,
              Codct: this.getHelper().getCatalogKey("oteil"),
              Rbnr: oFoundTechObject.Rbnr,
            });
            oVhModel.setProperty("/CatOteil", aOteilVh);

            // if (aOteilVh.length === 1) {
            // 	oNewNotifModel.setProperty("/Otkat", this.getHelper().getCatalogKey("oteil"));
            // 	oNewNotifModel.setProperty("/Otgrp", aOteilVh[0].Codgrr);
            // 	oNewNotifModel.setProperty("/Oteil", aOteilVh[0].Code);
            // }
          }
          this.getSharedModel().setProperty(
            "/OteilVisible",
            aOteilVh.length > 0
          );
          this.getSharedModel().setProperty(
            "/OteilEnabled",
            aOteilVh.length > 1
          );
        },

        _getCraftCodesForFl: function () {
          var oNewNotifModel = this.getView().getModel("newNotif");

          // oNewNotifModel.setProperty("/Equnr", "");
          // oNewNotifModel.setProperty("/Tplnr", sFunctionalLocation);

          var oFoundFloc = _.find(
            this.getSharedModel().getProperty("/techObjects"),
            jQuery.proxy(function (oFuncLoc) {
              return (
                oFuncLoc &&
                oFuncLoc.Tplnr === oNewNotifModel.getProperty("/Tplnr")
              );
            }, this)
          );

          // search craftcodes for selected func loc
          var aFoundFuncLocCraft = _.filter(
            this.getSharedModel().getProperty("/FuncLocCraft"),
            jQuery.proxy(function (oFuncLocCraft) {
              return oFoundFloc && oFuncLocCraft.Tplnr === oFoundFloc.Strno;
            }, this)
          );

          // no craft codes found for selected func loc, search for craft codes on higher func loc
          if (aFoundFuncLocCraft.length === 0) {
            aFoundFuncLocCraft = this._checkHigherFuncLocCraft(oFoundFloc);
          }

          if (aFoundFuncLocCraft && aFoundFuncLocCraft[0]) {
            if (aFoundFuncLocCraft.length > 0) {
              _.each(
                aFoundFuncLocCraft,
                jQuery.proxy(function (oFuncLocCraft) {
                  var oFoundCraft = _.find(
                    this.getModel("vh").getProperty("/Craft"),
                    function (oCraft) {
                      return oCraft.VhKey === oFuncLocCraft.Craft;
                    }
                  );

                  if (oFoundCraft) {
                    oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                  }
                }, this)
              );

              var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
              var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");
              aCraftCodeList.unshift(this.addEmptyLine(aCraftCodeList));
              this.getSharedModel().setProperty(
                "/CraftCodeList",
                aCraftCodeList
              );
              this.getSharedModel().setProperty(
                "/PlannerGroupList",
                aFoundFuncLocCraft
              );
              this.getSharedModel().setProperty(
                "/WorkCenterList",
                aWorkCenterList
              );
            }
          } else {
            var aCraftCodeList = [];
            this.getModel("newNotif").setProperty("/Craft", "");
            this.getSharedModel().setProperty("/CraftCodeList", "");
            this.getSharedModel().setProperty("/PlannerGroupList", []);
          }
        },

        _checkVHModel: function () {
          var oVHModel = this.getView().getModel("vh");

          if (oVHModel) {
            oVHModel.setProperty("/CatFecod", []);
            oVHModel.setProperty("/CatMfcod", []);
            oVHModel.setProperty("/CatMncod", []);
            oVHModel.setProperty("/CatQmcod", []);
            oVHModel.setProperty("/CatUrcod", []);

            if (
              oVHModel.getProperty("/Qmart") &&
              oVHModel.getProperty("/Catalog") &&
              oVHModel.getProperty("/Shift") &&
              oVHModel.getProperty("/Langu") &&
              oVHModel.getProperty("/Craft")
            ) {
              if (
                oVHModel.getProperty("/Qmart") !==
                  this.getSharedModel().getProperty("/vh/Qmart") ||
                (oVHModel.getProperty("/Catalog") !==
                  this.getSharedModel().getProperty("/vh/Catalog") &&
                  oVHModel.getProperty("/Shift") !==
                    this.getSharedModel().getProperty("/vh/Shift") &&
                  oVHModel.getProperty("/Langu") !==
                    this.getSharedModel().getProperty("/vh/Langu") &&
                  oVHModel.getProperty("/Craft") !==
                    this.getSharedModel().getProperty("/vh/Craft"))
              ) {
                return false;
              }
              return true;
            } else {
              return false;
            }
          } else {
            return false;
          }
        },

        _defaultNewNotif: function () {
          var oNewNotifModel = this.getView().getModel("newNotif"),
            oSharedModel = this.getSharedModel();

          oNewNotifModel.setProperty("/Handle", this.getHelper().getUUID());
          oNewNotifModel.setProperty(
            "/Ingpr",
            oSharedModel.getProperty("/sapSettings/INGRP")
          );
          oNewNotifModel.setProperty(
            "/Shift",
            oSharedModel.getProperty("/sapSettings/shift")
          );
          oNewNotifModel.setProperty(
            "/Swerk",
            oSharedModel.getProperty("/sapSettings/SWERK")
              ? oSharedModel.getProperty("/sapSettings/SWERK").toString()
              : oSharedModel.getProperty("/sapSettings/SWERK")
          );
          oNewNotifModel.setProperty(
            "/Iwerk",
            oSharedModel.getProperty("/sapSettings/IWERK").toString()
          );
          oNewNotifModel.setProperty(
            "/Qmdat",
            new moment().format("YYYY-MM-DD HH:mm:ss")
          );
          oNewNotifModel.setProperty(
            "/Arbpl",
            oSharedModel.getProperty("/sapSettings/GEWRK")
          );
          oNewNotifModel.setProperty(
            "/RepByWc",
            oSharedModel.getProperty("/sapSettings/REP_BY_WC")
          );
          oNewNotifModel.setProperty("/DescriptionEdit", true);
          $.when(this.getDBService().getEntitySet("Participant")).done(
            jQuery.proxy(function (oData) {
              var aParticipants = this.getHelper().rowsToArray(oData);

              var oPartic = _.find(aParticipants, function (oParticipant) {
                return oParticipant.Pernr !== "00000000" && oParticipant.Pernr;
              });

              var sVal = "";
              if (oPartic) {
                sVal = oPartic.Pernr;
              }
              // var oParticipant = {};
              // oParticipant.Pernr = oSharedModel.getProperty("/sapSettings/sapUser");
              // aParticipants.push(oParticipant);

              _.each(
                aParticipants,
                jQuery.proxy(function (oParticipant) {
                  if (
                    parseInt(oParticipant.Pernr) ===
                    oSharedModel.getProperty("/sapSettings/sapUser")
                  ) {
                    oNewNotifModel.setProperty("/Qmnam", oParticipant.Pernr);
                  }
                }, this)
              );

              if (!oSharedModel.getProperty("/notfications")) {
                oSharedModel.setProperty("/notfications", {});
              }
              oSharedModel.setProperty("/pernrValues", aParticipants);
              if (aParticipants.length === 1) {
                oNewNotifModel.setProperty("/Qmnam", sVal);
              } else if (aParticipants.length > 1) {
                var Perner = this.getView().getModel("shared").getData()
                    .sapSettings.PERNR,
                  oPartic = _.find(aParticipants, function (oParticipant) {
                    return oParticipant.Pernr === Perner;
                  });
                if (typeof oPartic !== "undefined") {
                  sVal = oPartic.Pernr;
                } else {
                  sVal = "";
                }
                oNewNotifModel.setProperty("/Qmnam", sVal);
              }

              // oSharedModel.setProperty("/notfications/defaultPernr", sVal);
            }, this)
          );
          // }
        },

        _filterSelects: function (sQmartKey, followUp) {
          var oVhModel = this.getView().getModel("vh"),
            oNewNotifModel = this.getView().getModel("newNotif"),
            aCatalog = oVhModel.getProperty("/Catalog"),
            aTechnicalObjects =
              this.getSharedModel().getProperty("/techObjects");

          if (oNewNotifModel.getProperty("/Tplnr")) {
            var oFoundTechObject = _.find(
              aTechnicalObjects,
              jQuery.proxy(function (oTechObject) {
                return (
                  oTechObject.Tplnr === oNewNotifModel.getProperty("/Tplnr")
                );
              }, this)
            );
          }
          if (sQmartKey) {
            sQmartKey = sQmartKey.split(",")[0];
          }

          //Qmcod
          //Reset Qmcod value
          //oNewNotifModel.setProperty("/Qmcod", "");
          /*Issue 41-13.0 Tracker Notification details screen - Redesign of notification type - Coding field has to be removed.

			var aQmcodVh = [];

			aQmcodVh = _.filter(aCatalog, {
				Qmart: sQmartKey,
				Codct: this.getHelper().getCatalogKey("qmcod")
			});
			if (!followUp) { 
				aQmcodVh = _.filter(aQmcodVh, jQuery.proxy(function (qmcod) {
					return (qmcod.Code !== "INRR") && (qmcod.Code !== "INRB");
				}, this));
			}
			oVhModel.setProperty("/CatQmcod", aQmcodVh);
			if (aQmcodVh.length === 1) {
				oNewNotifModel.setProperty("/Qmcod", aQmcodVh[0].Code);
				this._setGrpField("Qmgrp", aQmcodVh[0].Codgrr);
				this.findFunctionLocOrg();
			}
			
			
			oNewNotifModel.setProperty("/isQmcodRequired", aQmcodVh.length > 0);
			*/
          const cMncod = this.getHelper().getCatalogKey("mncod"),
            cFecod = this.getHelper().getCatalogKey("fecod"),
            cUrcod = this.getHelper().getCatalogKey("urcod"),
            cMfcod = this.getHelper().getCatalogKey("mfcod"),
            cOteil = this.getHelper().getCatalogKey("oteil");

          //Fecod
          var aFecodVh = [];

          if (oFoundTechObject && oFoundTechObject.Rbnr) {
            aFecodVh = _.filter(aCatalog, {
              Codct: cFecod,
              Rbnr: oFoundTechObject.Rbnr,
            });
          }

          if (aFecodVh.length > 0) {
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          } else {
            aFecodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cFecod,
            });
            oVhModel.setProperty(
              "/CatFecod",
              this.createTable(aFecodVh, cFecod)
            );
          }

          oNewNotifModel.setProperty("/Fekat", cFecod);

          let sharedSettings = this.getSharedModel().getProperty(
            "/sapSettings/notifFields"
          );
          //Urcod
          if (sharedSettings.Urcod) {
            var aUrcodVh = [];
            aUrcodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cUrcod,
            });
            oVhModel.setProperty(
              "/CatUrcod",
              this.createTable(aUrcodVh, cUrcod)
            );
          }
          oNewNotifModel.setProperty("/Urkat", cUrcod);

          //Mfcod - tasks
          if (sharedSettings.Mfcod) {
            var aMfcodVh = [];

            aMfcodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cMfcod,
            });
            oVhModel.setProperty(
              "/CatMfcod",
              this.createTable(aMfcodVh, cMfcod)
            );
          }
          oNewNotifModel.setProperty("/Mfkat", cMfcod);

          //Mncod - activities
          if (sharedSettings.Mncod) {
            var aMncodVh = [];
            aMncodVh = _.filter(aCatalog, {
              Qmart: sQmartKey,
              Codct: cMncod,
            });
            oVhModel.setProperty(
              "/CatMncod",
              this.createTable(aMncodVh, cMncod)
            );
          }
          oNewNotifModel.setProperty("/Mnkat", cMncod);

          //Oteil
          var aOteilVh = [];
          if (this.getSharedModel().getProperty("/OteilVisible")) {
            if (oFoundTechObject && oFoundTechObject.Rbnr) {
              aOteilVh = _.filter(aCatalog, {
                // Qmart: sQmartKey,
                Codct: cOteil,
                Rbnr: oFoundTechObject.Rbnr,
              });
              oVhModel.setProperty(
                "/CatOteil",
                this.createTable(aOteilVh, cOteil)
              );

              // if (aOteilVh.length === 1) {
              // 	oNewNotifModel.setProperty("/Otkat", this.getHelper().getCatalogKey("oteil"));
              // 	oNewNotifModel.setProperty("/Otgrp", aOteilVh[0].Codgrr);
              // 	oNewNotifModel.setProperty("/Oteil", aOteilVh[0].Code);
              // }
            }
          }

          // Add empty line to all of the catalogs

          oVhModel.setProperty(
            "/CatFecod",
            this.addEmptyLineToTable(oVhModel.getProperty("/CatFecod"))
          );
          oVhModel.setProperty(
            "/CatUrcod",
            this.addEmptyLineToTable(oVhModel.getProperty("/CatUrcod"))
          );
          oVhModel.setProperty(
            "/CatMfcod",
            this.addEmptyLineToTable(oVhModel.getProperty("/CatMfcod"))
          );
          oVhModel.setProperty(
            "/CatMncod",
            this.addEmptyLineToTable(oVhModel.getProperty("/CatMncod"))
          );
          oVhModel.setProperty(
            "/CatOteil",
            this.addEmptyLineToTable(oVhModel.getProperty("/CatOteil"))
          );

          //Reset Qmcod value
          // oNewNotifModel.setProperty("/Qmcod", "");
        },

        _getQmartText: function (sQmartCode) {
          var aVHQmart = this.getView().getModel("vh").getProperty("/Qmart"),
            oFind = _.find(aVHQmart, {
              Key: sQmartCode,
            });

          if (oFind) {
            return this.getText(oFind.Description);
          } else {
            return sQmartCode;
          }
        },
        /*Issue 41-13.0 Tracker Notification details screen - Redesign of notification type - Coding field has to be removed.

		_getQmcodText: function (sQmartCode, sQmcodCode) {
			var aVHQmcod = this.getView().getModel("vh").getProperty("/Catalog"),
				oFind = _.find(aVHQmcod, {
					Qmart: sQmartCode,
					Code: sQmcodCode
				});

			if (oFind) {
				return oFind.Kurztext;
			} else {
				return sQmartCode + "-" + sQmcodCode;
			}
		},
		*/

        _getAddNotificationDialog: function () {
          if (!this.oAddNotificationDialog) {
            this.oAddNotificationDialog = sap.ui.xmlfragment(
              "addNotificationDialog",
              "mobilework.view.notifications.AddNotificationDialog",
              this
            );
            this.getView().addDependent(this.oAddNotificationDialog);
          }

          return this.oAddNotificationDialog;
        },

        _getInstallationTreeDialog: function () {
          if (!this.getOwnerComponent().oInstallationTreeDialog) {
            this.getOwnerComponent().oInstallationTreeDialog =
              sap.ui.xmlfragment(
                "installationTree",
                "mobilework.view.notifications.InstallationTreeDialog",
                this
              );
            this.getView().addDependent(
              this.getOwnerComponent().oInstallationTreeDialog
            );
          }

          return this.getOwnerComponent().oInstallationTreeDialog;
        },

        _getPlannerGroupDialog: function () {
          if (!this.getOwnerComponent().oPlannerGroupDialog) {
            this.getOwnerComponent().oPlannerGroupDialog = sap.ui.xmlfragment(
              "plannerGroup",
              "mobilework.view.notifications.PlannerGroupDialog",
              this
            );
            this.getView().addDependent(
              this.getOwnerComponent().oPlannerGroupDialog
            );
          }

          return this.getOwnerComponent().oPlannerGroupDialog;
        },

        _getWorkCenterDialog: function () {
          if (!this.getOwnerComponent().oWorkCenterDialog) {
            this.getOwnerComponent().oWorkCenterDialog = sap.ui.xmlfragment(
              "WorkCenter",
              "mobilework.view.notifications.WorkCenterDialog",
              this
            );
            this.getView().addDependent(
              this.getOwnerComponent().oWorkCenterDialog
            );
          }

          return this.getOwnerComponent().oWorkCenterDialog;
        },

        _getOpenImageDialog: function () {
          if (!this.oOpenImageDialog) {
            this.oOpenImageDialog = sap.ui.xmlfragment(
              "OpenImageDialog",
              "mobilework.view.notifications.OpenImage",
              this
            );
            this.getView().addDependent(this.oOpenImageDialog);
          }

          return this.oOpenImageDialog;
        },

        _getValueHelpFromDb: function () {
          var d = jQuery.Deferred(),
            oPromCatalog = this.getDBService().getEntitySet("Catalog"),
            oPromQmart = this.getDBService().getEntitySet(
              "PMNotificationQmartVH"
            ),
            oPromShift = this.getDBService().getEntitySet(
              "PMNotificationShiftVH"
            ),
            oPromLangu = this.getDBService().getEntitySet(
              "PMNotificationLanguVH"
            ),
            oPromCraft = this.getDBService().getEntitySet(
              "PMNotificationCraftVH"
            ),
            oPromActType = this.getDBService().getEntitySet(
              "ConfirmationsPMActTypeVH"
            ),
            oPromPmenvr = this.getDBService().getEntitySet(
              "PMNotificationPmenvrVH"
            ),
            oPromPmqual = this.getDBService().getEntitySet(
              "PMNotificationPmqualVH"
            ),
            oPromPmsafe = this.getDBService().getEntitySet(
              "PMNotificationPmsafeVH"
            ),
            oPromQuotCoR = this.getDBService().getEntitySet(
              "PMNotificationQuotCoRVH"
            ),
            oPromQuotDeR = this.getDBService().getEntitySet(
              "PMNotificationQuotDeRVH"
            ),
            oPromQuotPrR = this.getDBService().getEntitySet(
              "PMNotificationQuotPrRVH"
            ),
            oPromQuotWcR = this.getDBService().getEntitySet(
              "PMNotificationQuotWcRVH"
            ),
            oPromImpactObl = this.getDBService().getEntitySet(
              "ImpactOblCustomizing"
            ),
            oPromNotifcationType = this.getHelper().getNotificationTypes();

          $.when(
            oPromQmart,
            oPromCatalog,
            oPromShift,
            oPromLangu,
            oPromCraft,
            oPromPmenvr,
            oPromPmqual,
            oPromPmsafe,
            oPromQuotCoR,
            oPromQuotDeR,
            oPromQuotPrR,
            oPromQuotWcR,
            oPromImpactObl,
            oPromNotifcationType
          ).done(
            jQuery.proxy(function (
              oQmartData,
              oCatalogData,
              oShiftData,
              oLanguData,
              oCraftData,
              oPmenvrData,
              oPmqualData,
              oPmsafeData,
              oQuotCoRData,
              oQuotDeRData,
              oQuotPrRData,
              oQuotWcRData,
              oImpactOblData,
              oNotifcationType
            ) {
              this.onVhDataRetreived(
                oQmartData,
                oCatalogData,
                oShiftData,
                oLanguData,
                oCraftData,
                oPmenvrData,
                oPmqualData,
                oPmsafeData,
                oQuotCoRData,
                oQuotDeRData,
                oQuotPrRData,
                oQuotWcRData,
                oImpactOblData,
                oNotifcationType
              );
              d.resolve();
            },
            this)
          );

          return d.promise();
        },

        _getFlocCraftFromDb: function () {
          var d = $.Deferred(),
            aFuncLocCraft = [],
            oPromFlocCraft = this.getDBService().getEntitySet("FuncLocCraft");

          $.when(oPromFlocCraft).done(
            jQuery.proxy(function (oFuncLocCraftData) {
              for (var i = 0; i < oFuncLocCraftData.rows.length; i++) {
                aFuncLocCraft.push(oFuncLocCraftData.rows.item(i));
              }
              this.getSharedModel().setProperty("/FuncLocCraft", aFuncLocCraft);
            }, this)
          );
        },

        _manualCreateNotification: function () {
          var oNotification = this.getView()
              .getModel("newNotif")
              .getProperty("/"),
            oValidation = null,
            sMandDamage = this.getSharedModel().getProperty(
              "/sapSettings/MAND_DAMAG"
            ),
            sMandCause = this.getSharedModel().getProperty(
              "/sapSettings/MAND_CAUSE"
            ),
            sMandActiv = this.getSharedModel().getProperty(
              "/sapSettings/MAND_ACTIV"
            ),
            sIncFields = "",
            oFollowUp = {
              Handle: oNotification.Handle,
              FollowUp: oNotification.FollowUp,
              DisabledForNotifFromOrder:
                oNotification.DisabledForNotifFromOrder,
              FinalArbplFrom: oNotification.FinalArbplFrom,
              FinalIngrpFrom: oNotification.FinalIngrpFrom,
            };
          if (oNotification) {
            oValidation = this.getValidator().validateNotification(
              oNotification,
              sMandCause,
              sMandDamage,
              sMandActiv,
              this.getSharedModel().getProperty("/")
            );

            if (oValidation.isValid) {
              delete oNotification.isQmcodRequired;

              $.when(
                this.getDBService().insertObject(
                  "PMNotification",
                  oNotification
                ),
                this._saveTableToDB(oFollowUp, FollowUpNotif)
              )
                .done(
                  jQuery.proxy(function (res) {
                    this.getView().getModel("newNotif").setProperty("/", {});
                    this.getLogs().addLog(
                      "Notification Created",
                      "INFO",
                      "NotificationMaster"
                    );
                    this.onNotificationCreated(res, oNotification);
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Notification Insert Failed",
                      "ERROR",
                      "NotificationMaster"
                    );
                  }, this)
                );
            } else {
              for (var sField in oValidation.aFields) {
                if (sIncFields === "") {
                  sIncFields += this.getText(oValidation.aFields[sField]);
                } else {
                  sIncFields +=
                    ", " + this.getText(oValidation.aFields[sField]);
                }
              }
              this.getLogs().addLog(
                this.getText("FillInRequiredFields", sIncFields),
                "INFO",
                "NotificationMaster"
              );
              MBox.error(this.getText("FillInRequiredFields", sIncFields));
            }
          }
        },

        _setGrpField: function (sField, sValue) {
          this.getView()
            .getModel("newNotif")
            .setProperty("/" + sField, sValue);
        },

        _clearPlannerGroupsList: function () {
          this.getSharedModel().setProperty("/plannerGroupsList", []);
        },

        _checkHigherFuncLocCraft: function (oObject) {
          var aFoundFuncLocCraft = [];

          var oParentFloc = _.find(
            this.getSharedModel().getProperty("/techObjects"),
            jQuery.proxy(function (oFuncLoc) {
              return (
                oFuncLoc && oObject && oFuncLoc.TechObject === oObject.Parent
              );
            }, this)
          );

          if (oParentFloc) {
            aFoundFuncLocCraft = _.filter(
              this.getSharedModel().getProperty("/FuncLocCraft"),
              jQuery.proxy(function (oFuncLocCraft) {
                return oFuncLocCraft.Tplnr === oParentFloc.Strno;
              }, this)
            );

            if (aFoundFuncLocCraft.length > 0) {
              aFoundFuncLocCraft = aFoundFuncLocCraft.concat(
                this._checkHigherFuncLocCraft(oParentFloc)
              );
              return aFoundFuncLocCraft;
            } else {
              aFoundFuncLocCraft = this._checkHigherFuncLocCraft(oParentFloc);
              return aFoundFuncLocCraft;
            }
          } else {
            return aFoundFuncLocCraft;
          }
        },
        onPictureUpload: function (oEvent) {
          var oFile = oEvent.getParameter("files")[0],
            oReader = new FileReader();

          oReader.onload = jQuery.proxy(function (oResult) {
            this.onPhotoTakenSuccess(oResult.target.result.split(",")[1]);
            sap.ui
              .getCore()
              .byId("addNotificationDialog--NotificationMasterFileUploader")
              .clear();
            var that = this;
            that.getSharedModel().setProperty("/IconBarNotifkey", "info");
            setTimeout(function () {
              that.getSharedModel().setProperty("/IconBarNotifkey", "photo");
            }, 2000);
          }, this);

          if (oFile) {
            oReader.readAsDataURL(oFile);
          }
        },

        onPhotoAddPress: function (oEvent) {
          navigator.camera.getPicture(
            jQuery.proxy(this.onPhotoTakenSuccess, this),
            jQuery.proxy(this.onPhotoTakenFail, this),
            {
              destinationType: Camera.DestinationType.DATA_URL,
              allowEdit: false,
              quality: 30,
            }
          );
        },

        onPhotoDeletePress: function (oEvent) {
          var oBindingContext = oEvent
              .getParameter("listItem")
              .getBindingContext("newNotif"),
            sPicHandle = oBindingContext.getObject().Handle;

          MBox.confirm(this.getText("ConfirmPicDelete"), {
            onClose: function (sAction) {
              if (sPicHandle && sAction === sap.m.MessageBox.Action.OK) {
                $.when(
                  this.getDBService().deleteObject(
                    "Picture",
                    oBindingContext.getObject()
                  )
                )
                  .done(
                    jQuery.proxy(function () {
                      this._getPhotosFromDatabase(
                        this.getView()
                          .getModel("newNotif")
                          .getProperty("/Handle")
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      MBox.error(this.getText("PicDeleteError"));
                    }, this)
                  );
              }
            }.bind(this),
          });
        },
        onPhotoTakenSuccess: function (sBase64) {
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "newImage"
          );
          var image = "data:image/jpeg;base64," + sBase64;
          this.getView()
            .getModel("newImage")
            .setProperty("/RotateImage", image);
          this._getRotateDialog().open();
        },

        onSuccessPics: function (sBase64) {
          this._getRotateDialog().close();
          var sHandle = "",
            sContent = "",
            sMimetype = "",
            sParentHandle = "",
            sName = "",
            oPhotoObject = {},
            sPicIndex = 0;

          sHandle = this.getHelper().getUUID();
          sParentHandle = this.getView()
            .getModel("newNotif")
            .getProperty("/Handle");
          sContent = sBase64;
          sMimetype = "image/jpeg";
          sName = "notif_" + new Date().getTime() + ".jpeg";
          if (this.getView().getModel("newNotif").getProperty("/Photos")) {
            sPicIndex =
              this.getView().getModel("newNotif").getProperty("/Photos")
                .length + 1;
          } else {
            sPicIndex = 1;
          }

          oPhotoObject = {
            Tag: "",
            Handle: sHandle,
            PicIndex: sPicIndex,
            Description: "",
            Parent: sParentHandle,
            PicName: sName,
            PicType: sMimetype,
            PicContent: sContent,
          };

          $.when(
            this.getDBService().insertObject("Picture", oPhotoObject)
          ).done(
            jQuery.proxy(function () {
              var oNewNotifModel = this.getView().getModel("newNotif"),
                aPhotos = oNewNotifModel.getProperty("/Photos");
              if (!aPhotos) {
                aPhotos = [];
              }
              aPhotos.push(oPhotoObject);
              oNewNotifModel.setProperty("/Photos", aPhotos);
              oNewNotifModel.setProperty("/PicCount", aPhotos.length);
            }, this)
          );
        },

        onPhotoTakenFail: function (oError) {
          MBox.error(oError.toString());
        },

        _getPhotosFromDatabase: function (sParentHandle) {
          $.when(this.getDBService().getPhotoNamesById(sParentHandle)).done(
            jQuery.proxy(function (oData) {
              var oNewNotifModel = this.getView().getModel("newNotif"),
                aPhotos = [];
              aPhotos = this.getHelper().rowsToArray(oData);
              if (aPhotos.length > 1) {
                aPhotos = _.sortBy(aPhotos, "PicIndex");
              }
              oNewNotifModel.setProperty("/Photos", aPhotos);
              oNewNotifModel.setProperty("/PicCount", aPhotos.length);
              oNewNotifModel.refresh(true);
            }, this)
          );
        },

        onSendToGkPress: function () {
          this.getView().getModel("newNotif").setProperty("/SendToGk", true);
          this.getView().getModel("newNotif").setProperty("/Complete", "");
          this.onAddDialogConfirmPress(null, true);
        },

        _getRotateDialog: function () {
          if (!this.getOwnerComponent().oRotateDialog) {
            this.getOwnerComponent().oRotateDialog = sap.ui.xmlfragment(
              "Rotate",
              "mobilework.view.notifications.RotateImage",
              this
            );
            this.getView().addDependent(this.getOwnerComponent().oRotateDialog);
          }

          return this.getOwnerComponent().oRotateDialog;
        },

        onRightRotate: function (base64) {
          var canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("newImage")
              .setProperty("/RotateImage", newurl);
          }, this);
        },
        onRotateClose: function () {
          this._getRotateDialog().close();
        },

        onLeftRotate: function (base64) {
          var canvas = document.createElement("canvas"),
            ctx = canvas.getContext("2d"),
            image = new Image();
          image.src =
            (base64.indexOf(",") == -1 ? "data:image/jpeg;base64," : "") +
            base64;
          image.onload = jQuery.proxy(function () {
            var w = image.width,
              h = image.height,
              rads = (-90 * Math.PI) / 180,
              c = Math.cos(rads),
              s = Math.sin(rads);
            if (s < 0) {
              s = -s;
            }
            if (c < 0) {
              c = -c;
            }
            canvas.width = h * s + w * c;
            canvas.height = h * c + w * s;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((-90 * Math.PI) / 180);
            ctx.drawImage(image, -image.width / 2, -image.height / 2);
            var newurl = canvas.toDataURL();
            this.getView()
              .getModel("newImage")
              .setProperty("/RotateImage", newurl);
          }, this);
        },

        onEditDescription: function () {
          var editValue = this.getView()
            .getModel("newNotif")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/DescriptionEdit", false);
          }
        },

        onSaveDescription: function () {
          var editValue = this.getView()
            .getModel("newNotif")
            .getProperty("/DescriptionEdit");
          if (editValue === false) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/DescriptionEdit", true);
          } else if (editValue === true) {
            this.getView()
              .getModel("newNotif")
              .setProperty("/DescriptionEdit", false);
          }
          var photos = this.getView()
            .getModel("newNotif")
            .getProperty("/Photos");
          photos.forEach(
            jQuery.proxy(function (oItem) {
              $.when(this.getDBService().updateObject("Picture", oItem))
                .done(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Success",
                      "INFO",
                      "NotificationMaster"
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    this.getLogs().addLog(
                      "Save Picture Description Fail",
                      "ERROR",
                      "NotificationMaster"
                    );
                  }, this)
                );
            }, this)
          );
        },

        onUpdateFinished: function (oEvt) {
          if (oEvt.getSource().getAggregation("items").length === 2) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", true);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 1) {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
          } else if (oEvt.getSource().getAggregation("items").length === 0) {
          } else {
            oEvt
              .getSource()
              .getAggregation("items")[0]
              .getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[0]
              .setProperty("visible", false);
            oEvt
              .getSource()
              .getAggregation("items")
              [
                oEvt.getSource().getAggregation("items").length - 1
              ].getAggregation("content")[0]
              .getAggregation("items")[2]
              .getAggregation("items")[2]
              .getAggregation("items")[1]
              .setProperty("visible", false);
            for (
              var i = 1;
              i < oEvt.getSource().getAggregation("items").length - 1;
              i++
            ) {
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[2]
                .getAggregation("items")[2]
                .getAggregation("items")[0]
                .setProperty("visible", true);
              oEvt
                .getSource()
                .getAggregation("items")
                [i].getAggregation("content")[0]
                .getAggregation("items")[2]
                .getAggregation("items")[2]
                .getAggregation("items")[1]
                .setProperty("visible", true);
            }
          }
        },
        onDropUp: function (oEvent) {
          if (
            this.getView()
              .getModel("newNotif")
              .getProperty("/DescriptionEdit") === false
          ) {
            var indexDropUp = oEvent.getParameter("id").lastIndexOf("-"),
              idDropUp = parseInt(
                oEvent.getParameter("id").substring(indexDropUp + 1),
                10
              ),
              photos = this.getView()
                .getModel("newNotif")
                .getProperty("/Photos"),
              tempItem = photos[idDropUp],
              tempIndex;
            photos[idDropUp] = photos[idDropUp - 1];
            photos[idDropUp - 1] = tempItem;
            tempIndex = photos[idDropUp].PicIndex;
            photos[idDropUp].PicIndex = photos[idDropUp - 1].PicIndex;
            photos[idDropUp - 1].PicIndex = tempIndex;
            this.getView().getModel("newNotif").refresh();
          }
        },
        onDropDown: function (oEvent) {
          if (
            this.getView()
              .getModel("newNotif")
              .getProperty("/DescriptionEdit") === false
          ) {
            var indexDropDown = oEvent.getParameter("id").lastIndexOf("-"),
              idDropDown = parseInt(
                oEvent.getParameter("id").substring(indexDropDown + 1),
                10
              ),
              photos = this.getView()
                .getModel("newNotif")
                .getProperty("/Photos"),
              tempItem = photos[idDropDown],
              tempIndex;
            photos[idDropDown] = photos[idDropDown + 1];
            photos[idDropDown + 1] = tempItem;
            tempIndex = photos[idDropDown].PicIndex;
            photos[idDropDown].PicIndex = photos[idDropDown + 1].PicIndex;
            photos[idDropDown + 1].PicIndex = tempIndex;
            this.getView().getModel("newNotif").refresh();
          }
        },

        onImagePress: function (Url) {
          var img = new Image(),
            me = this;
          img.src = Url;
          img.onload = function () {
            me.imageWidth = img.naturalWidth;
            me.imageHeight = img.naturalHeight;
          };
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "newImage"
          );
          this.getView().getModel("newImage").setProperty("/RotateImage", Url);
          this._getOpenImageDialog().open();
          sap.ui
            .getCore()
            .byId("OpenImageDialog--sliderInOpenImage")
            .setValue(75);
        },

        onResizeCarouselContainer: function (oEvent) {
          var iValue = oEvent.getParameter("value"),
            oCarouselContainer = sap.ui
              .getCore()
              .byId("OpenImageDialog--carouselOpenImage"),
            iNewHeight = Math.floor((this.imageHeight * iValue) / 98),
            iNewWidth = Math.floor((this.imageWidth * iValue) / 98);

          oCarouselContainer.setWidth(iNewWidth + "px");
          oCarouselContainer.setHeight(iNewHeight + "px");
        },

        onCloseImage: function () {
          this._getOpenImageDialog().close();
        },

        onCompleteNotificationPress: function () {
          var oNotifModel = this.getView().getModel("newNotif");
          oNotifModel.setProperty("/Complete", "X");
          oNotifModel.setProperty("/SendToGk", "");
          this.onAddDialogConfirmPress(null, true);
        },

        _onInstallationSelected: function (oObject) {
          var oNewNotifModel = this.getView().getModel("newNotif");
          if (oObject.TechObjectType === "EQ") {
            oNewNotifModel.setProperty("/Equnr", oObject.Equnr);
            // Added for Notification Desc. by 1015320 on 29/11/2022
            oNewNotifModel.setProperty("/Ktx02", oObject.Ktx01);
            //Ends.

            var oFoundFloc = _.find(
              this.getSharedModel().getProperty("/techObjects"),
              jQuery.proxy(function (oFuncLoc) {
                return (
                  oFuncLoc &&
                  oFuncLoc.TechObject === oObject.Parent &&
                  oFuncLoc.TechObjectType !== "PA"
                );
              }, this)
            );
            var oFoundFL = _.find(
              this.getSharedModel().getProperty("/techObjects"),
              jQuery.proxy(function (oFuncLoc) {
                return oFuncLoc && oFuncLoc.TechObject === oObject.TechObject;
              }, this)
            );
            if (oFoundFL)
              oNewNotifModel.setProperty("/TechObject", oFoundFL.TechObject);
            if (oFoundFloc) {
              oNewNotifModel.setProperty("/Tplnr", oFoundFloc.Strno);
              oNewNotifModel.setProperty("/Ktx01", oFoundFloc.Ktx01);
              var aFoundFuncLocCraft = _.filter(
                this.getSharedModel().getProperty("/FuncLocCraft"),
                jQuery.proxy(function (oFuncLocCraft) {
                  return oFuncLocCraft.Tplnr === oFoundFloc.Strno;
                }, this)
              );

              // no craft codes found for selected func loc, search for craft codes on higher func loc
              if (aFoundFuncLocCraft.length === 0) {
                aFoundFuncLocCraft = this._checkHigherFuncLocCraft(oObject);
              }
            }
          } else if (
            oObject.TechObjectType === "FL" ||
            oObject.TechObjectType === "IF"
          ) {
            oNewNotifModel.setProperty("/Equnr", "");
            oNewNotifModel.setProperty("/Tplnr", oObject.Strno);
            oNewNotifModel.setProperty("/TechObject", oObject.TechObject);
            // Added for Notification Desc. by 1015320 on 29/11/2022
            oNewNotifModel.setProperty("/Ktx01", oObject.Ktx01);
            oNewNotifModel.setProperty("/Ktx02", "");
            //Ends.

            this._checkFLSpecificData();

            // search craftcodes for selected func loc
            aFoundFuncLocCraft = _.filter(
              this.getSharedModel().getProperty("/FuncLocCraft"),
              jQuery.proxy(function (oFuncLocCraft) {
                return oFuncLocCraft.Tplnr === oObject.Strno;
              }, this)
            );

            var aFoundHigherFuncLocCraft =
              this._checkHigherFuncLocCraft(oObject);

            aFoundFuncLocCraft = _.concat(
              aFoundFuncLocCraft,
              aFoundHigherFuncLocCraft
            );
          } else {
            MBox.error(this.getText("GRInstallNotPossible"));
            return;
          }

          if (aFoundFuncLocCraft && aFoundFuncLocCraft[0]) {
            if (aFoundFuncLocCraft.length > 0) {
              _.each(
                aFoundFuncLocCraft,
                jQuery.proxy(function (oFuncLocCraft) {
                  var oFoundCraft = _.find(
                    this.getModel("vh").getProperty("/Craft"),
                    function (oCraft) {
                      return oCraft.VhKey === oFuncLocCraft.Craft;
                    }
                  );

                  if (oFoundCraft) {
                    oFuncLocCraft.CraftDesc = oFoundCraft.VhVal;
                  }
                }, this)
              );

              var aCraftCodeList = _.uniqBy(aFoundFuncLocCraft, "Craft");
              var aWorkCenterList = _.uniqBy(aFoundFuncLocCraft, "Gewrk");

              aCraftCodeList = this.addEmptyLineToTable(aCraftCodeList);
              aFoundFuncLocCraft = this.addEmptyLineToTable(aFoundFuncLocCraft);
              aWorkCenterList = this.addEmptyLineToTable(aWorkCenterList);
              this.getSharedModel().setProperty(
                "/CraftCodeList",
                aCraftCodeList
              );
              this.getSharedModel().setProperty(
                "/PlannerGroupList",
                aFoundFuncLocCraft
              );
              this.getSharedModel().setProperty(
                "/WorkCenterList",
                aWorkCenterList
              );
            }
          } else {
            var aCraftCodeList = [];
            this.getModel("newNotif").setProperty("/Craft", "");
            this.getSharedModel().setProperty("/CraftCodeList", "");
            this.getSharedModel().setProperty("/PlannerGroupList", []);
          }
          this.findFunctionLocOrg();
        },

        checkForRequiredInStartMalFn: function (sQmart) {
          if (sQmart) return sQmart === "30,DEFE" || sQmart === "30,IMME";
          else return false;
        },
        //Issue 17 12.0 Issue Tracker.
        checkForOverWriteArbpl: function (sQmart) {
          var odata = [{ sQmart: "40,BLUE" }, { sQmart: "50,BLUE" }];
          return this.visibiltyFilter(sQmart, odata);
        },

        findFunctionLocOrg: function () {
          var oNotification = this.getModel("newNotif").getProperty("/"),
            ingrp,
            arbpl;
          if (oNotification.FinalArbplFrom === "UserAdded") {
            arbpl = true;
          }
          if (oNotification.FinalIngrpFrom === "UserAdded") {
            ingrp = true;
          }
          $.when(this.getDBService().getEntitySet("FuncLocOrg")).done(
            jQuery.proxy(function (funcLocOrg) {
              var aFuncLocOrg = this.getHelper().rowsToArray(funcLocOrg),
                oFoundFlocOrg =
                  _.find(
                    aFuncLocOrg,
                    jQuery.proxy(function (oFuncLoc) {
                      return oFuncLoc && oFuncLoc.Tplnr === oNotification.Tplnr;
                    }, this)
                  ) || {};

              if (!oFoundFlocOrg.Ingrp || !oFoundFlocOrg.Arbpl) {
                oFoundFlocOrg = _.find(
                  this.getSharedModel().getProperty("/techObjects"),
                  jQuery.proxy(function (oFuncLoc) {
                    return oFuncLoc && oFuncLoc.Tplnr === oNotification.Tplnr;
                  }, this)
                );
                oFoundFlocOrg = this.checkHigherFuncLocOrg(
                  oFoundFlocOrg,
                  aFuncLocOrg
                );
              }
              if (!ingrp) {
                if (oNotification.Craft) {
                  oNotification.Ingpr = oNotification.CraftIngpr;
                } else if (oFoundFlocOrg && oFoundFlocOrg.Ingrp) {
                  oNotification.Ingpr = oFoundFlocOrg.Ingrp;
                } else {
                  oNotification.Ingpr =
                    this.getSharedModel().getProperty("/sapSettings/INGRP");
                }
              }
              if (!arbpl) {
                if (
                  oNotification.Qmart === "30,IMME" ||
                  (oNotification.Qmart === "30,DEFE" &&
                    oNotification.confirmationIsExisting)
                ) {
                  if (oNotification.Craft) {
                    oNotification.Arbpl = oNotification.CraftArbpl;
                  } else {
                    oNotification.Arbpl =
                      this.getSharedModel().getProperty("/sapSettings/GEWRK");
                  }
                } else if (this.checkForOverWriteArbpl(oNotification.Qmart)) {
                  oNotification.Arbpl =
                    this.getSharedModel().getProperty("/sapSettings/GEWRK");
                } else {
                  if (oNotification.Craft) {
                    oNotification.Arbpl = oNotification.CraftArbpl;
                  } else if (oFoundFlocOrg && oFoundFlocOrg.Arbpl) {
                    oNotification.Arbpl = oFoundFlocOrg.Arbpl;
                  } else {
                    oNotification.Arbpl =
                      this.getSharedModel().getProperty("/sapSettings/GEWRK");
                  }
                }
              }
              this.getView().getModel("newNotif").refresh();
            }, this)
          );
        },
        onIconBarSelect: function (oEvent) {
          var sKey = oEvent.getParameter("key"),
            bomTree,
            oNotification = this.getView()
              .getModel("newNotif")
              .getProperty("/");
          if (sKey === "bomTree") {
            if (oNotification.FollowUp) {
              $.when(this._onInstallationTreeRequest())
                .done(
                  jQuery.proxy(function () {
                    if (oNotification.Equnr) {
                      bomTree = this.getHelper().findChildTree(
                        this.getSharedModel().getProperty("/tree"),
                        oNotification,
                        "Equnr"
                      );
                    } else {
                      bomTree = this.getHelper().findChildTree(
                        this.getSharedModel().getProperty("/tree"),
                        oNotification,
                        "Tplnr"
                      );
                    }
                    this.getSharedModel().setProperty("/bomTree", [bomTree]);
                  }, this)
                )
                .fail(jQuery.proxy(function () {}, this));
            } else {
              if (oNotification.Equnr) {
                bomTree = this.getHelper().findChildTree(
                  this.getSharedModel().getProperty("/tree"),
                  oNotification,
                  "Equnr"
                );
              } else {
                bomTree = this.getHelper().findChildTree(
                  this.getSharedModel().getProperty("/tree"),
                  oNotification,
                  "Tplnr"
                );
              }
              this.getSharedModel().setProperty("/bomTree", [bomTree]);
            }
          } else if (sKey === "Impacts") {
            if (oNotification.FollowUp) {
              $.when(this._onInstallationTreeRequest())
                .done(
                  jQuery.proxy(function () {
                    this.setFLImpact();
                  }, this)
                )
                .fail(jQuery.proxy(function () {}, this));
            } else {
              this.setFLImpact();
            }
          }
        },
        onBomTreeSelected: function (oEvent) {
          var oObject = oEvent.getParameter("rowContext").getObject();
          if (!oObject.Matnr) {
            MToast.show(this.getText("NoBomForFlEQ"));
            return;
          }
          $.when(this.getDBService().getEntitySet("BomData"))
            .done(
              jQuery.proxy(function (oData) {
                var data = this.getHelper().rowsToArray(oData);
                var bomData = _.find(data, {
                  Parent: oObject.Parent,
                  Matnr: oObject.Matnr,
                });
                if (bomData) {
                  this.getDialogManager().open(
                    "notifications.BomInfo",
                    this.getView()
                  );
                  this.getModel("local").setProperty("/BomData", bomData);
                } else MToast.show(this.getText("MaterialNotFound", oObject.Ktx01));
              }, this)
            )
            .fail(jQuery.proxy(function () {}, this));
        },

        onBomDataColse: function () {
          this.getDialogManager().close(
            "notifications.BomInfo",
            this.getView()
          );
        },

        addDescription: function () {
          $.when(this.getDBService().getEntitySet("TechnicalObject")).done(
            jQuery.proxy(function (oData) {
              let oObject = this.getView()
                .getModel("newNotif")
                .getProperty("/");
              var aTechnicalObjectSet = this.getHelper().rowsToArray(oData);
              if (oObject.Tplnr) {
                var Ktx01 = _.filter(
                  aTechnicalObjectSet,
                  function (oTechnicalObject) {
                    return (
                      oTechnicalObject &&
                      oTechnicalObject.Tplnr === oObject.Tplnr
                    );
                  }
                );
                if (Ktx01.length > 0)
                  this.getView()
                    .getModel("newNotif")
                    .setProperty("/Ktx01", Ktx01[0].Ktx01);
              }
              if (oObject.Equnr) {
                var EqnurKtx01 = _.filter(
                  aTechnicalObjectSet,
                  function (oTechnicalObject) {
                    return (
                      oTechnicalObject &&
                      oTechnicalObject.Equnr === oObject.Equnr
                    );
                  }
                );
                if (EqnurKtx01.length > 0)
                  object.EqnurKtx01 = EqnurKtx01[0].Ktx01;
              }
            }, this)
          );
        },

        onSearchOpenPress: function () {
          this.getDialogManager().open(
            "notifications.FunctionLocationSearch",
            this.getView()
          );
        },

        onSearchCancelPress: function (oEvent) {
          oEvent.getSource().getBinding("items").filter([]);
          //this.getDialogManager().close("notifications.FunctionLocationSearch", this.getView());
        },

        onSearchFLPress: function (oEvent) {
          var sValue = oEvent.getParameters().value,
            aFilters = [];
          if (sValue) {
            aFilters = [
              new Filter(
                [
                  new Filter("Ktx01", function (sText) {
                    return (
                      (sText || "")
                        .toUpperCase()
                        .indexOf(sValue.toUpperCase()) > -1
                    );
                  }),
                ],
                false
              ),
            ];
          }
          oEvent.getSource().getBinding("items").filter(aFilters);
        },

        onConfirmFLSearch: function (oEvent) {
          let selected = oEvent.getParameter("selectedContexts");
          if (selected.length > 0) {
            let selectedData = this.getSharedModel().getProperty(
              selected[0].getPath()
            );
            this._onInstallationSelected(selectedData);
            this._getInstallationTreeDialog().close();
            oEvent.getSource().getBinding("items").filter([]);
          }
        },

        setFLImpact: function () {
          $.when(this.getDBService().getEntitySet("FuncLocImpact"))
            .done(
              jQuery.proxy(function (oData, oObject) {
                oData = this.getHelper().rowsToArray(oData);
                let notification = this.getView()
                  .getModel("newNotif")
                  .getProperty("/");
                if (notification.Equnr) {
                  var techObject = _.find(
                    this.getSharedModel().getProperty("/techObjects"),
                    { Equnr: notification.Equnr }
                  );
                } else {
                  var techObject = _.find(
                    this.getSharedModel().getProperty("/techObjects"),
                    { Tplnr: notification.Tplnr }
                  );
                }
                let impacts = this.findImpacts(techObject, oData);
                if (impacts) {
                  this.getModel("newNotif").setProperty(
                    "/QuotCoP",
                    impacts.QuotCoP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotEvP",
                    impacts.QuotEvP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotPrP",
                    impacts.QuotPrP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotQaP",
                    impacts.QuotQaP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotSaP",
                    impacts.QuotSaP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotDeP",
                    impacts.QuotDeP
                  );
                  this.getModel("newNotif").setProperty(
                    "/QuotWcP",
                    impacts.QuotWcP
                  );
                } else {
                  this.getModel("newNotif").setProperty("/QuotCoP", "");
                  this.getModel("newNotif").setProperty("/QuotEvP", "");
                  this.getModel("newNotif").setProperty("/QuotPrP", "");
                  this.getModel("newNotif").setProperty("/QuotQaP", "");
                  this.getModel("newNotif").setProperty("/QuotSaP", "");
                  this.getModel("newNotif").setProperty("/QuotDeP", "");
                  this.getModel("newNotif").setProperty("/QuotWcP", "");
                }
              }, this)
            )
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        qmartLangu: function (desc) {
          return this.getText(desc);
        },

        adjustQmart: function () {
          var qmart = this.getView().getModel("vh").getProperty("/Qmart"),
            oQmart = [];
          if (qmart) {
            var orderType = this.getView()
              .getModel("newNotif")
              .getProperty("/Qmcod");
            if (orderType) {
              qmart = qmart.filter(function (row) {
                return (
                  row.Key !== "20,1TIM" &&
                  row.Key !== "70,PROD" &&
                  row.Key !== "60,GENE"
                );
              });
            }
            if (orderType === "P010" || orderType === "P005") {
              oQmart = qmart.filter(function (row) {
                return row.Key !== "20,INRB" && row.Key !== "20,INRR";
              });
            } else if (orderType === "P020" || orderType === "P030") {
              oQmart = qmart.filter(function (row) {
                return row.Key !== "10,TBMP";
              });
            } else {
              oQmart = qmart.filter(function (row) {
                return (
                  row.Key !== "10,TBMP" &&
                  row.Key !== "20,INRB" &&
                  row.Key !== "20,INRR"
                );
              });
            }
          }
          this.getView().getModel("vh").setProperty("/oQmart", oQmart);
        },

        onSelected: function (oEvent) {
          const path = oEvent.getSource().getSelectedContextPaths();
          const oSelectedItem = oEvent
            .getSource()
            .getModel()
            .getProperty(path[0]);
          const oLocalModel = this.getModel("newNotif");

          if (oSelectedItem.Code) {
            switch (oSelectedItem.Codct) {
              case "C":
                oLocalModel.setProperty(`/Fecod`, oSelectedItem.Code);
                oLocalModel.setProperty(`/Fecodtxt`, oSelectedItem.Kurztext);
                oLocalModel.setProperty(`/Fegrp`, oSelectedItem.Codgrr);
                break;
              case "5":
                oLocalModel.setProperty(`/Urcod`, oSelectedItem.Code);
                oLocalModel.setProperty(`/Urcodtxt`, oSelectedItem.Kurztext);
                oLocalModel.setProperty(`/Urgrp`, oSelectedItem.Codgrr);

                break;
              case "2":
                oLocalModel.setProperty(`/Mncod`, oSelectedItem.Code);
                oLocalModel.setProperty(`/Mncodtxt`, oSelectedItem.Kurztext);
                oLocalModel.setProperty(`/Mngrp`, oSelectedItem.Codgrr);

                break;
              case "A":
                oLocalModel.setProperty(`/Mfcod`, oSelectedItem.Code);
                oLocalModel.setProperty(`/Mfcodtxt`, oSelectedItem.Kurztext);
                oLocalModel.setProperty(`/Mfgrp`, oSelectedItem.Codgrr);
                break;
              case "B":
                oLocalModel.setProperty(`/Oteil`, oSelectedItem.Code);
                oLocalModel.setProperty(`/Oteiltxt`, oSelectedItem.Kurztext);
                oLocalModel.setProperty(`/Otgrp`, oSelectedItem.Codgrr);
                break;
              default:
                break;
            }
            this.notifTreeTableCancel();
          } else {
            sap.m.MessageBox.error(this.getText("InvalidEntry"));
          }
        },

        onClearInput: function (oEvent) {
          const type = oEvent.getSource().getId().slice(-5),
            oLocalModel = this.getView().getModel("newNotif");
          if (!oEvent.getParameter("value")) {
            oLocalModel.setProperty(`/${type}`, "");
            oLocalModel.setProperty(`/${type}txt`, "");
            if (type) oLocalModel.setProperty(`/${type.slice(0, 2)}grp`, "");
          }
        },
      }
    );
  }
);
