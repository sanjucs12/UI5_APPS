sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/model/service",
    "mobilework/util/GdlDoc",
  ],
  function (Controller, MBox, Service, GdlApi) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.settings.SettingsLoadConfig",
      {
        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.SettingsLoadConfig
         */
        onInit: function () {
          this.busyDialog = new sap.m.BusyDialog();

          this.getView().setModel(new sap.ui.model.json.JSONModel(), "qs");
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "viewSettings"
          );
          this.getRouter()
            .getRoute("settingsLoadConfig")
            .attachMatched(
              $.proxy(function (oEvent) {
                var oParams = oEvent.getParameter("arguments"),
                  bFromMaster = oParams.fromMaster,
                  oModel = this.getView().getModel("viewSettings");
                if (bFromMaster) {
                  oModel.setProperty("/fromMaster", true);
                } else {
                  oModel.setProperty("/fromMaster", false);
                }
              }, this),
              this
            );
        },

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//
        onRouteMatched: function () {
          //set connection property
          this.getConnection();
        },

        onUploadChange: function (oEvent) {
          var oFile = oEvent.getParameter("files")[0],
            oReader = new FileReader();

          oReader.onload = jQuery.proxy(this.onFileRead, this);
          oReader.readAsText(oFile, "UTF-8");

          oEvent.getSource().setValue("");
        },

        onFileRead: function (oData) {
          var sErrorMsg = "",
            oJSON = null;

          if (oData.target.result && typeof oData.target.result === "string") {
            try {
              oJSON = JSON.parse(oData.target.result);
              // this._saveSapSettings(oJSON);

              this._save(oJSON);
            } catch (e) {
              sErrorMsg = this.getText("LoadConfigError");
            }
          } else {
            sErrorMsg = this.getText("LoadConfigError");
          }

          if (sErrorMsg) {
            MBox.error(sErrorMsg);
          }
        },

        onQrScanPress: function () {
          $.when(this.getScanHandler().scan())
            .done(
              jQuery.proxy(function (oData) {
                alert("Functionality not allowed in public release");
                return;

                this._save(JSON.parse(oData.text));

                //this._saveSapSettings(JSON.parse(oData.text));
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("LoadConfigError"));
              }, this)
            );
        },

        onManualEntryPress: function () {
          this.getDialogManager().open(
            "settings.QuickEntrySettings",
            this.getView()
          );
        },

        onQuickSettingsSave: function () {
          this.getView().getModel("qs").setProperty("/rfidMand", false);
          this.getView().getModel("qs").setProperty("/enableLogin", false);
          this.getView()
            .getModel("qs")
            .setProperty("/enableOrderConfCreation", false);
          this.getView()
            .getModel("qs")
            .setProperty("/enableDownloadBoms", false);
          this.getView().getModel("qs").setProperty("/persNoNotRequired", true);
          this.getView().getModel("qs").setProperty("/notifFields", {
            Text: true,
            Craft: true,
            Fecod: true,
            Fetxt: true,
            Urcod: true,
            Urtxt: true,
            Mfcod: true,
            Mftxt: true,
            Mncod: true,
            Matxt: true,
            Msaus: true,
            AusvnDatetime: true,
            AusbsDatetime: true,
            Ingrp: true,
            Qmnam: true,
          });
          this.getView().getModel("qs").setProperty("/MAND_DAMAG", false);
          this.getView().getModel("qs").setProperty("/MAND_CAUSE", false);
          this.getView().getModel("qs").setProperty("/MAND_ACTIV", false);
          this.getView().getModel("qs").setProperty("/CONF_M_DMG", false);
          this.getView().getModel("qs").setProperty("/CONF_M_CSE", false);
          this.getView().getModel("qs").setProperty("/CONF_M_BRD", false);
          this.getView().getModel("qs").setProperty("/IWERK", "");
          this.getView().getModel("qs").setProperty("/SWERK", "");
          this.getView().getModel("qs").setProperty("/INGRP", "");
          this.getView().getModel("qs").setProperty("/ARBPL", "");
          this.getView().getModel("qs").setProperty("/PERNR", "");

          var oValidation = this.getValidator().validateQuickSettings(
            this.getView().getModel("qs").getProperty("/")
          );

          if (oValidation.isValid) {
            this._save(this.getView().getModel("qs").getProperty("/"));
            //this._saveSapSettings(this.getView().getModel("qs").getProperty("/"));
          } else {
            var sFields = "";
            for (var x in oValidation.aFields) {
              if (parseInt(x) === oValidation.aFields.length - 1) {
                sFields += this.getText(oValidation.aFields[x]);
              } else {
                sFields += this.getText(oValidation.aFields[x]) + ", ";
              }
            }
            MBox.error(this.getText("SettingsIncomplete", sFields));
          }
        },

        onQuickSettingsCancel: function () {
          this.getDialogManager().close(
            "settings.QuickEntrySettings",
            this.getView()
          );
        },

        onNavBack: function () {
          this.getRouter().navTo("settingsMaster");
        },

        onDeviceNameChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oQuickEntryModel = this.getView().getModel("qs");

          if (sValue) {
            oQuickEntryModel.setProperty("/deviceName", sValue.toUpperCase());
          }
        },
        onSystemIdChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oQuickEntryModel = this.getView().getModel("qs");

          if (sValue) {
            oQuickEntryModel.setProperty("/sapSysId", sValue.toUpperCase());
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _save: function (oData) {
          var oSharedModel = this.getView().getModel("shared");

          if (
            oSharedModel &&
            oSharedModel.getProperty("/sapSettings") &&
            oData.host !== oSharedModel.getProperty("/sapSettings/host")
          ) {
            $.when(this.getDBService().dropAllTables()).done(
              jQuery.proxy(function () {
                this._saveSapSettings(oData);
              }, this)
            );
          } else {
            this._saveSapSettings(oData);
          }
        },

        _saveSapSettings: function (oData) {
          var oPromDelSettings =
              this.getDBService().deleteAllObjects("Setting"),
            oSharedModel = this.getView().getModel("shared"),
            oSettings = oData,
            sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
            sUrl = oData.host + sUri;

          var fnCreateModel = jQuery.proxy(function () {
            $.when(
              this.getService().createModelWithUser(
                oSettings.sapUser,
                oSettings.sapPass
              )
            ).done(
              jQuery.proxy(function () {
                this.getDBService()._createTablesFromMetadata();
                this.getDBService()._saveMetadataToSettings();
              }, this)
            );
          }, this);

          for (var sField in oSettings) {
            if (
              typeof oSettings[sField] === "string" &&
              sField !== "sapPass" &&
              sField !== "host" &&
              sField !== "gdlApi"
            ) {
              oSettings[sField] = oSettings[sField].toUpperCase();
            }
          }
          if (oSettings.notifFields) {
            if (oSettings.notifFields.Ingrp) {
              delete oSettings.notifFields.Ingrp;
            }

            if (oSettings.notifFields.Qmnam) {
              delete oSettings.notifFields.Qmnam;
            }

            if (oSettings.notifFields.Arbpl) {
              delete oSettings.notifFields.Arbpl;
            }
          }
          if (!oSettings.sapUser) {
            oSettings.sapUser = "";
          }

          if (!oSettings.sapPass) {
            oSettings.sapPass = "";
          }

          if (this._checkConfigRequiredFields(oData) === true) {
            $.when(oPromDelSettings)
              .done(
                jQuery.proxy(function () {
                  $.when(this.getDBService().saveSAPSettings(oSettings))
                    .done(
                      jQuery.proxy(function () {
                        if (this.getDialogManager()) {
                          this.getDialogManager().close(
                            "settings.QuickEntrySettings",
                            this.getView()
                          );
                        }

                        if (
                          oSettings.sapUser === undefined &&
                          oSettings.sapPass === undefined
                        ) {
                          
                          oSettings.sapUser = oSharedModel.getProperty(
                            "/sapSettings/sapUser"
                          );
                          oSettings.sapPass = oSharedModel.getProperty(
                            "/sapSettings/sapPass"
                          );
                        }
                        oSharedModel.setProperty("/sapSettings", oSettings);

                        if (oSettings.langu) {
                          sap.ui
                            .getCore()
                            .getConfiguration()
                            .setLanguage(oSettings.langu.toLowerCase());
                        }

                        MBox.success(this.getText("QSettingSuccess"), {
                          onClose: function () {
                            this.getRouter().navTo("reload", {}, true);
                          }.bind(this),
                        });
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function () {
                        if (this.getDialogManager()) {
                          this.getDialogManager().close(
                            "settings.QuickEntrySettings",
                            this.getView()
                          );
                        }
                        MBox.error(this.getText("LoadConfigError"));
                      }, this)
                    );
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  MBox.error(this.getText("LoadConfigError"));
                }, this)
              );
          } else {
            MBox.error(this._requiredFields);
          }
        },

        refreshValueHelp: function () {
          var oModel = null,
            oShared = this.getModel("shared"),
            oSettings = oShared.getProperty("/sapSettings"),
            sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
            sUrl = oSettings.host + sUri,
            sUrlToBeUsed = "";

          var oPromVH = this.getService().getValueHelpData(),
            oPromCatalog = this.getService().getCatalogSet(),
            oPromSettings = this.getService().getSettingSet();

          if (oSettings.langu) {
            sap.ui
              .getCore()
              .getConfiguration()
              .setLanguage(oSettings.langu.toLowerCase());
          }

          if (this.getHelper().isDevModeActive()) {
            sUrlToBeUsed = sUri;
          } else {
            sUrlToBeUsed = sUrl;
          }

          if (oSettings.sapClient && oSettings.sapClient !== "undefined") {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + oSettings.sapClient;
          }

          oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
            user: oSettings.sapUser,
            password: oSettings.sapPass,
          });

          //  // publicRelease version needed ??

          oModel.attachRequestFailed(function (oEvent) {
            console.debug("REQUEST FAILED");
            console.debug(oEvent);
          });

          this.getOwnerComponent().service = new Service(
            oModel,
            oSettings.host,
            sUrlToBeUsed,
            oSettings.deviceName,
            oSettings.sapClient,
            oSettings.sapUser,
            oSettings.sapPass,
            sUri,
            oSettings.langu,
            null,
            null,
            null,
            this.getOwnerComponent()
          );
          this.getOwnerComponent().gdlApi = new GdlApi(
            oSettings.sapSysId,
            oSettings.sapClient,
            oSettings.gdlApi,
            "BUS2007",
            oSettings.sapUser
          );
          this.getOwnerComponent().setModel(
            this.getService().getModel(),
            "odata"
          );

          if (oSettings.fromJSON) {
            delete oSettings.fromJSON;
            this.getDBService().saveSAPSettings(oSettings);
          }

          if (
            oSettings.sapUser === undefined &&
            oSettings.sapPass === undefined
          ) {
            
            oSettings.sapUser = oShared.getProperty("/sapSettings/sapUser");
            oSettings.sapPass = oShared.getProperty("/sapSettings/sapPass");
          }
          oShared.setProperty("/sapSettings", oSettings);

          $.when(oPromVH, oPromCatalog, oPromSettings).done(
            jQuery.proxy(
              this.getOwnerComponent()._onValueHelpRetreived,
              this.getOwnerComponent()
            )
          );
        },

        _saveMetadata: function () {
          var oSettings = this.getSharedModel().getProperty("/");

          if (this.getDBService().getMetaObject()) {
            oSettings.sapSettings.metadata = this.getDBService().getMetaObject();
          } else {
            this.getDBService().setMetaObject(
              this.getService()._oModel.oMetadata.oMetadata );
            oSettings.sapSettings.metadata = this.getDBService().getMetaObject();
          }
          //this.getService()._oModel.oMetadata.oMetadata;

          this.getDBService()._saveMetadataToSettings();
        },

        _updateSettingsInDb: function (oSettings) {
          var aSettingsArrary = [],
            oSharedModel = this.getSharedModel(),
            oSettingData = oSettings;

          for (var sProp in oSettings) {
            if (oSettings.hasOwnProperty(sProp)) {
              aSettingsArrary.push({
                SKey: sProp,
                SValue: oSettings[sProp],
              });
            }
          }

          $.when(this.getDBService().updateSAPSettings(aSettingsArrary)).done(
            jQuery.proxy(function () {
              for (var sProp1 in oSettingData) {
                if (oSettingData.hasOwnProperty(sProp1)) {
                  oSharedModel.setProperty(
                    "/sapSettings/" + sProp1,
                    oSettingData[sProp1]
                  );
                }
              }
            }, this)
          );
        },

        _checkConfigRequiredFields: function (oConfig) {
          var bConfComplete = true,
            sFieldString = "";

          // if (!oConfig.host || !oConfig.gdlApi || !oConfig.deviceName || !oConfig.sapClient || !oConfig.sapUser || !oConfig.sapPass || !oConfig.langu) {
          // 	bConfComplete = false;
          // }

          for (var sProp in oConfig) {
            if (
              sProp === "host" ||
              sProp === "gdlApi" ||
              sProp === "deviceName" ||
              sProp === "sapClient" ||
              sProp === "langu"
            ) {
              if (!oConfig[sProp]) {
                bConfComplete = false;
                if (sFieldString === "") {
                  sFieldString += sProp;
                } else {
                  sFieldString += ", " + sProp;
                }
              }
            }
          }

          this._requiredFields = this.getText("ConfigIncomplete", sFieldString);

          return bConfComplete;
        },

        _checkMetadata: function (oModel) {
          var d = $.Deferred();

          oModel.attachMetadataLoaded(
            jQuery.proxy(function (oEvent) {
              
              let oSharedModel = this.getSharedModel();
              oSharedModel.setProperty("/metaFailed", false);
              d.resolve(oEvent.getSource().oMetadata.oMetadata);
            }, this)
          );

          oModel.attachMetadataFailed(
            jQuery.proxy(function (oEvent) {
              
              let oSharedModel = this.getSharedModel();
              oSharedModel.setProperty("/metaFailed", true);
              d.reject();
            }, this)
          );

          return d.promise();
        },
      }
    );
  }
);
