sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "mobilework/model/service",
  ],
  function (Controller, MToast, MBox, Service) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.settings.SettingsTechnicalSettings",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onInit: function () {
          //this._initModels();
          this.getRouter()
            .getRoute("settingsTechnicalSettings")
            .attachMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function () {
          this.changeColorOfDeviceId();
        },

        onTestPingPress: function () {
          let oSharedModel = this.getModel("shared");
          let oHelper = this.getOwnerComponent().helper;
          //We don't have getService() if check without logging in. In that case testping is defined outside
         //But we can call Service.testPing() using this defining in this method
          $.when(Service.testPing(oSharedModel, oHelper))
            .done(
              jQuery.proxy(function (oData) {
                //	if(oData.includes("Server reached."))
                MBox.success(this.getText("ServerReached"));
                this.getLogs().addLog(
                  "Server Reached",
                  "INFO",
                  "SettingTechnicalSettings"
                );
              }, this)
            )
            .fail(
              jQuery.proxy(function (error) {
                if(error === 'UNKNOWN_BEARER'){
                  MBox.error(this.getText("LoginFirst"));
                }else{
                  MBox.error(this.getText("ServerFailed"));
                }
                let errorText = "Ping Failed Error:" + JSON.stringify(error);
                this.getLogs().addLog(
                  errorText,
                  "WARNING",
                  "SettingTechnicalSettings"
                );
                this.genericSetDeviceIdColor("Red");
                this.genericReplaceStyleClass(this.getView(), "Red");
                this.genericReplaceStyleClass(
                  this.getView().getParent().getParent(),
                  "Red"
                );
              }, this)
            );
        },

        onResetDeviceCertificate: async function () {
          console.debug("Reset device certificate");
          await this.getOwnerComponent().loginMethod.resetPincode();
        },

        onTestOdataSap: function () {
          this.getService().testServiceBrowser();
        },

        onNavBack: function () {
          this.getRouter().navTo("settingsMaster", true);
        },

        _connectionCheck: function (sUser, sPassword, oView, sCheckAction) {
          var d = $.Deferred();

          $.when(
            this.getService().connectionCheck(
              sUser,
              sPassword,
              this.getHelper().isDevModeActive()
            )
          )
            .done(
              jQuery.proxy(function (oData) {
                if (oData) {
                  if (oData.ConnectionCheck) {
                    var sMessageType = oData.ConnectionCheck.Type,
                      sMessage = this.getText("LoginSuccessful");
                    if (sMessageType === "S") {
                      if (sCheckAction === "Y") {
                        MBox.success(sMessage);
                      }

                      this.genericSetDeviceIdColor("Green");
                      this.genericReplaceStyleClass(this.getView(), "Green");
                      this.genericReplaceStyleClass(
                        this.getView().getParent().getParent(),
                        "Green"
                      );

                      this.getLogs().addLog(
                        sMessage,
                        "INFO",
                        "SettingsUSERSettings"
                      );
                      $.when(this.getService().logoff()).done(
                        jQuery.proxy(function () {
                          this.getService().updateIndex();
                          this.getService().createModelWithUser(
                            sUser,
                            sPassword
                          );
                        }, this)
                      );
                      this.getView()
                        .getModel("shared")
                        .setProperty("/metaFailed", false);
                      oView.setBusy(false);
                    } else {
                      MBox.show(
                        sMessage + "\n" + this.getText("ConnectionCheckWarning")
                      );
                      this.getLogs().addLog(
                        sMessage +
                          "\n" +
                          this.getText("ConnectionCheckWarning"),
                        "WARNING",
                        "SettingsUSERSettings"
                      );
                      oView.setBusy(false);
                      this.changeColorOfDeviceIdToRed();
                    }
                  } else if (oData.offline) {
                    this.getLogs().addLog(
                      this.getText("NoNetwork"),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                    MBox.error(this.getText("NoNetwork"));
                    oView.setBusy(false);
                    this.changeColorOfDeviceIdToRed();
                    d.resolve();
                  } else {
                    if (
                      this.getSharedModel().getProperty(
                        "/connectionErrorCode"
                      ) === 401 &&
                      oData &&
                      oData.statusCode === 401
                    ) {
                      var oShared = this.getModel("shared"),
                        oSettings = oShared.getProperty("/sapSettings");
                      MBox.error(
                        this.getText("UserNotAuthorized", oSettings.sapSysId)
                      );
                      this.getLogs().addLog(
                        this.getText("UserNotAuthorized", oSettings.sapSysId),
                        "ERROR",
                        "SettingsUSERSettings"
                      );
                    } else {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                      this.getLogs().addLog(
                        this.getText("SAPSettingsIncorrect"),
                        "ERROR",
                        "SettingsUSERSettings"
                      );
                    }
                    this.changeColorOfDeviceIdToRed();
                    oView.setBusy(false);
                  }
                } else {
                  if (
                    this.getSharedModel().getProperty(
                      "/connectionErrorCode"
                    ) === 401 ||
                    (oData && oData.statusCode === 401)
                  ) {
                    var oShared = this.getModel("shared"),
                      oSettings = oShared.getProperty("/sapSettings");
                    MBox.error(
                      this.getText("UserNotAuthorized", oSettings.sapSysId)
                    );
                    this.getLogs().addLog(
                      this.getText("UserNotAuthorized", oSettings.sapSysId),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                  } else {
                    MBox.error(this.getText("SAPSettingsIncorrect"));
                    this.getLogs().addLog(
                      this.getText("SAPSettingsIncorrect"),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                  }
                  oView.setBusy(false);
                  this.changeColorOfDeviceIdToRed();
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this.changeColorOfDeviceIdToRed();
                oView.setBusy(false);
                MBox.error(this.getText("NoSAPSystemConnection"));
                d.reject(oError);
              }, this)
            );

          return d.promise();
        },

        onTestLoginFunction: function () {
          var oView = this.getView(),
            sUser = this.getSharedModel().getProperty("/sapSettings/sapUser"),
            sPassword = this.getSharedModel().getProperty(
              "/sapSettings/sapPass"
            );
          if (!sUser || !sPassword) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }
          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          oView.setBusy(true);
          if (sUser) {
            if (this.getService() && !this.getHelper().isDevModeActive()) {
              if (this.getService().getModel().oMetadata.bLoaded === true) {
                $.when(this._connectionCheck(sUser, sPassword, oView, "Y"))
                  .done(jQuery.proxy(function () {}, this))
                  .fail(
                    jQuery.proxy(function (oError) {
                      if (oError.statusCode === 401) {
                        var oShared = this.getModel("shared"),
                          oSettings = oShared.getProperty("/sapSettings");
                        MBox.error(
                          this.getText("UserNotAuthorized", oSettings.sapSysId)
                        );
                      } else if (oError.statusCode === 0) {
                        MBox.error(this.getText("SAPSettingsIncorrect"));
                      } else {
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                      }
                      this.getLogs().addLog(
                        "onConnectionCheckPress Fail",
                        "Errror",
                        "Synchronize"
                      );
                    }, this)
                  );
              } else {
                MBox.error(
                  this.getText("ConnectionUnknown") +
                    "\n" +
                    this.getText("NoConnectionToSap")
                );
                oView.setBusy(false);
              }
            } else {
              $.when(this.getService().createModelWithUser(sUser, sPassword))
                .done(
                  jQuery.proxy(function () {
                    this._connectionCheck(sUser, sPassword, oView, "Y");
                    oView.setBusy(false);
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    MBox.error(
                      this.getText("ConnectionUnknown") +
                        "\n" +
                        this.getText("NoConnectionToSap")
                    );
                    oView.setBusy(false);
                  }, this)
                );
            }
          } else {
            MBox.error(this.getText("ProvideUserCT"));
            oView.setBusy(false);
          }
        },

        changeColorOfDeviceIdToRed: function () {
          this.genericSetDeviceIdColor("Red");
          this.genericReplaceStyleClass(this.getView(), "Red");
          this.genericReplaceStyleClass(
            this.getView().getParent().getParent(),
            "Red"
          );
        },
      }
    );
  }
);
