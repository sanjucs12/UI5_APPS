/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "mobilework/libs/lodash",
    "mobilework/model/service",
    "mobilework/util/GdlDoc",
  ],
  function (Controller, MToast, MBox, Lo, Service, GdlApi) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.settings.SettingsUserSettings",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onInit: function () {
          this.busyDialog = new sap.m.BusyDialog();
          this._initModels();
          this.getRouter()
            .getRoute("settingsUserSettings")
            .attachMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onNavBack: function () {
          this.getRouter().navTo("settingsMaster", true);
        },

        onRouteMatched: function (oEvent) {
          this.getScanHandler().setLocation("usersettings");
          //set connection property
          this.getConnection();
          $.when(this.getDBService().getSAPSettings()).done(
            jQuery.proxy(this.onUserSettingsRetreived, this)
          );
          this.changeColorOfDeviceId();
        },

        onUserSettingsRetreived: function (oData) {
          var oSharedModel = this.getView().getModel("shared"),
            oUSettingModel = this.getView().getModel("uSetting");

          // if (oData.sapUser === undefined && oData.sapPass === undefined) {
          
          oData.sapUser = oSharedModel.getProperty("/sapSettings/sapUser");
          oData.sapPass = oSharedModel.getProperty("/sapSettings/sapPass");
          // }
          // oSharedModel.setProperty("/sapSettings/sapUser", oData.sapUser);
          // oSharedModel.setProperty("/sapSettings/sapPass", oData.sapPass);

          

          oUSettingModel.setProperty("/sapUser", oData.sapUser);
          oUSettingModel.setProperty("/sapPass", oData.sapPass);
          oUSettingModel.setProperty(
            "/langu",
            oData.langu ? oData.langu.toUpperCase() : "EN"
          );
          oUSettingModel.setProperty("/SWERK", oData.SWERK);
          oUSettingModel.setProperty("/IWERK", oData.IWERK);
          oUSettingModel.setProperty("/INGRP", oData.INGRP);
          oUSettingModel.setProperty("/ARBPL", oData.ARBPL);
          oUSettingModel.setProperty("/ISTWERK", oData.ISTWERK);
          oUSettingModel.setProperty(
            "/Shiftindicator",
            oData.SHIFTINDIC ? true : false
          );
          oUSettingModel.setProperty("/policy", oData.policy);
          oUSettingModel.setProperty("/GEWRK", oData.GEWRK);
          oUSettingModel.setProperty("/REP_BY_WC", oData.REP_BY_WC);

          if (this.getService())
            // && !this.getHelper().isDevModeActive()) {
            this.getService().logoff();
        },

        onShowPassPress: function () {
          var oModel = this.getView().getModel("uSetting"),
            sCurrSetting = oModel.getProperty("/passFieldType");

          if (sCurrSetting === "Password") {
            oModel.setProperty("/passFieldType", "Text");
          } else {
            oModel.setProperty("/passFieldType", "Password");
          }
        },

        _onSavePress: function () {
          var uSetting = this.getView().getModel("uSetting").getProperty("/");
          $.when(
            this._connectionCheck(
              uSetting.sapUser,
              uSetting.sapPass,
              this.getView()
            )
          )
            .done(
              jQuery.proxy(function (oInfo) {
                if (oInfo === "NO_CONNECTION") {
                  console.debug(oInfo);

                  let sPart1 = this.getText("NoCredentialsFound");
                  let sPart2 = this.getText("LoginFirst");
                  MBox.error(sPart1 + ",\n" + sPart2);
                  return;
                }
                this.onSavePress();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                if (oError.statusCode === 401) {
                  var oShared = this.getModel("shared"),
                    oSettings = oShared.getProperty("/sapSettings");
                  MBox.error(
                    this.getText("UserNotAuthorized", oSettings.sapSysId)
                  );
                } else if (oError.statusCode === 0) {
                  MBox.error(this.getText("NoPing"));
                  // MBox.error(this.getText("SAPSettingsIncorrect"));
                } else {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                }
              }, this)
            );
        },

        onSavePress: function () {
          var oSharedModel = this.getView().getModel("shared"),
            oUSettingModel = this.getView().getModel("uSetting"),
            sViewUser = oUSettingModel.getProperty("/sapUser"),
            sViewPass = oUSettingModel.getProperty("/sapPass"),
            sViewLangu = oUSettingModel.getProperty("/langu"),
            sSharedUser = oSharedModel.getProperty("/sapSettings/sapUser"),
            sSharedPass = oSharedModel.getProperty("/sapSettings/sapPass"),
            sSharedLangu = oSharedModel.getProperty("/sapSettings/langu"),
            bConfigFailed = oSharedModel.getProperty("/configFailed");
          if (!sViewUser || !sViewPass) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }
          var fnCreateModel = jQuery.proxy(function () {
            $.when(this.getService().createModelWithUser(sViewUser, sViewPass))
              .done(
                jQuery.proxy(async function () {
                  this.getView()
                    .getModel("shared")
                    .setProperty("/metaFailed", false);
                  this.getDBService()._createTablesFromMetadata();
                  await this._updateSettingsInDb();
                  this.getDBService()._saveMetadataToSettings();

                  var uri = this.getManifestEntry(
                    "/sap.app/dataSources/configserver"
                  ).uri;
                  var oShared = this.getModel("shared"),
                    oSettings = oShared.getProperty("/sapSettings");
                  $.when(
                    this.getService().createConfigurationModel(uri, oSettings)
                  ).done(
                    jQuery.proxy(function (oResult) {
                      $.when(
                        this.getService().getValueHelpSet(),
                        this.getDBService().deleteAllObjects("ValueHelpSet")
                      ).done(
                        jQuery.proxy(function (oValueHelp) {
                          this.getDBService().initValueHelpSet(oValueHelp);
                          this.getLogs().addLog(
                            "Setting Save Success",
                            "INFO",
                            "Synchronize"
                          );
                        }, this)
                      );
                    }, this)
                  );
                  $.when(this.getDBService().getPermanentData(false)).done(
                    jQuery.proxy(function () {
                      // get new value help from backend
                      this.refreshValueHelp();
                      // set data into shared model for binding purposes
                      this.onDataDownloadSuccess();
                      this.busyDialog.close();
                    }, this)
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  this.getLogs().addLog(
                    "Setting Save FAILED",
                    "ERROR",
                    "Synchronize"
                  );
                  if (oError.getParameters().statusCode === 401) {
                    // MBox.error(this.getText("UserNotAuthorized"));
                  } else if (oError.getParameters().statusCode === 0) {
                    this.getSharedModel().setProperty(
                      "/connectionErrorCode",
                      oError.getParameters().statusCode
                    );
                    // MBox.error(this.getText("SAPSettingsIncorrect"));
                  } else {
                    this.getSharedModel().setProperty(
                      "/connectionErrorCode",
                      ""
                    );
                    // MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
                  }

                  this.getView()
                    .getModel("shared")
                    .setProperty("/metaFailed", true);
                }, this)
              );
          }, this);

          if (
            (sViewUser !== sSharedUser ||
              sViewPass !== sSharedPass ||
              sViewLangu !== sSharedLangu) &&
            !bConfigFailed
          ) {
            oSharedModel.setProperty("/sapSettings/langu", sViewLangu);

            if (this.getService()) {
              // this.getService().updateLanguage(sViewLangu.toLowerCase());
              oSharedModel.setProperty(
                "/sapSettings/langu",
                sViewLangu.toLowerCase()
              );
            }

            sap.ui
              .getCore()
              .getConfiguration()
              .setLanguage(sViewLangu.toLowerCase());

            if (
              !this.getService() &&
              sViewUser !== undefined &&
              sViewPass !== undefined
            ) {
              
              oSharedModel.setProperty("/sapSettings/sapUser", sViewUser);
              oSharedModel.setProperty("/sapSettings/sapPass", sViewPass);

              this.getOwnerComponent()._onUserDataLoaded(
                oSharedModel.getProperty("/sapSettings")
              );
            }

            // this.getService().updateLanguage(sViewLangu);
            oSharedModel.setProperty("/sapSettings/langu", sViewLangu);

            if (
              this.getHelper().isDevModeActive() &&
              sViewUser !== undefined &&
              sViewPass !== undefined
            ) {
               fnCreateModel();
              //this.getService().createModelWithUser(sViewUser, sViewPass);
              
              oSharedModel.setProperty("/sapSettings/sapUser", sViewUser);
              oSharedModel.setProperty("/sapSettings/sapPass", sViewPass);
            }else if (sViewUser !== undefined && sViewPass !== undefined) {
              $.when(this.getService().logoff()).done(
                jQuery.proxy(function () {
                  fnCreateModel();
                  //this.getService().createModelWithUser(sViewUser, sViewPass);
                  
                  oSharedModel.setProperty("/sapSettings/sapUser", sViewUser);
                  oSharedModel.setProperty("/sapSettings/sapPass", sViewPass);
                }, this)
              );
            }

           

           
            // var oPromDeleteTechObj = this.getDBService().deleteAllObjects("TechnicalObject"),
            // 	oPromDeleteFuncLocCraft = this.getDBService().deleteAllObjects("FuncLocCraft");

            // $.when(oPromDeleteTechObj, oPromDeleteFuncLocCraft).done(jQuery.proxy(function () {

            // }, this));
          } else {
            this._updateSettingsInDb();
          }

          if (sViewLangu !== sSharedLangu) {
            MBox.show(this.getText("BewareOfFlocLangu"));

            //this.busyDialog.open();
            this.getDBService().setService(this.getService());

            // $.when(this.getDBService().getPermanentData())
            // 	.done(jQuery.proxy(function () {

            // 		// get new value help from backend
            // 		this.refreshValueHelp();
            // 		// set data into shared model for binding purposes
            // 		this.onDataDownloadSuccess();

            // 		this.busyDialog.close();
            // 	}, this));
          }

          // this.getService().getModel().attachMetadataLoaded(jQuery.proxy(function () {
          // 	console.log("metadata loaded");
          // 	this.getView().getModel("shared").setProperty("/metaFailed", false);
          // 	this.getDBService()._createTablesFromMetadata();
          // }, this));
          /*this.getService().getModel().metadataLoaded().then(jQuery.proxy(function () {
				console.log("userSettings: metadata loaded");
				this.getView().getModel("shared").setProperty("/metaFailed", false);
				this.getDBService()._createTablesFromMetadata();
			}, this));*/
        },

        onDataDownloadPress: function () {
          var sUser = this.getView()
              .getModel("uSetting")
              .getProperty("/sapUser"),
            sPassword = this.getView()
              .getModel("uSetting")
              .getProperty("/sapPass");
          if (!sUser || !sPassword) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }
          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          this.getService().getModel().refresh(true);

          this.getDBService().setService(this.getService());

          this.getView().getParent().getParent().setBusy(true);

          if (this.getService()) {
            if (this.getService().getModel().oMetadata.bLoaded === true) {
              $.when(this._checkConnection(sUser, sPassword))
                .done(
                  jQuery.proxy(function () {
                    $.when(this.getDBService().getPermanentData(true))
                      // .done(jQuery.proxy(this.onDataDownloadSuccess, this))
                      // .fail(jQuery.proxy(function (oError) {
                      // 	this.getLogs().addLog("Data Download Fail", "Errror", "Synchronize");
                      .done(
                        jQuery.proxy(function () {
                          this.onDataDownloadSuccess();
                          this.getView().getParent().getParent().setBusy(false);
                        }, this)
                      )
                      .fail(
                        jQuery.proxy(function (oError) {
                          this.getView().getParent().getParent().setBusy(false);
                          this.getLogs().addLog(
                            "Data Download Fail",
                            "Errror",
                            "Synchronize"
                          );
                        }, this)
                      );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    this.getLogs().addLog(
                      "ConnectionCheck Fail",
                      "Errror",
                      "Synchronize"
                    );
                    if (oError.statusCode === 401) {
                      var oShared = this.getModel("shared"),
                        oSettings = oShared.getProperty("/sapSettings");
                      MBox.error(
                        this.getText("UserNotAuthorized", oSettings.sapSysId)
                      );
                    } else if (oError.statusCode === 0) {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                    } else {
                      MBox.error(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap")
                      );
                    }
                    this.getView().getParent().getParent().setBusy(false);
                  }, this)
                );
            } else {
              MBox.error(
                this.getText("ConnectionUnknown") +
                  "\n" +
                  this.getText("NoConnectionToSap")
              );
              this.getView().setBusy(false);
              this.getView().getParent().getParent().setBusy(false);
            }
          } else {
            $.when(this.getDBService().getPermanentData(true))
              .done(
                jQuery.proxy(function () {
                  this.onDataDownloadSuccess();
                  this.getView().getParent().getParent().setBusy(false);
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  this.getView().getParent().getParent().setBusy(false);
                }, this)
              );
          }
        },

        onDataDownloadSuccess: function () {
          var oPromCatalog = this.getDBService().getEntitySet("Catalog"),
            oPromQmart = this.getDBService().getEntitySet(
              "PMNotificationQmartVH"
            ),
            oPromShift = this.getDBService().getEntitySet(
              "PMNotificationShiftVH"
            ),
            oPromLangu = this.getDBService().getEntitySet(
              "PMNotificationLanguVH"
            ),
            oPromUnWork = this.getDBService().getEntitySet(
              "ConfirmationsUnWorkVH"
            ),
            oPromCraft = this.getDBService().getEntitySet(
              "PMNotificationCraftVH"
            ),
            oPromSettings = this.getDBService().getSAPSettings(),
            oPromActType = this.getDBService().getEntitySet(
              "ConfirmationsPMActTypeVH"
            ),
            oPromPmenvr = this.getDBService().getEntitySet(
              "PMNotificationPmenvrVH"
            ),
            oPromPmqual = this.getDBService().getEntitySet(
              "PMNotificationPmqualVH"
            ),
            oPromPmsafe = this.getDBService().getEntitySet(
              "PMNotificationPmsafeVH"
            ),
            oPromQuotCoR = this.getDBService().getEntitySet(
              "PMNotificationQuotCoRVH"
            ),
            oPromQuotDeR = this.getDBService().getEntitySet(
              "PMNotificationQuotDeRVH"
            ),
            oPromQuotPrR = this.getDBService().getEntitySet(
              "PMNotificationQuotPrRVH"
            ),
            oPromQuotWcR = this.getDBService().getEntitySet(
              "PMNotificationQuotWcRVH"
            ),
            oPromImpactOblCustomizing = this.getDBService().getEntitySet(
              "ImpactOblCustomizing"
            ),
            oPromNotifcationType = this.getHelper().getNotificationTypes();

          $.when(
            oPromQmart,
            oPromCatalog,
            oPromShift,
            oPromLangu,
            oPromUnWork,
            oPromCraft,
            oPromSettings,
            oPromActType,
            oPromPmenvr,
            oPromPmqual,
            oPromPmsafe,
            oPromQuotCoR,
            oPromQuotDeR,
            oPromQuotPrR,
            oPromQuotWcR,
            oPromImpactOblCustomizing,
            oPromNotifcationType
          ).done(
            jQuery.proxy(function (
              _oQmartData,
              _oCatalogData,
              _oShiftData,
              _oLanguData,
              _oUnWorkData,
              _oCraftData,
              _oSettingData,
              _oActyTpeData,
              _oPmenvrData,
              _oPmqualData,
              _oPmsafeData,
              _oQuotCoRData,
              _oQuotDeRData,
              _oQuotPrRData,
              _oQuotWcRData,
              _oImpactOblData,
              oNotifcationType
            ) {
              var oSharedModel = this.getView().getModel("shared"),
                oUSettingModel = this.getView().getModel("uSetting"),
                aQmart = [],
                aCatalog = [],
                aShift = [],
                aLangu = [],
                aCraft = [],
                aUnWork = [],
                aActType = [],
                aPmqual = [],
                aPmsafe = [],
                aQuotCoR = [],
                aQuotDeR = [],
                aQuotPrR = [],
                aQuotWcR = [],
                aPmenvr = [],
                aImpactObl = [];

              // for (var i = 0; i < _oQmartData.rows.length; i++) {
              // 	aQmart.push(_oQmartData.rows.item(i));
              // }

              for (var j = 0; j < _oCatalogData.rows.length; j++) {
                aCatalog.push(_oCatalogData.rows.item(j));
              }

              for (var k = 0; k < _oShiftData.rows.length; k++) {
                aShift.push(_oShiftData.rows.item(k));
              }

              for (var l = 0; l < _oLanguData.rows.length; l++) {
                aLangu.push(_oLanguData.rows.item(l));
              }

              for (var m = 0; m < _oUnWorkData.rows.length; m++) {
                aUnWork.push(_oUnWorkData.rows.item(m));
              }

              for (var n = 0; n < _oCraftData.rows.length; n++) {
                aCraft.push(_oCraftData.rows.item(n));
              }

              for (var o = 0; o < _oActyTpeData.rows.length; o++) {
                aActType.push(_oActyTpeData.rows.item(o));
              }

              for (var o = 0; o < _oPmenvrData.rows.length; o++) {
                aPmenvr.push(_oPmenvrData.rows.item(o));
              }
              for (var o = 0; o < _oPmqualData.rows.length; o++) {
                aPmqual.push(_oPmqualData.rows.item(o));
              }
              for (var o = 0; o < _oPmsafeData.rows.length; o++) {
                aPmsafe.push(_oPmsafeData.rows.item(o));
              }
              for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
                aQuotCoR.push(_oQuotCoRData.rows.item(o));
              }
              for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
                aQuotDeR.push(_oQuotDeRData.rows.item(o));
              }
              for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
                aQuotPrR.push(_oQuotPrRData.rows.item(o));
              }
              for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
                aQuotWcR.push(_oQuotWcRData.rows.item(o));
              }
              for (var o = 0; o < _oImpactOblData.rows.length; o++) {
                aImpactObl.push(_oImpactOblData.rows.item(o));
              }

              // Issue no. 110 in V13.0
              aPmenvr.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aPmqual.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aPmsafe.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aQuotCoR.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aQuotDeR.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aQuotPrR.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aQuotWcR.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });
              aImpactObl.sort((a, b) => {
                return a.VhKey - b.VhKey;
              });

              oSharedModel.setProperty("/vh", {});
              oSharedModel.setProperty("/vh/Qmart", oNotifcationType.Types);
              oSharedModel.setProperty("/vh/Catalog", aCatalog);
              oSharedModel.setProperty("/vh/Shift", aShift);
              oSharedModel.setProperty("/vh/Langu", aLangu);
              oSharedModel.setProperty("/vh/UnWork", aUnWork);
              oSharedModel.setProperty("/vh/Craft", aCraft),
                oSharedModel.setProperty("/vh/Pmenvr", aPmenvr);
              oSharedModel.setProperty("/vh/Pmqual", aPmqual);
              oSharedModel.setProperty("/vh/Pmsafe", aPmsafe);
              oSharedModel.setProperty("/vh/QuotCoR", aQuotCoR);
              oSharedModel.setProperty("/vh/QuotDeR", aQuotDeR);
              oSharedModel.setProperty("/vh/QuotPrR", aQuotPrR);
              oSharedModel.setProperty("/vh/QuotWcR", aQuotWcR);
              oSharedModel.setProperty("/vh/ImpactObl", aImpactObl);
              oSharedModel.setProperty(
                "/vh/headerLines",
                aCatalog.filter((aCat) => {
                  return aCat.Code === "";
                })
              );

              if (
                _oSettingData.sapUser === undefined &&
                _oSettingData.sapPass === undefined
              ) {
                
                _oSettingData.sapUser = oSharedModel.getProperty(
                  "/sapSettings/sapUser"
                );
                _oSettingData.sapPass = oSharedModel.getProperty(
                  "/sapSettings/sapPass"
                );
              }
              oSharedModel.setProperty("/sapSettings", _oSettingData);
              oSharedModel.setProperty("/vh/ActType", aActType);

              oUSettingModel.setProperty("/SWERK", _oSettingData.SWERK);
              oUSettingModel.setProperty("/IWERK", _oSettingData.IWERK);
              oUSettingModel.setProperty("/INGRP", _oSettingData.INGRP);
              oUSettingModel.setProperty("/ARBPL", _oSettingData.ARBPL);
              oUSettingModel.setProperty("/ISTWERK", _oSettingData.ISTWERK);
              oUSettingModel.setProperty("/langu", _oSettingData.langu);
              oUSettingModel.setProperty("/sapUser", _oSettingData.sapUser);
              oUSettingModel.setProperty("/sapPass", _oSettingData.sapPass);
              oUSettingModel.setProperty("/GEWRK", _oSettingData.GEWRK);
              oUSettingModel.setProperty("/REP_BY_WC", _oSettingData.REP_BY_WC);
              oUSettingModel.setProperty(
                "/Shiftindicator",
                _oSettingData.SHIFTINDIC ? true : false
              );

              MToast.show(this.getText("PermanentDataSuccess"));

              // $.when(this.getOwnerComponent().createParticipant(_oSettingData.sapUser)).done(jQuery.proxy(function () {
              // 	this._getParticipantsFromDb();
              // }, this)).fail(jQuery.proxy(function (oError) {
              // 	if (oError) {
              // 		if (oError.offline === true) {
              // 			// MBox.error(this.getText("NoNetwork"));
              // 			MBox.error(this.getText("NoNetwork"));
              // 			// this.getView().setBusy(false);
              // 		} else if (oError.connection === false) {
              // 			MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
              // 			// this.getView().setBusy(false);
              // 		}
              // 	}
              // }, this));
            },
            this)
          );
        },

        onConnectionCheckPress: function () {
          var oView = this.getView(),
            sUser = this.getView().getModel("uSetting").getProperty("/sapUser"),
            sPassword = this.getView()
              .getModel("uSetting")
              .getProperty("/sapPass");
          if (!sUser || !sPassword) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }
          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          oView.setBusy(true);
          if (sUser) {
            if (this.getService()) {
              // && !this.getHelper().isDevModeActive()) {
              if (this.getService().getModel().oMetadata.bLoaded === true) {
                $.when(this._connectionCheck(sUser, sPassword, oView, "Y"))
                  .done(jQuery.proxy(function () {}, this))
                  .fail(
                    jQuery.proxy(function (oError) {
                      if (oError.statusCode === 401) {
                        var oShared = this.getModel("shared"),
                          oSettings = oShared.getProperty("/sapSettings");
                        MBox.error(
                          this.getText("UserNotAuthorized", oSettings.sapSysId)
                        );
                      } else if (oError.statusCode === 0) {
                        MBox.error(this.getText("SAPSettingsIncorrect"));
                      } else {
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                      }
                    }, this)
                  );
              } else {
                if (this.getService().getModel().oMetadata.bLoaded === false) {
                  $.when(this._connectionCheck(sUser, sPassword, oView, "Y"))
                    .done(jQuery.proxy(function () {}, this))
                    .fail(
                      jQuery.proxy(function (oError) {
                        if (oError.statusCode === 401) {
                          var oShared = this.getModel("shared"),
                            oSettings = oShared.getProperty("/sapSettings");
                          MBox.error(
                            this.getText(
                              "UserNotAuthorized",
                              oSettings.sapSysId
                            )
                          );
                        } else if (oError.statusCode === 0) {
                          MBox.error(this.getText("SAPSettingsIncorrect"));
                        } else {
                          MBox.error(
                            this.getText("ConnectionUnknown") +
                              "\n" +
                              this.getText("NoConnectionToSap")
                          );
                        }
                        this.getLogs().addLog(
                          "onConnectionCheckPress Fail",
                          "Errror",
                          "Synchronize"
                        );
                      }, this)
                    );
                } else {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                  oView.setBusy(false);
                }
              }
            } else {
              $.when(this.getService().createModelWithUser(sUser, sPassword))
                .done(
                  jQuery.proxy(function () {
                    this._connectionCheck(sUser, sPassword, oView, "Y");
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    MBox.error(
                      this.getText("ConnectionUnknown") +
                        "\n" +
                        this.getText("NoConnectionToSap")
                    );
                    oView.setBusy(false);
                  }, this)
                );
            }
          } else {
            MBox.error(this.getText("ProvideUserCT"));
            oView.setBusy(false);
          }
        },

        onResetConnectionPress: function () {
          var oView = this.getView(),
            sUser = this.getView().getModel("uSetting").getProperty("/sapUser"),
            sPassword = this.getView()
              .getModel("uSetting")
              .getProperty("/sapPass");
          if (!sUser || !sPassword) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }
          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          oView.setBusy(true);

          $.when(this.getService().logoff())
            .done(
              jQuery.proxy(function () {
                $.when(this.getService().createModelWithUser(sUser, sPassword))
                  .done(
                    jQuery.proxy(function () {
                      this._connectionCheck(sUser, sPassword, oView);
                      oView.setBusy(false);
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function (oError) {
                      if (oError.getParameters().statusCode === 401) {
                        var oShared = this.getModel("shared"),
                          oSettings = oShared.getProperty("/sapSettings");
                        MBox.error(
                          this.getText("UserNotAuthorized", oSettings.sapSysId)
                        );
                      } else if (oError.getParameters().statusCode === 0) {
                        MBox.error(this.getText("SAPSettingsIncorrect"));
                      } else {
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                      }
                      oView.setBusy(false);
                      this.getLogs().addLog(
                        "onResetConnectionPress Fail - createModelWithUser",
                        "Errror",
                        "Synchronize"
                      );
                    }, this)
                  );
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                // 						$.when(this.getService().createModelWithUser(sUser, sPassword)).done(jQuery.proxy(function () {
                // 									this._connectionCheck(sUser, sPassword, oView);
                // 								}, this)).fail(jQuery.proxy(function (oError) {
                if (oError.status === 401) {
                  var oShared = this.getModel("shared"),
                    oSettings = oShared.getProperty("/sapSettings");
                  MBox.error(
                    this.getText("UserNotAuthorized", oSettings.sapSysId)
                  );
                } else if (oError.status === 0) {
                  MBox.error(this.getText("SAPSettingsIncorrect"));
                } else {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                }
                this.getLogs().addLog(
                  "onResetConnectionPress Fail - logoff",
                  "Errror",
                  "Synchronize"
                );
                oView.setBusy(false);
              }, this)
            );
        },

        onSapUserChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/sapUser", sValue.toUpperCase());
          }
        },

        onIngrpChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/INGRP", sValue.toUpperCase());
          }
        },
        onGewrkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/GEWRK", sValue.toUpperCase());
          }
        },

        onArbplChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/ARBPL", sValue.toUpperCase());
          }
        },

        onIwerkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/IWERK", sValue.toUpperCase());
          }
        },

        onSwerkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/SWERK", sValue.toUpperCase());
          }
        },
        onREP_BY_WCChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/REP_BY_WC", sValue.toUpperCase());
          }
        },
        onIstwerkChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("uSetting");

          if (sValue) {
            oSettingModel.setProperty("/ISTWERK", sValue.toUpperCase());
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {
          if (!this.getView().getModel("uSetting")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel({
                passFieldType: "Password",
              }),
              "uSetting"
            );
          }
        },

        _updateSettingsInDb: function () {
          var d = $.Deferred();
          var aSettingsArrary = [],
            oUSettingModel = this.getView().getModel("uSetting"),
            oSharedModel = this.getSharedModel(),
            oSettingData = oUSettingModel.getProperty("/");

          for (var sProp in oSettingData) {
            if (oSettingData.hasOwnProperty(sProp)) {
              aSettingsArrary.push({
                SKey: sProp,
                SValue: oSettingData[sProp],
              });
            }
          }

          $.when(this.getDBService().updateSAPSettings(aSettingsArrary)).done(
            jQuery.proxy(function () {
              MToast.show(this.getText("USettingUpdateSuccess"));
              this.getLogs().addLog(
                this.getText("USettingUpdateSuccess"),
                "INFO",
                "SettingsUSERSettings"
              );
              for (var sProp1 in oSettingData) {
                if (oSettingData.hasOwnProperty(sProp1)) {
                  oSharedModel.setProperty(
                    "/sapSettings/" + sProp1,
                    oSettingData[sProp1]
                  );
                }
              }
              d.resolve();
            }, this)
          );
          return d.promise();
        },

        refreshValueHelp: function () {
          var oModel = null,
            oShared = this.getModel("shared"),
            oSettings = oShared.getProperty("/sapSettings"),
            sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
            sUrl = oSettings.host + sUri,
            sUrlToBeUsed = "";

          var oPromVH = this.getService().getValueHelpData(),
            oPromCatalog = this.getService().getCatalogSet(),
            oPromSettings = this.getService().getSettingSet();

          if (oSettings.langu) {
            sap.ui
              .getCore()
              .getConfiguration()
              .setLanguage(oSettings.langu.toLowerCase());
          }

          if (this.getHelper().isDevModeActive()) {
            sUrlToBeUsed = sUri;
          } else {
            sUrlToBeUsed = sUrl;
          }

          if (oSettings.sapClient && oSettings.sapClient !== "undefined") {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + oSettings.sapClient;
          }

          //  // publicRelease version needed ??
          oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
            user: oSettings.sapUser,
            password: oSettings.sapPass,
          });

          oModel.attachRequestFailed(function (oEvent) {
            console.error("Request failed");
            console.error(oEvent);
          });

          this.getOwnerComponent().service = new Service(
            oModel,
            oSettings.host,
            sUrlToBeUsed,
            oSettings.deviceName,
            oSettings.sapClient,
            oSettings.sapUser,
            oSettings.sapPass,
            sUri,
            oSettings.langu,
            null,
            null,
            null,
            this.getOwnerComponent()
          );
          this.getOwnerComponent().gdlApi = new GdlApi(
            oSettings.sapSysId,
            oSettings.sapClient,
            oSettings.GDL_API_URL,
            "BUS2007",
            oSettings.sapUser,
            this
          );
          this.getOwnerComponent().setModel(
            this.getService().getModel(),
            "odata"
          );

          if (oSettings.fromJSON) {
            delete oSettings.fromJSON;
            this.getDBService().saveSAPSettings(oSettings);
          }

          if (
            oSettings.sapUser === undefined &&
            oSettings.sapPass === undefined
          ) {
            
            oSettings.sapUser = oShared.getProperty("/sapSettings/sapUser");
            oSettings.sapPass = oShared.getProperty("/sapSettings/sapPass");
          }
          oShared.setProperty("/sapSettings", oSettings);
          //$.when(oPromVH, oPromCatalog, oPromSettings).done(jQuery.proxy(this.getOwnerComponent()._onValueHelpRetreived()));
          $.when(oPromVH, oPromCatalog, oPromSettings).done(
            jQuery.proxy(
              this.getOwnerComponent()._onValueHelpRetreived,
              this.getOwnerComponent()
            )
          );
        },

        // _createParticipant: function (sSapUser) {
        // 	var aFilters = [];

        // 	aFilters.push(new sap.ui.model.Filter({
        // 		path: "Pernr",
        // 		operator: sap.ui.model.FilterOperator.EQ,connectionCheck
        // 		value1: sSapUser
        // 	}));

        // 	$.when(this.getService().getParticipantData(aFilters)).done(jQuery.proxy(function (oParticipantData) {
        // 		this.busyDialog.close();
        // 		this.getView().setBusy(false);
        // 		if (oParticipantData && oParticipantData.results && oParticipantData.results.length > 0) { // Valid pernr entered.

        // 			$.when(this.getDBService().updateParticipants("Participant", oParticipantData.results, this.getModel("local").getProperty(
        // 				"/ParticipantSet"))).done(jQuery.proxy(function (oData) {
        // 				this._getParticipantsFromDb();
        // 			}, this));
        // 		}
        // 	}, this)).fail(jQuery.proxy(function (oError) {
        // 		if (oError.offline === true) {
        // 			MBox.error(this.getText("NoNetwork"));
        // 			this.getView().setBusy(false);
        // 		} else if (oError.connection === false) {
        // 			MBox.error(this.getText("ConnectionUnknown"));
        // 			this.getView().setBusy(false);
        // 		}
        // 	}, this));
        // },

        _getParticipantsFromDb: function () {
          $.when(this.getDBService().getEntitySet("Participant"))
            .done(
              jQuery.proxy(function (oData) {
                var oLocalModel = this.getView().getModel("local"),
                  oSharedModel = this.getSharedModel(),
                  aLocalParticipantSet = [];

                if (!oLocalModel.getProperty("/ParticipantSet")) {
                  oLocalModel.setProperty("/ParticipantSet", []);
                }

                for (var x = 0; x < oData.rows.length; x++) {
                  aLocalParticipantSet.push(oData.rows.item(x));
                }

                if (aLocalParticipantSet.length > 0) {
                  oSharedModel.setProperty("/hasParticipants", true);
                } else {
                  oSharedModel.setProperty("/hasParticipants", false);
                }

                oLocalModel.setProperty(
                  "/ParticipantSet",
                  aLocalParticipantSet
                );
                oSharedModel.setProperty(
                  "/ParticipantSet",
                  aLocalParticipantSet
                );
              }, this)
            )
            .fail(jQuery.proxy(function (oError) {}, this));
        },

        _connectionCheck: function (sUser, sPassword, oView, sCheckAction) {
          var d = $.Deferred();

          if (this.getService() === null) {
            // User not yet logged in
            console.error("_connectionCheck : get service not available");
            return d.resolve("NO_CONNECTION");
          }

          $.when(
            this.getService().connectionCheck(
              sUser,
              sPassword,
              this.getHelper().isDevModeActive()
            )
          )
            .done(
              jQuery.proxy(function (oData) {
                console.debug("Result: ", oData);
                console.debug(this.getService());
                /*console.log(oData.ConnectionCheck);
					console.log(oData.message);
					console.log(JSON.stringify(oData.responseText));*/
                //var test = JSON.stringify(oData.responseText);

                if (oData) {
                  if (oData.ConnectionCheck) {
                    var sMessageType = oData.ConnectionCheck.Type,
                      sMessage = oData.ConnectionCheck.Message;

                    if (sMessageType === "S") {
                      if (sCheckAction === "Y") {
                        MBox.success(sMessage);
                      }

                      this.genericSetDeviceIdColor("Green");
                      this.genericReplaceStyleClass(this.getView(), "Green");

                      this.getLogs().addLog(
                        sMessage,
                        "INFO",
                        "SettingsUSERSettings"
                      );
                      $.when(this.getService().logoff()).done(
                        jQuery.proxy(function () {
                          this.getService().updateIndex();
                          this.getService().createModelWithUser(
                            sUser,
                            sPassword
                          );
                        }, this)
                      );
                      this.getView()
                        .getModel("shared")
                        .setProperty("/metaFailed", false);
                      var oPromSettingSer = this.getService().getSettingSet(),
                        oPromPartDb =
                          this.getDBService().getEntitySet("Participant");
                      $.when(oPromSettingSer, oPromPartDb)
                        .done(
                          jQuery.proxy(function (oSettings, oParticipants) {
                            var aPartic = [],
                              oPartic = null,
                              oPernr = null;
                            for (
                              var i = 0;
                              i < oParticipants.rows.length;
                              i++
                            ) {
                              aPartic.push(oParticipants.rows.item(i));
                            }
                            oPernr = _.find(oSettings.results, {
                              SKey: "PERNR",
                            });
                            if (oPernr && oPernr.SValue !== "00000000") {
                              oPartic = _.find(aPartic, {
                                Pernr: oPernr.SValue,
                              });

                              if (!oPartic) {
                                $.when(
                                  this.getDBService().insertObject(
                                    "Participant",
                                    {
                                      Arbpl: "",
                                      Pernr: oPernr.SValue,
                                    }
                                  )
                                )
                                  .done(function () {
                                    oView.setBusy(false);
                                  })
                                  .fail(function () {
                                    oView.setBusy(false);
                                  });
                              } else {
                                oView.setBusy(false);
                              }
                            } else {
                              oView.setBusy(false);
                            }

                            d.resolve();
                          }, this)
                        )
                        .fail(
                          jQuery.proxy(function (oError) {
                            d.resolve();
                            oView.setBusy(false);
                          }, this)
                        );
                    } else {
                      MBox.show(
                        sMessage + "\n" + this.getText("ConnectionCheckWarning")
                      );
                      this.getLogs().addLog(
                        sMessage +
                          "\n" +
                          this.getText("ConnectionCheckWarning"),
                        "WARNING",
                        "SettingsUSERSettings"
                      );
                      oView.setBusy(false);
                      $.when(this.getService().logoff()).done(
                        jQuery.proxy(function () {
                          this.getService().updateIndex();
                          this.getService().createModelWithUser(
                            sUser,
                            sPassword
                          );
                          d.resolve();
                        }, this)
                      );
                      this.changeColorOfDeviceIdToRed();
                    }
                  } else if (oData.offline) {
                    this.getLogs().addLog(
                      this.getText("NoNetwork"),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                    MBox.error(this.getText("NoNetwork"));
                    oView.setBusy(false);
                    this.changeColorOfDeviceIdToRed();
                    d.resolve();
                  } else {
                    if (
                      this.getSharedModel().getProperty(
                        "/connectionErrorCode"
                      ) === 401 &&
                      oData &&
                      oData.statusCode === 401
                    ) {
                      var oShared = this.getModel("shared"),
                        oSettings = oShared.getProperty("/sapSettings");
                      MBox.error(
                        this.getText("UserNotAuthorized", oSettings.sapSysId)
                      );
                      this.getLogs().addLog(
                        this.getText("UserNotAuthorized", oSettings.sapSysId),
                        "ERROR",
                        "SettingsUSERSettings"
                      );
                    } else if (
                      this.getSharedModel().getProperty(
                        "/connectionErrorCode"
                      ) === 0 &&
                      oData &&
                      oData.statusCode === 0
                    ) {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                      this.getLogs().addLog(
                        this.getText("SAPSettingsIncorrect"),
                        "ERROR",
                        "SettingsUSERSettings"
                      );
                    } else {
                      $.when(this.getService().logoff())
                        .done(
                          jQuery.proxy(function () {
                            this.getService().updateIndex();
                            $.when(
                              this.getService().createModelWithUser(
                                sUser,
                                sPassword
                              )
                            ).done(
                              jQuery.proxy(function () {
                                // WR --> disable recursive call :: this._connectionCheck(sUser, sPassword, oView);
                                oView.setBusy(false);
                              }, this)
                            );
                            d.resolve();
                          }, this)
                        )
                        .fail(
                          jQuery.proxy(function (oError) {
                            if (oError.status === 401) {
                              var oShared = this.getModel("shared"),
                                oSettings = oShared.getProperty("/sapSettings");
                              MBox.error(
                                this.getText(
                                  "UserNotAuthorized",
                                  oSettings.sapSysId
                                )
                              );
                              this.getLogs().addLog(
                                this.getText(
                                  "UserNotAuthorized",
                                  oSettings.sapSysId
                                ),
                                "ERROR",
                                "SettingsUSERSettings"
                              );
                            } else if (oError.status === 0) {
                              MBox.error(this.getText("SAPSettingsIncorrect"));
                              this.getLogs().addLog(
                                this.getText("SAPSettingsIncorrect"),
                                "ERROR",
                                "SettingsUSERSettings"
                              );
                            } else {
                              MBox.error(
                                this.getText("ConnectionUnknown") +
                                  "\n" +
                                  this.getText("NoConnectionToSap")
                              );
                              this.getLogs().addLog(
                                this.getText("ConnectionUnknown") +
                                  "\n" +
                                  this.getText("NoConnectionToSap"),
                                "ERROR",
                                "SettingsUSERSettings"
                              );
                            }
                          }, this)
                        );
                    }
                    this.changeColorOfDeviceIdToRed();

                    oView.setBusy(false);
                  }
                } else {
                  if (
                    this.getSharedModel().getProperty(
                      "/connectionErrorCode"
                    ) === 401 ||
                    (oData && oData.statusCode === 401)
                  ) {
                    var oShared = this.getModel("shared"),
                      oSettings = oShared.getProperty("/sapSettings");
                    MBox.error(
                      this.getText("UserNotAuthorized", oSettings.sapSysId)
                    );
                    this.getLogs().addLog(
                      this.getText("UserNotAuthorized", oSettings.sapSysId),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                  } else if (
                    this.getSharedModel().getProperty(
                      "/connectionErrorCode"
                    ) === 0 ||
                    (oData && oData.statusCode === 0)
                  ) {
                    MBox.error(this.getText("SAPSettingsIncorrect"));
                    this.getLogs().addLog(
                      this.getText("SAPSettingsIncorrect"),
                      "ERROR",
                      "SettingsUSERSettings"
                    );
                  } else {
                    $.when(this.getService().logoff()).done(
                      jQuery.proxy(function () {
                        this.getService().updateIndex();
                        $.when(
                          this.getService().createModelWithUser(
                            sUser,
                            sPassword
                          )
                        )
                          .done(
                            jQuery.proxy(function () {
                              // WR --> disable recursive call :: this._connectionCheck(sUser, sPassword, oView);
                              oView.setBusy(false);
                            }, this)
                          )
                          .fail(
                            jQuery.proxy(function (oError) {
                              if (oError.getParameters().statusCode === 401) {
                                var oShared = this.getModel("shared"),
                                  oSettings =
                                    oShared.getProperty("/sapSettings");
                                MBox.error(
                                  this.getText(
                                    "UserNotAuthorized",
                                    oSettings.sapSysId
                                  )
                                );
                                this.getLogs().addLog(
                                  this.getText(
                                    "UserNotAuthorized",
                                    oSettings.sapSysId
                                  ),
                                  "ERROR",
                                  "SettingsUSERSettings"
                                );
                              } else if (
                                oError.getParameters().statusCode === 0
                              ) {
                                MBox.error(
                                  this.getText("SAPSettingsIncorrect")
                                );
                                this.getLogs().addLog(
                                  this.getText("SAPSettingsIncorrect"),
                                  "ERROR",
                                  "SettingsUSERSettings"
                                );
                              } else {
                                MBox.error(
                                  this.getText("ConnectionUnknown") +
                                    "\n" +
                                    this.getText("NoConnectionToSap")
                                );
                                this.getLogs().addLog(
                                  this.getText("ConnectionUnknown") +
                                    "\n" +
                                    this.getText("NoConnectionToSap"),
                                  "ERROR",
                                  "SettingsUSERSettings"
                                );
                              }
                            }, this)
                          );
                        d.resolve();
                      }, this)
                    );
                  }
                  oView.setBusy(false);
                  this.changeColorOfDeviceIdToRed();
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                this.changeColorOfDeviceIdToRed();
                console.debug("Error: ", oError);
                oView.setBusy(false);
                d.reject(oError);
              }, this)
            );

          return d.promise();
        },

        // **************************************** //
        //				  ONBOARDING				//
        // **************************************** //

        onResetApplicationPress: function () {
          var oUSettingModel = this.getView().getModel("uSetting"),
            oSharedModel = this.getView().getModel("shared");

          var yesnodialog = sap.ui.controller(
            "mobilework.controller.dialogs.YesNoDialog"
          );

          yesnodialog.openYesNoDialog(
            this,
            this.getText("ConfirmResetApp"),
            this.getText("Confirm"),
            function () {
              var uri = this.getManifestEntry(
                "/sap.app/dataSources/configserver"
              ).uri;
              var oShared = this.getModel("shared"),
                oSettings = oShared.getProperty("/sapSettings");
              $.when(this.getService().createConfigurationModel(uri, oSettings))
                .done(
                  jQuery.proxy(function () {
                    $.when(
                      this.getService().unassignDevice(
                        oSharedModel.getProperty("/sapSettings/deviceName"),
                        oSharedModel.getProperty("/sapSettings/plant")
                      )
                    ).done(
                      jQuery.proxy(function () {
                        var oPromDelSettings =
                          this.getDBService().deleteAllObjects("Setting");
                        
                        $.when(oPromDelSettings)
                          .done(
                            $.proxy(function () {
                              //oHashChangerInstance.replaceHash("");

                              oSharedModel.setProperty("/configFailed", true);
                              oSharedModel.setProperty("/metaFailed", true);
                              oSharedModel.setProperty("/loggedInAsMsg", "");
                              oSharedModel.setProperty("/bUserIconVisible", false);
                              oSharedModel.setProperty("/sapSettings", {});
                              this.getRouter().navTo("reload", {}, true);
                            }, this)
                          )
                          .fail(
                            $.proxy(function () {
                              //oHashChangerInstance.replaceHash("");

                              oSharedModel.setProperty("/configFailed", true);
                              oSharedModel.setProperty("/metaFailed", true);
                              oSharedModel.setProperty("/loggedInAsMsg", "");
                              oSharedModel.setProperty("/bUserIconVisible", false);
                              oSharedModel.setProperty("/sapSettings", {});
                              this.getRouter().navTo("reload", {}, true);
                            }, this)
                          );
                      }, this)
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    if (oError.getParameters().statusCode === 401) {
                      //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                      MBox.error(
                        this.getText("UserNotAuthorized", oSettings.sapSysId)
                      );
                    } else if (oError.getParameters().statusCode === 0) {
                      //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                    } else {
                      //this.getSharedModel().setProperty("/connectionErrorCode", "");
                      MBox.error(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap")
                      );
                    }
                  }, this)
                );
            },
            function () {
              // nothing yet
            }
          );
        },

        _checkConnection: async function (sUser, sPassword) {
          // if (!this.getHelper().isDevModeActive()) {
          let oSharedModel = this.getView().getModel("shared");

          if (oSharedModel.getProperty("/publicRelease")) {
            await this.getService().logoff();

            this.getService().updateIndex();
            await this.getService().createModelWithUser(sUser, sPassword);
          } else {
            await this._connectionCheck(sUser, sPassword, this.getView());
          }
        },

        onSyncConfigServer: function () {
          let oSharedModel = this.getView().getModel("shared"),
            sAppVersion =
              this.getOwnerComponent().getManifestObject()._oManifest._version;
          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          var uri = this.getManifestEntry(
            "/sap.app/dataSources/configserver"
          ).uri;
          var oShared = this.getModel("shared"),
            oSettings = oShared.getProperty("/sapSettings");
          var sUser = this.getView()
              .getModel("uSetting")
              .getProperty("/sapUser"),
            sPassword = this.getView()
              .getModel("uSetting")
              .getProperty("/sapPass");
          if (!sUser || !sPassword) {
            MBox.error(this.getText("SettingsMissing"));
            return;
          }

          this.getView().getParent().getParent().setBusy(true);
          $.when(this._checkConnection(sUser, sPassword))
            .done(
              jQuery.proxy(function () {
                $.when(
                  this.getService().createConfigurationModel(uri, oSettings)
                )
                  .done(
                    jQuery.proxy(function (oResult) {
                      $.when(
                        this.getService().getDeviceSettings(
                          oSharedModel.getProperty("/sapSettings/deviceName"),
                          oSharedModel.getProperty("/sapSettings/plant")
                        ),
                        this.getService().getValueHelpSet(),
                        this.getService().setVersion(
                          oSharedModel.getProperty("/sapSettings/deviceName"),
                          oSharedModel.getProperty("/sapSettings/plant"),
                          sAppVersion
                        )
                      ).done(
                        jQuery.proxy(function (oResult, oValueHelp) {
                          
                          var notifFields = {};
                          this._aDeviceSettings =
                            oResult.navDeviceSettings.results;
                            // var oComponent = this.getOwnerComponent();
                            // var mainController = oComponent.getRouter().getViews().getView("mobilework.controller.Main").getController();
                            // if (!this._aDeviceSettings.find (settingActive => settingActive.Fieldname === "POActive")){
                            //   let MainPageGrid = mainController.byId("MainPageGrid"),
                            //       slideTilePurchaseOrders = mainController.byId("slideTilePurchaseOrders"),
                            //       count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);
                            //       if (count >= 0) {
                            //         MainPageGrid.removeContent(count);
                            //       }
            
                            // }

                          

                          for (var x in this._aDeviceSettings) {
                            if (
                              this._aDeviceSettings[x].Fieldname.indexOf(
                                "notifFields"
                              ) !== -1
                            ) {
                              var aNotifField =
                                this._aDeviceSettings[x].Fieldname.split("_");
                              var sNotifField = aNotifField[1];
                              notifFields[sNotifField] =
                                this._aDeviceSettings[x].Type === "BOOL"
                                  ? this._aDeviceSettings[x].ValueBool
                                  : this._aDeviceSettings[x].ValueString;
                            } else {
                              this.getModel("onboarding").setProperty(
                                "/" + this._aDeviceSettings[x].Fieldname,
                                this._aDeviceSettings[x].Type === "BOOL"
                                  ? this._aDeviceSettings[x].ValueBool
                                  : this._aDeviceSettings[x].ValueString
                              );
                            }
                          }
                          // 	}
                          // 	if(this._aDeviceSettings[x].Type === "BOOL") {
                          // 		this.getModel("onboarding").getProperty("/enableDownloadBoms");
                          // 	}
                          // 	var enableDownloadBoms = _.find(this._aDeviceSettings, {Fieldname: 'enableDownloadBoms'});
                          // 	var enableOrderConfCreation = _.find(this._aDeviceSettings, {Fieldname: 'enableOrderConfCreation'});
                          // 	var persNoNotRequired = _.find(this._aDeviceSettings, {Fieldname: 'persNoNotRequired'});
                          // 	var rfidMand = _.find(this._aDeviceSettings, {Fieldname: 'rfidMand'});
                          // 	var hideLogOffButton = _.find(this._aDeviceSettings, {Fieldname: 'hideLogOffButton'});
                          // 	if(!enableDownloadBoms) {
                          // 		this.getModel("onboarding").setProperty("/enableDownloadBoms", false);
                          // 	}
                          // 	if(!enableOrderConfCreation) {
                          // 		this.getModel("onboarding").setProperty("/enableOrderConfCreation", false);
                          // 	}
                          // 	if(!persNoNotRequired) {
                          // 		this.getModel("onboarding").setProperty("/persNoNotRequired", false);
                          // 	}
                          // 	if(!rfidMand) {
                          // 		this.getModel("onboarding").setProperty("/rfidMand", false);
                          // 	}
                          // 	if(!hideLogOffButton) {
                          // 		this.getModel("onboarding").setProperty("/hideLogOffButton", false);
                          // 	}
                          // 	notifFields = this.getHelper().onNotifFieldChange(notifFields);
                          // 	this.getModel("shared").setProperty("/sapSettings/notifFields", notifFields);
                          // 	this.getModel("onboarding").setProperty("/notifFields", notifFields);
                          // 	this.getModel("onboarding").setProperty("/langu", this.getModel("onboarding").getProperty("/langu").toUpperCase());

                          // 	;
                          // 	$.when(this.getDBService().saveSAPSettings(this.getModel("onboarding").getProperty("/")))
                          // 		.done(jQuery.proxy(function () {
                          // 			var oSetting=this.getModel("onboarding").getProperty("/");
                          // 			for (var sProp in oSetting) {
                          // 				if(sProp !== "langu") {
                          // 					this.getModel("shared").setProperty("/sapSettings/"+sProp,oSetting[sProp] );
                          // 				}
                          // 			}
                          // 	}, this));
                          // 	$.when(this.getDBService().deleteAllObjects('ValueHelpSet'))
                          // 		.done(jQuery.proxy(function () {
                          // 			this.getDBService().initValueHelpSet(oValueHelp);
                          // 	}, this));
                          // 	this.getLogs().addLog(this.getText("SyncWithConfigServerSuccess"), "INFO", "SettingsUSERSettings");
                          // 	MBox.success(this.getText("SyncWithConfigServerSuccess"));
                          // }, this));
                          if (this._aDeviceSettings[x].Type === "BOOL") {
                            this.getModel("onboarding").getProperty(
                              "/enableDownloadBoms"
                            );
                          }
                          var enableDownloadBoms = _.find(
                            this._aDeviceSettings,
                            { Fieldname: "enableDownloadBoms" }
                          );
                          var enableOrderConfCreation = _.find(
                            this._aDeviceSettings,
                            { Fieldname: "enableOrderConfCreation" }
                          );
                          var persNoNotRequired = _.find(
                            this._aDeviceSettings,
                            { Fieldname: "persNoNotRequired" }
                          );
                          var rfidMand = _.find(this._aDeviceSettings, {
                            Fieldname: "rfidMand",
                          });
                          var hideLogOffButton = _.find(this._aDeviceSettings, {
                            Fieldname: "hideLogOffButton",
                          });
                          var Notifstatus_tbp = _.find(this._aDeviceSettings, {
                            Fieldname: "Notifstatus_tbp",
                          });
                          var TrCheckError = _.find(this._aDeviceSettings, {
                            Fieldname: "TrCheckError",
                          });
                          var POActive = _.find(this._aDeviceSettings, {
                            Fieldname: "POActive",
                          });
                          var Connected = _.find(this._aDeviceSettings, {
                            Fieldname: "Connected",
                          });
                          var ZoneBadging = _.find(this._aDeviceSettings, {
                            Fieldname: "ZoneBadging",
                          });
                          if (!enableDownloadBoms) {
                            this.getModel("onboarding").setProperty(
                              "/enableDownloadBoms",
                              false
                            );
                          }
                          if (!enableOrderConfCreation) {
                            this.getModel("onboarding").setProperty(
                              "/enableOrderConfCreation",
                              false
                            );
                          }
                          if (!persNoNotRequired) {
                            this.getModel("onboarding").setProperty(
                              "/persNoNotRequired",
                              false
                            );
                          }
                          if (!rfidMand) {
                            this.getModel("onboarding").setProperty(
                              "/rfidMand",
                              false
                            );
                          }
                          if (!hideLogOffButton) {
                            this.getModel("onboarding").setProperty(
                              "/hideLogOffButton",
                              false
                            );
                          }
                          if (!Notifstatus_tbp) {
                            this.getModel("onboarding").setProperty(
                              "/Notifstatus_tbp",
                              false
                            );
                          }
                          if (!TrCheckError) {
                            this.getModel("onboarding").setProperty(
                              "/TrCheckError",
                              false
                            );
                          }
                          if (!POActive) {
                            this.getModel("onboarding").setProperty(
                              "/POActive",
                              false
                            );
                          }
                          if (!Connected) {
                            this.getModel("onboarding").setProperty(
                              "/Connected",
                              false
                            );
                          }
                          if (!ZoneBadging) {
                            this.getModel("onboarding").setProperty(
                              "/ZoneBadging",
                              false
                            );
                          }
                          notifFields =
                            this.getHelper().onNotifFieldChange(notifFields);
                          this.getModel("shared").setProperty(
                            "/sapSettings/notifFields",
                            notifFields
                          );
                          this.getModel("onboarding").setProperty(
                            "/notifFields",
                            notifFields
                          );
                          this.getModel("onboarding").setProperty(
                            "/langu",
                            this.getModel("onboarding")
                              .getProperty("/langu")
                              .toUpperCase()
                          );

                          // this.getDBService().saveSAPSettings(this.getModel("onboarding").getProperty("/"));
                          $.when(
                            this.getDBService().saveSAPSettings(
                              this.getModel("onboarding").getProperty("/")
                            )
                          ).done(
                            jQuery.proxy(function () {
                              var oSetting =
                                this.getModel("onboarding").getProperty("/");
                              for (var sProp in oSetting) {
                                if (sProp !== "langu") {
                                  this.getModel("shared").setProperty(
                                    "/sapSettings/" + sProp,
                                    oSetting[sProp]
                                  );
                                }
                              }
                            }, this)
                          );
                          $.when(
                            this.getDBService().deleteAllObjects("ValueHelpSet")
                          ).done(
                            jQuery.proxy(function () {
                              this.getDBService().initValueHelpSet(oValueHelp);
                            }, this)
                          );
                          this.getLogs().addLog(
                            this.getText("SyncWithConfigServerSuccess"),
                            "INFO",
                            "SettingsUSERSettings"
                          );
                          MBox.success(
                            this.getText("SyncWithConfigServerSuccess")
                          );
                          this.getView().getParent().getParent().setBusy(false);
                        }, this)
                      );
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function (oError) {
                      if (oError.statusCode === 401) {
                        this.getLogs().addLog(
                          this.getText("UserNotAuthorized", oSettings.sapSysId),
                          "ERROR",
                          "SettingsUSERSettings"
                        );
                        MBox.error(
                          this.getText("UserNotAuthorized", oSettings.sapSysId)
                        );
                      } else if (oError.statusCode === 0) {
                        MBox.error(this.getText("SAPSettingsIncorrect"));
                        this.getLogs().addLog(
                          this.getText("SAPSettingsIncorrect"),
                          "ERROR",
                          "SettingsUSERSettings"
                        );
                      } else {
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                        this.getLogs().addLog(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap"),
                          "ERROR",
                          "SettingsUSERSettings"
                        );
                      }
                      this.getView().getParent().getParent().setBusy(false);
                    }, this)
                  );
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                // 	if (oError.statusCode === 401) {
                // 		MBox.error(this.getText("UserNotAuthorized", oSettings.sapSysId));
                // 		this.getLogs().addLog(this.getText("UserNotAuthorized", oSettings.sapSysId), "ERROR", "SettingsUSERSettings");
                // 	} else if (oError.statusCode === 0) {
                // 		MBox.error(this.getText("SAPSettingsIncorrect"));
                // 		this.getLogs().addLog(this.getText("SAPSettingsIncorrect"), "ERROR", "SettingsUSERSettings");
                // 	} else {
                // 		MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
                // 		this.getLogs().addLog(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"), "ERROR", "SettingsUSERSettings");
                // 	}
                // }, this));

                if (oError.statusCode === 401) {
                  MBox.error(
                    this.getText("UserNotAuthorized", oSettings.sapSysId)
                  );
                  this.getLogs().addLog(
                    this.getText("UserNotAuthorized", oSettings.sapSysId),
                    "ERROR",
                    "SettingsUSERSettings"
                  );
                } else if (oError.statusCode === 0) {
                  MBox.error(this.getText("SAPSettingsIncorrect"));
                  this.getLogs().addLog(
                    this.getText("SAPSettingsIncorrect"),
                    "ERROR",
                    "SettingsUSERSettings"
                  );
                } else {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                  this.getLogs().addLog(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap"),
                    "ERROR",
                    "SettingsUSERSettings"
                  );
                }
                this.getView().getParent().getParent().setBusy(false);
              }, this)
            );
          /*}, this)).fail(jQuery.proxy(function (oError) {
						if (oError.statusCode === 401) {
							MBox.error(this.getText("UserNotAuthorized"));
						} else if (oError.statusCode === 0) {
							MBox.error(this.getText("SAPSettingsIncorrect"));
						} else {
							MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
						}
					}, this));*/
        },

        changeColorOfDeviceIdToRed: function () {
          this.genericSetDeviceIdColor("Red");
          this.genericReplaceStyleClass(this.getView(), "Red");

          // this.getSharedModel().setProperty("/deviceIdColor", "XXXRed");
          // this.getView().removeStyleClass("XXXGreen");
          // this.getView().addStyleClass("XXXRed");
          // this.getView().getParent().getParent().removeStyleClass("XXXGreen");
          // this.getView().getParent().getParent().addStyleClass("XXXRed");
        },
      }
    );
  }
);
