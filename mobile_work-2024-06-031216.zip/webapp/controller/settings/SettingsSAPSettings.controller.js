sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
  ],
  function (Controller, MToast, MBox) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.settings.SettingsSAPSettings",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onInit: function () {
          this._initModels();
          this.getRouter()
            .getRoute("settingsSAPSettings")
            .attachPatternMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ParticipantsMaster
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function () {
          //set connection property
          this.getConnection();
          $.when(this.getDBService().getSAPSettings()).done(
            jQuery.proxy(this.onSAPSettingsRetreived, this)
          );
          $.when(this.connectionCheckTogiveColour())
            .done(
              jQuery.proxy(function () {
                this.genericSetDeviceIdColor("Green");
                this.genericReplaceStyleClass(this.getView(), "Green");

                // this.getView().getParent().getParent().removeStyleClass("XXXRed");
                // this.getView().getParent().getParent().addStyleClass("XXXGreen");
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                this.genericSetDeviceIdColor("Red");
                this.genericReplaceStyleClass(this.getView(), "Red");

                // this.getView().getParent().getParent().removeStyleClass("XXXGreen");
                // this.getView().getParent().getParent().addStyleClass("XXXRed");
              }, this)
            );
        },

        onSAPSettingsRetreived: function (oData) {
          var oSharedModel = this.getView().getModel("shared"),
            oSAPSettingModel = this.getView().getModel("sapSetting");

          if (oData.sapUser === undefined && oData.sapPass === undefined) {
            
            oData.sapUser = oSharedModel.getProperty("/sapSettings/sapUser");
            oData.sapPass = oSharedModel.getProperty("/sapSettings/sapPass");
          }
          oSharedModel.setProperty("/sapSettings", oData);

          // oSharedModel.setProperty("/sapSettings/host", oData.host);
          // oSharedModel.setProperty("/sapSettings/deviceName", oData.deviceName);
          // oSharedModel.setProperty("/sapSettings/sapClient", oData.sapClient);
          // oSharedModel.setProperty("/sapSettings/sapSysId", oData.sapSysId);
          // oSharedModel.setProperty("/sapSettings/gdlApi", oData.gdlApi);
          // oSharedModel.setProperty("/sapSettings/notifFields", oData.notifFields);
          // oSharedModel.setProperty("/sapSettings/rfidMand", oData.rfidMand);
          // oSharedModel.setProperty("/sapSettings/enableLogin", oData.enableLogin);
          // oSharedModel.setProperty("/sapSettings/enableOrderConfCreation", oData.enableOrderConfCreation);
          // oSharedModel.setProperty("/sapSettings/enableDownloadBoms", oData.enableDownloadBoms);

          oSAPSettingModel.setProperty("/host", oData.host);
          oSAPSettingModel.setProperty("/deviceName", oData.deviceName);
          oSAPSettingModel.setProperty("/sapClient", oData.sapClient);
          oSAPSettingModel.setProperty("/sapSysId", oData.sapSysId);
          oSAPSettingModel.setProperty("/GDL_API_URL", oData.GDL_API_URL);
          oSAPSettingModel.setProperty("/rfidMand", oData.rfidMand);
          oSAPSettingModel.setProperty("/enableLogin", oData.enableLogin);
          oSAPSettingModel.setProperty(
            "/enableOrderConfCreation",
            oData.enableOrderConfCreation
          );
          oSAPSettingModel.setProperty(
            "/enableDownloadBoms",
            oData.enableDownloadBoms
          );
          oSAPSettingModel.setProperty(
            "/persNoNotRequired",
            oData.persNoNotRequired
          );
          oSAPSettingModel.setProperty(
            "/hideLogOffButton",
            oData.hideLogOffButton
          );
          oSAPSettingModel.setProperty(
            "/Notifstatus_tbp",
            oData.Notifstatus_tbp
          );
          oSAPSettingModel.setProperty("/TrCheckError", oData.TrCheckError);
          oSAPSettingModel.setProperty("/POActive", oData.POActive);
          oSAPSettingModel.setProperty("/Connected", oData.Connected);
          oSAPSettingModel.setProperty("/ZoneBadging", oData.ZoneBadging);
          //oSAPSettingModel.setProperty("/policy", oData.policy);
          $.when(this.getDBService().getEntitySet("ValueHelpSet")).done(
            jQuery.proxy(function (oValueHelpSet) {
              for (var i = 0; i < oValueHelpSet.rows.length; i++) {
                if (oValueHelpSet.rows.item(i).Value === oData.policy) {
                  oSAPSettingModel.setProperty(
                    "/policy",
                    oValueHelpSet.rows.item(i).Description
                  );
                }
              }
            }, this)
          );
          //oSAPSettingModel.setProperty("/Shiftindicator", oData.SHIFTINDIC ? true : false);
          this._prepFieldCombobox();
        },

        onNavBack: function () {
          this.getRouter().navTo("settingsMaster", true);
        },

        /*
        onSavePress: function () {
          var oSharedModel = this.getView().getModel("shared"),
            oSAPSettingModel = this.getView().getModel("sapSetting"),
            sViewHost = oSAPSettingModel.getProperty("/host"),
            sViewClient = oSAPSettingModel.getProperty("/sapClient"),
            sSharedHost = oSharedModel.getProperty("/sapSettings/host"),
            sSharedClient = oSharedModel.getProperty("/sapSettings/sapClient"),
            bConfigFailed = oSharedModel.getProperty("/configFailed");

          var fnCreateModel = jQuery.proxy(function () {
            $.when(
              this.getService().createModelWithHostAndClient(
                sViewHost,
                sViewClient
              )
            )
              .done(
                jQuery.proxy(function () {
                  this.getView()
                    .getModel("shared")
                    .setProperty("/metaFailed", false);
                  this.getDBService()._createTablesFromMetadata();
                  this.getDBService()._saveMetadataToSettings();
                  this.getService().getCatalogSet();
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  this.component
                    .getModel("shared")
                    .setProperty("/metaFailed", true);
                }, this)
              );
          }, this);

          //if ((sViewHost !== sSharedHost || sViewClient !== sSharedClient) && !bConfigFailed) {

          // this.getService().updateHost(sViewHost);
          oSharedModel.setProperty("/settings/host", sViewHost);

          // if (!this.getHelper().isDevModeActive()) {

          
          if (this.getService()) {
            $.when(this.getService().logoff())
              .done(
                jQuery.proxy(function () {
                  this.getView()
                    .getModel("shared")
                    .setProperty("/metaFailed", true); // User logged off > models are no longer connected
                  fnCreateModel();

                  // this.getService().setDeviceName(oSAPSettingModel.getProperty("/deviceName"));
                  oSharedModel.setProperty(
                    "/sapSettings/deviceName",
                    oSAPSettingModel.getProperty("/deviceName")
                  );

                  oSharedModel.setProperty("/settings/host", sViewHost);
                  oSharedModel.setProperty("/settings/sapClient", sViewClient);
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  fnCreateModel();
                  // this.getService().setDeviceName(oSAPSettingModel.getProperty("/deviceName"));
                  oSharedModel.setProperty(
                    "/sapSettings/deviceName",
                    oSAPSettingModel.getProperty("/deviceName")
                  );

                  oSharedModel.setProperty("/settings/host", sViewHost);
                  oSharedModel.setProperty("/settings/sapClient", sViewClient);
                }, this)
              );
          }

          // } else {
          // 	//this.getView().getModel("shared").setProperty("/metaFailed", true);

          // 	fnCreateModel();
          // 	this.getService().setDeviceName(oSAPSettingModel.getProperty("/deviceName"));

          // 	oSharedModel.setProperty("/settings/host", sViewHost);
          // 	oSharedModel.setProperty("/settings/sapClient", sViewClient);

          // }

          this._updateSettingsInDb();

          if (sSharedHost !== sViewHost) {
            var oPromDeleteTechObj =
                this.getDBService().deleteAllObjects("TechnicalObject"),
              oPromDeleteFuncLocCraft =
                this.getDBService().deleteAllObjects("FuncLocCraft");

            $.when(oPromDeleteTechObj, oPromDeleteFuncLocCraft).done(
              jQuery.proxy(function () {
                console.log(
                  "technical objects deleted + func loc crafts deleted"
                );
              }, this)
            );
          }

        //   this.getService().getModel().metadataLoaded().then(jQuery.proxy(function () {
		// 		console.log("metadata loaded");
		// 		this.getView().getModel("shared").setProperty("/metaFailed", false);
		// 		this.getDBService()._createTablesFromMetadata();
		// 	}, this));

		// 	this.getService().getCatalogSet();
        },

		*/

        onUploadChange: function (oEvent) {
          var oFile = oEvent.getParameter("files")[0],
            oReader = new FileReader();

          oReader.onload = jQuery.proxy(this.onFileRead, this);
          oReader.readAsText(oFile, "UTF-8");

          oEvent.getSource().setValue("");
        },

        onFileRead: function (oData) {
          var sErrorMsg = "",
            oJSON = null,
            oViewModelSettings = this.getView().getModel("sapSetting"),
            oViewDataSettings = oViewModelSettings.getData(),
            oViewModelFields = this.getView().getModel("fields"),
            oViewDataFields = oViewModelFields.getData();

          if (oData.target.result && typeof oData.target.result === "string") {
            try {
              oJSON = JSON.parse(oData.target.result);
              for (var sProp in oJSON) {
                if (oViewDataSettings.hasOwnProperty(sProp)) {
                  oViewModelSettings.setProperty("/" + sProp, oJSON[sProp]);
                } else if (oViewDataFields.hasOwnProperty(sProp)) {
                  oViewModelFields.setProperty("/" + sProp, oJSON[sProp]);
                }
              }
              this._prepFieldCombobox();
            } catch (e) {
              sErrorMsg = this.getText("LoadConfigError");
            }
          } else {
            sErrorMsg = this.getText("LoadConfigError");
          }

          if (sErrorMsg) {
            MBox.error(sErrorMsg);
          }
        },

        onQrScanPress: function (oEvent) {
          var oJSON = null,
            oViewModelSettings = this.getView().getModel("sapSetting"),
            oViewDataSettings = oViewModelSettings.getData(),
            oViewModelFields = this.getView().getModel("fields"),
            oViewDataFields = oViewModelFields.getData();

          $.when(this.getScanHandler().scan())
            .done(
              jQuery.proxy(function (oData) {
                alert("functionality not allowed in public release");
                return;

                oJSON = JSON.parse(oData.text);
                for (var sProp in oJSON) {
                  if (oViewDataSettings.hasOwnProperty(sProp)) {
                    oViewModelSettings.setProperty("/" + sProp, oJSON[sProp]);
                  } else if (oViewDataFields.hasOwnProperty(sProp)) {
                    oViewModelFields.setProperty("/" + sProp, oJSON[sProp]);
                  }
                }
                this._prepFieldCombobox();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                MBox.error(this.getText("LoadConfigError"));
              }, this)
            );
        },

        onDeviceNameChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("sapSetting");

          if (sValue) {
            oSettingModel.setProperty("/deviceName", sValue.toUpperCase());
          }
        },

        onSystemIdChange: function (oEvent) {
          var sValue = oEvent.getParameter("newValue"),
            oSettingModel = this.getView().getModel("sapSetting");

          if (sValue) {
            oSettingModel.setProperty("/sapSysId", sValue.toUpperCase());
          }
        },

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {
          if (!this.getView().getModel("sapSetting")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel(),
              "sapSetting"
            );
          }
          if (!this.getView().getModel("fields")) {
            this.getView().setModel(
              new sap.ui.model.json.JSONModel(),
              "fields"
            );
          }
        },

        _prepFieldCombobox: function () {
          var oCombo = this.getView().byId("notifFields"),
            oFields = this.getSharedModel().getProperty(
              "/sapSettings/notifFields"
            ),
            aFields = [];

          for (var sProp in oFields) {
            aFields.push({
              sKey: sProp,
              sText: this.getText(sProp),
              bSelected: oFields[sProp],
            });
          }

          this.getView()
            .getModel("fields")
            .setProperty("/notifFields", aFields);
          oCombo.removeAllSelectedItems();
          oCombo.getItems().forEach(function (oItem) {
            var _oObject = oItem.getBindingContext("fields").getObject();
            if (_oObject.bSelected) {
              oCombo.addSelectedItem(oItem);
            }
          });
        },

        _updateSettingsInDb: function () {
          var aSettingsArrary = [],
            oUSettingModel = this.getView().getModel("sapSetting"),
            oFieldsModel = this.getView().getModel("fields"),
            oFieldsData = oFieldsModel.getProperty("/"),
            oNotifFields = this.getSharedModel().getProperty(
              "/sapSettings/notifFields"
            ),
            oSettingData = oUSettingModel.getProperty("/");

          for (var _sProp in oNotifFields) {
            if (oFieldsData.selectedNotifFields.indexOf(_sProp) !== -1) {
              oNotifFields[_sProp] = true;
            } else {
              oNotifFields[_sProp] = false;
            }
          }

          oSettingData.notifFields = oNotifFields;

          for (var sProp in oSettingData) {
            if (oSettingData.hasOwnProperty(sProp)) {
              aSettingsArrary.push({
                SKey: sProp,
                SValue: oSettingData[sProp],
              });
            }
          }

          if (
            oSettingData.sapUser === undefined &&
            oSettingData.sapPass === undefined
          ) {
            
            oSettingData.sapUser = this.getSharedModel().getProperty(
              "/sapSettings/sapUser"
            );
            oSettingData.sapPass = this.getSharedModel().getProperty(
              "/sapSettings/sapPass"
            );
          }
          this.getSharedModel().setProperty("/sapSettings", oSettingData);

          $.when(this.getDBService().updateSAPSettings(aSettingsArrary)).done(
            jQuery.proxy(function () {
              $.when(this.getDBService().getSAPSettings()).done(
                jQuery.proxy(this.onSAPSettingsRetreived, this)
              );
              MToast.show(this.getText("SSettingUpdateSuccess"));
            }, this)
          );
        },

        _onResetApplicationPress: function () {
          var oUSettingModel = this.getView().getModel("uSetting"),
           oLocalModel = this.getView().getModel("local"),
            oSharedModel = this.getView().getModel("shared");
          var yesnodialog = sap.ui.controller(
            "mobilework.controller.dialogs.YesNoDialog"
          );
          yesnodialog.openYesNoDialog(
            this,
            this.getText("ConfirmResetApp"),
            this.getText("Confirm"),
            function () {
              var uri = this.getManifestEntry(
                "/sap.app/dataSources/configserver"
              ).uri;
              var oShared = this.getModel("shared"),
                oSettings = oShared.getProperty("/sapSettings");
              // $.when(this.getService().createConfigurationModel(uri, oSettings),this._deassign()).done(jQuery.proxy(function () {
              // 	$.when(this.getService().unassignDevice(oSharedModel.getProperty("/sapSettings/deviceName"), oSharedModel.getProperty(
              // 		"/sapSettings/plant"))).done(
              // 		jQuery.proxy(function () {
              // 			var oPromDelSettings = this.getDBService().deleteAllObjects("Setting");
              // 			$.when(oPromDelSettings)
              // 				.done($.proxy(function () {
              // 					this.getLogs().addLog("Reset Success", "INFO", "SettingsSAPSettings");
              // 					this.getRouter().navTo("reload", {}, true);
              // 				}, this))
              // 				.fail($.proxy(function () {
              // 					this.getLogs().addLog("Reset Failed", "ERROR", "SettingsSAPSettings");
              // 					this.getRouter().navTo("reload", {}, true);
              // 				}, this));
              // 		}, this));

              if (
                this.getService() === null ||
                oSharedModel.getProperty("/sapSettings/sapPass") === undefined
              ) {
                MBox.error("User settings not correctly loaded, login again");
                return;
              }

              $.when(
                this.getService().createConfigurationModel(uri, oSettings),
                this._deassign()
              )
                .done(
                  jQuery.proxy(function () {
                    $.when(
                      this.getService().unassignDevice(
                        oSharedModel.getProperty("/sapSettings/deviceName"),
                        oSharedModel.getProperty("/sapSettings/plant")
                      )
                    ).done(
                      jQuery.proxy(function () {
                        var oPromDelSettings =
                          this.getDBService().deleteAllObjects("Setting");
                        
                        $.when(oPromDelSettings)
                          .done(
                            $.proxy(function () {
                              this.getService().logoff();
                              
                              var count = {
                                ConfirmationNotStarted: 0,
                                FinalConfirmation: 0,
                                ConfirmationOngoing: 0,
                                FinishedConfirmation: 0,
                                Notifications: 0,
                                FinishedFinalConfirmation: 0,
                              };
                              oSharedModel.setProperty("/counts", count);
                              oSharedModel.setProperty("/configFailed", true);
                              oSharedModel.setProperty("/metaFailed", true);
                              oSharedModel.setProperty("/loggedInAsMsg", "");
                              oSharedModel.setProperty("/bUserIconVisible", false);
                              oSharedModel.setProperty("/sapSettings", {});
                              oLocalModel.setProperty("/", {});
                              this.getModel('PurchaseOrders').setProperty("/", {});
                              this.getLogs().addLog(
                                "Reset Success",
                                "INFO",
                                "SettingsSAPSettings"
                              );
                              // this.getRouter().navTo("reload", {}, true);
                            }, this)
                          )
                          .fail(
                            $.proxy(function () {
                              this.getService().logoff();
                              
                              oSharedModel.setProperty("/configFailed", true);
                              oSharedModel.setProperty("/metaFailed", true);
                              oSharedModel.setProperty("/loggedInAsMsg", "");
                              oSharedModel.setProperty("/bUserIconVisible", false);
                              oSharedModel.setProperty("/sapSettings", {});
                              oLocalModel.setProperty("/", {});
                              this.getModel('PurchaseOrders').setProperty("/", {});
                              this.getLogs().addLog(
                                "Reset Failed",
                                "ERROR",
                                "SettingsSAPSettings"
                              );
                              this.getRouter().navTo("reload", {}, true);
                            }, this)
                          );
                      }, this)
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    if (oError.getParameters().statusCode === 401) {
                      MBox.error(this.getText("UserNotAuthorized"));
                      this.getLogs().addLog(
                        this.getText("UserNotAuthorized"),
                        "ERROR",
                        "SettingsSAPSettings"
                      );
                    } else if (oError.getParameters().statusCode === 0) {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                      this.getLogs().addLog(
                        this.getText("SAPSettingsIncorrect"),
                        "ERROR",
                        "SettingsSAPSettings"
                      );
                    } else {
                      MBox.error(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap")
                      );
                      this.getLogs().addLog(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap"),
                        "ERROR",
                        "SettingsSAPSettings"
                      );
                    }
                  }, this)
                );
            },
            function (oError) {
              // Nothing
            }
          );
        },

        _deassign: function () {
          var d = $.Deferred();
          var oSettings = this.getSharedModel().getProperty("/sapSettings"),
            that = this;

          $.when(
            this.getService().deassignAllData(
              oSettings.deviceName,
              this.getHelper().isDevModeActive()
            )
          ).done(
            jQuery.proxy(function (oResult) {
              var oPromDeleteOrders =
                  this.getDBService().deleteAllObjects("PMOrder"),
                oPromDeleteOper =
                  this.getDBService().deleteAllObjects("Operation"),
                oPromDeletePrt = this.getDBService().deleteAllObjects("PRT"),
                oPromDeleteComp =
                  this.getDBService().deleteAllObjects("Component"),
                oPromDeleteConf =
                  this.getDBService().deleteAllObjects("Confirmation"),
                oPromDeleteBoundNotif =
                  this.getDBService().deleteBoundNotifications();

              $.when(
                oPromDeleteOrders,
                oPromDeleteOper,
                oPromDeletePrt,
                oPromDeleteComp,
                oPromDeleteConf,
                oPromDeleteBoundNotif
              )
                .done(
                  jQuery.proxy(function (oData) {
                    MBox.success(this.getText("OrderDeassignSuccess"), {
                      onClose: function (sAction) {
                        that.getRouter().navTo("reload", {}, true);
                      },
                    });
                    this.getLogs().addLog(
                      "Deassign Success",
                      "INFO",
                      "Synchronize"
                    );
                    d.resolve();
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    MBox.success(this.getText("OrderDeassignFailed"));
                    this.getLogs().addLog(
                      "Deassign Failed",
                      "ERROR",
                      "Synchronize"
                    );
                    d.reject();
                  }, this)
                );
            }, this)
          );
          return d.promise();
        },

        onResetApplicationPress: function () {
          if (this.getService() === null) {
            MBox.error("You need to be logged in to perform this action");
          } else {
            this.getService()
              .checkTokenExpiration()
              .then(this._onResetApplicationPress.bind(this))
              .catch(function (oError) {
                MBox.error("Failed to reset the app");
              });
          }
        },
      }
    );
  }
);
