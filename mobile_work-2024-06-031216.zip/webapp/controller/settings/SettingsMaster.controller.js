sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "mobilework/util/GdlDoc",
  ],
  function (Controller, MToast, MBox, GDLHandler) {
    "use strict";

    return Controller.extend("mobilework.controller.settings.SettingsMaster", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      sAdminPass: "admin",

      navAfterPass: "",

      /** @type sap.m.Dialog */
      oPasswordDialog: null,

      /** @type sap.m.Dialog */
      oAboutDialog: null,

      //---------------------------//
      // LIFECYCLE
      //---------------------------//

      /**
       * Called when a controller is instantiated and its View controls (if available) are already created.
       * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
       * @memberOf mobilework.view.ParticipantsMaster
       */
      onInit: function () {
        this._initModels();
        this._getInfoFromManifest();
        this._getAdditionalDataForAbout();
        this.getRouter()
          .getRoute("settingsMaster")
          .attachMatched(this.onRouteMatched, this);
      },

      /**
       * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
       * @memberOf mobilework.view.ParticipantsMaster
       */
      onExit: function () {},

      //---------------------------//
      // EVENT HANDLERS
      //---------------------------//

      onRouteMatched: function () {
        //set connection property
        this.getConnection();
        this.changeColorOfDeviceId();
        if (this.getSharedModel().getProperty("/reloadedRun")) {
          this._getAdditionalDataForAbout();
          this.getSharedModel().setProperty("/reloadedRun", false);
        }
      },

      onNavBack: function () {
        this.getRouter().navTo("main", true);
      },

      onTilePress: function (oEvent) {
        var sTileId = oEvent.getSource().getId(),
          oPasswordDialog = null;

        this.navAfterPass = "";
        //this.navAfterPassObj = {};

        if (sTileId.indexOf("sapSettings") !== -1) {
          if (!this.getHelper().isDevModeActive()) {
            oPasswordDialog = this._getPasswordDialog();
            //this.navAfterPass = "";
            oPasswordDialog.open();
          } else {
            this.getRouter().navTo("settingsSAPSettings");
          }
        } else if (sTileId.indexOf("userSettings") !== -1) {
          this.getRouter().navTo("settingsUserSettings");
        } else if (sTileId.indexOf("technicalSettings") !== -1) {
          this.getRouter().navTo("settingsTechnicalSettings");
        } else if (sTileId.indexOf("about") !== -1) {
          this._getAboutDialog().open();
        }
        // else if (sTileId.indexOf("loadConfig") !== -1) {
        // 	if (!this.getHelper().isDevModeActive()) {
        // 		oPasswordDialog = this._getPasswordDialog();
        // 		this.navAfterPass = "settingsLoadConfig";
        // 		this.navAfterPassObj = {
        // 			fromMaster: true
        // 		};
        // 		oPasswordDialog.open();
        // 	} else {
        // 		this.getRouter().navTo("settingsLoadConfig", {
        // 			fromMaster: true
        // 		});
        // 	}
        // }
      },

      onPasswordDialogConfirmPress: function (oEvent) {
        var oModel = this.getView().getModel("password"),
          sPass = oModel.getProperty("/pass"),
          sMessage = this.getText("IncorrectAdminPass");

        if (sPass === this.sAdminPass) {
          this.getRouter().navTo("settingsSAPSettings");
          this.oPasswordDialog.close();
        } else {
          MToast.show(sMessage);
        }

        oModel.setProperty("/pass", "");
      },

      onPasswordDialogCancelPress: function (oEvent) {
        this._getPasswordDialog().close();
      },

      onAboutDialogExit: function () {
        this._getAboutDialog().close();
      },

      //---------------------------//
      // PRIVATES
      //---------------------------//

      _initModels: function () {
        if (!this.getView().getModel("password")) {
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "password"
          );
        }
        if (!this.getView().getModel("about")) {
          this.getView().setModel(new sap.ui.model.json.JSONModel(), "about");
        }
      },

      _getPasswordDialog: function () {
        if (!this.oPasswordDialog) {
          this.oPasswordDialog = sap.ui.xmlfragment(
            "passwordDialog",
            "mobilework.view.settings.SAPSettingsPasswordDialog",
            this
          );
          this.getView().addDependent(this.oPasswordDialog);
        }

        return this.oPasswordDialog;
      },

      _getAboutDialog: function () {
        if (!this.oAboutDialog) {
          this.oAboutDialog = sap.ui.xmlfragment(
            "aboutDialog",
            "mobilework.view.settings.SettingsAboutDialog",
            this
          );
          this.getView().addDependent(this.oAboutDialog);
        }

        return this.oAboutDialog;
      },

      _getInfoFromManifest: function () {
        var oModel = this.getView().getModel("about"),
          sAppVersion =
            this.getOwnerComponent().getManifestObject()._oManifest._version;

        oModel.setProperty("/version", sAppVersion);
      },

      _getAdditionalDataForAbout: function () {
        var oModel = this.getView().getModel("about"),
          oSharedModel = this.getOwnerComponent().getModel("shared");

        if (oSharedModel) {
          oModel.setProperty(
            "/deviceName",
            oSharedModel.getProperty("/sapSettings/deviceName")
          );
          oModel.setProperty(
            "/sapSysId",
            oSharedModel.getProperty("/sapSettings/sapSysId")
          );
        }
      },

      _saveWorkSetToDb: function (oData) {
        $.when(this.getDBService().saveWorkSet(oData))
          .done(
            jQuery.proxy(function () {
              this.getLogs().addLog(
                this.getText("OrderDownloadSuccess", oData.length),
                "INFO",
                "ParticipantsMaster"
              );
              MBox.success(this.getText("OrderDownloadSuccess", oData.length));
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              this.getLogs().addLog(
                this.getText("OrderDownloadFail"),
                "Error",
                "SettingsMaster"
              );
              MBox.error(this.getText("OrderDownloadFail"));
            }, this)
          );
      },
    });
  }
);
