/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "mobilework/model/tables/GdlLink",
    "mobilework/model/tables/OrderSyncTime",
  ],
  function (Controller, MBox, MToast, GdlLink, OrderSyncTime) {
    "use strict";

    return Controller.extend("mobilework.controller.synchronize.Synchronize", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      aUnconfirmedOrders: [],

      aUnconfirmedOperations: [],

      UNCONF: "UNCONF",

      UNOPER: "UNOPER",

      UNFIN: "UNFIN",

      NODATA: "NODATA",

      FINCONFMISSINGDATA: "FINCONFMISSINGDATA",

      NOTIFMISSINGDATA: "NOTIFMISSINGDATA",

      NOCONFISRUNNING: "NOCONFISRUNNING",

      //---------------------------//
      // LIFECYCLE
      //---------------------------//

      /**
       * Called when a controller is instantiated and its View controls (if available) are already created.
       * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
       * @memberOf mobilework.view.Synchronize
       */
      onInit: function () {
        var oFlGroupsVHModel = new sap.ui.model.json.JSONModel();

        oFlGroupsVHModel.setSizeLimit(2000);

        this.getView().setModel(new sap.ui.model.json.JSONModel(), "newFl");
        this.getView().setModel(oFlGroupsVHModel, "FLgroupsVH");

        //subscribe to scanner
        this.getEventBus().subscribe(
          "scanner",
          "scannedFunctionalLocation",
          this.onExtScanSuccess,
          this
        );
        this.getRouter()
          .getRoute("synchronize")
          .attachMatched(this.onRouteMatched, this);
        /*BEGIN: Date: 22/02/2024 AMID: A0866990 13.1 Bug Number: Tile leaving empty space in MW when hidden*/
        // let synchronizeGrid = this.getView().byId("synchronizeGrid"),
        //   sendTStoSap = this.getView().byId("sendTStoSap"),
        //   getPurOrder = this.getView().byId("getPurOrder"),
        //   deleteallPOs = this.getView().byId("deleteallPOs"),
        //   sharedModel = this.getSharedModel(),
        //   poActive = sharedModel.getData().sapSettings.POActive ;
        // if (
        //   (synchronizeGrid &&
        //   sharedModel &&
        //   !sharedModel.getProperty("/publicRelease")) ||
        //   poActive === false
        // ) {
        //   if (sendTStoSap) {
        //     let count = synchronizeGrid.indexOfContent(sendTStoSap);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        //   if (getPurOrder) {
        //     let count = synchronizeGrid.indexOfContent(getPurOrder);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        //   if (deleteallPOs) {
        //     let count = synchronizeGrid.indexOfContent(deleteallPOs);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        // }
        // if (poActive === false) {
        //   if (getPurOrder) {
        //     let count = synchronizeGrid.indexOfContent(getPurOrder);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        // }


      },
      checkoAllRequestDone: function (oAllDownloadedPersent) {
        let oRepuestStatu = {
          done: 0,
          send: 0
        };
        for (let key in oAllDownloadedPersent) {
          if (!key.includes("length")) {
            oRepuestStatu.send++;
            if (oAllDownloadedPersent[key] === oAllDownloadedPersent[key + "length"]) {
              oRepuestStatu.done++;
            }
          }
        }
        return oRepuestStatu;
      },
      showDialogWithProgressBar: function (progressValue, oAllDownloadedPersent) {
        let oRepuestStatu = {};
        if (!this.oDialogProgress) {
          // Create a dialog
          this.oDialogProgress = new sap.m.Dialog({
            showHeader: false,
            contentWidth: "300px",
            //contentHeight: "200px",
            // endButton: new sap.m.Button({
            //     text: "Close",
            //     press: function () {
            //       this.oDialogProgress.close();
            //     }.bind(this)
            // })
          });

          // Create a progress indicator
          var oProgressIndicator = new sap.m.ProgressIndicator({
            width: "90%",
            percentValue: 0,// Initial progress value (0%)
            displayAnimation: true,
            displayValue: "0%",
            showValue: true
            //state:"Information"
          });
          let oTextForProgress = new sap.m.Text({
            text: "Loading..."
          }),
            oTextTextForNoOfReqDone = oTextForProgress.clone();
          oTextTextForNoOfReqDone.setText("[0/0]");
          oTextForProgress.addStyleClass("sapUiTinyMargin");
          oTextTextForNoOfReqDone.addStyleClass("sapUiTinyMargin")
          let oVBox = new sap.m.VBox({
            justifyContent: "Center",
            alignItems: "Center",
            width: "100%",
            fitContainer: true,
            renderType: sap.m.FlexRendertype.Bare
          }),
            oVBoxProgressText = oVBox.clone(),
            oVBoxForText = oVBox.clone();

          oVBoxProgressText.setAlignItems(sap.m.FlexAlignContent.Start);
          oVBoxForText.setAlignItems(sap.m.FlexAlignContent.End);
          oVBoxProgressText.setJustifyContent(sap.m.FlexJustifyContent.Start);
          oVBoxForText.setJustifyContent(sap.m.FlexJustifyContent.End);

          oVBoxProgressText.addItem(oTextForProgress);
          oVBox.addItem(oProgressIndicator);
          oVBoxForText.addItem(oTextTextForNoOfReqDone);
          // Add the progress indicator to the dialog
          this.oDialogProgress.addContent(oVBoxProgressText);
          this.oDialogProgress.addContent(oVBox);
          this.oDialogProgress.addContent(oVBoxForText);

        }
        if (oAllDownloadedPersent) {
          oRepuestStatu = this.checkoAllRequestDone(oAllDownloadedPersent);
        }
        if (!this.oDialogProgress.isOpen()) {
          // Open the dialog
          this.oDialogProgress.open();
        }
        if (this.oDialogProgress.isOpen() && progressValue) {
          // Open the dialog
          if (progressValue >= 100) {
            this.oDialogProgress.getContent()[1].getItems()[0].setPercentValue(0);
            this.oDialogProgress.getContent()[1].getItems()[0].setDisplayValue("0%");
            this.oDialogProgress.getContent()[2].getItems()[0].setText("[0/0]");
            this.oDialogProgress.close();
          } else {
            this.oDialogProgress.getContent()[1].getItems()[0].setPercentValue(progressValue);
            this.oDialogProgress.getContent()[1].getItems()[0].setDisplayValue(progressValue + "%");
          }
        }
        this.oDialogProgress.getContent()[2].getItems()[0].setText("[" + oRepuestStatu.done + "/" + oRepuestStatu.send + "]");
      },
      /**
       * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
       * @memberOf mobilework.view.Synchronize
       */
      onExit: function () { },

      //---------------------------//
      // EVENT HANDLERS
      //---------------------------//

      onRouteMatched: function () {
        //set connection property
        this.getConnection();
        this.changeColorOfDeviceId();
        this.addPOTiles();

      },

      addPOTiles: function () {
        let synchronizeGrid = this.getView().byId("synchronizeGrid"),
          // sendTStoSap = this.getView().byId("__component0---synchronize--sendTStoSap"),
          // getPurOrder = this.getView().byId("__component0---synchronize--getPurOrder"),
          // deleteallPOs = this.getView().byId("__component0---synchronize--deleteallPOs"),
          sendTStoSap,
          getPurOrder,
          deleteallPOs,
          sharedModel = this.getSharedModel(),
          poActive = sharedModel.getProperty("/sapSettings/POActive"),
          tiles = synchronizeGrid.getContent(),
          allCustomData = [];
        tiles.forEach(function (tile) {
          // Get the custom data objects of the current tile
          var customDataArray = tile.getCustomData();

          // Iterate over each custom data object within the current tile
          customDataArray.forEach(function (customData) {
            // Extract key and value from each custom data object
            var key = customData.getKey();
            var value = customData.getValue();
            if (key === "Key1" && value === "sendTStoSap") {
              sendTStoSap = tile;
            }
            if (key === "Key2" && value === "getPurOrder") {
              getPurOrder = tile;
            }
            if (key === "Key3" && value === "deleteallPOs") {
              deleteallPOs = tile;
            }
            // Store the key-value pair in the allCustomData array
            allCustomData.push({ key: key, value: value });
          });
        });
        // if (
        //   (synchronizeGrid &&
        //   sharedModel &&
        //   !sharedModel.getProperty("/publicRelease"))
        // ) {
        //   if (sendTStoSap) {
        //     let count = synchronizeGrid.indexOfContent(sendTStoSap);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        //   if (getPurOrder) {
        //     let count = synchronizeGrid.indexOfContent(getPurOrder);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //     }
        //   }
        //   if (deleteallPOs) {
        //     let count = synchronizeGrid.indexOfContent(deleteallPOs);
        //     if (count >= 0) {
        //       synchronizeGrid.removeContent(count);
        //       // synchronizeGrid.getContent()[count].destroy();
        //     }
        //   }
        // }
        if ((synchronizeGrid &&
          sharedModel &&
          !sharedModel.getProperty("/publicRelease")) || !poActive) {
          if (sendTStoSap) {
            let count = synchronizeGrid.indexOfContent(sendTStoSap);
            if (count >= 0 && allCustomData.length) {
              // synchronizeGrid.removeContent(count);
              synchronizeGrid.getContent()[count].destroy();
            }
          }
          if (getPurOrder) {
            let count = synchronizeGrid.indexOfContent(getPurOrder);
            if (count >= 0) {
              // synchronizeGrid.removeContent(count);
              synchronizeGrid.getContent()[count].destroy();
            }
          }
          if (deleteallPOs) {
            let count = synchronizeGrid.indexOfContent(deleteallPOs);
            if (count >= 0) {
              // synchronizeGrid.removeContent(count);
              synchronizeGrid.getContent()[count].destroy();
            }
          }
        } else {
          let count1 = synchronizeGrid.indexOfContent(sendTStoSap),
            count2 = synchronizeGrid.indexOfContent(getPurOrder),
            count3 = synchronizeGrid.indexOfContent(deleteallPOs);
          if (count1 < 0 && count2 < 0 && count3 < 0 && allCustomData.length === 0) {
            // synchronizeGrid.getContent().destroy();

            var sendTStoSapTile = new sap.m.GenericTile({
              // id: "__component0---synchronize--sendTStoSap",
              header: "{i18n>sendTStoSap}",
              visible: "{shared>/publicRelease}",
              press: this.onTilePress.bind(this)
            });

            var getPurOrderTile = new sap.m.GenericTile({
              // id: "__component0---synchronize--getPurOrder",
              header: "{i18n>GetPurOrder}",
              press: this.onTilePress.bind(this)
            });

            var deleteallPOsTile = new sap.m.GenericTile({
              // id: "__component0---synchronize--deleteallPOs",
              header: "{i18n>DeassignPOOrders}",
              press: this.onTilePress.bind(this)
            });

            // Adding style class to tiles
            sendTStoSapTile.addStyleClass("sapUiTinyMargin");
            getPurOrderTile.addStyleClass("sapUiTinyMargin");
            //getPurOrderTile.addStyleClass("sapUiTinyMargin");
            deleteallPOsTile.addStyleClass("sapUiTinyMargin");

            var sendTStileContent = new sap.m.TileContent(),
              getPurOrderTileContent = new sap.m.TileContent(),
              deleteallPOsTileContent = new sap.m.TileContent();

            var imageContent1 = new sap.m.ImageContent({
              src: "sap-icon://future"
            });
            var imageContent2 = new sap.m.ImageContent({
              src: "sap-icon://functional-location"
            });
            var imageContent3 = new sap.m.ImageContent({
              src: "sap-icon://paper-plane"
            });
            sendTStileContent.setContent(imageContent1);
            getPurOrderTileContent.setContent(imageContent2);
            deleteallPOsTileContent.setContent(imageContent3);

            sendTStoSapTile.addTileContent(sendTStileContent);
            getPurOrderTile.addTileContent(getPurOrderTileContent);
            deleteallPOsTile.addTileContent(deleteallPOsTileContent);

            var layoutData = new sap.ui.layout.GridData({
              spanS: 6,
              spanM: 4,
              spanL: 3,
              spanXL: 3
            });
            sendTStoSapTile.setLayoutData(layoutData);
            getPurOrderTile.setLayoutData(layoutData);
            deleteallPOsTile.setLayoutData(layoutData);

            sendTStoSapTile.data("Key1", "sendTStoSap");
            getPurOrderTile.data("Key2", "getPurOrder");
            deleteallPOsTile.data("Key3", "deleteallPOs");

            synchronizeGrid.insertContent(sendTStoSapTile, 1);
            synchronizeGrid.insertContent(getPurOrderTile, 3);
            synchronizeGrid.insertContent(deleteallPOsTile, 7);

            // synchronizeGrid.addContent(sendTStoSapTile);
            // synchronizeGrid.addContent(getPurOrderTile);
            // synchronizeGrid.addContent(deleteallPOsTile);

            synchronizeGrid.getContent().forEach(function (content, index) {
              if (content instanceof sap.m.GenericTile) {
                var layoutData = new sap.ui.layout.GridData({
                  // span: "L4 M6 S12" // Adjust span based on desired layout
                  span: "XL3 L3 M4 S6"
                });
                content.setLayoutData(layoutData);
              }
            });


          }
          // if (getPurOrder) {
          //   let count = synchronizeGrid.indexOfContent(getPurOrder);
          //   if (count >= 0) {
          //     synchronizeGrid.removeContent(count);
          //   }
          // }
          // if (deleteallPOs) {
          //   let count = synchronizeGrid.indexOfContent(deleteallPOs);
          //   if (count >= 0) {
          //     synchronizeGrid.removeContent(count);
          //   }
          // }

        }
      },

      onNavBack: function () {
        this.getRouter().navTo("main");
      },

      onTilePress: function (oEvent) {
        var sTileId = oEvent.getSource().getId(),
          sTileHeader = oEvent.getSource().getHeader(),
          sendTStoSap,
          getPurOrder,
          deleteallPOs,
          sendTStoSapHeader,
          getPurOrderHeader,
          deleteallPOsHeader,
          synchronizeGrid = this.getView().byId("synchronizeGrid"),
          sUser = this.getSharedModel().getProperty("/sapSettings/sapUser"),
          sPassword = this.getSharedModel().getProperty("/sapSettings/sapPass"),
          tiles = synchronizeGrid.getContent(),
          allCustomData = [];
        tiles.forEach(function (tile) {
          // Get the custom data objects of the current tile
          var customDataArray = tile.getCustomData();

          // Iterate over each custom data object within the current tile
          customDataArray.forEach(function (customData) {
            // Extract key and value from each custom data object
            var key = customData.getKey();
            var value = customData.getValue();
            if (key === "Key1" && value === "sendTStoSap") {
              sendTStoSap = tile;
            }
            if (key === "Key2" && value === "getPurOrder") {
              getPurOrder = tile;
            }
            if (key === "Key3" && value === "deleteallPOs") {
              deleteallPOs = tile;
            }
            // Store the key-value pair in the allCustomData array
            allCustomData.push({ key: key, value: value });
          });
        });
        sendTStoSapHeader = sendTStoSap ? sendTStoSap.getProperty("header") : sendTStoSap
        getPurOrderHeader = getPurOrder ? getPurOrder.getProperty("header") : getPurOrder;
        deleteallPOsHeader = deleteallPOs ? deleteallPOs.getProperty("header") : deleteallPOs
        if (sTileId.indexOf("deleteallPOs") !== -1 || oEvent.getSource().getHeader() === deleteallPOsHeader) {
          this.deletePoMWX();
          return;
        }
        if (!sUser || !sPassword) {
          MBox.error(this.getText("SettingsMissing"))

          return;
        }

        if (sTileId.indexOf("sendToSap") !== -1) {
          console.info('=====================BEFORE=====================');
          this.getView().byId("sendToSap").setPressEnabled(false);
          setTimeout(
            jQuery.proxy(function () {
              this.getView().byId("sendToSap").setPressEnabled(true);
            }, this),
            5000
          );
        }
        if (sTileId.indexOf("getPurOrder") !== -1 || oEvent.getSource().getHeader() === getPurOrderHeader) {
          // this.getView().byId("getPurOrder").setPressEnabled(false);
          getPurOrder.setPressEnabled(false);
          setTimeout(
            jQuery.proxy(function () {
              // this.getView().byId("getPurOrder").setPressEnabled(true);
              getPurOrder.setPressEnabled(true);
            }, this),
            5000
          );
        }
        if (sTileId.indexOf("sendTStoSap") !== -1 || oEvent.getSource().getHeader() === sendTStoSapHeader) {
          // this.getView().byId("sendTStoSap").setPressEnabled(false);
          sendTStoSap.setPressEnabled(false);
          setTimeout(
            jQuery.proxy(function () {
              // this.getView().byId("sendTStoSap").setPressEnabled(true);
              sendTStoSap.setPressEnabled(true); 6
            }, this),
            5000
          );
        }

        if (
          this.getService() &&
          this.getService().getModel() &&
          this.getService().getModel().oMetadata &&
          this.getService().getModel().oMetadata.bFailed === false
        ) {
          console.error('BEFORE:oMetadata.bFailed: Still going with tile press');

          $.when(this.getService().logoff())
            .done(
              jQuery.proxy(function () {
                this._tilePress(sTileId, sTileHeader);
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                if (
                  oError.responseText !== undefined &&
                  oError.status === 404
                ) {
                  // let sMessage = "No internet connection to handle tile press";
                  let sMessage =
                    "Cannot connect to the server to perform this action"; // oError.responseText;
                  console.error(sMessage);
                  MBox.show(sMessage);
                  return;
                }
              })
            );
        } else {
          this._tilePress(sTileId, sTileHeader);
        }
      },


      onCloseFlDialogPress: function () {
        this._resetInput();
        this.getDialogManager().close(
          "synchronize.AddFunctionalLocation",
          this.getView()
        );
      },

      onExtScanSuccess: function (sChannel, sEvent, oData) {
        if (!oData.result.error) {
          this.getView()
            .getModel("newFl")
            .setProperty("/Scanid", oData.result.barcode);
        } else {
          MBox.error(oData.result.errorMessage);
        }
      },

      onScanFlPress: function () {
        //	this.getScanHandler().onNfcReadNDEF();
        $.when(this.getScanHandler().scan()).done(
          jQuery.proxy(function (oData) {
            this.getView()
              .getModel("newFl")
              .setProperty("/Scanid", oData.text.slice(0, 30)); // max length 30
          }, this)
        );
      },
      onAddFlPress: function () {
        var sId = this.getView().getModel("newFl").getProperty("/Scanid"),
          sGroup = this.getView().getModel("newFl").getProperty("/FLgroup");

        if (sId || sGroup.length > 0) {
          if (sId) {
            sId = sId.toUpperCase();
            this._addFl(sId);
          } else {
            this._addFlGroup(sGroup);
          }
        } else {
          MBox.error(this.getText("EnterFunctionalLocation"));
        }
      },

      onFlLiveChange: function (oEvent) {
        if (oEvent.getParameters().newValue !== "") {
          this.getModel("newFl").setProperty("/singleEntryEnabled", true);
          this.getModel("newFl").setProperty("/groupEntryEnabled", false);
        } else {
          this.getModel("newFl").setProperty("/singleEntryEnabled", true);
          this.getModel("newFl").setProperty("/groupEntryEnabled", true);
        }
      },
      onSyncFlocChange: function (oEvent) {
        var sValue = oEvent.getParameter("newValue");

        if (sValue) {
          this.getView()
            .getModel("newFl")
            .setProperty("/Scanid", sValue.toUpperCase());
        }
      },

      onGroupSelectionChange: function (oEvent) {
        if (oEvent.getSource().getSelectedKeys().length > 0) {
          this.getModel("newFl").setProperty("/groupEntryEnabled", true);
          this.getModel("newFl").setProperty("/singleEntryEnabled", false);
        } else {
          this.getModel("newFl").setProperty("/groupEntryEnabled", true);
          this.getModel("newFl").setProperty("/singleEntryEnabled", true);
        }
      },

      //--------------------------------------
      // CONFIRMORDERDELETE.FRAGMENT.XML
      //--------------------------------------

      onDeleteOrderNoPress: function () {
        this._sendToSap(false);
        this.deletePressNo = true;
        this.getDialogManager().close(
          "synchronize.ConfirmOrderDelete",
          this.getView()
        );
      },

      onDeleteOrderCancelPress: function () {
        this.getDialogManager().close(
          "synchronize.ConfirmOrderDelete",
          this.getView()
        );
      },

      onDeleteOrderAllPress: function () {
        this._sendToSap(true);
        this.getDialogManager().close(
          "synchronize.ConfirmOrderDelete",
          this.getView()
        );
      },

      //---------------------------//
      // PRIVATES
      //---------------------------//

      // _tilePress: function (sTileId) {
      // 	if(sTileId.indexOf("sendToSap") !== -1)
      // 		this.getView().byId('sendToSap').setPressEnabled(false);
      // 	$.when(this.connectionCheckTogiveColour()).done(jQuery.proxy(function(){
      // 		if (sTileId.indexOf("sendToSap") !== -1) {

      // 			   setTimeout(jQuery.proxy(function(){
      // 			        this.getView().byId('sendToSap').setPressEnabled(true);
      // 			    },this), 5000);
      // 			$.when(this._preSendCheck()).done(jQuery.proxy(function (oResult) {
      // 				if (oResult.send) {
      // 					if (oResult.reason) {
      // 						this._confirmBackendNotifications(oResult.reason);
      // 					} else {
      // 						this._sendToSap(true);
      // 					}
      // 				} else {
      // 					switch (oResult.reason) {
      // 					case this.UNCONF:
      // 					case this.UNOPER:
      // 					case this.UNCONF + ";" + this.UNOPER:
      // 						this.getDialogManager().open("synchronize.ConfirmOrderDelete", this.getView());
      // 						break;
      // 					case this.UNFIN:
      // 						MBox.warning(this.getText("UnfinishedConfirmations"));
      // 						break;
      // 					case this.FINCONFMISSINGDATA:
      // 						if (oResult.fields !== "") {
      // 							MBox.warning(this.getText("FinalConfirmationMissingData", oResult.fields));
      // 						}
      // 						break;
      // 					case this.NOTIFMISSINGDATA:
      // 						MBox.warning(this.getText("NotificationMissingData"));
      // 						break;
      // 					case this.NODATA:
      // 						MBox.information(this.getText("NoNotifConfirm"));
      // 						break;
      // 					case this.NOCONFISRUNNING:
      // 						this._sendToSap(null,true);
      // 						break;
      // 					default :
      // 						break;

      // 					}
      _tilePress: async function (sTileId, sTileHeader) {
        var sendTStoSap,
          getPurOrder,
          deleteallPOs,
          sendTStoSapHeader,
          getPurOrderHeader,
          deleteallPOsHeader,
          synchronizeGrid = this.getView().byId("synchronizeGrid"),
          tiles = synchronizeGrid.getContent(),
          allCustomData = [];
        tiles.forEach(function (tile) {
          // Get the custom data objects of the current tile
          var customDataArray = tile.getCustomData();

          // Iterate over each custom data object within the current tile
          customDataArray.forEach(function (customData) {
            // Extract key and value from each custom data object
            var key = customData.getKey();
            var value = customData.getValue();
            if (key === "Key1" && value === "sendTStoSap") {
              sendTStoSap = tile;
            }
            if (key === "Key2" && value === "getPurOrder") {
              getPurOrder = tile;
            }
            if (key === "Key3" && value === "deleteallPOs") {
              deleteallPOs = tile;
            }
            // Store the key-value pair in the allCustomData array
            allCustomData.push({ key: key, value: value });
          });
        });
        sendTStoSapHeader = sendTStoSap ? sendTStoSap.getProperty("header") : sendTStoSap;
        getPurOrderHeader = getPurOrder ? getPurOrder.getProperty("header") : getPurOrder;
        deleteallPOsHeader = deleteallPOs ? deleteallPOs.getProperty("header") : deleteallPOs;

        // Check if service authentication is available, if not show the authentication dialog popup
        // Only execute when you are offline

        if (this.getService() === null) {
          let sMessage = "Please login first";
          console.error(sMessage);
          MBox.show(sMessage);
          return;
        } else if (this.getService()._oModel.oMetadata.bFailed === false)
          await this.getService().checkTokenExpirationForModels();
        else {
          let sMessage = this.getText("No_Internet_Conenction_to_Handle");
          console.error(sMessage);
          MBox.show(sMessage);
          return;
        }

        $.when(this.connectionCheckTogiveColour())
          .done(
            jQuery.proxy(function () {
              console.info('BEFORE:Server is reachable');
              typeof WifiWizard2 !== 'undefined' && WifiWizard2.getConnectedSSID().then((oRes) => { console.info("BEFORE: Name of the wifi connected " + oRes) });
              typeof WifiWizard2 !== 'undefined' && WifiWizard2.getWifiIPInfo().then((oRes) => { console.info("BEFORE: IP address of connected wifi is " + oRes.ip) });
              console.info('=====================BEFORE:END=====================');
              if (sTileId.indexOf("sendToSap") !== -1) {
                $.when(this._preSendCheck()).done(
                  jQuery.proxy(function (oResult) {
                    if (oResult.send) {
                      if (oResult.reason) {
                        this._confirmBackendNotifications(oResult.reason);
                      } else {
                        this._sendToSap(true);
                      }
                    } else {
                      switch (oResult.reason) {
                        case this.UNCONF:
                        case this.UNOPER:
                        case this.UNCONF + ";" + this.UNOPER:
                          this.getDialogManager().open(
                            "synchronize.ConfirmOrderDelete",
                            this.getView()
                          );
                          break;
                        case this.UNFIN:
                          MBox.warning(this.getText("UnfinishedConfirmations"));
                          break;
                        case this.FINCONFMISSINGDATA:
                          if (oResult.fields !== "") {
                            MBox.warning(
                              this.getText(
                                "FinalConfirmationMissingData",
                                oResult.fields
                              )
                            );
                          }
                          break;
                        case this.NOTIFMISSINGDATA:
                          MBox.warning(this.getText("NotificationMissingData"));
                          break;
                        case this.NODATA:
                          MBox.information(this.getText("NoNotifConfirm"));
                          break;
                        case this.NOCONFISRUNNING:
                          this._sendToSap(false);
                          break;
                        default:
                          break;
                      }
                    }
                  }, this)
                );
              } else if (sTileId.indexOf("getOrders") !== -1) {
                this._getOrders();
              } else if (sTileId.indexOf("getFL") !== -1) {
                //set scanner location
                this.getScanHandler().setLocation("FunctionalLocation");
                this._getFL();
              } else if (sTileId.indexOf("deleteFL") !== -1) {
                this._deleteAllFL();
              } else if (sTileId.indexOf("deassignAllOrders") !== -1) {
                this._deassignAllOrders();
              } else if (sTileId.indexOf("getPurOrder") !== -1 || sTileHeader === getPurOrderHeader) {
                this._getPurOrder();
              } else if (sTileId.indexOf("sendTStoSap") !== -1 || sTileHeader === sendTStoSapHeader) {
                this.sendTStoSap();
              }
            }, this)
          )
          .fail(jQuery.proxy(function () { }, this));
      },

      _preSendCheck: function () {
        var oPromNotif,
          oPromConf,
          oPromOper,
          oPromOrder,
          d = jQuery.Deferred(),
          oPromTimeSheet = null;

        // Get master data
        oPromNotif = this.getDBService().getEntitySet("PMNotification");
        oPromConf = this.getDBService().getEntitySet("Confirmation");
        oPromOper = this.getDBService().getEntitySet("Operation");
        oPromOrder = this.getDBService().getEntitySet("PMOrder");

        if (this.getSharedModel().getProperty("/publicRelease")) {
          oPromTimeSheet = this.getDBService().getEntitySet("PlanItem");
        }

        $.when(oPromNotif, oPromConf, oPromOper, oPromOrder, oPromTimeSheet)
          .done(
            jQuery.proxy(function (
              oNotifs,
              oConfs,
              oOpers,
              oOrders,
              oTimeSheet
            ) {
              var aNotifications,
                aConfirmations,
                aOperations,
                aUnfinished,
                aOrders,
                oResult = {
                  send: true,
                  reason: null,
                  fields: "",
                },
                oSapSetting = this.getSharedModel().getProperty("/sapSettings");

              // Convert objects to arrays
              aNotifications = this.getHelper().rowsToArray(oNotifs);
              aConfirmations = this.getHelper().rowsToArray(oConfs);
              aOperations = this.getHelper().rowsToArray(oOpers);
              aOrders = this.getHelper().rowsToArray(oOrders);
              this.aUnconfirmedConf = [];
              this.aUnconfirmedOperations = [];
              this.aUnconfirmedOrders = [];
              this.aFinalConfirmedOrders = [];
              this.hidePopUp = true;
              this.pending = false;
              this.aFinalConfirmedOper = [];
              this.deletePressNo = false;

              // System Log
              console.info("Server Reached and Connection Status is Ok");
              typeof WifiWizard2 !== 'undefined' && WifiWizard2.getConnectedSSID().then((oRes) => { console.info("Name of the wifi connected " + oRes) });
              typeof WifiWizard2 !== 'undefined' && WifiWizard2.getWifiIPInfo().then((oRes) => { console.info("IP address of connected wifi is " + oRes.ip) });

              // Check if there is data to sync (only conf & notif are relevant)
              if (
                aNotifications &&
                aConfirmations &&
                (aNotifications.length > 0 || aConfirmations.length > 0)
              ) {
                // Final confirmation, make sure damage code, causecode and breakdown details are entered on corresponding notification.
                var aFinConf = _.filter(aConfirmations, function (oConf) {
                  return oConf.FinConf === true || oConf.FinConf === "true";
                });

                if (aFinConf.length > 0) {
                  _.each(
                    aFinConf,
                    jQuery.proxy(function (oConf) {
                      var oCorrespondingNotif = _.find(
                        aNotifications,
                        function (oNotif) {
                          return (
                            oNotif.Handle && oNotif.Handle === oConf.NotifHandle
                          );
                        }
                      );

                      var oCorrespondingOrder = _.find(
                        aOrders,
                        function (oOrder) {
                          return oOrder.Orderid === oConf.Aufnr;
                        }
                      );

                      var sFields = "";

                      if (oCorrespondingNotif) {
                        if (oCorrespondingOrder) {
                          if (
                            (!oCorrespondingNotif.Fecod &&
                              oCorrespondingOrder.ConfMDmg === "true") ||
                            (!oCorrespondingNotif.Urcod &&
                              oCorrespondingOrder.ConfMCse === "true") ||
                            (!oCorrespondingNotif.AusbsDatetime &&
                              oCorrespondingOrder.ConfMBrd === "true")
                          ) {
                            if (
                              !oCorrespondingNotif.Fecod &&
                              oCorrespondingOrder.ConfMDmg === "true" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME" ||
                                oCorrespondingNotif.Qmart === "40,RED")
                            ) {
                              sFields += this.getText("Fecod") + ", ";
                            }

                            if (
                              !oCorrespondingNotif.Urcod &&
                              oCorrespondingOrder.ConfMCse === "true" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME" ||
                                oCorrespondingNotif.Qmart === "40,RED")
                            ) {
                              sFields += this.getText("Urcod") + ", ";
                            }

                            if (
                              !oCorrespondingNotif.AusbsDatetime &&
                              oCorrespondingOrder.ConfMBrd === "true" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME")
                            ) {
                              sFields += this.getText("AusbsDatetime") + ", ";
                            }
                            sFields = sFields.slice(0, -2);
                            if (sFields) {
                              oResult.send = false;
                              oResult.reason = this.FINCONFMISSINGDATA;
                              oResult.fields = sFields;
                              d.resolve(oResult);
                              return;
                            }
                          }
                        } else {
                          if (
                            (!oCorrespondingNotif.Fecod &&
                              oSapSetting.CONF_M_DMG === "X") ||
                            (!oCorrespondingNotif.Urcod &&
                              oSapSetting.CONF_M_CSE === "X") ||
                            (!oCorrespondingNotif.AusbsDatetime &&
                              oSapSetting.CONF_M_BRD === "X")
                          ) {
                            if (
                              !oCorrespondingNotif.Fecod &&
                              oSapSetting.CONF_M_DMG === "X" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME" ||
                                oCorrespondingNotif.Qmart === "40,RED")
                            ) {
                              sFields += this.getText("Fecod") + ", ";
                            }

                            if (
                              !oCorrespondingNotif.Urcod &&
                              oSapSetting.CONF_M_CSE === "X" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME" ||
                                oCorrespondingNotif.Qmart === "40,RED")
                            ) {
                              sFields += this.getText("Urcod") + ", ";
                            }

                            if (
                              !oCorrespondingNotif.AusbsDatetime &&
                              oSapSetting.CONF_M_BRD === "X" &&
                              (oCorrespondingNotif.Qmart === "30,DEFE" ||
                                oCorrespondingNotif.Qmart === "30,IMME")
                            ) {
                              sFields += this.getText("AusbsDatetime") + ", ";
                            }

                            sFields = sFields.slice(0, -2);
                            if (sFields) {
                              oResult.send = false;
                              oResult.reason = this.FINCONFMISSINGDATA;
                              oResult.fields = sFields;
                              d.resolve(oResult);
                              return;
                            }
                          }
                        }
                      }
                    }, this)
                  );
                }

                // Check if there are unfinished confirmations

                this.aUnconfirmedConf = this.aUnconfirmedConf.concat(
                  _.filter(aConfirmations, {
                    Split: "false",
                    IsFinished: "false",
                  }).map(function (aConfirmation) {
                    return aConfirmation.Handle;
                  })
                );
                var splitTodelete = _.filter(aConfirmations, {
                  Split: "true",
                });
                splitTodelete.forEach(
                  jQuery.proxy(function (dConf) {
                    var asplitConfTobeDeleted = _.filter(aConfirmations, {
                      ParentHndl: dConf.Handle,
                      IsFinished: "false",
                    }).map(function (aConfirmation) {
                      return aConfirmation.ParentHndl;
                    });
                    if (asplitConfTobeDeleted.length > 0) {
                      //this.splitLength--;
                      this.aUnconfirmedConf = this.aUnconfirmedConf.concat(
                        asplitConfTobeDeleted
                      );
                    }
                  }, this)
                );
                _.uniqBy(this.aUnconfirmedConf);
                d.resolve(
                  this._checkOperationsConfirmed(
                    aConfirmations,
                    aOperations,
                    aOrders,
                    aNotifications
                  )
                );
              } else {
                oTimeSheet = this.getHelper().rowsToArray(oTimeSheet);
                if (
                  this.getSharedModel().getProperty("/publicRelease") &&
                  oTimeSheet.length > 0
                ) {
                  d.resolve(oResult);
                  return;
                } else {
                  oResult.send = false;
                  oResult.reason = this.NODATA;
                  d.resolve(oResult);
                  return;
                }
              }
            },
              this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              MBox.error(this.getText("ErrorMasterDataRetrieve"));
            }, this)
          );

        return d.promise();
      },

      _addFl: function (sId) {
        this.getView().getModel("newFl").setProperty("/dialogBusy", true);

        var bEnableDownloadBoms = this.getSharedModel().getProperty(
          "/sapSettings/enableDownloadBoms"
        );

        var aNavCraft = [],
          aNAVTechFloc = [],
          aNavBom = [],
          aNavImpact = [],
          oAllDownloadedPersent = {};

        var bInactiveFloc = true;

        $.when(
          this.getDBService().getScanId(sId),
          this.getOwnerComponent().sqlDataBaseUpdate()
        )
          .done(
            jQuery.proxy(function (oDBResultId) {
              if (oDBResultId.rows.length > 0) {
                oAllDownloadedPersent[sId] = 0;
                // Installation Tree is already in DB: get from DB
                this.showDialogWithProgressBar(null, oAllDownloadedPersent);
                $.when(
                  this.getService().getInstallationTreeSet(
                    "Scanid",
                    sId,
                    bEnableDownloadBoms,
                    1,
                    1
                  )
                )
                  .done(
                    jQuery.proxy(function (oDataTree) {
                      oAllDownloadedPersent[sId + "length"] = oDataTree.results.length;
                      if (oDataTree.results.length > 0) {
                        for (var i = 0; i < oDataTree.results.length; i++) {
                          if (oDataTree.results[i].TechObjectType === "EQ") {
                            oDataTree.results[i].Tplnr =
                              oDataTree.results[i].Equnr;
                          }
                          if (
                            oDataTree.results[i].NavCraft.results.length > 0
                          ) {
                            for (var y in oDataTree.results[i].NavCraft
                              .results) {
                              aNavCraft.push(
                                oDataTree.results[i].NavCraft.results[y]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].NAVTechFloc.results.length > 0
                          ) {
                            for (var x in oDataTree.results[i].NAVTechFloc
                              .results) {
                              aNAVTechFloc.push(
                                oDataTree.results[i].NAVTechFloc.results[x]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].BomDataSet.results.length > 0
                          ) {
                            for (var z in oDataTree.results[i].BomDataSet
                              .results) {
                              aNavBom.push(
                                oDataTree.results[i].BomDataSet.results[z]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].NavImpact.results.length > 0
                          ) {
                            for (var z in oDataTree.results[i].NavImpact
                              .results) {
                              aNavImpact.push(
                                oDataTree.results[i].NavImpact.results[z]
                              );
                            }
                          }
                          if (oDataTree.results[i].Tplnr === sId) {
                            bInactiveFloc = false;
                          }
                        }

                        if (bInactiveFloc === false) {
                          $.when(
                            this._downloadLowerFl(
                              oDataTree,
                              0,
                              aNavCraft,
                              [],
                              2,
                              aNAVTechFloc,
                              aNavBom,
                              aNavImpact,
                              [],
                              oAllDownloadedPersent
                            )
                          ).done(
                            jQuery.proxy(function () {
                              $.when(
                                this.getDBService().updateInstallationTree(
                                  sId,
                                  oDataTree.results
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocCraft",
                                  aNavCraft
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocOrg",
                                  aNAVTechFloc
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "BomData",
                                  aNavBom
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocImpact",
                                  aNavImpact
                                )
                              )
                                .done(
                                  jQuery.proxy(function () {
                                    this.getView()
                                      .getModel("newFl")
                                      .setProperty("/dialogBusy", false);
                                    this._resetInput();
                                    this.getLogs().addLog(
                                      this.getText("TreeAddedToDb"),
                                      "INFO",
                                      "Synchronize"
                                    );
                                    MBox.success(this.getText("TreeAddedToDb"));
                                  }, this)
                                )
                                .fail(
                                  jQuery.proxy(function () {
                                    this.getView()
                                      .getModel("newFl")
                                      .setProperty("/dialogBusy", false);
                                    MBox.error(
                                      this.getText("InstallationTreeError")
                                    );
                                    this.getLogs().addLog(
                                      this.getText("InstallationTreeError"),
                                      "ERROR",
                                      "Synchronize"
                                    );
                                  }, this)
                                );
                            }, this)
                          );
                        } else {
                          this.getView()
                            .getModel("newFl")
                            .setProperty("/dialogBusy", false);
                          MBox.error(this.getText("FlHasWrongStatus"));
                          this.getLogs().addLog(
                            this.getText("FlHasWrongStatus"),
                            "ERROR",
                            "Synchronize"
                          );
                        }
                      } else {
                        this.getView()
                          .getModel("newFl")
                          .setProperty("/dialogBusy", false);
                        this.getLogs().addLog(
                          this.getText("NoFlFoundForID"),
                          "ERROR",
                          "Synchronize"
                        );
                        MBox.error(this.getText("NoFlFoundForID"));
                      }
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      this.getView()
                        .getModel("newFl")
                        .setProperty("/dialogBusy", false);
                      MBox.error(this.getText("InstallationTreeError"));
                      this.getLogs().addLog(
                        this.getText("InstallationTreeError"),
                        "ERROR",
                        "Synchronize"
                      );
                    }, this)
                  );
              } else {
                oAllDownloadedPersent[sId] = 0;
                // Get Installation Tree via Service and add to DB
                $.when(
                  this.getService().getInstallationTreeSet(
                    "Scanid",
                    sId,
                    bEnableDownloadBoms,
                    1,
                    1
                  )
                )
                  .done(
                    jQuery.proxy(function (oDataTree) {
                      oAllDownloadedPersent[sId + "length"] = oDataTree.results.length;
                      if (oDataTree.results.length > 0) {
                        for (var i = 0; i < oDataTree.results.length; i++) {
                          if (oDataTree.results[i].TechObjectType === "EQ") {
                            oDataTree.results[i].Tplnr =
                              oDataTree.results[i].Equnr;
                          }
                          if (
                            oDataTree.results[i].NavCraft.results.length > 0
                          ) {
                            for (var y in oDataTree.results[i].NavCraft
                              .results) {
                              aNavCraft.push(
                                oDataTree.results[i].NavCraft.results[y]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].NAVTechFloc.results.length > 0
                          ) {
                            for (var z in oDataTree.results[i].NAVTechFloc
                              .results) {
                              aNAVTechFloc.push(
                                oDataTree.results[i].NAVTechFloc.results[z]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].BomDataSet.results.length > 0
                          ) {
                            for (var x in oDataTree.results[i].BomDataSet
                              .results) {
                              aNavBom.push(
                                oDataTree.results[i].BomDataSet.results[x]
                              );
                            }
                          }
                          if (
                            oDataTree.results[i].NavImpact.results.length > 0
                          ) {
                            for (var x in oDataTree.results[i].NavImpact
                              .results) {
                              aNavImpact.push(
                                oDataTree.results[i].NavImpact.results[x]
                              );
                            }
                          }
                          if (oDataTree.results[i].Tplnr === sId) {
                            bInactiveFloc = false;
                          }
                        }

                        if (bInactiveFloc === false) {
                          $.when(
                            this._downloadLowerFl(
                              oDataTree,
                              0,
                              aNavCraft,
                              [],
                              2,
                              aNAVTechFloc,
                              aNavBom,
                              aNavImpact,
                              [],
                              oAllDownloadedPersent
                            )
                          ).done(
                            jQuery.proxy(function () {
                              $.when(
                                this.getDBService().updateInstallationTree(
                                  sId,
                                  oDataTree.results
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocCraft",
                                  aNavCraft
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocOrg",
                                  aNAVTechFloc
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "BomData",
                                  aNavBom
                                ),
                                this.getDBService().saveMultipleReplace(
                                  "FuncLocImpact",
                                  aNavImpact
                                )
                              )
                                .done(
                                  jQuery.proxy(function () {
                                    this.getView()
                                      .getModel("newFl")
                                      .setProperty("/dialogBusy", false);
                                    this._resetInput();
                                    MBox.success(this.getText("TreeAddedToDb"));
                                    this.getLogs().addLog(
                                      this.getText("TreeAddedToDb"),
                                      "INFO",
                                      "Synchronize"
                                    );
                                  }, this)
                                )
                                .fail(
                                  jQuery.proxy(function () {
                                    this.getView()
                                      .getModel("newFl")
                                      .setProperty("/dialogBusy", false);
                                    MBox.error(
                                      this.getText("InstallationTreeError")
                                    );
                                    this.getLogs().addLog(
                                      this.getText("InstallationTreeError"),
                                      "ERROR",
                                      "Synchronize"
                                    );
                                  }, this)
                                );
                            }, this)
                          );
                        } else {
                          this.getView()
                            .getModel("newFl")
                            .setProperty("/dialogBusy", false);
                          MBox.error(this.getText("FlHasWrongStatus"));
                          this.getLogs().addLog(
                            this.getText("FlHasWrongStatus"),
                            "ERROR",
                            "Synchronize"
                          );
                        }
                      } else {
                        this.getView()
                          .getModel("newFl")
                          .setProperty("/dialogBusy", false);
                        MBox.error(this.getText("NoFlFoundForID"));
                        this.getLogs().addLog(
                          this.getText("NoFlFoundForID"),
                          "ERROR",
                          "Synchronize"
                        );
                      }
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function () {
                      this.getView()
                        .getModel("newFl")
                        .setProperty("/dialogBusy", false);
                      MBox.error(this.getText("InstallationTreeError"));
                      this.getLogs().addLog(
                        this.getText("InstallationTreeError"),
                        "ERROR",
                        "Synchronize"
                      );
                    }, this)
                  );
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function () {
              this.getView()
                .getModel("newFl")
                .setProperty("/dialogBusy", false);
              MBox.error(this.getText("InstallationTreeError"));
              this.getLogs().addLog(
                this.getText("InstallationTreeError"),
                "ERROR",
                "Synchronize"
              );
            }, this)
          );
      },

      _downloadLowerFl: function (
        oDataTree,
        iIndex,
        aNavCraft,
        aDoneFl,
        iCall,
        aNAVTechFloc,
        aNavBom,
        aNavImpact,
        oAllDownloadedFLs,
        oAllDownloadedPersent
      ) {
        var d = $.Deferred();

        var aNavCraftCurrent = [],
          aNavTechFlocCurrent = [],
          aNavBomCurrent = [],
          aNavImpactCurrent = [];
        console.info("no of reqeust sent", iIndex);
        var bInactiveFloc = true,
          bEnableDownloadBoms = this.getSharedModel().getProperty(
            "/sapSettings/enableDownloadBoms"
          );
        let oGroupName = oDataTree.results.find((obj) => {
          return obj.Groupname;
        }),
          oTotal = 0,
          oTotalDone = 0;
        if (oGroupName) {
          if (oAllDownloadedPersent.hasOwnProperty(oGroupName.Groupname)) {
            oAllDownloadedPersent[oGroupName.Groupname] = iIndex;
            console.info(oAllDownloadedPersent);
          }
          for (let key in oAllDownloadedPersent) {
            if (key.includes("length")) {
              oTotal += Number(oAllDownloadedPersent[key]);
              oTotalDone += Number(oAllDownloadedPersent[key.split("length")[0]]);
            }
          }
        }
        else {
          oTotal = oDataTree.results.length - 1;
          oTotalDone = iIndex;
        }
        this.showDialogWithProgressBar(((Number(oTotalDone) / Number(oTotal)) * 100).toFixed(), oAllDownloadedPersent);
        if (iIndex < oDataTree.results.length) {
          if (
            oDataTree.results[iIndex].Tplnr !== "" &&
            oDataTree.results[iIndex].TechObjectType === "FL"
          ) {
            var oAlreadyDone = _.find(aDoneFl, function (oFl) {
              return oFl === oDataTree.results[iIndex].Tplnr;
            });
            let oCanBeSkipped = oAllDownloadedFLs.indexOf(oDataTree.results[iIndex].Tplnr) === -1 ? true : false;
            if (!oAlreadyDone && oCanBeSkipped) {
              aDoneFl.push(oDataTree.results[iIndex].Tplnr);

              $.when(
                this.getService().getInstallationTreeSet(
                  "Scanid",
                  oDataTree.results[iIndex].Tplnr,
                  bEnableDownloadBoms,
                  99,
                  iCall
                )
              )
                .done(
                  jQuery.proxy(function (oDataTree2) {
                    if (oDataTree2.results.length > 0) {
                      for (var j = 0; j < oDataTree2.results.length; j++) {
                        if (oDataTree2.results[j].TechObjectType === "EQ") {
                          oDataTree2.results[j].Tplnr =
                            oDataTree2.results[j].Equnr;
                        }
                        if (oDataTree2.results[j].NavCraft.results.length > 0) {
                          for (var y in oDataTree2.results[j].NavCraft
                            .results) {
                            aNavCraft.push(
                              oDataTree2.results[j].NavCraft.results[y]
                            );
                            aNavCraftCurrent.push(
                              oDataTree2.results[j].NavCraft.results[y]
                            );
                          }
                        }

                        if (
                          oDataTree2.results[j].NAVTechFloc.results.length > 0
                        ) {
                          for (var z in oDataTree2.results[j].NAVTechFloc
                            .results) {
                            aNAVTechFloc.push(
                              oDataTree2.results[j].NAVTechFloc.results[z]
                            );
                            aNavTechFlocCurrent.push(
                              oDataTree2.results[j].NAVTechFloc.results[z]
                            );
                          }
                        }
                        if (
                          oDataTree2.results[j].BomDataSet.results.length > 0
                        ) {
                          for (var x in oDataTree2.results[j].BomDataSet
                            .results) {
                            aNavBom.push(
                              oDataTree2.results[j].BomDataSet.results[x]
                            );
                            aNavBomCurrent.push(
                              oDataTree2.results[j].BomDataSet.results[x]
                            );
                          }
                        }
                        if (
                          oDataTree2.results[j].NavImpact.results.length > 0
                        ) {
                          for (var x in oDataTree2.results[j].NavImpact
                            .results) {
                            aNavImpact.push(
                              oDataTree2.results[j].NavImpact.results[x]
                            );
                            aNavImpactCurrent.push(
                              oDataTree2.results[j].NavImpact.results[x]
                            );
                          }
                        }
                        if (
                          oDataTree2.results[j].Tplnr ===
                          oDataTree.results[iIndex].Tplnr
                        ) {
                          bInactiveFloc = false;
                        }

                      }
                      oDataTree2.results.forEach((obj) => {
                        oAllDownloadedFLs.push(obj.Tplnr);
                      });
                      //this.getDBService().saveFlocCraft(aNavCraft);
                      if (bInactiveFloc === false) {
                        $.when(
                          this.getDBService().updateInstallationTree(
                            oDataTree.results[iIndex].Tplnr,
                            oDataTree2.results
                          ),
                          this.getDBService().saveMultipleReplace(
                            "FuncLocCraft",
                            aNavCraftCurrent
                          ),
                          this.getDBService().saveMultipleReplace(
                            "FuncLocOrg",
                            aNavTechFlocCurrent
                          ),
                          this.getDBService().saveMultipleReplace(
                            "BomData",
                            aNavBomCurrent
                          ),
                          this.getDBService().saveMultipleReplace(
                            "FuncLocImpact",
                            aNavImpactCurrent
                          )
                        )
                          .done(
                            jQuery.proxy(function (oData) {
                              // this.getSharedModel().setProperty("/FuncLocCraft", aNavCraft);
                              // this.getView().getModel("newFl").setProperty("/dialogBusy", false);
                              // this._resetInput();
                              // MBox.success(this.getText("TreeAddedToDb"));
                              iIndex++;
                              $.when(
                                this._downloadLowerFl(
                                  oDataTree,
                                  iIndex,
                                  aNavCraft,
                                  aDoneFl,
                                  iCall,
                                  aNAVTechFloc,
                                  aNavBom,
                                  aNavImpact,
                                  oAllDownloadedFLs,
                                  oAllDownloadedPersent
                                )
                              ).done(
                                jQuery.proxy(function () {
                                  d.resolve(oAllDownloadedPersent);
                                }, this)
                              );
                            }, this)
                          )
                          .fail(
                            jQuery.proxy(function (oError) {
                              iIndex++;
                              $.when(
                                this._downloadLowerFl(
                                  oDataTree,
                                  iIndex,
                                  aNavCraft,
                                  aDoneFl,
                                  iCall,
                                  aNAVTechFloc,
                                  aNavBom,
                                  aNavImpact,
                                  oAllDownloadedFLs,
                                  oAllDownloadedPersent
                                )
                              ).done(
                                jQuery.proxy(function () {
                                  d.resolve(oAllDownloadedPersent);
                                }, this)
                              );
                              // this.getView().getModel("newFl").setProperty("/dialogBusy", false);
                              // MBox.error(this.getText("InstallationTreeError"));
                            }, this)
                          );
                      } else {
                        iIndex++;
                        $.when(
                          this._downloadLowerFl(
                            oDataTree,
                            iIndex,
                            aNavCraft,
                            aDoneFl,
                            iCall,
                            aNAVTechFloc,
                            aNavBom,
                            aNavImpact,
                            oAllDownloadedFLs,
                            oAllDownloadedPersent
                          )
                        ).done(
                          jQuery.proxy(function () {
                            d.resolve(oAllDownloadedPersent);
                          }, this)
                        );
                        // this.getView().getModel("newFl").setProperty("/dialogBusy", false);
                        // MBox.error(this.getText("FlHasWrongStatus"));
                      }
                    } else {
                      iIndex++;
                      $.when(
                        this._downloadLowerFl(
                          oDataTree,
                          iIndex,
                          aNavCraft,
                          aDoneFl,
                          iCall,
                          aNAVTechFloc,
                          aNavBom,
                          aNavImpact,
                          oAllDownloadedFLs,
                          oAllDownloadedPersent
                        )
                      ).done(
                        jQuery.proxy(function () {
                          d.resolve(oAllDownloadedPersent);
                        }, this)
                      );
                      // this.getView().getModel("newFl").setProperty("/dialogBusy", false);
                      // MBox.error(this.getText("NoFlFoundForID"));
                    }
                  }, this)
                )
                .fail(
                  jQuery.proxy(function () {
                    iIndex++;
                    $.when(
                      this._downloadLowerFl(
                        oDataTree,
                        iIndex,
                        aNavCraft,
                        aDoneFl,
                        iCall,
                        aNAVTechFloc,
                        aNavBom,
                        aNavImpact,
                        oAllDownloadedFLs,
                        oAllDownloadedPersent
                      )
                    ).done(
                      jQuery.proxy(function () {
                        d.resolve(oAllDownloadedPersent);
                      }, this)
                    );
                    // this.getView().getModel("newFl").setProperty("/dialogBusy", false);
                    // MBox.error(this.getText("InstallationTreeError"));
                  }, this)
                );
            } else {
              iIndex++;
              $.when(
                this._downloadLowerFl(
                  oDataTree,
                  iIndex,
                  aNavCraft,
                  aDoneFl,
                  iCall,
                  aNAVTechFloc,
                  aNavBom,
                  aNavImpact,
                  oAllDownloadedFLs,
                  oAllDownloadedPersent
                )
              ).done(
                jQuery.proxy(function () {
                  d.resolve(oAllDownloadedPersent);
                }, this)
              );
            }
          } else {
            iIndex++;
            $.when(
              this._downloadLowerFl(
                oDataTree,
                iIndex,
                aNavCraft,
                aDoneFl,
                iCall,
                aNAVTechFloc,
                aNavBom,
                aNavImpact,
                oAllDownloadedFLs,
                oAllDownloadedPersent
              )
            ).done(
              jQuery.proxy(function () {
                d.resolve(oAllDownloadedPersent);
              }, this)
            );
          }
        } else {
          this.getSharedModel().setProperty("/FuncLocCraft", aNavCraft);
          this.getSharedModel().setProperty("/FuncLocOrg", aNAVTechFloc);
          this.getSharedModel().setProperty("/BomData", aNavBom);
          this.getSharedModel().setProperty("/FuncLocImpact", aNavImpact);
          this.getView().getModel("newFl").setProperty("/dialogBusy", false);
          this._resetInput();
          // MBox.success(this.getText("TreeAddedToDb"));
          d.resolve(oAllDownloadedPersent);
        }

        return d.promise();
      },

      _addFlGroup: function (aGroup) {
        var aTechObjGroup = aGroup;

        var bEnableDownloadBoms = this.getSharedModel().getProperty(
          "/sapSettings/enableDownloadBoms"
        );

        var aNavCraft = [],
          aNAVTechFloc = [],
          aNavBom = [],
          aNavImpact = [],
          oAllDownloadedPersent = {},
          oAllFLGroupData = [],
          noOfReqSent = 0,
          noOfReqDone = 0;

        var bInactiveFloc = true;

        for (var i in aTechObjGroup) {
          //this.getView().getModel("newFl").setProperty("/dialogBusy", true);
          oAllDownloadedPersent[aTechObjGroup[i]] = 0;
          noOfReqSent++;
          this.showDialogWithProgressBar(null, oAllDownloadedPersent);
          $.when(
            this.getService().getInstallationTreeSet(
              "Groupname",
              aTechObjGroup[i],
              bEnableDownloadBoms,
              1,
              1
            ),
            this.getOwnerComponent().sqlDataBaseUpdate()
          )
            .done(
              jQuery.proxy(function (oDataTree) {
                noOfReqDone++;
                if (oDataTree.results.length > 0) {
                  let oGroupName = oDataTree.results.find((obj) => {
                    return obj.Groupname;
                  });
                  oAllDownloadedPersent[oGroupName.Groupname + "length"] = oDataTree.results.length;
                  oAllFLGroupData.push(oDataTree);
                  /*for (var j = 0; j < oDataTree.results.length; j++) {
                if (oDataTree.results[j].Type === "E") {
                  oDataTree.results[j].Tplnr = oDataTree.results[j].Equnr;
                }
              }*/
                  if (noOfReqDone === noOfReqSent) {
                    for (let oRes = 0; oRes < oAllFLGroupData.length; oRes++) {
                      this.makeFLCall(oAllFLGroupData[oRes], aNavCraft, aNAVTechFloc, aNavBom, aNavImpact, oAllDownloadedPersent);
                    }
                  }
                } else {
                  this.getView()
                    .getModel("newFl")
                    .setProperty("/dialogBusy", false);
                  MBox.error(this.getText("NoFlFoundForID"));
                  this.getLogs().addLog(
                    this.getText("NoFlFoundForID"),
                    "ERROR",
                    "Synchronize"
                  );
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (error) {
                this.getView()
                  .getModel("newFl")
                  .setProperty("/dialogBusy", false);
                this.getLogs().addLog(error.message, "ERROR", "Synchronize");
                this.getLogs().addLog(
                  JSON.stringify(error),
                  "ERROR",
                  "Synchronize"
                );
                MBox.error(this.getText("InstallationTreeError"));
                MBox.error(error.message.toString());
              }, this)
            );
        }
      },
      makeFLCall: function (oDataTree, aNavCraft, aNAVTechFloc, aNavBom, aNavImpact, oAllDownloadedPersent) {
        let isMessageShow = false;
        $.when(
          this._downloadLowerFl(
            oDataTree,
            0,
            aNavCraft,
            [],
            2,
            aNAVTechFloc,
            aNavBom,
            aNavImpact,
            [],
            oAllDownloadedPersent
          )
        ).done(
          jQuery.proxy(function (oAllDownloadedPersent) {
            //$.when(this.getDBService().insertInstallationTree(aTechObjGroup[i], oDataTree.results))
            let oFLocGroup = oDataTree.results.find((obj) => {
              return obj.Groupname;
            });
            $.when(
              this.getDBService().updateInstallationTree(
                oFLocGroup.Groupname,//aTechObjGroup[i],
                oDataTree.results
              )
            )
              .done(
                jQuery.proxy(function () {
                  this.getView()
                    .getModel("newFl")
                    .setProperty("/dialogBusy", false);
                  this._resetInput();
                  let oRepuestStatu = {};
                  if (oAllDownloadedPersent) {
                    oRepuestStatu = this.checkoAllRequestDone(oAllDownloadedPersent);
                  }
                  if (oRepuestStatu.done === oRepuestStatu.send && !isMessageShow) {
                    isMessageShow = true;
                    MBox.success(this.getText("TreeAddedToDb"));
                  }
                  this.getLogs().addLog(
                    this.getText("TreeAddedToDb"),
                    "INFO",
                    "Synchronize"
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function (error) {
                  this.getView()
                    .getModel("newFl")
                    .setProperty("/dialogBusy", false);
                  MBox.error(this.getText("InstallationTreeError"));
                  this.getLogs().addLog(
                    this.getText("InstallationTreeError"),
                    "ERROR",
                    "Synchronize"
                  );
                }, this)
              );
          }, this)
        );
      },
      _checkOperationsConfirmed: function (aConf, aOper, aOrder, aNotif) {
        // Incoming params are data from db
        var oResult = {
          send: true,
          reason: "",
        };

        var aIncorrectOperations = [];

        aOrder.forEach(
          function (oOrder) {
            // for each order check if there exists a confirmation
            var aConfByOrder = _.filter(aConf, {
              Aufnr: oOrder.Orderid,
              IsFinished: "true",
            }),
              UncofirmedOperForOrders = [],
              finalConfByOrder = [];
            this.noCostOper = [];
            finalConfByOrder = _.filter(aConfByOrder, {
              FinConf: "true",
              Vornr: "",
            });
            var stillRunningOrder = _.filter(aConf, {
              Split: "false",
              IsFinished: "false",
              Aufnr: oOrder.Orderid,
            });
            // purpleConfByOrder=_.filter(aConf, {
            // 	FinConf: "true"
            // });
            if (stillRunningOrder.length === 0) {
              this.aFinalConfirmedOrders = this.aFinalConfirmedOrders.concat(
                finalConfByOrder.map(function (aConfirmation) {
                  return aConfirmation.Aufnr;
                })
              );
              // this.aFinalConfirmedOrders = finalConfByOrder.reduce(function(result, aConfirmation) {
              // 	  if (aConfirmation.Vornr==="") {
              // 	    result.push(aConfirmation.Aufnr);
              // 	  }
              // 	  return result;
              // 	}, []);
            } else {
              if (finalConfByOrder.length > 0) {
                this.aUnconfirmedConf = this.aUnconfirmedConf.concat(
                  aConfByOrder.map(function (cConf) {
                    return cConf.Handle;
                  })
                );
                this.pending = true;
              }
            }

            // if non are found, add order id to unconfirmed orders
            if (!aConfByOrder || aConfByOrder.length === 0) {
              this.aUnconfirmedOrders.push(oOrder.Orderid);
              // also add the corresponding operations
              this.aUnconfirmedOperations = this.aUnconfirmedOperations.concat(
                _.filter(aOper, {
                  Orderid: oOrder.Orderid,
                }).map(function (oOper) {
                  return oOper.Handle;
                })
              );
            }
            // if a confirm. is found, check if all operations are confirmed
            else {
              // if confirmation on header level exists, operation check can be skipped
              if (
                !_.find(aConfByOrder, {
                  Aufnr: oOrder.Orderid,
                  Vornr: "",
                })
              ) {
                var aOperByOrder = _.filter(aOper, {
                  Orderid: oOrder.Orderid,
                }),
                  count = aOperByOrder.length;
                // only continue if there are operations for this order
                if (aOperByOrder && aOperByOrder.length > 0) {
                  aOperByOrder.forEach(
                    function (oOper) {
                      // find a confirmation for this operation
                      var aConfByOper = _.filter(aConfByOrder, {
                        Aufnr: oOper.Orderid,
                        Vornr: oOper.Activity,
                        SubActivity: oOper.SubActivity,
                      });

                      // if none found add oper to unconf opers
                      if (!aConfByOper || aConfByOper.length === 0) {
                        if (
                          this.getHelper().checkOperationValid(
                            oOper.Orderid,
                            oOper
                          ).ControlKeyIsValid &&
                          this.getHelper().checkOperationValid(
                            oOper.Orderid,
                            oOper
                          ).PMEXValid
                        ) {
                          this.aUnconfirmedOperations.push(oOper.Handle);
                          UncofirmedOperForOrders.push(oOper.Handle);
                          // also add order to unconf orders, since order is not finished
                          this.aUnconfirmedOrders.push(oOper.Orderid);
                        } else {
                          aIncorrectOperations.push(oOper.Handle);
                        }
                      } else if (
                        oOper.ContainsCosts &&
                        oOper.ContainsCosts === "false" &&
                        oOper.ControlKey === "PMEX"
                      ) {
                        aConfByOper[0].OperationData = oOper;
                        this.noCostOper.push(aConfByOper[0]);
                      }
                      var stillRunningOrders = _.filter(aConf, {
                        Split: "false",
                        IsFinished: "false",
                        Aufnr: oOper.Orderid,
                        Vornr: oOper.Activity,
                      }),
                        finalConfByOper = _.filter(aConfByOper, {
                          FinConf: "true",
                        });
                      if (stillRunningOrders.length > 0) {
                        this.aUnconfirmedOperations.push(oOper.Handle);
                        if (finalConfByOper.length > 0) {
                          this.aUnconfirmedConf = this.aUnconfirmedConf.concat(
                            aConfByOper.map(function (cConf) {
                              return cConf.Handle;
                            })
                          );
                          this.pending = true;
                        }
                      } else if (stillRunningOrders.length === 0) {
                        if (finalConfByOper.length > 0) {
                          this.aFinalConfirmedOper =
                            this.aFinalConfirmedOper.concat(
                              finalConfByOper.map(
                                jQuery.proxy(function (aConfirmation) {
                                  return oOper.Handle;
                                }, this)
                              )
                            );
                          count--;
                          if (count === 0) {
                            this.aFinalConfirmedOrders =
                              this.aFinalConfirmedOrders.concat(
                                finalConfByOper.map(function (aConfirmation) {
                                  return aConfirmation.Aufnr;
                                })
                              );
                          }
                          // For PMST operations check
                          this.aPMST = [];
                          var total_Count_Of_Opr_PMST_Order = 0;
                          for (var x = 0; x < aOper.length; x++) {
                            if (aOper[x].ControlKey === "PMST") {
                              for (var y = 0; y < aOper.length; y++) {
                                if (aOper[x].Orderid === aOper[y].Orderid) {
                                  total_Count_Of_Opr_PMST_Order =
                                    total_Count_Of_Opr_PMST_Order + 1;
                                }
                              }
                              var countObj = {
                                Orderid: aOper[x].Orderid,
                                OperCount: total_Count_Of_Opr_PMST_Order,
                              };
                              this.aPMST.push(countObj);
                            }
                          }
                          var checkCount = 0;
                          for (var z = 0; z < this.aPMST.length; z++) {
                            for (var t = 0; t < aOper.length; t++) {
                              if (this.aPMST[z].Orderid === aOper[t].Orderid) {
                                for (
                                  var q = 0;
                                  q < this.aFinalConfirmedOper.length;
                                  q++
                                ) {
                                  if (
                                    aOper[t].Handle ===
                                    this.aFinalConfirmedOper[q]
                                  ) {
                                    checkCount = checkCount + 1;
                                  }
                                }
                              }
                            }
                            if (this.aPMST[z].OperCount === checkCount + 1) {
                              this.aFinalConfirmedOrders.push(
                                this.aPMST[z].Orderid
                              );
                            }
                          }
                          this.aPMST = [];
                          // Check Ends here
                        } else {
                          this.hidePopUp = false;
                        }

                        // 	Vornr: oOper.Activity});
                        // if(stillRunningOrders.length>0){
                        // 	this.aUnconfirmedOperations.push(oOper.Handle);
                      }
                    }.bind(this)
                  );
                  if (UncofirmedOperForOrders.length > 0) {
                    _.each(
                      aIncorrectOperations,
                      jQuery.proxy(function (oIncorrectOperation) {
                        this.aUnconfirmedOperations.push(oIncorrectOperation);
                      }, this)
                    );
                  }
                }
              } else if (finalConfByOrder.length === 0) {
                this.hidePopUp = false;
                // this.aUnconfirmedOperations = this.aUnconfirmedOperations.concat(_.filter(aOper, {
                // 	Orderid: oOrder.Orderid
                // }).map(function (oOper) {
                // 	return oOper.Handle;
                // }));
              }
              //else {
              // this.aUnconfirmedOperations = this.aUnconfirmedOperations.concat(_.filter(aOper, {
              // 	Orderid: oOrder.Orderid
              // }).map(function (oOper) {
              // 	return oOper.Handle;
              // }));
              //}
            }
          }.bind(this)
        );

        var bConf = _.filter(aConf, {
          Split: "false",
          IsFinished: "false",
        });
        bConf.forEach(
          function (oConf) {
            if (
              !this.aUnconfirmedOrders.find(function (opera) {
                return opera === oConf.Aufnr;
              })
            ) {
              this.aUnconfirmedOrders.push(oConf.Aufnr);
            }
          }.bind(this)
        );

        if (this.aUnconfirmedOperations.length > 0) {
          _.each(
            aIncorrectOperations,
            jQuery.proxy(function (oIncorrectOperation) {
              this.aUnconfirmedOperations.push(oIncorrectOperation);
            }, this)
          );
        }
        this.aUnconfirmedOperations = _.uniqBy(
          this.aUnconfirmedOperations,
          function (row) {
            return row;
          }
        );
        var finishedConfirmation = [];
        if (aConf && aConf.length > 0) {
          finishedConfirmation = _.filter(aConf, function (oConf) {
            return oConf.IsFinished === "true";
          });
          // if(bConf.length===0){
          // 	oResult.send = false;
          // 	oResult.reason = this.NOCONFISRUNNING;
          // 	return oResult;
          // }
          // if (this.aUnconfirmedOrders.length > 0 || this.aUnconfirmedOperations.length > 0) {
          // 	oResult.send = false;
          // 	if (this.aUnconfirmedOrders.length > 0 && this.aUnconfirmedOperations.length > 0) {
          // 		oResult.reason = this.UNCONF + ";" + this.UNOPER;
          // 	} else if (this.aUnconfirmedOrders.length > 0) {
          // 		oResult.reason = this.UNCONF;
          // 	} else if (this.aUnconfirmedOperations.length > 0) {
          // 		oResult.reason = this.UNOPER;
          // 	}
        }
        var bNotif = aNotif.find(function (row) {
          return !row.Qmnum;
        });
        var aFinConf = _.filter(finishedConfirmation, function (oConf) {
          return oConf.FinConf === true || oConf.FinConf === "true";
        });
        if (finishedConfirmation.length === 0) {
          if (bNotif) {
            oResult.send = false;
            oResult.reason = this.NOCONFISRUNNING;
            return oResult;
          } else {
            oResult.send = false;
            oResult.reason = this.NODATA;
            return oResult;
          }
        } else if (finishedConfirmation && finishedConfirmation.length > 0) {
          if (finishedConfirmation.length === aFinConf.length) {
            oResult.send = false;
            //SimilarExecution Like NOCONFISRUNNING
            oResult.reason = this.NOCONFISRUNNING;
            return oResult;
          } else {
            if (this.hidePopUp) {
              oResult.send = false;
              oResult.reason = this.NOCONFISRUNNING;
            } else {
              oResult.send = false;
              oResult.reason = this.UNCONF;
              return oResult;
            }

            return oResult;
          }
        }

        // if (this.aUnconfirmedOrders.length > 0 || this.aUnconfirmedOperations.length > 0) {
        //	oResult.send = false;
        // if (this.aUnconfirmedOrders.length > 0 && this.aUnconfirmedOperations.length > 0) {
        //	oResult.reason = this.UNCONF + ";" + this.UNOPER;
        // }
        //else if (this.aUnconfirmedOrders.length > 0) {
        // 		oResult.reason = this.UNCONF;
        // 	} else if (this.aUnconfirmedOperations.length > 0) {
        // 		oResult.reason = this.UNOPER;
        // 	}
        // }else{
        // 	if(finishedConfirmation && finishedConfirmation.length>0){
        // 		oResult.send = false;
        // 		oResult.reason = this.UNCONF;
        // 		return oResult;
        // 	}
        // }
        return oResult;
      },

      _sendToSap: function (bDeleteAllOrders, bDeleteConfirmations) {
        var oPromNotif = this.getDBService().getEntitySet("PMNotification"),
          oPromConf = this.getDBService().getEntitySet("Confirmation"),
          oPromPartic = this.getDBService().getEntitySet("Participant"),
          // oPromPic = this.getDBService().getEntitySet("Picture"),
          oPromOrder = this.getDBService().getEntitySet("PMOrder"),
          oPromOperation = this.getDBService().getEntitySet("Operation"),
          oView = this.getView();

        var aConfirmations = [],
          aToSyncNotifs = [],
          aOrders = [],
          aOperations = [];

        var oSettings = this.getSharedModel().getProperty("/sapSettings");

        oView.setBusy(true);

        $.when(
          oPromConf,
          oPromNotif,
          oPromPartic,
          oPromOrder,
          oPromOperation
        ).done(
          jQuery.proxy(function (
            oConfData,
            oNotifData,
            oParticData,
            oOrderData,
            oOperationData
          ) {
            let aPartic = this.getHelper().rowsToArray(oParticData);

            //update parent confirmations after sending child confirmation to backend
            var hiddenConf = _.filter(this.getHelper().rowsToArray(oConfData), {
              Hidden: "true",
              IsFinished: "true",
            }),
              splitLength;
            splitLength = hiddenConf.length;
            if (splitLength > 0) {
              hiddenConf.forEach(
                jQuery.proxy(function (dConf) {
                  var asplitConfTobeDeleted = _.find(
                    this.getHelper().rowsToArray(oConfData),
                    {
                      Handle: dConf.ParentHndl,
                      IsFinished: "false",
                    }
                  );
                  if (
                    asplitConfTobeDeleted &&
                    asplitConfTobeDeleted.PersNo &&
                    asplitConfTobeDeleted.PersNo.split(",")
                  ) {
                    var persno = asplitConfTobeDeleted.PersNo.split(",");
                    persno = persno.filter(function (row) {
                      return row !== dConf.PersNo;
                    });
                    asplitConfTobeDeleted.PersNo = persno.join(",");
                    if (asplitConfTobeDeleted.PersNo)
                      asplitConfTobeDeleted.ExecutantCnt = persno.length;
                    this.getDBService().updateObject(
                      "Confirmation",
                      asplitConfTobeDeleted
                    );
                  }
                }, this)
              );
            }

            var aConf = _.filter(this.getHelper().rowsToArray(oConfData), {
              IsFinished: "true",
              Split: "false",
            }),
              aNotif = this.getHelper().rowsToArray(oNotifData),
              //aPic = this.getHelper().rowsToArray(oPicData),
              aOrder = this.getHelper().rowsToArray(oOrderData),
              aOperation = this.getHelper().rowsToArray(oOperationData),
              sHandle = [];
            if (this.aUnconfirmedConf.length) {
              aConf = aConf.filter(
                jQuery.proxy(function (bConf) {
                  return !this.aUnconfirmedConf.includes(bConf.Handle);
                }, this)
              );
            }

            //to add delete option in confirmation

            if (aConf.length > 0) {
              aConfirmations = aConf;
            }

            if (aOrder.length > 0) {
              aOrders = aOrder;
            }

            if (aOperation.length > 0) {
              aOperations = aOperation;
            }

            // Filter notifications to only send back those created in mobile work and those where a confirmation exists on an order with a backend notification linked to the order
            aToSyncNotifs = _.filter(
              aNotif,
              jQuery.proxy(function (oNotif) {
                return oNotif.Qmnum === "";
              }, this)
            );
            if (!aConf.length && !aToSyncNotifs.length) {
              MBox.information(this.getText("NoNotifConfirm"));
              //if(this.pending)
              //	MToast.show("Final Confirmation is still running on the device");
              oView.setBusy(false);
              return;
            }
            _.each(
              aConf,
              jQuery.proxy(function (oConf) {
                if (aOrder.length > 0 && oConf.Aufnr) {
                  var oOrderFound = _.find(
                    aOrder,
                    jQuery.proxy(function (oOrder) {
                      return oOrder.Orderid === oConf.Aufnr;
                    }, this)
                  );

                  if (oOrderFound) {
                    var oNotifFound = _.find(
                      aNotif,
                      jQuery.proxy(function (oNotif) {
                        return (
                          oNotif.Qmnum === oOrderFound.NotifNo &&
                          oOrderFound.NotifNo !== ""
                        );
                      }, this)
                    );

                    if (oNotifFound) {
                      aToSyncNotifs.push(oNotifFound);
                    }
                  }
                }
              }, this)
            );

            var aToSyncNotifQmnum = [],
              aToSyncNotifHandle = [];

            _.each(
              aToSyncNotifs,
              jQuery.proxy(function (oNotif) {
                if (oNotif.Qmnum) {
                  //sToSyncNotifQmnum += oNotif.Qmnum + "','";
                  aToSyncNotifQmnum.push(oNotif.Qmnum);
                }
                if (oNotif.Handle) {
                  //sToSyncNotifHandle += oNotif.Handle + "','";
                  aToSyncNotifHandle.push(oNotif.Handle);
                }
              }, this)
            );

            // sToSyncNotifQmnum = sToSyncNotifQmnum.slice(0, -2);
            // sToSyncNotifHandle = sToSyncNotifHandle.slice(0, -2);

            // _.each(aNotif, function(oNotif) {
            // 	oNotif.Swerk = oNotif.Swerk.toString();
            // 	oNotif.Iwerk = oNotif.Iwerk.toString();
            // });

            aConf = this._convertTimeToMin(aConf);
            aConf.forEach(
              jQuery.proxy(function (conf) {
                if (conf.FinConf === "true") {
                  conf.Complete = true;
                } else if (this.deletePressNo === true) {
                  conf.Complete = true;
                } else {
                  conf.Complete = false;
                }
              }, this)
            );
            var completeFin = _.filter(aConf, { Complete: true });
            var noncompleteFin = _.filter(aConf, { Complete: false });
            aConf = noncompleteFin.concat(completeFin);
            if (aConf.length > 0 || aToSyncNotifs.length > 0) {
              aConf.forEach((oObject) => {
                sHandle.push(oObject.Handle);
              });
              aToSyncNotifs.forEach((oObject) => {
                sHandle.push(oObject.Handle);
              });
            }
            $.when(this.getDBService().onSelectMultiple("Picture", sHandle))
              .done(
                jQuery.proxy(function (oPicData) {
                  let aPic = oPicData;
                  $.when(
                    this.getService().sync(aToSyncNotifs, aConf, aPartic, aPic)
                  )
                    .done(
                      jQuery.proxy(function () {
                        console.info('=====================AFTER-->Changes done in app=====================');
                        console.info('AFTER Changes: To be Deleted notification ' + aToSyncNotifHandle);
                        console.info('AFTER Changes: To be Deleted notification(Order)' + aToSyncNotifQmnum);

                        this.getView().setBusy(true)

                        var oAllDownloadedPersent = {};
                        var noOfReqSent = 0;
                        // aPic.forEach((pic) => {
                        for (var i in aPic) {
                          oAllDownloadedPersent[aPic[i]] = 0;
                          noOfReqSent++;
                          this.showDialogWithProgressBar(null, oAllDownloadedPersent);
                          $.when(this.getService().imageUpload(aPic[i])).done(jQuery.proxy(function () {
                            console.log('Success')
                            debugger;
                            this.getView().setBusy(false)
                            // MBox.success('Image Uploaded Successfully')
                          }, this)).fail(function () {
                            debugger;
                            this.getView().setBusy(false)
                            // MBox.error('Image Upload Failed')                            
                          }.bind(this));
                        }
                        // })

                        var oPromDelNotifH =
                          this.onDeleteNotifSameTime(aToSyncNotifHandle, aToSyncNotifQmnum),
                          oPromDelPic =
                            this.getDBService().deleteAllObjects("Picture"),
                          oPromDelOrder = null,
                          oPromDelOper = null,
                          oPromDelConf = null,
                          oPromDeassign = null,
                          oFollowUp =
                            this.getDBService().deleteAllObjects(
                              "FollowUpNotif"
                            ),
                          oPromDelOrderWCARisks = null,
                          oPromDelOrderWCAOpeData = null,
                          oPromDelOrderWCAOpeRisks = null,
                          oPromDelOrderWCAData = null;

                        if (bDeleteAllOrders) {

                          this.getDBService().deleteAllObjects("WCARisks");
                          console.info('AFTER Changes: Delete all PMOrder,Operation,WCAOpeRisks,WCAData,');
                          oPromDelConf =
                            this.getDBService().deleteAllObjects(
                              "Confirmation"
                            );
                          oPromDelOrder =
                            this.getDBService().deleteAllObjects("PMOrder");
                          oPromDelOper =
                            this.getDBService().deleteAllObjects("Operation");
                          oPromDeassign = this.getService().deassignAllData(
                            oSettings.deviceName,
                            this.getHelper().isDevModeActive()
                          );
                          oPromDelOrderWCAData =
                            this.getDBService().deleteAllObjects("WCAData");
                          oPromDelOrderWCAOpeRisks =
                            this.getDBService().deleteAllObjects("WCAOpeRisks");
                          oPromDelOrderWCAOpeData =
                            this.getDBService().deleteAllObjects("WCAOpeData");
                          oPromDelOrderWCARisks =
                            this.getDBService().deleteAllObjects("WCARisks");
                        } else if (bDeleteConfirmations) {
                          console.info('AFTER Changes: Delete all Conirmations:Dont keep confirm:onDeleteOrderYesPress');
                          if (this.aUnconfirmedConf.length !== 0) {
                            console.info('AFTER Changes: Unconfirmed Confirmation' + this.aUnconfirmedConf);
                            oPromDelConf =
                              this.getDBService().deleteConfirmationsExcluding(
                                "Handle",
                                this.aUnconfirmedConf
                              );
                          } else {
                            oPromDelConf =
                              this.getDBService().deleteAllObjects(
                                "Confirmation"
                              );
                          }
                          if (this.aFinalConfirmedOrders.length !== 0) {
                            console.info('AFTER Changes: Final Confirmaed Orders' + this.aFinalConfirmedOrders);
                            console.info('AFTER Changes: Delete WCAData,WCARisks,WCAOpeData,WCAOpeRisks' + this.aFinalConfirmedOrders);

                            oPromDelOrder = this.getDBService().deleteIncluding(
                              "PMOrder",
                              "Orderid",
                              this.aFinalConfirmedOrders
                            );
                            oPromDelOrderWCAData =
                              this.getDBService().deleteIncluding(
                                "WCAData",
                                "Objid",
                                this.aFinalConfirmedOrders
                              );
                            oPromDelOrderWCAOpeRisks =
                              this.getDBService().deleteIncluding(
                                "WCAOpeRisks",
                                "Objid",
                                this.aFinalConfirmedOrders
                              );
                            oPromDelOrderWCAOpeData =
                              this.getDBService().deleteIncluding(
                                "WCAOpeData",
                                "Objid",
                                this.aFinalConfirmedOrders
                              );
                            oPromDelOrderWCARisks =
                              this.getDBService().deleteIncluding(
                                "WCARisks",
                                "Objid",
                                this.aFinalConfirmedOrders
                              );
                          }
                          if (this.aFinalConfirmedOper.length !== 0) {
                            oPromDelOper = this.getDBService().deleteIncluding(
                              "Operation",
                              "Handle",
                              this.aFinalConfirmedOper
                            );
                          }
                        } else {
                          if (this.aUnconfirmedConf.length !== 0) {
                            console.info('AFTER Changes: Unconfirmed Confirmation' + this.aUnconfirmedConf);
                            oPromDelConf =
                              this.getDBService().deleteConfirmationsExcluding(
                                "Handle",
                                this.aUnconfirmedConf
                              );
                          } else {
                            console.info('AFTER Changes:Delete all confirmations');

                            oPromDelConf =
                              this.getDBService().deleteAllObjects(
                                "Confirmation"
                              );
                          }
                          if (this.aUnconfirmedOrders.length !== 0) {
                            console.info('AFTER Changes: Unconfirmed Orders' + this.aUnconfirmedOrders);

                            oPromDelOrder = this.getDBService().deleteExcluding(
                              this.aUnconfirmedOrders,
                              "PMOrder",
                              "Orderid"
                            );
                            oPromDelOrderWCAData =
                              this.getDBService().deleteExcluding(
                                this.aUnconfirmedOrders,
                                "WCAData",
                                "Objid"
                              );
                            oPromDelOrderWCAOpeRisks =
                              this.getDBService().deleteExcluding(
                                this.aUnconfirmedOrders,
                                "WCAOpeRisks",
                                "Objid"
                              );
                            oPromDelOrderWCAOpeData =
                              this.getDBService().deleteExcluding(
                                this.aUnconfirmedOrders,
                                "WCAOpeData",
                                "Objid"
                              );
                            oPromDelOrderWCARisks =
                              this.getDBService().deleteExcluding(
                                this.aUnconfirmedOrders,
                                "WCARisks",
                                "Objid"
                              );
                          } else {
                            console.info('AFTER Changes:Delete all Orders');
                            oPromDelOrder =
                              this.getDBService().deleteAllObjects("PMOrder");
                            oPromDelOrderWCAData =
                              this.getDBService().deleteAllObjects("WCAData");
                            oPromDelOrderWCAOpeRisks =
                              this.getDBService().deleteAllObjects(
                                "WCAOpeRisks"
                              );
                            oPromDelOrderWCAOpeData =
                              this.getDBService().deleteAllObjects(
                                "WCAOpeData"
                              );
                            oPromDelOrderWCARisks =
                              this.getDBService().deleteAllObjects("WCARisks");
                          }
                          if (this.aUnconfirmedOperations.length !== 0) {

                            console.info('AFTER Changes:Unconfirmaed Operations' + this.aUnconfirmedOperations);

                            oPromDelOper =
                              this.getDBService().deleteOperationsExcluding(
                                "Handle",
                                this.aUnconfirmedOperations
                              );
                          } else {
                            console.info('AFTER Changes:Delete all Operations');
                            oPromDelOper =
                              this.getDBService().deleteAllObjects("Operation");
                          }
                        }

                        $.when(
                          oPromDelConf,
                          oPromDelNotifH,
                          oPromDelPic,
                          oPromDelOrder,
                          oPromDelOper,
                          oPromDeassign,
                          oFollowUp,
                          oPromDelOrderWCARisks,
                          oPromDelOrderWCAOpeData,
                          oPromDelOrderWCAOpeRisks,
                          oPromDelOrderWCAData
                        )
                          .done(
                            jQuery.proxy(function () {

                              console.info('AFTER Changes:EVERY delete operations are success');

                              this.aUnconfirmedOrders = [];
                              this.aUnconfirmedOperations = [];
                              this.aUnconfirmedConf = [];
                              var aNonSubConfirmations = _.filter(
                                aConfirmations,
                                jQuery.proxy(function (oConf) {
                                  return oConf.Hidden !== true;
                                }, this)
                              );
                              var sConfLength =
                                aNonSubConfirmations.length > 0
                                  ? aNonSubConfirmations.length + splitLength
                                  : splitLength;
                              splitLength = 0;
                              var sNotifLength = aToSyncNotifs
                                ? aToSyncNotifs.length
                                : 0;
                              this.getView()
                                .getModel("local")
                                .setProperty("/ConfirmationSet", []);
                              this.getView()
                                .getModel("local")
                                .setProperty("/PMNotificationSet", []);
                              oView.setBusy(false);
                              MBox.success(
                                this.getText("SyncSuccess") +
                                "\n" +
                                this.getText("SyncTotals", [
                                  sConfLength,
                                  sNotifLength,
                                ])
                              );
                            }, this)
                          )
                          .fail(
                            jQuery.proxy(function (oError) {
                              oView.setBusy(false);
                              console.info('AFTER Changes:Failed Delete operation');

                              console.error(oError);
                              this.getLogs().addLog(
                                oError,
                                "ERROR",
                                "Synchronize"
                              );
                              // MBox.error(oError.message);
                            }, this)
                          );
                        this.getLogs().addLog(
                          "Sync Success",
                          "INFO",
                          "Synchronize"
                        );
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function (oError) {
                        console.info('AFTER Changes:Failed case of service call ' + oError);

                        //multiple click on sendtosap button gives csrf token error 12.0 - 69
                        if (oError && oError.noAction) {
                          MBox.error(oError.message);
                          oView.setBusy(false);
                          return;
                        }
                        if (oError && oError.statusCode === 401) {
                          MBox.error(oError.responseText);
                          oView.setBusy(false);
                          return;
                        }
                        this.deleteSendOrdersWithCost(oError);
                        // Remove duplicate entries from array.
                        oError.orders = _.uniqBy(
                          oError.orders,
                          function (oOrder) {
                            return oOrder;
                          }
                        );
                        oError.operations = _.uniqBy(
                          oError.operations,
                          function (oOperation) {
                            return oOperation;
                          }
                        );
                        oError.parentHandles = _.uniqBy(
                          oError.parentHandles,
                          function (oParentHandle) {
                            return oParentHandle;
                          }
                        );

                        var aHandles = [];
                        var aOrdersNoRemove = [];

                        _.each(
                          aOrders,
                          jQuery.proxy(function (oOrder) {
                            var oConfBoundToOrderFound = _.find(
                              aConfirmations,
                              jQuery.proxy(function (oConf) {
                                return oConf.Aufnr === oOrder.Orderid;
                              }, this)
                            );

                            if (!oConfBoundToOrderFound) {
                              aOrdersNoRemove.push(oOrder.Orderid);
                            }
                          }, this)
                        );

                        _.each(
                          aConfirmations,
                          jQuery.proxy(function (oConf) {
                            var oConfFoundNotifHandle = _.find(
                              oError.failedHandles,
                              function (oFailed) {
                                return oFailed === oConf.NotifHandle;
                              }
                            );

                            if (oConfFoundNotifHandle) {
                              aHandles.push(oConf.Handle);
                              this.aUnconfirmedConf.push(oConf.Handle);
                            }

                            var oConfFoundParentHandle = _.find(
                              oError.parentHandles,
                              function (oFailed) {
                                return oFailed === oConf.ParentHndl;
                              }
                            );

                            if (oConfFoundParentHandle) {
                              aHandles.push(oConf.Handle);
                              if (oConf.Hidden === true) {
                                aHandles.push(oConf.ParentHndl);
                              }
                            }

                            var oConfFoundOrder = _.find(
                              oError.orders,
                              function (oFailed) {
                                return oFailed === oConf.Aufnr;
                              }
                            );

                            if (oConfFoundOrder) {
                              aHandles.push(oConf.Handle);
                              aOrdersNoRemove.push(oConf.Aufnr);
                            }

                            aHandles = _.uniqBy(aHandles, function (oHandle) {
                              return oHandle;
                            });

                            this.aUnconfirmedConf = _.uniqBy(
                              this.aUnconfirmedConf,
                              function (oHandle) {
                                return oHandle;
                              }
                            );
                          }, this)
                        );

                        _.each(
                          aOperations,
                          jQuery.proxy(function (oOperation) {
                            var oOrderNoRemoveFound = _.find(
                              aOrdersNoRemove,
                              jQuery.proxy(function (oOrder) {
                                return oOperation.Orderid === oOrder;
                              }, this)
                            );

                            if (oOrderNoRemoveFound) {
                              oError.parentHandles.push(oOperation.Handle);
                            }
                          }, this)
                        );
                        console.info('AFTER Changes:Failed Handles of notifications' + oError.failedHandles);

                        if (oError.failedHandles.length > 0) {
                          var oPromDelNotif =
                            this.getDBService().deleteNotificationsExcluding(
                              "Handle",
                              oError.failedHandles
                            ),
                            oPromDelPic =
                              this.getDBService().deletePicturesExcludingParent(
                                "Parent",
                                oError.failedHandles
                              );
                        }

                        if (oError.orders.length > 0) {
                          if (oError.parentHandles.length > 0) {
                            console.info('AFTER Changes:Failed Handles of Operations' + oError.parentHandles);
                            console.info('AFTER Changes:Failed Handles of Orders' + aOrdersNoRemove);

                            var oPromDelOper =
                              this.getDBService().deleteOperationsExcluding(
                                "Handle",
                                oError.parentHandles
                              );
                            var oPromDelOrder =
                              this.getDBService().deleteExcluding(
                                aOrdersNoRemove,
                                "PMOrder",
                                "Orderid"
                              ),
                              oPromDelOrderWCAData =
                                this.getDBService().deleteExcluding(
                                  aOrdersNoRemove,
                                  "WCAData",
                                  "Objid"
                                ),
                              oPromDelOrderWCAOpeRisks =
                                this.getDBService().deleteExcluding(
                                  aOrdersNoRemove,
                                  "WCAOpeRisks",
                                  "Objid"
                                ),
                              oPromDelOrderWCAOpeData =
                                this.getDBService().deleteExcluding(
                                  aOrdersNoRemove,
                                  "WCAOpeData",
                                  "Objid"
                                ),
                              oPromDelOrderWCARisks =
                                this.getDBService().deleteExcluding(
                                  aOrdersNoRemove,
                                  "WCARisks",
                                  "Objid"
                                );
                          } else {
                            console.info('AFTER Changes:Delete Operations(Excluding)' + aOrdersNoRemove);
                            console.info('AFTER Changes:Delete Orders(Excluding)' + aOrdersNoRemove);
                            console.info('AFTER Changes:Delete Confirmations(Excluding)' + aHandles);
                            console.info('AFTER Changes:Delete Confirmations(Excluding)' + this.aUnconfirmedConf);
                            oPromDelOrder = this.getDBService().deleteExcluding(
                              aOrdersNoRemove,
                              "PMOrder",
                              "Orderid"
                            );
                            oPromDelOper =
                              this.getDBService().deleteOperationsExcluding(
                                "Orderid",
                                aOrdersNoRemove
                              );
                            oPromDelOrderWCAData =
                              this.getDBService().deleteExcluding(
                                aOrdersNoRemove,
                                "WCAData",
                                "Objid"
                              );
                            oPromDelOrderWCAOpeRisks =
                              this.getDBService().deleteExcluding(
                                aOrdersNoRemoves,
                                "WCAOpeRisks",
                                "Objid"
                              );
                            oPromDelOrderWCAOpeData =
                              this.getDBService().deleteExcluding(
                                aOrdersNoRemove,
                                "WCAOpeData",
                                "Objid"
                              );
                            oPromDelOrderWCARisks =
                              this.getDBService().deleteExcluding(
                                aOrdersNoRemove,
                                "WCARisks",
                                "Objid"
                              );
                          }
                          var oPromDelConf =
                            this.getDBService().deleteConfirmationsExcluding(
                              "Handle",
                              _.concat(aHandles, this.aUnconfirmedConf)
                            );
                        } else {
                          var CodeOfError = "NO_CONFIRMATION_FROM_ORDER_FAILED";
                          console.info('AFTER Changes:NO_CONFIRMATION_FROM_ORDER_FAILED');
                          if (bDeleteConfirmations) {
                            if (
                              this.aUnconfirmedConf.length !== 0 ||
                              aHandles.length > 0
                            ) {
                              console.info('AFTER Changes:Delete Confirmations(Excluding)' + aHandles);
                              console.info('AFTER Changes:Delete Confirmations(Excluding)' + this.aUnconfirmedConf);
                              oPromDelConf =
                                this.getDBService().deleteConfirmationsExcluding(
                                  "Handle",
                                  _.concat(aHandles, this.aUnconfirmedConf)
                                );
                            } else {
                              console.info('AFTER Changes:Delete all confirmations');

                              oPromDelConf =
                                this.getDBService().deleteAllObjects(
                                  "Confirmation"
                                );
                            }
                            if (this.aFinalConfirmedOrders.length !== 0) {
                              console.info('AFTER Changes:Delete orders:' + this.aFinalConfirmedOrders);

                              oPromDelOrder =
                                this.getDBService().deleteIncluding(
                                  "PMOrder",
                                  "Orderid",
                                  this.aFinalConfirmedOrders
                                );
                              oPromDelOrderWCAData =
                                this.getDBService().deleteIncluding(
                                  "WCAData",
                                  "Objid",
                                  this.aFinalConfirmedOrders
                                );
                              oPromDelOrderWCAOpeRisks =
                                this.getDBService().deleteIncluding(
                                  "WCAOpeRisks",
                                  "Objid",
                                  this.aFinalConfirmedOrders
                                );
                              oPromDelOrderWCAOpeData =
                                this.getDBService().deleteIncluding(
                                  "WCAOpeData",
                                  "Objid",
                                  this.aFinalConfirmedOrders
                                );
                              oPromDelOrderWCARisks =
                                this.getDBService().deleteIncluding(
                                  "WCARisks",
                                  "Objid",
                                  this.aFinalConfirmedOrders
                                );
                            }
                            if (this.aFinalConfirmedOper.length !== 0) {
                              console.info('AFTER Changes:Delete Operations:' + this.aFinalConfirmedOper);

                              oPromDelOper =
                                this.getDBService().deleteIncluding(
                                  "Operation",
                                  "Handle",
                                  this.aFinalConfirmedOper
                                );
                            }
                          } else {
                            if (this.aUnconfirmedConf.length !== 0) {
                              console.info('AFTER Changes:Delete Confirmation(excluding):' + this.aUnconfirmedConf);

                              oPromDelConf =
                                this.getDBService().deleteConfirmationsExcluding(
                                  "Handle",
                                  this.aUnconfirmedConf
                                );
                            } else {
                              console.info('AFTER Changes:Delete All Confirmation');

                              oPromDelConf =
                                this.getDBService().deleteAllObjects(
                                  "Confirmation"
                                );
                            }
                            if (this.aUnconfirmedOrders.length !== 0) {
                              console.info('AFTER Changes:Delete Orders(excluding):' + this.aUnconfirmedOrders);

                              oPromDelOrder =
                                this.getDBService().deleteExcluding(
                                  this.aUnconfirmedOrders,
                                  "PMOrder",
                                  "Orderid"
                                );
                              oPromDelOrderWCAData =
                                this.getDBService().deleteExcluding(
                                  this.aUnconfirmedOrders,
                                  "WCAData",
                                  "Objid"
                                );
                              oPromDelOrderWCAOpeRisks =
                                this.getDBService().deleteExcluding(
                                  this.aUnconfirmedOrders,
                                  "WCAOpeRisks",
                                  "Objid"
                                );
                              oPromDelOrderWCAOpeData =
                                this.getDBService().deleteExcluding(
                                  this.aUnconfirmedOrders,
                                  "WCAOpeData",
                                  "Objid"
                                );
                              oPromDelOrderWCARisks =
                                this.getDBService().deleteExcluding(
                                  this.aUnconfirmedOrders,
                                  "WCARisks",
                                  "Objid"
                                );
                            } else {
                              console.info('AFTER Changes:Delete All Orders');
                              oPromDelOrder =
                                this.getDBService().deleteAllObjects("PMOrder");
                              oPromDelOrderWCAData =
                                this.getDBService().deleteAllObjects("WCAData");
                              oPromDelOrderWCAOpeRisks =
                                this.getDBService().deleteAllObjects(
                                  "WCAOpeRisks"
                                );
                              oPromDelOrderWCAOpeData =
                                this.getDBService().deleteAllObjects(
                                  "WCAOpeData"
                                );
                              oPromDelOrderWCARisks =
                                this.getDBService().deleteAllObjects(
                                  "WCARisks"
                                );
                            }
                            if (this.aUnconfirmedOperations.length !== 0) {
                              console.info('AFTER Changes:Delete Operation(excluding):' + this.aUnconfirmedOperations);

                              oPromDelOper =
                                this.getDBService().deleteOperationsExcluding(
                                  "Handle",
                                  this.aUnconfirmedOperations
                                );
                            } else {
                              console.info('AFTER Changes:Delete All Operation');
                              oPromDelOper =
                                this.getDBService().deleteAllObjects(
                                  "Operation"
                                );
                            }
                          }
                        }

                        $.when(
                          oPromDelNotif,
                          oPromDelConf,
                          oPromDelPic,
                          oPromDelOrder,
                          oPromDelOper,
                          oPromDelOrderWCARisks,
                          oPromDelOrderWCAOpeData,
                          oPromDelOrderWCAOpeRisks,
                          oPromDelOrderWCAData
                        )
                          .done(
                            jQuery.proxy(function () {
                              console.info('AFTER Changes:All delete operations done is successful');

                              if (
                                CodeOfError ===
                                "NO_CONFIRMATION_FROM_ORDER_FAILED"
                              ) {
                                var length =
                                  aConfirmations.length - aHandles.length,
                                  notifLength =
                                    aToSyncNotifs.length -
                                    oError.failedHandles.length;

                                if (length > 0 || notifLength > 0) {
                                  MBox.success(
                                    this.getText("SyncSuccess") +
                                    "\n" +
                                    this.getText("SyncTotals", [
                                      length,
                                      notifLength,
                                    ])
                                  );
                                }
                              }
                              this.aUnconfirmedOrders = [];
                              this.aUnconfirmedOperations = [];
                              this.aUnconfirmedConf = [];
                              this.getView()
                                .getModel("local")
                                .setProperty("/ConfirmationSet", []);
                              oView.setBusy(false);
                            }, this)
                          )
                          .fail(
                            jQuery.proxy(function (oError) {
                              this.aUnconfirmedOrders = [];
                              this.aUnconfirmedOperations = [];
                              this.aUnconfirmedConf = [];

                              oView.setBusy(false);
                              console.info('AFTER Changes:Failed delete operationafter getting response from SAP');

                              console.error(oError);
                              // MBox.error(JSON.stringify(oError));
                            }, this)
                          );

                        oView.setBusy(false);

                        if (!oError.unknown) {
                          MBox.error(oError.message);
                          this.getLogs().addLog(
                            oError.message,
                            "ERROR",
                            "Synchronize"
                          );
                        } else {
                          if (
                            this.getService().getModel().oMetadata.bLoaded ===
                            false
                          ) {
                            this.getLogs().addLog(
                              this.getText("ConnectionUnknown") +
                              "\n" +
                              this.getText("NoConnectionToSap"),
                              "ERROR",
                              "Synchronize"
                            );
                            MBox.error(
                              this.getText("ConnectionUnknown") +
                              "\n" +
                              this.getText("NoConnectionToSap")
                            );
                          } else {
                            MBox.error(this.getText("UnknownGateWayError"));
                            this.getLogs().addLog(
                              this.getText("UnknownGateWayError"),
                              "ERROR",
                              "Synchronize"
                            );
                          }
                        }

                        if (aHandles && aHandles.length > 0) {
                          var iSuccessLength =
                            aConfirmations.length - aHandles.length;

                          if (iSuccessLength > 0) {
                            MBox.success(
                              this.getText("SyncSuccess") +
                              "\n" +
                              this.getText("SyncTotals", [iSuccessLength, 0])
                            );
                          }
                        }
                      }, this)
                    );
                }, this)
              )
              .fail(function () {
                MBox.error("Fetching Photo Failed");
              });
          },
            this)
        );
      },

      _convertTimeToMin: function (aConfirmations) {
        var aConf = aConfirmations;
        _.each(
          aConf,
          jQuery.proxy(function (oConf) {
            var sUnit = oConf.UnWork;
            switch (sUnit) {
              case "HUR" || "HR":
                oConf.ActWork = (parseFloat(oConf.ActWork) * 60).toString();
                break;
              case "DAY":
                oConf.ActWork = (parseFloat(oConf.ActWork) * 8 * 60).toString();
                break;
              default:
                break;
            }
            oConf.UnWork = "MIN";
          }, this)
        );

        return aConf;
      },

      _getOrders: function () {
        var oPromWorkSet = this.getService().getWorkSet(),
          sqlUpdate = this.getOwnerComponent().sqlDataBaseUpdate(),
          // oPromDeleteOrders = this.getDBService().deleteAllObjects("PMOrder"),
          // oPromDeleteOper = this.getDBService().deleteAllObjects("Operation"),
          // oPromDeletePrt = this.getDBService().deleteAllObjects("PRT"),
          // oPromDeleteComp = this.getDBService().deleteAllObjects("Component"),
          oView = this.getView();

        oView.setBusy(true);

        $.when(oPromWorkSet, sqlUpdate) //, oPromDeleteOrders, oPromDeleteOper, oPromDeletePrt, oPromDeleteComp)
          .done(
            jQuery.proxy(function (oData) {
              oView.setBusy(false);

              // Remove duplicate orders
              oData.NavOrder.results = _.uniqBy(
                oData.NavOrder.results,
                function (e) {
                  return e.Orderid;
                }
              );

              this._saveWorkSetToDb(oData);

              // Do not fetch GDL data in publicRelease version
              if (!this.getHelper().isDevModeActive()) {
                var aOrders = [];

                oData.NavOrder.results.forEach(function (oOrder) {
                  aOrders.push(oOrder.Orderid);
                });

                if (aOrders.length > 0) {
                  $.when(this.getGdlApi().fetchDocuments(aOrders))
                    .done(
                      jQuery.proxy(function (oError) {
                        let self = this;
                        setTimeout(function () {
                          self.updateGDLPresent(aOrders);
                        }, 5000);
                        //this.updateGDLPresent(aOrders);
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function (oError) {
                        // Don't show message in public release version
                        // MBox.error(oError.message);
                      }, this)
                    );
                }
              } else {
                this.updateGDLPresent(null);
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              oView.setBusy(false);

              // if (oError === "UNAUTHORIZED"){
              // 	MBox.error(this.getText("LoginAgain"));
              // 	console.log(this.getText("LoginAgain"));
              // 	return;
              // }

              // if( this.getView().getModel('shared').getProperty('/publicRelease') && oError.statusCode === 401)
              // 	return;
              if (oError && !oError.unknown) {
                MBox.error(oError.message);
                this.getLogs().addLog(oError.message, "ERROR", "Synchronize");
              } else {
                MBox.error(this.getText("UnknownGateWayError"));
                this.getLogs().addLog(
                  this.getText("UnknownGateWayError"),
                  "ERROR",
                  "Synchronize"
                );
              }
            }, this)
          );
      },

      _getFL: function () {
        var aFlGroups = [];

        $.when(this.getDBService().getInstallationTreeGroups()).done(
          jQuery.proxy(function (res) {
            var aTechObjGroups = this.getHelper().rowsToArray(res);

            var aGroups = _.filter(
              aTechObjGroups,
              jQuery.proxy(function (oGroup) {
                return (
                  oGroup.VhKey.indexOf(
                    this.getSharedModel().getProperty("/sapSettings/sapUser")
                  ) !== -1
                );
              }, this)
            );

            if (aGroups.length === 0) {
              aGroups = _.filter(
                aTechObjGroups,
                jQuery.proxy(function (oGroup) {
                  return (
                    oGroup.VhKey.indexOf(
                      this.getSharedModel().getProperty("/sapSettings/sapUser")
                    ) === -1
                  );
                }, this)
              );
            }

            aFlGroups = aGroups;

            // for (var i = 0; i < res.rows.length; i++) {
            // 	aFlGroups.push(res.rows.item(i));
            // }

            this.getView().getModel("FLgroupsVH").setProperty("/", aFlGroups);
          }, this)
        );
        this.getDialogManager().open(
          "synchronize.AddFunctionalLocation",
          this.getView()
        );
      },

      _deleteAllFL: function () {
        var yesnodialog = sap.ui.controller(
          "mobilework.controller.dialogs.YesNoDialog"
        );

        yesnodialog.openYesNoDialog(
          this,
          this.getText("ConfirmDeleteAllFl"),
          this.getText("Confirm"),
          function () {
            $.when(
              this.getDBService().deleteAllInstallationTree(),
              this.getDBService().deleteAllObjects("FuncLocCraft"),
              this.getDBService().deleteAllObjects("FuncLocOrg"),
              this.getDBService().deleteAllObjects("KnownScanId")
            )
              .done(
                jQuery.proxy(function (res) {
                  MBox.success(
                    this.getText("FunctionalLocationDeletionSuccess")
                  );
                  this.getLogs().addLog(
                    this.getText("FunctionalLocationDeletionSuccess"),
                    "INFO",
                    "Synchronize"
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  MBox.error(this.getText("FunctionalLocationDeletionFailed"));
                  this.getLogs().addLog(
                    this.getText("FunctionalLocationDeletionFailed"),
                    "ERROR",
                    "Synchronize"
                  );
                }, this)
              );
          },
          function () {
            // nothing yet
          }
        );
      },

      _deassignAllOrders: function () {
        var yesnodialog = sap.ui.controller(
          "mobilework.controller.dialogs.YesNoDialog"
        );

        $.when(
          this.getDBService().getEntitySet("Confirmation"),
          this.getDBService().getEntitySet("PMOrder")
        ).done(
          jQuery.proxy(function (aConfirmations, aOrders) {
            var aLocalConfirmationSet =
              this.getHelper().rowsToArray(aConfirmations),
              aLocalOrderSet = this.getHelper().rowsToArray(aOrders);

            var aFilterConfirmations = _.filter(
              aLocalConfirmationSet,
              function (oConf) {
                return oConf.IsFinished === "true";
              }
            );

            if (
              aFilterConfirmations.length === aLocalConfirmationSet.length &&
              aLocalConfirmationSet.length > 0
            ) {
              yesnodialog.openYesNoDialog(
                this,
                this.getText("ConfirmDeassignWhenAllFinished"),
                this.getText("Confirm"),
                jQuery.proxy(function () {
                  this._deassign();
                }, this),
                jQuery.proxy(function () {
                  //this.closeFragments();
                }, this)
              );
            } else if (
              aFilterConfirmations.length > 0 &&
              aLocalConfirmationSet.length > 0
            ) {
              yesnodialog.openYesNoDialog(
                this,
                this.getText("ConfirmDeassignWhenFinishedExist"),
                this.getText("Confirm"),
                jQuery.proxy(function () {
                  this._deassign();
                }, this),
                jQuery.proxy(function () {
                  //this.closeFragments();
                }, this)
              );
            } else {
              if (aLocalOrderSet.length > 0) {
                yesnodialog.openYesNoDialog(
                  this,
                  this.getText("ConfirmDeassign"),
                  this.getText("Confirm"),
                  jQuery.proxy(function () {
                    this._deassign();
                  }, this),
                  jQuery.proxy(function () {
                    //this.closeFragments();
                  }, this)
                );
              } else {
                MBox.error(this.getText("NoOrdersToDeassign"));
                this.getLogs().addLog(
                  this.getText("NoOrdersToDeassign"),
                  "ERROR",
                  "Synchronize"
                );
              }

              //this._deassign();
            }
          }, this)
        );
      },

      _confirmBackendNotifications: function (sMessage) {
        var yesnodialog = sap.ui.controller(
          "mobilework.controller.dialogs.YesNoDialog"
        );

        yesnodialog.openYesNoDialog(
          this,
          sMessage,
          this.getText("Confirm"),
          function () {
            this._sendToSap(true);
          },
          function () {
            // nothing yet
          }
        );
      },

      _deassign: function () {
        var oSettings = this.getSharedModel().getProperty("/sapSettings");

        $.when(
          this.getService().deassignAllData(
            oSettings.deviceName,
            this.getHelper().isDevModeActive()
          )
        ).done(
          jQuery.proxy(function (oResult) {
            var oPromDeleteOrders =
              this.getDBService().deleteAllObjects("PMOrder"),
              oPromDeleteOper =
                this.getDBService().deleteAllObjects("Operation"),
              oPromDeletePrt = this.getDBService().deleteAllObjects("PRT"),
              oPromDeleteComp =
                this.getDBService().deleteAllObjects("Component"),
              oPromDeleteConf =
                this.getDBService().deleteAllObjects("Confirmation"),
              oPromDeleteBoundNotif =
                this.getDBService().deleteBoundNotifications(),
              oPromDelOrderWCAData =
                this.getDBService().deleteAllObjects("WCAData"),
              oPromDelOrderWCAOpeRisks =
                this.getDBService().deleteAllObjects("WCAOpeRisks"),
              oPromDelOrderWCAOpeData =
                this.getDBService().deleteAllObjects("WCAOpeData"),
              oPromDelOrderWCARisks =
                this.getDBService().deleteAllObjects("WCARisks");

            $.when(
              oPromDeleteOrders,
              oPromDeleteOper,
              oPromDeletePrt,
              oPromDeleteComp,
              oPromDeleteConf,
              oPromDeleteBoundNotif,
              oPromDelOrderWCAData,
              oPromDelOrderWCAOpeRisks,
              oPromDelOrderWCAOpeData,
              oPromDelOrderWCARisks
            )
              .done(
                jQuery.proxy(function (oData) {
                  MBox.success(this.getText("OrderDeassignSuccess"));
                  this.getLogs().addLog(
                    "Deassign Success",
                    "INFO",
                    "Synchronize"
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function () {
                  MBox.success(this.getText("OrderDeassignFailed"));
                  this.getLogs().addLog(
                    "Deassign Failed",
                    "ERROR",
                    "Synchronize"
                  );
                }, this)
              );
          }, this)
        );
      },

      _saveWorkSetToDb: function (oData) {
        var sLength = 0;

        $.when(this.getDBService().saveWorkSet(oData))
          .done(
            jQuery.proxy(function (aExistingOrders) {
              if (oData.NavOrder.results.length) {
                sLength = oData.NavOrder.results.length;
              }

              if (aExistingOrders.length > 0) {
                var sExistingOrders = "";

                _.each(aExistingOrders, function (oOrder) {
                  sExistingOrders += oOrder + ", ";
                });
                sExistingOrders = sExistingOrders.slice(0, -2);

                var iSuccess = sLength - aExistingOrders.length;

                MBox.success(
                  this.getText("OrderAlreadyExistsOnDevice", sExistingOrders) +
                  "\n" +
                  this.getText("OrderDownloadSuccess", iSuccess.toString())
                );
              } else {
                MBox.success(
                  this.getText("OrderDownloadSuccess", sLength.toString())
                );
              }
              let wcmTime = this.createTimeofSyncIn(oData.NavOrder.results);
              this._saveTableToDB(wcmTime, OrderSyncTime, "Replace");
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              MBox.error(this.getText("OrderDownloadFail"));
            }, this)
          );
      },

      _resetInput: function () {
        this.getView().getModel("newFl").setProperty("/Scanid", "");
        this.getView()
          .getModel("newFl")
          .setProperty("/singleEntryEnabled", true);
        this.getView().getModel("newFl").setProperty("/FLgroup", []);
        this.getView()
          .getModel("newFl")
          .setProperty("/groupEntryEnabled", true);
      },
      deleteSendOrdersWithCost: function (oError) {
        //Issue 11 Armp 11.2 Tracker
        if (oError.orders && this.noCostOper && this.noCostOper.length) {
          this.noCostOper.forEach(
            jQuery.proxy(function (Conf) {
              if (oError.orders.includes(Conf.Aufnr) === false) {
                this.getDBService().deleteObject("Confirmation", Conf);
                this.getDBService().deleteObject(
                  "Confirmation",
                  Conf.OperationData
                );
              } else if (oError.orders.includes(Conf.Aufnr)) {
                if (
                  oError.operations.includes(
                    parseInt(Conf.Vornr).toString()
                  ) === false
                ) {
                  this.getDBService().deleteObject("Confirmation", Conf);
                  this.getDBService().deleteObject(
                    "Operation",
                    Conf.OperationData
                  );
                }
              }
            }, this)
          );
        }
      },

      onDeleteOrderYesPress: function () {
        this._sendToSap(null, true);
        this.getDialogManager().close(
          "synchronize.ConfirmOrderDelete",
          this.getView()
        );
      },

      updateGDLPresent: async function (oOrders) {
        let oData;
        oOrders = Array.from(new Set(oOrders));
        try {
          oData = await this.getGdlApi().fetchHashLinks(oOrders);
        } catch (e) {
          MBox.error(e.message);
          return;
        }
        if (oData && oData.length > 0) {
          let oLocalModel = this.getView().getModel("local"),
            GdlLinks = oLocalModel.getProperty("/GdlLinks");
          oData.forEach((hasLinks) => {
            if (hasLinks && hasLinks.HasLinksFlags) {
              hasLinks.HasLinksFlags =
                hasLinks.HasLinksFlags.bHasLinks ||
                  hasLinks.HasLinksFlags.bHasDirectLinks
                  ? "true"
                  : "false";
            } else {
              hasLinks.HasLinksFlags = "false";
            }
          });
          this._saveTableToDB(oData, GdlLink, "Replace");
          oLocalModel.setProperty("/GdlLinks", oData.concat(GdlLinks || []));
        }
      },

      /*BEGIN: Date: 23/01/2024 AMID: A0866990 13.1 Bug Number: 22*/
      createTimeofSyncIn: function (results) {
        let _results = results,
          timeOfSync = [];
        _results.forEach((orders) => {
          timeOfSync.push({
            Orderid: orders.Orderid,
            Operation: "",
            Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
          });
          orders.NavOperation &&
            orders.NavOperation.results.forEach((operation) => {
              timeOfSync.push({
                Orderid: operation.Orderid,
                Operation: operation.Activity,
                Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
              });
            });
        });
        return timeOfSync;
      },

      _getPurOrder: function () {
        this.getView().setBusy(true);

        let self = this,
          oPromiseOrders = this.getService().getPurOrderItems();
        //oPromiseOperation = this.getService().getPurOrderService();
        //oPromiseOrders = this.getService().getPurOrderService();
        Promise.all([
          oPromiseOrders,
          //,oPromiseOperation
        ])
          .then((results) => {
            var service = [];
            //let oPurchaseOrders = self.getHelper().rowsToArray(results[0]);
            let MW_PO_SERVICES = results[0].entity.find(
              (enity) => enity.name === "xARMPxMW_PO_SERVICESType"
            );
            let MW_PO = results[0].entity.find(
              (enity) => enity.name === "xARMPxMW_POType"
            );
            /*BEGIN: Date: 07/03/2024 AMID: A0866990 13.1 MWX Bug Number: 27 
            PO added from PO screen was deleted by createtableandfill method*/
            // BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33
            if (MW_PO.key.propertyRef.length === 2)
              MW_PO.key.propertyRef.push(
                { name: "AssignedDevice" },
                { name: "PlannedParticipant" }
              );
            // End: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33

            if (results[0].data.length) {
              self
                ._saveTableToDB(results[0].data, MW_PO, "Replace")
                .then(() => {
                  console.info("save to db of PO was success");
                })
                .catch((error) => {
                  MToast.show(
                    "Save to db of PO was success : Error occurred:" + error
                  );
                  console.error(
                    "Save to db of PO was success : Error occurred:" + error
                  );
                });
            }

            results[0].data.forEach(function (oPurOrd) {
              service = service.concat(oPurOrd.to_POServices.results);
            });
            if (service.length) {
              self
                ._saveTableToDB(service, MW_PO_SERVICES, "Replace")
                .then(() => {
                  console.log("save to db of PO was success");
                })
                .catch((error) => {
                  MToast.show(
                    "Save to db of PO was success : Error occurred:" + error
                  );
                  console.error(
                    "Save to db of PO was success : Error occurred:" + error
                  );
                });
            }

            MBox.success(
              results[0].data.length +
              " " +
              this.getModel("i18n")
                .getResourceBundle()
                .getText("ordersretrived")
            );
            self.getView().setBusy(false);

            // oPurchaseOrders.forEach(function(row){
            // 	row.nodes=[{

            // 		"Packno": "0000001456",
            // 		"Introw": "0000000003",
            // 		"Extrow": "0000000020",
            // 		"PoNumber": "4500000031",
            // 		"PoItem": "00010",
            // 		"ServiceNum": "3000127",
            // 		"ServiceText": "IT Software Developer",
            // 		"Quantity": "10",
            // 		"BaseUnit": "DAY",
            // 		"Zone_Serv": "STL"
            // 	}]
            // })
            // this.getModel('local').setProperty('/PurchaseOrdersSet',oPurchaseOrders);
          })
          .catch(function (err) {
            self.getView().setBusy(false);
            if (err) MBox.error(err.message);
          });
      },

      deletePoMWX: function () {
        MBox.confirm(
          this.getModel("i18n").getResourceBundle().getText("WantToDeletepo"),
          {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                this.getDBService().deleteAllObjects(
                  "xARMPxMW_PO_SERVICESType"
                );
                this.getDBService().deleteAllObjects("xARMPxMW_POType");
                this.getDBService().deleteAllObjects("PlanItem");
                MBox.success(
                  this.getModel("i18n").getResourceBundle().getText("PODeleted")
                );
              }
            }, this),
          }
        );
      },
      closeMessageLog: function () {
        this.getDialogManager().close(
          "fragments.MessageFragment",
          this.getView()
        );
      },

      // sendTStoSap: async function(){
      // 	// if(this.getSharedModel().getProperty('/publicRelease')){
      // 		var oPromTimeSheets = this.getDBService().getEntitySet("PlanItem"),
      // 		oPromPartic = this.getDBService().getEntitySet("Participant");
      // 	// }
      // 	$.when(oPromTimeSheets,oPromPartic)
      // 	.done(jQuery.proxy( function (oTimeSheets,oParticData) {

      // 		oTimeSheets = this.getHelper().rowsToArray(oTimeSheets);
      // 		oTimeSheets=oTimeSheets.filter((oTs)=>{return oTs.Status==="true" && oTs.RowExcel !=='X'});
      // 		let aPartic = this.getHelper().rowsToArray(oParticData);
      // 		let oNewSheets = []
      // 		this.sendTimeSheets = [];
      // 		oTimeSheets.forEach((TS=>{
      // 			let pernr = TS.Pernr.split(',');
      // 			if(pernr.length>1){
      // 				let length=pernr.length;
      // 				pernr.forEach((row)=>{
      // 					if(row){
      // 						let timeSheet = {
      // 							"Erdat": TS.Erdat,
      // 							"RowExcel": "",
      // 							"Source": TS.Source,
      // 							"Installation":TS.Installation,
      // 							"StartTime": TS.StartTime,
      // 							"Lifnr": TS.Lifnr,
      // 							"PlId": this.getHelper().getUUID(),
      // 							"PoiText": TS.PoiText,
      // 							"Werks": TS.Werks,
      // 							"ServText": TS.ServText,
      // 							"PersName": TS.PersName,
      // 							"ServText":TS.ServText,
      // 							"PlDate": TS.PlDate,
      // 							"Pernr": row,
      // 							"Quantity":TS.Quantity/length,
      // 							"PoNr": TS.PoNr,
      // 							"PoPosNr": TS.PoPosNr,
      // 							"Service": TS.Service,
      // 							"Unit": TS.Unit,
      // 							"Packno": TS.Packno,
      // 							"Introw": TS.Introw,
      // 							"PlComment": TS.PlComment,
      // 							"TotalQnty": TS.TotalQnty,
      // 							"TrZone": TS.TrZone
      // 						}
      // 						oNewSheets.push(timeSheet)
      // 						this.sendTimeSheets.push(timeSheet.PlId);
      // 					}
      // 				})
      // 			}else{
      // 				oNewSheets.push(TS)
      // 			}
      // 		}));
      // 		let i = 0;
      // 		oNewSheets.forEach((TS=>{
      // 			let partcipant =aPartic.find(row=>{return row.Pernr === TS.Pernr})
      // 			i++;
      // 			TS.RowExcel= i;

      // 			if(TS.Unit === "DAY"){
      // 				TS.Quantity = TS.Quantity*24
      // 			}else if ( TS.Unit ==='MIN'){
      // 				TS.Quantity = TS.Quantity/60
      // 			}else{
      // 				TS.Quantity = TS.Quantity.toString();
      // 			}
      // 			TS.Unit ="HR"

      // 			return TS.Lifnr =partcipant.Lifnr
      // 		}))
      // 		$.when(this.getService().sendTimeSheets(oNewSheets,aPartic)).done(
      // 			function(odata){
      // 				let plIds = oNewSheets.map((obj) => {
      // 						return obj.PlId;
      // 					});
      // 				this.getDBService().deleteIncluding("PlanItem", "PlId", plIds);
      // 				MBox.success("Time Sheets sent succesfully to SAP")
      // 			}.bind(this)).fail(function(oError){
      // 				let errors =oError.message.split('\n').map(JSON.parse);

      // 				let lines = Array.from(new Set(errors.map(obj=>obj.line))),
      // 				errorSheets = oNewSheets.map((obj) => {
      // 						if(lines.includes(obj.RowExcel)){
      // 							return obj.PlId;
      // 						}});
      // 				errors.forEach((oErr)=>{oErr.Severity='Error'})
      // 				this.getDBService().deleteExcluding(errorSheets,"PlanItem", "PlId");
      // 				this.getModel("local").setProperty("/messages",errors);
      // 				this.getDialogManager().open(
      // 				  "fragments.MessageFragment",
      // 				  this.getView()
      // 				);
      // 			}.bind(this))

      // 	}, this)).fail(function(oError){
      // 		console.assert.log(oError)
      // 	});

      // },

      sendTStoSap: async function () {
        this.getView().setBusy(true);
        // if(this.getSharedModel().getProperty('/publicRelease')){
        var oPromTimeSheets = this.getDBService().getEntitySet("PlanItem"),
          oPromPartic = this.getDBService().getEntitySet("Participant");
        // }
        Promise.all([oPromTimeSheets, oPromPartic])
          .then(
            async function (results) {
              let oTimeSheets = results[0],
                oParticData = results[1];
              oTimeSheets = this.getHelper().rowsToArray(oTimeSheets);
              oTimeSheets = oTimeSheets.filter((oTs) => {
                return oTs.Status === "true" && oTs.RowExcel !== "X";
              });
              let aPartic = this.getHelper().rowsToArray(oParticData);
              let oNewSheets = [];
              this.sendTimeSheets = [];
              if (!oTimeSheets.length) {
                MBox.information(this.getModel("i18n").getResourceBundle().getText("NoTStosend"));
                this.getView().setBusy(false);
                return;
              }
              oTimeSheets.forEach((TS) => {
                let pernr = TS.Pernr.split(",");
                if (pernr.length > 1) {
                  let length = pernr.length;
                  pernr.forEach((row) => {
                    if (row) {
                      let timeSheet = {
                        Erdat: TS.Erdat,
                        RowExcel: "",
                        Source: TS.Source,
                        Installation: TS.Installation,
                        StartTime: TS.StartTime,
                        Lifnr: TS.Lifnr,
                        PlId: TS.PlId,
                        PoiText: TS.PoiText,
                        Werks: TS.Werks,
                        ServText: TS.ServText,

                        /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 
                          In case of multiple persname is there this field throws error.
                          Backend already adds pername to table. So frontend onlt send the persname*/
                        PersName: "",
                        /*END: Date: 17/03/2024 AMID: A0866990 13.1 */
                        ServText: TS.ServText,
                        PlDate: TS.PlDate,
                        Pernr: row,
                        Quantity: TS.Quantity / length,
                        PoNr: TS.PoNr,
                        PoPosNr: TS.PoPosNr,
                        Service: TS.Service,
                        Unit: TS.Unit,
                        Packno: TS.Packno,
                        Introw: TS.Introw,
                        PlComment: TS.PlComment,
                        TotalQnty: TS.TotalQnty,
                        TrZone: TS.TrZone,
                      };
                      oNewSheets.push(timeSheet);
                      this.sendTimeSheets.push(timeSheet.PlId);
                    }
                  });
                } else {
                  oNewSheets.push(Object.assign({}, TS));
                }
              });
              let i = 0;
              oNewSheets.forEach((TS) => {
                let partcipant = aPartic.find((row) => {
                  return row.Pernr === TS.Pernr;
                });
                i++;
                TS.RowExcel = i;

                if (TS.Unit === "DAY") {
                  TS.Quantity = TS.Quantity * 24;
                } else if (TS.Unit === "MIN") {
                  TS.Quantity = TS.Quantity / 60;
                } else {
                  TS.Quantity = TS.Quantity.toString();
                }
                TS.Unit = "HR";

                TS.Lifnr = partcipant.Lifnr;
              });

              let sendTs = null,
                oError;
              try {
                sendTs = await this.getService().sendTimeSheets(
                  oNewSheets,
                  aPartic
                );
              } catch (error) {
                sendTs = null;
                oError = error;
              }
              this.getView().setBusy(false);
              if (sendTs) {
                let plIds = [];
                oTimeSheets.forEach((obj) => {
                  plIds.push(obj.PlId);
                  if (obj.RowExcel) {
                    plIds.push(obj.RowExcel);
                  }
                });
                this.getDBService().deleteIncluding("PlanItem", "PlId", plIds);
                let count = sendTs.NavPlanItem.results.length;
                MBox.success(this.getText("TimeSheetSuccess", count));
              } else {
                let errors = oError.message.split("\n").map(JSON.parse);
                let lines = Array.from(new Set(errors.map((obj) => obj.line))),
                  errorSheets = oNewSheets.map((obj) => {
                    if (lines.includes(obj.RowExcel)) {
                      return obj.PlId;
                    }
                  });
                errors.forEach((oErr) => {
                  oErr.Severity = "Error";
                });
                // oTimeSheets.map((obj) => {
                // 	if(errorSheets.includes(obj.PlId)){return obj.RowExcel};
                // }).filter(o=>o);
                oTimeSheets.forEach((obj) => {
                  if (errorSheets.includes(obj.PlId)) {
                    errorSheets.push(obj.RowExcel);
                  }
                });

                this.getDBService().deleteExcluding(
                  errorSheets.filter(Boolean),
                  "PlanItem",
                  "PlId"
                );
                this.getModel("local").setProperty("/messages", errors);
                this.getDialogManager().open(
                  "fragments.MessageFragment",
                  this.getView()
                );
              }
            }.bind(this)
          )
          .catch(function (err) {
            console.error(err.message);
          });
      },

      onDeleteNotifSameTime: async function (aToSyncNotifHandle, aToSyncNotifQmnum) {
        let that = this;
        return new Promise(async function (resolve, reject) {

          try {
            await
              that.getDBService().deleteNotificationsWithQmnumAndHandle(
                aToSyncNotifHandle,
                "Handle"
              );
            await
              that.getDBService().deleteNotificationsWithQmnumAndHandle(
                aToSyncNotifQmnum,
                "Qmnum"
              );
            resolve()
          } catch (err) {
            reject(err);
          }

        })

      }
      /*END: Date: 23/01/2024 AMID: A0866990 13.1 Bug Number: 22*/
    });
  }
);
