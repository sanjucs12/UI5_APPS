/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/libs/lodash",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
    "mobilework/util/Formatter",
    "mobilework/controller/purchase/PurchaseHelper",
  ],
  function (
    Controller,
    MBox,
    Mo,
    Lo,
    Filter,
    FilterOperator,
    JSONModel,
    Sorter,
    Formatter,
    PurchaseHelper
  ) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.purchase.PurchaseOrderDetail",
      {
        formatter: Formatter,

        //---------------------------//
        // PROPERTIES
        //---------------------------//

        /** @type sap.m.Dialog */
        oAddConfirmationDialog: null,

        /** @type sap.m.List */
        oMasterList: null,

        bFromOrderList: false,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ConfirmationsMaster
         */
        onInit: function () {
          //this._initModels();
          this.getRouter()
            .getRoute("purchaseOrderDetail")
            .attachMatched(this.onRouteMatched, this);
          if (!this.getOwnerComponent().PurchaseHelper) {
            this.getOwnerComponent().PurchaseHelper = new PurchaseHelper();
          }
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.ConfirmationsMaster
         */
        onExit: function () {
          // nothing yet
        },

        onRouteMatched: async function (oEvent) {
          //set scanner location
          this.getScanHandler().setLocation("ItemDetail");

          //set connection property
          this.getConnection();
          //this._getConfirmationsFromDb();
          this.changeColorOfDeviceId();
          this.bindElement();
          // Promise.all([oFuncLocOrg]).then((results) => {
          // 	let oPurchaseOrders = self.getHelper().rowsToArray(results[0]);
          // 	oPurchaseOrders.forEach(function(row){
          // 		row.nodes=[{
          // 			"Packno": "0000001456",
          // 			"Introw": "0000000003",
          // 			"Extrow": "0000000020",
          // 			"PoNumber": "4500000031",
          // 			"PoItem": "00010",
          // 			"ServiceNum": "3000127",
          // 			"ServiceText": "IT Software Developer",
          // 			"Quantity": "10",
          // 			"BaseUnit": "DAY",
          // 			"Zone_Serv": "STL"
          // 		}]
          // 	})
          // 		this.getModel('local').setProperty('/PurchaseOrders',oPurchaseOrders);
          // 		this.PurchaseOrders=oPurchaseOrders;
          // 		this.onExpandTreetable()
          //  });
        },

        onNavBack: function () {
			this.getRouter().navTo("purchaseMaster");
					},

        bindElement: function () {
          let sBindingPath = this.getModel("PurchaseOrders").getProperty(
            "/selectedPurchaseOrder"
          );
          this.getView().bindElement({
            path: sBindingPath,
            model: "PurchaseOrders",
          });
          // this.order =order;
          let order = this.getModel("PurchaseOrders").getProperty(sBindingPath);
          var oOperationTable = this.getView().byId("PurchaseItemsTable");

          // this.getView().bindElement({
          // 	path: sBindingPath,
          // 	model: "PurchaseOrders"
          // });

          oOperationTable.bindItems(
            "PurchaseOrders>" + "/PurchaseOrdersSet",
            new sap.m.ColumnListItem({
              type: "Navigation",
              cells: [
                new sap.m.Text({
                  text: "{PurchaseOrders>PoItem}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>PoShText}",
                }),
              ],

              press: jQuery.proxy(this.onItemPress, this),
            })
          );
          oOperationTable
            .getBinding("items")
            .filter(new Filter("PoNumber", FilterOperator.EQ, order.PoNumber));
        },
        onItemPress: function (oEvent) {
          // let path = oEvent.getParameter('id').slice(oEvent.getParameter('id').lastIndexOf('-')+1);
          let path = oEvent.getSource().getBindingContextPath(),
            oOrder = this.getModel("PurchaseOrders").getProperty(path);
          this.getModel("PurchaseOrders").setProperty(
            "/selectedPurchaseOrder",
            path
          );
          this.getRouter().navTo("purchaseItemDetail", {
            order: oOrder.PoNumber,
            operation: oOrder.PoItem,
          });
        },
      }
    );
  }
);
