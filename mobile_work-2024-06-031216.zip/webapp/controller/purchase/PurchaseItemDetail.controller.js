/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/libs/lodash",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
    "mobilework/util/Formatter",
    "mobilework/controller/purchase/PurchaseHelper",
  ],
  function (
    Controller,
    MBox,
    Mo,
    Lo,
    Filter,
    FilterOperator,
    JSONModel,
    Sorter,
    Formatter,
    PurchaseHelper
  ) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.purchase.PurchaseItemDetail",
      {
        formatter: Formatter,

        //---------------------------//
        // PROPERTIES
        //---------------------------//

        /** @type sap.m.Dialog */
        oAddConfirmationDialog: null,

        /** @type sap.m.List */
        oMasterList: null,

        bFromOrderList: false,

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.ConfirmationsMaster
         */
        onInit: function () {
          this.getRouter()
            .getRoute("purchaseItemDetail")
            .attachMatched(this.onRouteMatched, this);
          if (!this.getOwnerComponent().PurchaseHelper) {
            this.getOwnerComponent().PurchaseHelper = new PurchaseHelper();
          }
          // this.getRouter().getRoute("purchaseItemDetailTable").attachMatched(this.onTableRouteMatched, this);
        },

        onRouteMatched: async function (oEvent) {
          this.getScanHandler().setLocation("PurchaseItemDetail");
          this.getConnection();
          this.changeColorOfDeviceId();
          this.bindElement();
        },
        // onTableRouteMatched: async function (oEvent) {

        // 	this.getScanHandler().setLocation("PurchaseItemDetail");
        // 	this.getConnection();
        // 	this.changeColorOfDeviceId();
        // 	let order = oEvent.getParameter("arguments").order;
        // 	let operation = oEvent.getParameter("arguments").operation;
        // 	this.bindElement(order,operation)
        // },

        onNavBack: function () {
          this.getRouter().navTo("purchaseMaster");
        },

        bindElement: function () {
          let sBindingPath;

          sBindingPath = this.getModel("PurchaseOrders").getProperty(
            "/selectedPurchaseOrder"
          );
          // console.log(this.getModel('PurchaseOrders'));

          // if(sBindingPath ==="order"){
          // 	let path = this.getModel('PurchaseOrders').findIndex(function(order){
          // 		return order.PoNumber === order
          // 	});
          // }
          this.getView().bindElement({
            path: sBindingPath,
            model: "PurchaseOrders",
          });
          var oOperationTable = this.getView().byId("PurchaseServicesTable");

          // this.getView().bindElement({
          // 	path: sBindingPath,
          // 	model: "PurchaseOrders"
          // });

          oOperationTable.bindItems(
            "PurchaseOrders>" + sBindingPath + "/nodes",
            new sap.m.ColumnListItem({
              // type: "Navigation",
              cells: [
                new sap.m.Text({
                  text: "{PurchaseOrders>Extrow}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>ServiceNum}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>ServiceText}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>Quantity}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>BaseUnit}",
                }),
                new sap.m.Text({
                  text: "{PurchaseOrders>Zone_Serv}",
                }),
              ],
              press: jQuery.proxy(this.onItemPress, this),
            })
          );
        },
        onItemPress: function (oEvent) {
          // let path = oEvent.getParameter('id').slice(oEvent.getParameter('id').lastIndexOf('-')+1);
          // this.getRouter().navTo("purchaseItemDetailTable",{
          // 	order :this.order,
          // 	operation: path
          // });
        },
      }
    );
  }
);
