/*global moment:true*/
/*global Connection:true*/
/*global X2JS:true*/
/*global _:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel",
    "mobilework/libs/moment",
    "mobilework/libs/xml2json",
    "mobilework/libs/lodash",
  ],
  function (Object, JSONModel, Mo, Xml2, Lo) {
    "use strict";

    return Object.extend("mobilework.controller.purchase.PurchaseHelper", {
      /*BEGIN: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/

      _setParticipantSet: function (oParticipantsDb) {
        let aParticipants = oParticipantsDb.map((Participant) => {
          let sKey = Participant.Pernr ? Participant.Pernr : Participant.Arbpl;
          let sText = Participant.Pernr ? Participant.Pernr : Participant.Arbpl;
          let sName = Participant.Ename ? Participant.Ename : "";
          let lifnr = Participant.Pernr
            ? Participant.Lifnr
              ? true
              : false
            : false;
          let bPernr = Participant.Pernr ? true : false;

          return {
            sKey: sKey,
            sText: sText,
            sName: sName,
            bPernr: bPernr,
            lifnr: lifnr,
          };
        });

        aParticipants = _.sortBy(aParticipants, ["sName", "sKey"]);
        return aParticipants;
      },
      /*END: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
    });
  }
);
