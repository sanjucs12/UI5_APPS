/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/libs/lodash",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
    "sap/m/MessageToast",
    "mobilework/controller/purchase/PurchaseHelper",
  ],
  function (
    Controller,
    MBox,
    Mo,
    Lo,
    Filter,
    FilterOperator,
    JSONModel,
    Sorter,
    MToast,
    PurchaseHelper
  ) {
    "use strict";

    return Controller.extend("mobilework.controller.purchase.TimeSheet", {
      onInit: function () {
        this._initModels();
        this.getRouter()
          .getRoute("timeSheet")
          .attachMatched(this.onRouteMatched, this);
        if (!this.getOwnerComponent().PurchaseHelper) {
          this.getOwnerComponent().PurchaseHelper = new PurchaseHelper();
        }
      },

      _initModels: function () {
        if (!this.getView().getModel("newTimeSheets")) {
          this.getView().setModel(new JSONModel(), "newTimeSheets");
        }
        if (!this.getView().getModel("viewModel")) {
          this.getView().setModel(
            new sap.ui.model.json.JSONModel(),
            "viewModel"
          );
        }
      },

      onExit: function () {
        // nothing yet
      },
      onAfterRendering: function () {
        if (!this._oTimeDetailForm) {
          this._oTimeDetailForm = this.getView().byId("PurTimeTableDetailFrom");
        }
      },

      onRouteMatched: async function (oEvent) {
        this.getScanHandler().setLocation("TimeSheet");
        this.getConnection();
        this.changeColorOfDeviceId();

        this.bindElement();
        if (this._oTimeDetailForm) {
          this._oTimeDetailForm.unbindElement();
          this._oTimeDetailForm.setVisible(false);
        }
      },

      onNavBack: function () {
        this.getRouter().navTo("purchaseMaster");
      },

      bindElement: function () {
        this.getModel("PurchaseOrders").setProperty("/oServices", {});
        //this.getView().getModel("newTimeSheets").setProperty('/',{})

        let sBindingPath = this.getModel("PurchaseOrders").getProperty(
          "/createConfirmationSelected"
        );
        let current = this.getModel("PurchaseOrders").getProperty(sBindingPath),
          services,
          data,
          child;
        if (current.RowExcel !== "X" && current.RowExcel) {
          let parent = sBindingPath.slice(
              0,
              sBindingPath.lastIndexOf("/nodes")
            ),
            timeSheets = this.getModel("PurchaseOrders").getProperty(parent);
          let index = timeSheets.nodes.findIndex((a) => {
            return current.RowExcel === a.PlId;
          });
          data = timeSheets.nodes.find((a) => {
            return current.RowExcel === a.PlId;
          });
          child = timeSheets.nodes.filter((a) => {
            return current.RowExcel === a.RowExcel;
          });

          sBindingPath = parent + "/nodes/" + index;
        } else {
          data = current;
        }

        // this.getView().getModel("newTimeSheets").setProperty('/Status','false');
        /*BEGIN: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 22*/
        // if (this.getHelper().isDevModeActive()) data.Zone_Serv = "AMF-4900"; //Comment after dev
        /*END: Date: 28/02/2024 AMID: A0866990 13.1 Bug Number: 22*/

        if (data.Pernr) {
          this.updatePartcipants(data.Pernr);
          // 	let self = this, oPromPlan =  this.getDBService().getEntitySet("PlanItem",["SELECT * from PlanItem where RowExcel=?", [data.PlId]]);
          // 	Promise.all([oPromPlan])
          // 	.then(function(results) {
          // 		let ChildConfirmations = self.getHelper().rowsToArray(results[0]);
          this.getModel("PurchaseOrders").setProperty(
            sBindingPath + "/ChildConfirmations",
            child
          );
          // 		self._getChildConfirmations()
          // 	})
          //   .catch(function(err) {
          // 	console.error(err.message);
          //   });
          this.getView().bindElement({
            path: sBindingPath,
            model: "PurchaseOrders",
          });
          let index = sBindingPath.lastIndexOf(
            "/nodes",
            sBindingPath.lastIndexOf("/nodes") - 1
          );
          let sServicePath = sBindingPath.slice(0, sBindingPath.lastIndexOf("/nodes") );
          let sParentPath = sBindingPath.slice(0, index);

          // let servicePath= sBindingPath.slice(0,sBindingPath.lastIndexOf("/nodes"));
          // this.getView().getModel("newTimeSheets").setProperty("/",data)
          let parent = this.getModel("PurchaseOrders").getProperty(sParentPath),
           sService = this.getModel("PurchaseOrders").getProperty(sServicePath);

          this.getModel("PurchaseOrders").setProperty(
            sBindingPath + "/DeliveryDt",
            parent.DeliveryDt
          );
          this.getModel("PurchaseOrders").setProperty(
            sBindingPath + "/PoShText",
            parent.PoShText
          );
          this.getModel("PurchaseOrders").setProperty(
            sBindingPath + "/Split",
            data.RowExcel ? true : false
          );
          services = [{ key: data.Service, zone: data.TrZone ,description : sService.ServiceText}];
        } else if (data.ServiceNum) {
          let newTs = data.nodes ? data.nodes.length : 0;
          let childPath = sBindingPath + "/nodes/" + newTs;

          let sParentPath = sBindingPath.slice(
            0,
            sBindingPath.lastIndexOf("/nodes")
          );
          let parent = this.getModel("PurchaseOrders").getProperty(sParentPath);
          // this.getModel('PurchaseOrders').setProperty(sParentPath+"/"+newTs,{});
          let newTsObj = {
            DeliveryDt: parent.DeliveryDt,
            PoShText: parent.PoShText,
            Werks: parent.Plant,
            Service: data.ServiceNum,
            PoNr: parent.PoNumber,
            PoPosNr: parent.PoItem,
            Service: data.ServiceNum,
            TrZone: data.Zone_Serv,
            Introw: data.Introw,
            Packno: data.Packno,
            PlId: this.getHelper().getUUID(),
            Unit: data.Unit || "HUR",
            //Using this property for split confirmations
            RowExcel: "",
            Status: "false",
            AllZone: data.AllZone,
          };
          services = [{ key: data.ServiceNum, zone: data.Zone_Serv ,description : data.ServiceText}];
          this.getModel("PurchaseOrders").setProperty(childPath, newTsObj);
          this.getView().bindElement({
            path: childPath,
            model: "PurchaseOrders",
          });

          let oZonedPartcipants =
            this.getModel("PurchaseOrders").getProperty("/ZonedPartcipants");
          let aParticipants =
            this.getPurchaseHelper()._setParticipantSet(oZonedPartcipants);
          this.getSharedModel().setProperty(
            "/ParticipantPurchaseSet",
            aParticipants
          );

          // this.getModel('PurchaseOrders').setProperty(childPath+ '/DeliveryDt',parent.DeliveryDt)
          // this.getModel('PurchaseOrders').setProperty(childPath+ '/PoShText',parent.PoShText)
          // this.getModel('PurchaseOrders').setProperty(childPath+ '/Werks',parent.Plant);
          // this.getModel('PurchaseOrders').setProperty(childPath+ '/Service',data.ServiceNum);
          // // this.getModel('PurchaseOrdersSet').setProperty(sBindingPath+ '/Plant',parent.Plant)
          // this.getModel('PurchaseOrders').setProperty(childPath+ '/PoNr',parent.PoNumber);
          // this.getModel('PurchaseOrders').setProperty(childPath+ '/PoPosNr',parent.PoItem);

          //  this.getModel('PurchaseOrders').setProperty(childPath+ '/Service',data.ServiceNum);
          //  this.getModel('PurchaseOrders').setProperty(childPath+ '/TrZone',data.Zone_Serv);
          //  this.getModel('PurchaseOrders').setProperty(childPath+ '/Introw',data.Introw);
          //  this.getModel('PurchaseOrders').setProperty(childPath+ '/Packno',data.Packno);
          //  this.getModel('PurchaseOrders').setProperty(childPath+'/Status','false');
          //  this.getModel('PurchaseOrders').setProperty(childPath+'/PlId',this.getHelper().getUUID());
          //  this.getModel('PurchaseOrders').setProperty(childPath+'/Unit',data.Unit || "HUR");
        } else {
          // this.getView().getModel("newTimeSheets").setProperty('/Werks',data.Plant);
          // this.getView().getModel("newTimeSheets").setProperty('/PoNr',data.PoNumber);
          // this.getView().getModel("newTimeSheets").setProperty('/PoPosNr',data.PoItem);
          // if(!data.nodes || !data.nodes.length){
          // 	data.nodes= [];
          // }
          // let length = data.nodes.length;
          // data.nodes.push({
          // 	PoNumber: data.PoNumber,
          // 	PoItem:data.PoItem,
          // 	PoShText:data.PoShText,
          // 	DeliveryDt:data.DeliveryDt
          // })
          // this.getView().bindElement({
          // 	path: sBindingPath ="/nodes/"+length,
          // 	model: "PurchaseOrdersSet"
          // });
          // services =data.nodes.map((oServ)=>{return {key :oServ.ServiceNum,zone:oServ.Zone_Serv}})
        }
        this.getModel("PurchaseOrders").setProperty("/oServices", services);
        //this.getView().getModel("newTimeSheets").refresh()
      },

      formatHeaderDate: function (sDateString) {
        if (sDateString) {
          return new moment(sDateString).format("DD/MM/YYYY HH:mm");
        } else {
          return "-";
        }
      },

      persNoSelectedKeys: function (sPerNo) {
        if (sPerNo && sPerNo.indexOf(",") !== -1) {
          return sPerNo.split(",");
        } else {
          return sPerNo;
        }
      },

      onParticipantChange: function (oEvent) {
        let aSelectedKeys = oEvent.getSource().getSelectedKeys();
        let iCurrCount = oEvent.getSource().getSelectedKeys().length,
          local = this.getView().getModel("local"),
          oTimeSheets = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          PurchaseOrders = this.getView().getModel("PurchaseOrders");
        let temp = oTimeSheets.Pernr,
          count = oTimeSheets.ExecutantCnt;

        let partcipants = [],
          TrZone = oTimeSheets.TrZone;
        aSelectedKeys = aSelectedKeys.filter((a) => a);

        if (aSelectedKeys.length) {
          /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
          if (PurchaseOrders.getProperty(sBindingPath + "/PlDate")) {
            PurchaseOrders.setProperty(
              sBindingPath + "/PersNo",
              aSelectedKeys.join(",")
            );
            if (
              aSelectedKeys.join(",") !== "" &&
              this.confirmationBlocker(
                PurchaseOrders,
                sBindingPath,
                PurchaseOrders.getProperty(sBindingPath),
                null,
                aSelectedKeys
              )
            ) {
              PurchaseOrders.setProperty(sBindingPath + "/Pernr", temp);
              this.getView()
                .byId("persComboTime")
                .setSelectedKeys(temp.split(","));
              return;
            }
          }
          /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
          if (PurchaseOrders.getProperty(sBindingPath + "/Split") === true) {
            this._clearSubConfirmations();
            this._createSubConfirmations();
          } else {
            this._clearSubConfirmations();
          }
        } else {
          PurchaseOrders.setProperty(sBindingPath + "/Split", false);
          PurchaseOrders.setProperty(sBindingPath + "/Quantity", "");
          PurchaseOrders.setProperty(sBindingPath + "/PlDate", null);
          PurchaseOrders.setProperty(sBindingPath + "/EndDate", null);
          PurchaseOrders.setProperty(sBindingPath + "/Pernr", "");
          if (PurchaseOrders.getProperty(sBindingPath + "/Split") === true) {
            this._clearSubConfirmations();
          }
        }

        // var aSelected = oLocalModel.getProperty(sCurrPath + "/PersNo");

        // _.remove(aSelected, function (sVal) {
        //   return sVal === "";
        // });

        // oLocalModel.setProperty(sCurrPath + "/ExecutantCnt", iCurrCount);

        this.getView()
          .getModel("PurchaseOrders")
          .setProperty(sBindingPath + "/Pernr", aSelectedKeys.join(","));
        this.getView()
          .getModel("PurchaseOrders")
          .setProperty(sBindingPath + "/ExecutantCnt", iCurrCount);
        let revert = this._onSavePress();
        if (revert) {
          this.getView()
            .byId("persComboTime")
            .setSelectedKeys(temp ? temp.split(",") : temp);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Pernr", temp);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/ExecutantCnt", count);
          this.updatePartcipants(temp ? temp : "");
        } else {
          this.updatePartcipants(aSelectedKeys);
        }
      },

      onStartPress: function (oEvent) {
        var oLocalModel = this.getView().getModel("local"),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          oValidation = null;

        let oObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          Pernr = oObject.Pernr;
        if (!Pernr) {
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Quantity", "");
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/PlDate", null);
          MBox.error(this.getText("SelectPartcipant"));
          return;
        } else {
          if (this.getSharedModel().getProperty("/publicRelease")) {
            //Level 2 validation is required.
            if (!oObject.Pernr) {
              oObject.Pernr = "";
            }
            var oValidation = this.getValidator().validatePublicTS(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.Pernr.split(","),
              "onStartPress"
            );
          }
          if (oValidation && oValidation.isValid === false) {
            /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: 42*/
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: 42*/
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/Quantity", "");
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/PlDate", null);
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/EndDate", null);
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
            // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){

            // }else{
            // 	MBox.warning(oValidation.sMessage);
            // }
          }
          let moStart = new moment();
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(
              sBindingPath + "/PlDate",
              moStart.format("YYYY-MM-DD HH:mm:ss")
            );
          /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
          let save =  this.confirmationBlocker(this.getView().getModel("PurchaseOrders"), sBindingPath, oObject)
          if(!save){
            this._onSavePress();
          }
          /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
          
        }
        
      },

      showStartButton: function (oExecStart, bSplit) {
        if (!oExecStart && !bSplit) {
          this.getSharedModel().setProperty("/WidthofLabelS", 10);
          this.getSharedModel().setProperty("/WidthofLabelL", 7);
          this.getSharedModel().setProperty("/WidthofLabelM", 7);
          return true;
        } else {
          this.getSharedModel().setProperty("/WidthofLabelS", 10);
          this.getSharedModel().setProperty("/WidthofLabelL", 7);
          this.getSharedModel().setProperty("/WidthofLabelM", 7);
          return false;
        }
      },
      countPartic: function (Pernr) {
        return Pernr ? Pernr.split(",").length : 0;
      },
      splitIconEnable: function (Pernr, Status) {
        if (Pernr) {
          return Status === "false" ? true : false;
        }
        return false;
      },

      showStopButton: function (oExecStart, ActWork, bSplit) {
        if (oExecStart && !ActWork && ActWork !== 0 && !bSplit) {
          this.getSharedModel().setProperty("/WidthofLabelS", 10);
          this.getSharedModel().setProperty("/WidthofLabelL", 7);
          this.getSharedModel().setProperty("/WidthofLabelM", 7);
          return true;
        } else {
          if (oExecStart) {
            this.getSharedModel().setProperty("/WidthofLabelS", 12);
            this.getSharedModel().setProperty("/WidthofLabelL", 9);
            this.getSharedModel().setProperty("/WidthofLabelM", 9);
          }
          return false;
        }
      },

      onExecStartChange: async function (oEvent) {
        let oObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          sExecFin = oObject.EndDate,
          moFin = new moment(sExecFin),
          sExecStart = oEvent.getParameter("newValue"),
          moStart = new moment(sExecStart),
          oCalcData = this._calcActualWork(moStart, moFin),
          oLocalModel = this.getView().getModel("local"),
          PurchaseOrders = this.getView().getModel("PurchaseOrders");
          let sCurrPath =  sBindingPath,sCurrObject = oObject;
          if(oObject.Split){
            var childPath = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getBindingContextPath("PurchaseOrders");
            sCurrPath = childPath;
            sCurrObject = PurchaseOrders.getProperty(childPath)
          }
          /*BEGIN: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42
          Section Logic/ Checks- Add logic for actual work =0 MW PO FLOW*/
          if((oCalcData.ActWork===0 || oCalcData.ActWork==="0") && sExecFin)  {
            let proceed = await this.showConfirmationforQuantity();
            if(!proceed){
              PurchaseOrders.setProperty(sCurrPath + "/Quantity", "");
              PurchaseOrders.setProperty(sCurrPath + "/PlDate", null);
              PurchaseOrders.setProperty(sCurrPath + "/EndDate", null);
              return;
            }
          }
          /*END: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42*/

        if (!oObject.Pernr) {
          PurchaseOrders.setProperty(sBindingPath + "/PlDate", null);
          PurchaseOrders.setProperty(sBindingPath + "/Quantity", "");
          MBox.error(this.getText("SelectPartcipant"));
        } else {
          let oValidation = "";
          if (this.getSharedModel().getProperty("/publicRelease")) {
            if (oObject.Split) {
         
              oValidation = this.getValidator().validatePublicTS(
                PurchaseOrders.getProperty(childPath),
                this.getSharedModel(),
                oLocalModel,
                ""
              );
            } else {
              if (!oObject.Pernr) {
                oObject.Pernr = "";
              }
              oValidation = this.getValidator().validatePublicTS(
                oObject,
                this.getSharedModel(),
                oLocalModel,
                oObject.Pernr.split(",")
              );
            }
          }
          
          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
               /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
              // if (childPath) {
              //   PurchaseOrders.setProperty(childPath + "/Quantity", "");
              //   PurchaseOrders.setProperty(childPath + "/PlDate", null);
              //   PurchaseOrders.setProperty(childPath + "/EndDate", null);
              //   MBox.error(oValidation.sMessage);
              //   return;
              // } else {
              /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/

                PurchaseOrders.setProperty(sCurrPath + "/Quantity", "");
                PurchaseOrders.setProperty(sCurrPath + "/PlDate", null);
                PurchaseOrders.setProperty(sCurrPath + "/EndDate", null);
                MBox.error(oValidation.sMessage);
                return;
              // }
            } else {
              MBox.warning(oValidation.sMessage);
            }
            // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){

            // }else{
            // 	MBox.warning(oValidation.sMessage);
            // }
          }

          
          //oTimeSheets.setProperty("/PlDate", new Date());
          if (sExecFin) {
            if (oCalcData.bValid) {
              // oLocalModel.setProperty(sCurrPath + "/Quantity", oCalcData.ActWork);
              // oLocalModel.setProperty(sCurrPath + "/Unit", oCalcData.UnWork);
              PurchaseOrders.setProperty(
                sBindingPath + "/PlDate",
                moStart.format("YYYY-MM-DD HH:mm:ss")
              );
              PurchaseOrders.setProperty(
                sCurrPath + "/Quantity",
                oCalcData.ActWork
              );
              PurchaseOrders.setProperty(
                sCurrPath + "/Unit",
                oCalcData.UnWork
              );
            } else {
              /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/

              PurchaseOrders.setProperty(sCurrPath + "/PlDate", null);
              PurchaseOrders.setProperty(sCurrPath + "/Quantity", "");
              PurchaseOrders.setProperty(sCurrPath + "/Unit", "HUR");
              // return;
              /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/

              // oLocalModel.setProperty(sCurrPath + "/PlDate", null);
              // oLocalModel.setProperty(sCurrPath + "/Quantity", "");
              // oLocalModel.setProperty(sCurrPath + "/Unit", "");
            }
          } else {
            
            // PurchaseOrders.setProperty(
            //   sBindingPath + "/PlDate",
            //   moStart.format("YYYY-MM-DD HH:mm:ss")
            // );
            /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
           let valid =  this.confirmationBlocker(
              PurchaseOrders,
              sCurrPath,
              sCurrObject,
              moStart.format("YYYY-MM-DD HH:mm:ss")
            );
            if(!valid){
              if(!oObject.PlDate){
                 PurchaseOrders.setProperty(
                    sBindingPath + "/PlDate",
                    moStart.format("YYYY-MM-DD HH:mm:ss")
                  ); 
              }
            }
            PurchaseOrders.setProperty(sBindingPath + "/Quantity", "");
            PurchaseOrders.setProperty(sBindingPath + "/Unit", "HUR");
            // return;
            /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
          }
        }
      },

      onServiceSelect: function (oEvent) {
        let sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          //TBD
          sParentPath = sBindingPath.lastIndexOf(
            "/nodes",
            sBindingPath.lastIndexOf("/nodes") - 1
          );
        let Service = this.getView()
          .getModel("PurchaseOrders")
          .getProperty(sBindingPath + "/Service");
        let selected = this.getView()
          .getModel("PurchaseOrders")
          .getProperty(sParentPath + "/nodes")
          .find((aNode) => {
            return Service == aNode.ServiceNum;
          });
        if (selected) {
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/TrZone", selected.Zone_Serv);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Introw", selected.Introw);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Packno", selected.Packno);
        }
      },
      onEditPress: function () {
        let sBindingPath = this.getView()
          .getBindingContext("PurchaseOrders")
          .getPath();
        this.getView()
          .getModel("PurchaseOrders")
          .setProperty(sBindingPath + "/Status", "false");
        this._onSavePress();
      },

      onSavePress: function () {
        var oObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sPath = this.getView().getBindingContext("PurchaseOrders").getPath(),
          oLocalModel = this.getView().getModel("local"),
          oValidation = null;
        /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 
    Time registration need not be checked in case of save.
      It is only required in case of start / stop timig or by calender widget  */
        // if (this.getSharedModel().getProperty("/publicRelease")) {
        //   if (!oObject.Pernr) {
        //     oObject.Pernr = "";
        //   }
        //   oValidation = this.getValidator().validatePublicTS(
        //     oObject,
        //     this.getSharedModel(),
        //     oLocalModel,
        //     oObject.Pernr.split(",")
        //   );
        // }
        // if (oValidation && oValidation.isValid === false) {
        //   // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){
        //   if (this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant) {
        //     MBox.error(oValidation.sMessage);
        //     return true;
        //   } else {
        //     MBox.warning(oValidation.sMessage);
        //   }
        // }
        /*END: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: */
        this._onSavePress();
      },

      _onSavePress: function () {
        let oObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sPath = this.getView().getBindingContext("PurchaseOrders").getPath();

        if (oObject.Split === true && oObject.Pernr === "") {
          MBox.error(this.getText("MissingParticipants"));
          return;
        }
        var aChildren = oObject.ChildConfirmations,
          bSplit = oObject.Split,
          oValidation = null,
          sIncFields = "",
          aProm = [];
        if (!aChildren) aChildren = [];
        //TBD
        oValidation = this.getValidator().validateTimeSheets(
          oObject,
          this.getSharedModel()
        );
        if (oValidation && oValidation.isValid) {
          let PlanItem = this.getDBService().getPlanItemEntity();
          let update;
          if (PlanItem) {
            var self = this;
            update = this.getDBService().replaceObject(
              "PlanItem",
              oObject,
              PlanItem,
              PlanItem.key.propertyRef
            );
            Promise.all([update]).then((results) => {
              let path = self
                .getView()
                .getBindingContext("PurchaseOrders")
                .getPath();
              //object  = self.getView().getBindingContext("PurchaseOrders").getObject();
              // if(object.ServiceNum){
              // 	if(!object.nodes || !object.nodes.length){
              // 		object.nodes=[oCurrent];
              // 	}else{
              // 		let present =  object.nodes.findIndex(node=>{return node.PlId === oCurrent.PlId})
              // 		if(present!==-1){
              // 			object.nodes[present]=oCurrent;
              // 		}else{
              // 			object.nodes.push(oCurrent);
              // 		}
              // 	}
              // }else{
              // 	let index, service ;
              // 	let nodes = self.getView().getBindingContext("PurchaseOrders").getObject().nodes;
              // 	if(nodes){
              // 		index =self.getView().getBindingContext("PurchaseOrders").getObject().nodes.findIndex(function(oServ){return oServ.ServiceNum == oCurrent.Service});
              // 		service =self.getModel('PurchaseOrders').getProperty(path+ '/nodes/'+index)
              // 	}else{
              // 		let sBindingPath = self.getView().getBindingContext("PurchaseOrders").getPath();
              // 		let sParentPath= sBindingPath.slice(0,sBindingPath.lastIndexOf("/nodes"));
              // 		service = self.getModel('PurchaseOrders').getProperty(sParentPath);
              // 	}

              // 	if(!service.nodes || !service.nodes.length){
              // 		service.nodes=[oCurrent];
              // 	}else{
              // 		let timeIndex = service.nodes.findIndex((aNode)=>{return aNode.PlId === oCurrent.PlId})
              // 		if(timeIndex!==-1){
              // 			service.nodes[timeIndex]=oCurrent
              // 		}else{
              // 			service.nodes.push(oCurrent);
              // 		}
              // 	}
              // }
              self.getModel("PurchaseOrders").setProperty(path, oObject);

              if (!bSplit && aChildren && aChildren.length > 0) {
                aChildren.forEach(
                  jQuery.proxy(function (oChild) {
                    aProm.push(
                      this.getDBService().deleteObject(
                        "PlanItem",
                        oChild,
                        this.getDBService().getPlanItemEntity()
                      )
                    );
                  }, this)
                );

                // this.updateTreeTable();

                $.when(aProm).done(
                  jQuery.proxy(function () {
                    oModel.setProperty(sPath + "/ChildConfirmations", []);
                    MToast.show(this.getText("ConfUpdated"));
                  }, this)
                );
              } else {
                if (aChildren.length === 0) {
                  // this.updateTreeTable()
                }
                aChildren.forEach(
                  jQuery.proxy(function (oChild) {
                    for (var sProp in oObject) {
                      switch (sProp) {
                        case "PlComment":
                          // case "FinConf":
                          // case "Text":
                          oChild[sProp] = oObject[sProp];
                          break;
                      }
                    }
                    aProm.push(
                      this._saveTableToDB(
                        oChild,
                        this.getDBService().getPlanItemEntity(),
                        "Replace"
                      )
                    );
                  }, this)
                );
                $.when(aProm)
                  .done(
                    jQuery.proxy(function () {
                      MToast.show(this.getText("ConfUpdated"));
                      this.getLogs().addLog(
                        this.getText("ConfUpdated"),
                        "INFO",
                        "ConfirmationDetail"
                      );
                      // this.updateTreeTable();
                    }, this)
                  )
                  .fail(
                    function () {
                      // this.updateTreeTable();
                    }.bind(this)
                  );
              }
            });
          }
        } else {
          for (var sField in oValidation.aFields) {
            if (sIncFields === "") {
              sIncFields += this.getText(oValidation.aFields[sField]);
            } else {
              sIncFields += ", " + this.getText(oValidation.aFields[sField]);
            }
          }
          MBox.error(this.getText(oValidation.sMessage, [sIncFields]));
          this.getLogs().addLog(
            this.getText(oValidation.sMessage, [sIncFields]),
            "ERROR",
            "ConfirmationDetail"
          );
        }
      },

      onFinalizePress: function (oEvent) {
        //TBD
        let oCurrent = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sPath = this.getView().getBindingContext("PurchaseOrders").getPath();
        let oValidation = this.getValidator().validateFinalTimeSheets(
            oCurrent,
            this.getSharedModel()
          ),
          sIncFields = "";
        if (oValidation && oValidation.isValid) {
          var self = this;
          oCurrent.Status = "true";
          self
            .getView()
            .getModel("PurchaseOrders")
            .setProperty(sPath + "/Status", "true");
          this._onSavePress();
          return true;

          // update = this.getDBService().replaceObject(
          //   "PlanItem",
          //   oCurrent,
          //   PlanItem,
          //   PlanItem.key.propertyRef
          // );
          // Promise.all([update]).then((results) => {
          //   let path = self
          //       .getView()
          //       .getBindingContext("PurchaseOrders")
          //       .getPath(),
          //     object = self
          //       .getView()
          //       .getBindingContext("PurchaseOrders")
          //       .getObject();

          // });
        } else {
          for (var sField in oValidation.aFields) {
            if (sIncFields === "") {
              sIncFields += this.getText(oValidation.aFields[sField]);
            } else {
              sIncFields += ", " + this.getText(oValidation.aFields[sField]);
            }
          }
          MBox.error(this.getText(oValidation.sMessage, [sIncFields]));
          return false;
        }
      },

      onStopPress: async function (oEvent) {
        //Stop Execution
        var oPurchaseOrdersModel = this.getView().getModel("PurchaseOrders"),
          oLocalModel = this.getView().getModel("local"),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath();
        // Issue 115 & 116 in V13.0
        var oObject = this.getView()
          .getBindingContext("PurchaseOrders")
          .getObject();

        if (!oObject.Pernr) {
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/PlDate", null);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Quantity", "");
          MBox.error(this.getText("SelectPartcipant"));
        } else {
          if (this.getSharedModel().getProperty("/publicRelease")) {
            //Level 2 validation is required.
            if (!oObject.Pernr) {
              oObject.Pernr = "";
            }
            var oValidation = this.getValidator().validatePublicTS(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.Pernr.split(","),
              "onStopPress"
            );
            //Code written to check auto exit /sapSettings/EXIT_TIME
            this.exitTimeCheck(false);
          }

          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/PlDate", null);
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/Quantity", "");
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/EndDate", null);
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
            // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError')||oValidation.isImportant){

            // }else{
            // 	MBox.warning(oValidation.sMessage);
            // }
          }
          var oMomStart = new moment(oObject.PlDate),
            oMomEnd = new moment(new Date());
          let oCalcData = this._calcActualWork(oMomStart, oMomEnd);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Quantity", oCalcData.ActWork);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Unit", oCalcData.UnWork);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(
              sBindingPath + "/EndDate",
              oMomEnd.format("YYYY-MM-DD HH:mm:ss")
            );
          /*BEGIN: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42
          Section Logic/ Checks- Add logic for actual work =0 MW PO FLOW*/
          if(oCalcData.ActWork===0 || oCalcData.ActWork==="0")  {
            let proceed = await this.showConfirmationforQuantity();
            if(!proceed){
              this.getView()
              .getModel("PurchaseOrders")
              .setProperty(sBindingPath + "/Quantity", "");
            this.getView()
              .getModel("PurchaseOrders")
              .setProperty(sBindingPath + "/Unit", "HUR");
            this.getView()
              .getModel("PurchaseOrders")
              .setProperty(sBindingPath + "/EndDate", null);
              return;
            }
          }
          /*END: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42*/
         
          /*BEGIN: Date: 04/03/2024 AMID: A0866990  V13.1- MWX- Frontend-  Bug 48481 - MWX - Adjust confirmation when participant exits zone is in a 'running' confirmation */
          MBox.confirm(
            this.getText("FinalizeTimesheet"),
            jQuery.proxy(function (sAction) {
              if (sAction === sap.m.MessageBox.Action.OK) {
                // $.when(this.onFinalizePress()).done(jQuery.proxy(function (res) {
                if (this.onFinalizePress()) {
                  this._onSavePress();
                } else {
                  this.getView()
                    .getModel("PurchaseOrders")
                    .setProperty(sBindingPath + "/Quantity", "");
                  this.getView()
                    .getModel("PurchaseOrders")
                    .setProperty(sBindingPath + "/Unit", "HUR");
                  this.getView()
                    .getModel("PurchaseOrders")
                    .setProperty(sBindingPath + "/EndDate", null);
                }
                // }, this)).fail(jQuery.proxy(function (error) {

                // }, this));
              }
            }, this)
          );

          /*END: Date: 04/03/2024 AMID: A0866990  V13.1- MWX- Frontend-  Bug 48481 - MWX - Adjust confirmation when participant exits zone is in a 'running' confirmation */
        }
      },

      _calcActualWork: function (oMomStart, oMomEnd) {
        var oReturn = {
            ActWork: 0,
            UnWork: "",
            bValid: true,
          },
          oDuration = moment.duration(oMomEnd.diff(oMomStart)),
          iDuration = 0,
          iDays = Math.round(oDuration.asDays() * 10) / 10,
          iHours = Math.round(oDuration.asHours() * 10) / 10,
          iMinutes = Math.round(oDuration.asMinutes() * 10) / 10;

        if (oDuration.asMilliseconds() < 0) {
          oReturn.bValid = false;
          return oReturn;
        }

        if (iDays % 1 !== 0 || iDays === 0) {
          if (iHours % 1 !== 0 || iHours === 0) {
            iDuration = iMinutes;
            oReturn.UnWork = "MIN";
          } else {
            iDuration = iHours;
            oReturn.UnWork = "HUR";
          }
        } else {
          iDuration = iDays;
          oReturn.UnWork = "DAY";
        }

        oReturn.ActWork = Math.round(iDuration);

        return oReturn;
      },
      onActWorkChange: function (oEvent) {
        this._setConfirmationTimeStamp();
      },

      onUnWorkChange: function (oEvent) {
        this._setConfirmationTimeStamp();
      },

      _setConfirmationTimeStamp: async function () {
        var oObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          sActWork = oObject.Quantity,
          sUnWork = oObject.Unit,
          PlDate = oObject.PlDate,
          Pernr = oObject.Pernr,
          oCalcData = null,
          oLocalModel = this.getView().getModel("local");

        if (!PlDate || !Pernr) {
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Quantity", "");
            return
        }
        /*BEGIN: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42
          Section Logic/ Checks- Add logic for actual work =0 MW PO FLOW*/
        if( sActWork===0 || sActWork==="0"){
          let proceed = await this.showConfirmationforQuantity()
         if(!proceed){
          this.getView()
          .getModel("PurchaseOrders")
          .setProperty(sBindingPath + "/Quantity", "");
          return;
         }
        }
        /*END: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42*/

        if (sUnWork && sActWork) {
          oCalcData = this._calcExecStartFin(sActWork, sUnWork, PlDate);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/EndDate", oCalcData.ExecFin);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/PlDate", oCalcData.ExecStart);
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/Quantity", sActWork);
          if (this.getSharedModel().getProperty("/publicRelease")) {
            //Level 2 validation is required.
            if (!oObject.Pernr) {
              oObject.Pernr = "";
            }
            var oValidation = this.getValidator().validatePublicTS(
              oObject,
              this.getSharedModel(),
              oLocalModel,
              oObject.Pernr.split(","),
              ""
            );
          }
          if (oValidation && oValidation.isValid === false) {
            if (
              this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
              oValidation.isImportant
            ) {
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/Quantity", "");
              this.getView()
                .getModel("PurchaseOrders")
                .setProperty(sBindingPath + "/EndDate", null);
              MBox.error(oValidation.sMessage);
              return;
            } else {
              MBox.warning(oValidation.sMessage);
            }
            // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError') || oValidation.isImportant){

            // }else{
            // 	MBox.warning(oValidation.sMessage);
            // }
          }

          // oLocalModel.setProperty(sCurrPath + "/ExecStart", oCalcData.ExecStart);
          // oLocalModel.setProperty(sCurrPath + "/ExecFin", oCalcData.ExecFin);
        } else {
          // oLocalModel.setProperty(sCurrPath + "/IsFinished", false);
          // oLocalModel.setProperty(sCurrPath + "/ExecStart", "");
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/EndDate", null);
        }
      },

      onDeletePress: function (oEvent) {
        var oObject = this.getView()
          .getBindingContext("PurchaseOrders")
          .getObject();
        MBox.confirm("Do you want to delete the time sheet?", {
          onClose: jQuery.proxy(function (sAction) {
            if (sAction === "OK") {
              $.when(
                this.getDBService().deleteObject(
                  "PlanItem",
                  oObject,
                  this.getDBService().getPlanItemEntity()
                )
              )
                .done(
                  jQuery.proxy(function () {
                    this.getDBService().deleteIncluding(
                      "PlanItem",
                      "RowExcel",
                      [oObject.PlId]
                    );
                    this.getRouter().navTo("purchaseMaster");
                  }, this)
                )
                .fail(jQuery.proxy(function () {}, this));
            }
          }, this),
        });
      },

      onSplitSelected: function (oEvent) {
        if (oEvent.getParameters().selected) {
          this._createSubConfirmations();
        } else {
          this._clearSubConfirmations();
        }
        let sPath = this.getView()
          .getBindingContext("PurchaseOrders")
          .getPath();
        this.getModel("PurchaseOrders").setProperty(sPath + "/Quantity", "");
        this.getModel("PurchaseOrders").setProperty(sPath + "/EndDate", "");
        this._onSavePress();
      },

      onAddPersonPress: function (oEvent) {
        if (!this._oPersonPopover) {
          this._oPersonPopover = sap.ui.xmlfragment(
            "AddConfirmationDialog",
            "mobilework.view.purchase.PurchaseDetailTimeTablePopover",
            this
          );
          this.getView().addDependent(this._oPersonPopover);
        }
        this._oPersonPopover.openBy(oEvent.getSource());
      },
      onCancelPress: function () {
        this.getRouter().navTo("purchaseMaster");
      },

      _createSubConfirmations: function () {
        var sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          oParentConfirm = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          aConfParticipants,
          perNos = oParentConfirm.Pernr,
          // sSelectedPerson = oViewModel.getProperty("/SelectedPerson"),
          aCurrPersons = oParentConfirm.ChildConfirmations || [];

        if (perNos && typeof perNos === "string") {
          aConfParticipants = perNos.split(",").filter(Boolean);
        } else if (perNos) {
          aConfParticipants = perNos.filter(Boolean);
        }

        _.each(
          aConfParticipants,
          jQuery.proxy(function (oParticipant) {
            var oNewConf = {};

            for (var sProp in oParentConfirm) {
              oNewConf[sProp] = oParentConfirm[sProp];
            }

            var oFoundParticipant = _.find(
              this.getSharedModel().getProperty("/ParticipantPurchaseSet"),
              jQuery.proxy(function (oPartic) {
                return oPartic.sKey === oParticipant;
              }, this)
            );

            oNewConf.PlId = this.getHelper().getUUID();
            oNewConf.Pernr = oParticipant;
            oNewConf.PersName = oFoundParticipant
              ? oFoundParticipant.sName
              : "";
            // oNewConf.ExecStart = "";
            oNewConf.Quantity = "";
            oNewConf.EndDate = "";
            // oNewConf.FinConf = oParentConfirm.FinConf;
            oNewConf.Status = "false";
            oNewConf.Split = false; // oNewConf.Hidden = true;
            oNewConf.RowExcel = oParentConfirm.PlId;
            oNewConf.ExecutantCnt = 1; // IMPORTANT - Otherwise causes bugs in backend
            delete oNewConf.ChildConfirmations;
            this.getDBService().insertObject(
              "PlanItem",
              oNewConf,
              this.getDBService().getPlanItemEntity()
            );
            this._saveTableToDB(
              oNewConf,
              this.getDBService().getPlanItemEntity(),
              "Replace"
            );

            aCurrPersons.push(oNewConf);

            this.getView()
              .getModel("PurchaseOrders")
              .setProperty(sBindingPath + "/ChildConfirmations", aCurrPersons);

            // let timeSheets = this.getView().getModel("PurchaseOrders").getProperty(path+'/nodes')
            // let index = timeSheets.findIndex((oTs)=> oTs === oTimeSheets.Handle)
            // if(index!==-1){
            // 	timeSheets.splice( index, 1, oNewConf);
            // }else{
            // 	timeSheets.push(oNewConf);
            // }
            // this.getView().getModel("PurchaseOrders").setProperty(path+'/nodes',timeSheets)

            //aConfirmations.push(oNewConf);
          }, this)
        );
        if (aConfParticipants && aConfParticipants.length) {
          this.getView()
            .getModel("PurchaseOrders")
            .setProperty(sBindingPath + "/RowExcel", "X");
          oParentConfirm.RowExcel = "X";

          this._saveTableToDB(
            oParentConfirm,
            this.getDBService().getPlanItemEntity()
          );
        }

        //oLocalModel.setProperty("/ConfirmationSet", aConfirmations);
      },

      _clearSubConfirmations: function () {
        var oLocalModel = this.getView().getModel("PurchaseOrders"),
          sBindingPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          oParentConfirm = oLocalModel.getProperty(sBindingPath),
          aChildConfirmations = oParentConfirm.ChildConfirmations;

        oParentConfirm.ChildConfirmations = [];
        this.getView()
          .getModel("PurchaseOrders")
          .setProperty(sBindingPath + "/RowExcel", "");
        _.each(
          aChildConfirmations,
          jQuery.proxy(function (oChildConf) {
            this.getDBService().deleteObject(
              "PlanItem",
              oChildConf,
              this.getDBService().getPlanItemEntity()
            );
          }, this)
        );
        this._saveTableToDB(
          oParentConfirm,
          this.getDBService().getPlanItemEntity(),
          "Replace"
        );
      },

      onStartPersonPress: function (oEvent) {
        var oModel = this.getView().getModel("PurchaseOrders"),
          oLocalModel = this.getView().getModel("local"),
          sParentPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          parentObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          sPath = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getBindingContextPath("PurchaseOrders"),
          oObject = oModel.getProperty(sPath);
        if (this.getSharedModel().getProperty("/publicRelease")) {
          if (!oObject.Pernr) {
            oObject.Pernr = "";
          }
          var oValidation = this.getValidator().validatePublicTS(
            oObject,
            this.getSharedModel(),
            oLocalModel,
            oObject.Pernr.split(","),
            "onStartPersonPress"
          );
        }
        if (oValidation && oValidation.isValid === false) {
          // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError')||oValidation.isImportant){
          // 	MBox.error(oValidation.sMessage);
          // 	return;
          // }else{
          if (
            this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
            oValidation.isImportant
          ) {
            MBox.error(oValidation.sMessage);
            return;
          } else {
            MBox.warning(oValidation.sMessage);
            let moStart = new moment();
            oModel.setProperty(
              sPath + "/PlDate",
              moStart.format("YYYY-MM-DD HH:mm:ss")
            );
            // oModel.setProperty(
            //   sParentPath + "/PlDate",
            //   moStart.format("YYYY-MM-DD HH:mm:ss")
            // );
           
          }
          // }
        } else {
          let moStart = new moment();
          oModel.setProperty(
            sPath + "/PlDate",
            moStart.format("YYYY-MM-DD HH:mm:ss")
          );
        
        
        }
        /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
        let save = this.confirmationBlocker(this.getView().getModel("PurchaseOrders"), sPath, oObject)
        if(!save){
          this._onSavePress();
          if (!parentObject.PlDate) {
            oModel.setProperty(
              sParentPath + "/PlDate",
              moStart.format("YYYY-MM-DD HH:mm:ss")
            );
          }
        }
        /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/

      },

      onStopPersonPress: async function (oEvent) {
        var oModel = this.getView().getModel("PurchaseOrders"),
          oLocalModel = this.getView().getModel("local"),
          sPath = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getBindingContextPath("PurchaseOrders"),
          oObject = oModel.getProperty(sPath),
          oParentObject = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          oParentPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath();
        // Issue 115 & 116 in V13.0
        // if((oObject.Plant ? false : true) && (oParentObject.Plant ? false : true)){
        // 	var plantField = this.getText("Plant");
        // 	MBox.error(this.getText("FillInRequiredFields", plantField));
        // 	return ;
        //  }else if((this.getSharedModel().getProperty("/sapSettings/FILL_CONFT")==='X')?true:false){
        // 	 if((oObject.ConfText ? false : true) && (oParentObject.ConfText ? false : true)){
        // 		var ConfTextField = this.getText("ConfText");
        // 		MBox.error(this.getText("FillInRequiredFields", ConfTextField));
        // 		return ;
        // 	 }
        //  }
        var aOtherChildren = oParentObject.ChildConfirmations,
          aUnfinishedChildren = _.filter(aOtherChildren, {
            Status: "false",
          }),
          oMomStart = new moment(oObject.PlDate),
          oMomEnd = new moment(new Date()),
          oActWork = this._calcActualWork(oMomStart, oMomEnd),
          fnDoUpdate = jQuery.proxy(function () {
            oModel.setProperty(sPath + "/PlComment", oParentObject.PlComment);
            oModel.setProperty(sPath + "/Status", "true");
            oModel.setProperty(sPath + "/Quantity", oActWork.ActWork);
            oModel.setProperty(sPath + "/Unit", oActWork.UnWork);
            oModel.setProperty(
              sPath + "/EndDate",
              oMomEnd.format("YYYY-MM-DD HH:mm:ss")
            );
            this._onSavePress();
            //this._saveToDb();
          }, this);
        if (this.getSharedModel().getProperty("/publicRelease")) {
            /*BEGIN: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42
          Section Logic/ Checks- Add logic for actual work =0 MW PO FLOW*/
            if(oActWork.ActWork===0 || oActWork.ActWork==="0")  {
              let proceed = await this.showConfirmationforQuantity();
              if(!proceed){
                return;
              }
            }
           /*END: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42*/


          if (!oObject.Pernr) {
            oObject.Pernr = "";
          }
          var oValidation = this.getValidator().validatePublicTS(
            oObject,
            this.getSharedModel(),
            oLocalModel,
            oObject.Pernr.split(","),
            "onStopPersonPress"
          );
        }
        if (oValidation && oValidation.isValid === false) {
          if (
            this.getSharedModel().getProperty("/sapSettings/TrCheckError") ||
            oValidation.isImportant
          ) {
            MBox.error(oValidation.sMessage);
            return;
          } else {
            MBox.warning(oValidation.sMessage);
          }
          // if(this.getSharedModel().getProperty('/sapSettings/TrCheckError')){
          // 	MBox.error(oValidation.sMessage);
          // 	return;
          // }else{
          // MBox.warning(oValidation.sMessage);
          // }
        }

        if (new Date() < new Date(oObject.PlDate)) {
          MBox.error(this.getText("NoFinalizeStartInFuture"));
        } else {
          // check if current person is last to be finished
          // if so, check if all data has been provided on parent
          if (
            aUnfinishedChildren.length === 1 &&
            aUnfinishedChildren[0].PlId === oObject.PlId
          ) {
            // oParentObject.PlDate="true";
            // oParentObject.Status="true";
            // if (aUnfinishedChildren.length === 1 && aUnfinishedChildren[0].Handle === oObject.Handle) {
            var oValidation = this.getValidator().validateFinalTimeSheets(
              oParentObject,
              this.getSharedModel()
            );
            if (!oValidation.isValid) {
              MBox.error(this.getText("FillRequiredOnParentConf"));
            } else {
              if (oActWork.bValid) {
                oParentObject.Quantity = "true";
                //oParentObject.IsFinished="true";//For 98 12.1
                // oParentObject.ActWork="true";

                oParentObject.EndDate = new moment(new Date()).format(
                  "YYYY-MM-DD HH:mm:ss"
                );
                // oModel.setProperty(
                //   oParentPath + "/EndDate",
                //   oMomEnd.format("YYYY-MM-DD HH:mm:ss")
                // );
                fnDoUpdate();
              }
            }
            //oLocalModel.setProperty(sPath + "/FinalConfirmButton", true);
          } else {
            if (oActWork.bValid) {
              fnDoUpdate();
            }
          }
        }
      },

      // _saveToDb: function () {

      // 	var oModel = this.getView().getModel("PurchaseOrders"),
      // 	oLocalModel = this.getView().getModel("local"),
      // 	   sPath = this.getView().getBindingContext("PurchaseOrders").getPath(),
      // 	   oObject = oModel.getProperty(sPath);
      // 	//    oParentObject = this.getView().getBindingContext("PurchaseOrders").getObject(),
      // 	//    oParentPath = this.getView().getBindingContext("PurchaseOrders").getPath();
      // 	// var oLocal = this.getView().getModel("local"),
      // 	// 	oConfirmation = this.getView().getBindingContext("local").getObject(),
      // 	// 	sPath = this.getView().getBindingContext("local").getPath();
      // 		// if (this.getView().byId("persCombo") && this.getView().byId("persCombo").getSelectedKeys()) {
      // 		// 	oConfirmation.PersNo = this.getView().byId("persCombo").getSelectedKeys().join(",");
      // 		// }
      // 		if(oObject.Split ===true && oObject.Pernr===""){
      // 			MBox.error(this.getText('MissingParticipants'));
      // 			return;
      // 		}
      // 	var	aChildren = oObject.ChildConfirmations,
      // 		bSplit = oObject.Split,
      // 		oValidation = null,
      // 		sIncFields = "",
      // 		aProm = [];
      // 	if(!aChildren) aChildren=[];
      // 	// var plant=oConfirmation.Plant.toString();
      // 	// if(plant&&plant.length<4){
      // 	// 	while (	plant.length < 4) plant = "0" + plant;
      // 	// }
      // 	// oConfirmation.Plant=plant;
      // 	oValidation = this.getValidator().validatePublicTS(oObject, this.getSharedModel(),oLocalModel,oObject.Pernr.split(','));

      // 	if (oValidation && oValidation.isValid) {
      // 		// if(!this.getHelper().checkFinalConfExists(oLocal.getProperty("/ConfirmationSet"), oConfirmation.Aufnr, oConfirmation.Vornr, oConfirmation.SubActivity)){
      // 		// 	oLocal.setProperty(sPath+'/newConfirmationButton', oConfirmation.FinConf);
      // 		// }else{
      // 		// 	oLocal.setProperty(sPath+'/newConfirmationButton', true);
      // 		// }
      // 		$.when(	this._saveTableToDB(oObject, this.getDBService().getPlanItemEntity(),'Replace'))
      // 			.done(jQuery.proxy(function (oData) {

      // 				if (!bSplit && aChildren && aChildren.length > 0) {
      // 					aChildren.forEach(jQuery.proxy(function (oChild) {
      // 						aProm.push(this.getDBService().deleteObject("PlanItem", oChild,this.getDBService().getPlanItemEntity()));
      // 					}, this));

      // 					// this.updateTreeTable();

      // 					$.when(aProm).done(jQuery.proxy(function () {
      // 						oModel.setProperty(sPath + "/ChildConfirmations", []);
      // 						MToast.show(this.getText("ConfUpdated"));
      // 						this.getLogs().addLog(this.getText("ConfUpdated"), "INFO", "ConfirmationDetail");
      // 					}, this));
      // 				} else {
      // 					if(aChildren.length === 0){
      // 						// this.updateTreeTable()
      // 					}
      // 					aChildren.forEach(jQuery.proxy(function (oChild) {
      // 						for (var sProp in oConfirmation) {
      // 							switch (sProp) {
      // 							case "PlComment":
      // 							// case "FinConf":
      // 							// case "Text":
      // 								oChild[sProp] = oConfirmation[sProp];
      // 								break;

      // 							}
      // 						}
      // 						aProm.push(this._saveTableToDB(oChild, this.getDBService().getPlanItemEntity(),'Replace'));
      // 					}, this));
      // 					$.when(aProm).done(jQuery.proxy(function () {
      // 						MToast.show(this.getText("ConfUpdated"));
      // 						this.getLogs().addLog(this.getText("ConfUpdated"), "INFO", "ConfirmationDetail");
      // 						// this.updateTreeTable();
      // 					}, this)).fail(function(){
      // 						// this.updateTreeTable();
      // 					}.bind(this));
      // 				}
      // 			}, this))
      // 			.fail(jQuery.proxy(function (oError) {
      // 				MBox.error(this.getText("ConfUpdateFail"));
      // 				this.getLogs().addLog(this.getText("ConfUpdateFail"), "ERROR", "ConfirmationDetail");
      // 			}, this));
      // 	} else {
      // 		for (var sField in oValidation.aFields) {
      // 			if (sIncFields === "") {
      // 				sIncFields += this.getText(oValidation.aFields[sField]);
      // 			} else {
      // 				sIncFields += ", " + this.getText(oValidation.aFields[sField]);
      // 			}
      // 		}
      // 		MBox.error(this.getText(oValidation.sMessage, [sIncFields]));
      // 		this.getLogs().addLog(this.getText(oValidation.sMessage, [sIncFields]), "ERROR", "ConfirmationDetail");
      // 	}
      // },

      onTabSelect: function (oEvent) {
        var oShared = this.getSharedModel(),
          oViewModel = this.getModel("viewModel"),
          aPartic = oShared.getProperty("/ParticipantPurchaseSet"),
          aFinal = [];

        if (oEvent.getParameter("key") === "time") {
          aPartic.forEach(function (oPartic) {
            aFinal.push(oPartic);
          });
          oViewModel.setProperty("/ParticipantSet", aFinal);
          if (this._oTimeDetailForm) {
            this._oTimeDetailForm.unbindElement();
            this._oTimeDetailForm.setVisible(false);
          }
        }
      },

      onPersonPress: function (oEvent) {
        var sPath = oEvent.getSource().getBindingContextPath("PurchaseOrders"),
          sPersNo = this.getView()
            .getModel("PurchaseOrders")
            .getProperty(sPath + "/Pernr");

        if (!this._oTimeDetailForm) {
          this._oTimeDetailForm = this.getView().byId(
            "confTimeTableDetailFrom"
          );
          this._oTimeDetailForm.setVisible(true);
        }

        this._oTimeDetailForm.bindElement({
          path: sPath,
          model: "PurchaseOrders",
        });
        // We do this because otherwise we have a bug in create conf from order
        this._oTimeDetailForm.setTitle(sPersNo);
        this._oTimeDetailForm.setVisible(true);
      },

      onDeletePersonPress: function (oEvent) {
        var oModel = this.getView().getModel("PurchaseOrders"),
          oLocalModel = this.getView().getModel("local"),
          sPath = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getBindingContextPath("PurchaseOrders"),
          oObject = oModel.getProperty(sPath),
          // var oLocalModel = this.getView().getModel("local"),
          // sPath = oEvent.getSource().getParent().getParent().getBindingContextPath("local"),
          // oObject = oLocalModel.getProperty(sPath),
          sParentPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          sParentObject = oModel.getProperty(sParentPath),
          aChildren = oModel.getProperty(sParentPath + "/ChildConfirmations");

        $.when(
          this.getDBService().deleteObject(
            "PlanItem",
            oObject,
            this.getDBService().getPlanItemEntity()
          )
        )
          .done(
            jQuery.proxy(function () {
              var aCorrectedSelection = _.filter(
                this.getView().byId("persComboTime").getSelectedKeys(),
                function (oKey) {
                  return oKey !== oObject.Pernr;
                }
              );

              this.getView()
                .byId("persComboTime")
                .setSelectedKeys(aCorrectedSelection);
              oModel.setProperty(
                sParentPath + "/Pernr",
                aCorrectedSelection.toString()
              );
              oModel.setProperty(
                sParentPath + "/ExecutantCnt",
                oModel.getProperty(sParentPath + "/ExecutantCnt") - 1
              );
              _.remove(aChildren, {
                PlId: oObject.PlId,
              });
              oModel.setProperty(
                sParentPath + "/ChildConfirmations",
                aChildren
              );
              if (aChildren.length === 0) {
                // var parent=_.remove(this.getView().getModel("local").getProperty("/ConfirmationSet"), {
                // 	Handle: oObject.ParentHndl
                // });
                this.getDBService().deleteObject(
                  "PlanItem",
                  sParentObject,
                  this.getDBService().getPlanItemEntity()
                );
                this.getRouter().navTo("purchaseMaster");
              } else {
                this._onSavePress();
                // this._saveToDb();
                // _.remove(this.getView().getModel("local").getProperty("/ConfirmationSet"), {
                // 	Handle: oObject.Handle
                // });
              }
              oModel.refresh(true);
              // var path=this.findPath(oObject.ParentHndl);
              // if(path){
              // this.getView().bindElement({
              // 		path: "/ConfirmationSet/" + path,
              // 		model: "local"
              // 	});
              // }
              if (this._oTimeDetailForm) {
                this._oTimeDetailForm.setVisible(false);
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              MBox.error(this.getText("ConfirmDeleteError"));
            }, this)
          );
      },

      _getChildConfirmations: function () {
        var oModel = this.getView().getModel("PurchaseOrders"),
          oLocalModel = this.getView().getModel("local"),
          sPath = this.getView().getBindingContext("PurchaseOrders").getPath(),
          oObject = oModel.getProperty(sPath),
          // var oLocalModel = this.getView().getModel("local"),
          // aConfirmations = oLocalModel.getProperty("/ConfirmationSet"),
          // sPath = this.getView().getBindingContext("local").sPath,
          oParent = this.getView()
            .getBindingContext("PurchaseOrders")
            .getObject(),
          aChildren = [];

        if (!oParent) {
          return;
        }

        aChildren = oObject.ChildConfirmations;

        _.each(
          aChildren,
          jQuery.proxy(function (oChild) {
            var oFoundParticipant = _.find(
              this.getSharedModel().getProperty("/ParticipantPurchaseSet"),
              jQuery.proxy(function (oPartic) {
                return oPartic.sKey === oChild.Pernr;
              }, this)
            );

            oChild.PersName = oFoundParticipant ? oFoundParticipant.sName : "";
          }, this)
        );

        //this.getView().getModel("local").setProperty(sPath + "/ChildConfirmations", aChildren);

        if (aChildren && aChildren.length > 0 && this._oTimeDetailForm) {
          this._oTimeDetailForm.bindElement({
            path: sPath + "/ChildConfirmations/0",
            model: "PurchaseOrders",
          });
          // We do this because otherwise we have a bug in create conf from order
          this._oTimeDetailForm.setTitle(aChildren[0].Pernr);
        } else {
          if (this._oTimeDetailForm) {
            this._oTimeDetailForm.unbindElement();
            this._oTimeDetailForm.setTitle("");
          }
        }
      },

      onPersonAcceptPress: function () {
        var oLocalModel = this.getView().getModel("local"),
          oPurchaseOrdersModel = this.getView().getModel("PurchaseOrders"),
          oViewModel = this.getModel("viewModel"),
          sCurrPath = this.getView()
            .getBindingContext("PurchaseOrders")
            .getPath(),
          oParentConfirm = oPurchaseOrdersModel.getProperty(sCurrPath),
          sSelectedPerson = oViewModel.getProperty("/SelectedPerson"),
          aCurrPersons =
            oPurchaseOrdersModel.getProperty(
              sCurrPath + "/ChildConfirmations"
            ) || [],
          oNewConf = {};
        // aConfirmations = oLocalModel.getProperty("/ConfirmationSet");

        if (!sSelectedPerson) {
          return;
        }

        if (
          _.find(aCurrPersons, {
            Pernr: sSelectedPerson,
            Status: "false",
          })
        ) {
          MBox.error(
            this.getText("ConfirmationPersonExists", [sSelectedPerson])
          );
          return;
        } else {
          //oParentConfirm.PersNo.push(sSelectedPerson);
          this.getView().byId("persComboTime").addSelectedKeys(sSelectedPerson);
          oParentConfirm.Pernr = this.getView()
            .byId("persComboTime")
            .getSelectedKeys()
            .toString();
          oParentConfirm.ExecutantCnt = oParentConfirm.ExecutantCnt + 1;
          this._onSavePress();
        }

        for (var sProp in oParentConfirm) {
          oNewConf[sProp] = oParentConfirm[sProp];
        }

        var oFoundParticipant = _.find(
          this.getSharedModel().getProperty("/ParticipantPurchaseSet"),
          jQuery.proxy(function (oPartic) {
            return oPartic.sKey === sSelectedPerson;
          }, this)
        );
        oNewConf.PlId = this.getHelper().getUUID();
        oNewConf.Pernr = sSelectedPerson;
        oNewConf.PersName = oFoundParticipant ? oFoundParticipant.sName : "";
        // oNewConf.ExecStart = "";
        oNewConf.Quantity = "";
        oNewConf.EndDate = "";
        // oNewConf.FinConf = oParentConfirm.FinConf;
        oNewConf.Status = "false";
        oNewConf.PlDate = "";
        // oNewConf.Hidden = true;
        oNewConf.RowExcel = oParentConfirm.PlId;
        oNewConf.Split = false;
        oNewConf.ExecutantCnt = 1; // IMPORTANT - Otherwise causes bugs in backend
        delete oNewConf.ChildConfirmations;

        aCurrPersons.push(oNewConf);

        oViewModel.setProperty("/SelectedPerson", "");
        oPurchaseOrdersModel.setProperty(
          sCurrPath + "/ChildConfirmations",
          aCurrPersons
        );

        this.getDBService().insertObject(
          "PlanItem",
          oNewConf,
          this.getDBService().getPlanItemEntity()
        );
        this._oPersonPopover.close();
      },

      updatePartcipants: function (Pernr) {
        let oZonedPartcipants =
          this.getModel("PurchaseOrders").getProperty("/ZonedPartcipants");
        let oAllPartcipants =
          this.getModel("PurchaseOrders").getProperty("/AllPartcipants");
        let missingObjects = [],
          Pernrs;
        if (typeof Pernr === "string") {
          Pernrs = Pernr.split(",").filter(Boolean) || [];
        } else {
          Pernrs = Pernr ? Pernr.filter(Boolean) : [];
        }

        Pernrs.forEach(function (pernr) {
          var found = oZonedPartcipants.some(function (item) {
            return item.Pernr === pernr;
          });
          if (!found) {
            missingObjects.push(
              oAllPartcipants.find(function (participant) {
                return participant.Pernr === pernr;
              })
            );
          }
          return found;
        });

        let aParticipants = this.getPurchaseHelper()._setParticipantSet(
          oZonedPartcipants.concat(missingObjects)
        );
        this.getSharedModel().setProperty(
          "/ParticipantPurchaseSet",
          aParticipants
        );
      },
      /*BEGIN: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42
          Section Logic/ Checks- Add logic for actual work =0 MW PO FLOW*/
      showConfirmationforQuantity: async function(){
        var self = this;
        let sAction =  await new Promise((resolve, reject) => {
          MBox.confirm(this.getModel("i18n").getResourceBundle().getText("AWCantZero"), {
            actions: [
              MBox.Action.OK,
              MBox.Action.CANCEL,
            ],
            emphasizedAction: MBox.Action.OK,
            onClose: function (sAction) {
              resolve(sAction);
            },
          });
        })
        if (sAction === MBox.Action.OK) {
          return false
        }else{
          return true
        }
      },
       /*END: Date: 20/03/2024 AMID: A0866990 13.1 MWX Bug Number: 42*/
      /*BEGIN: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/
      confirmationBlocker: function (
        PurchaseOrders,
        sPath,
        oObject,
        dateTimePicker,
        participantChange
      ) {
        var runningConfirmations;
        var oConfirmations = this.getView().getModel("PurchaseOrders").getProperty("/TimeSheetSet").filter((row)=>{return row.RowExcel !== "X"})
        // _.filter(
        //   this.getView().getModel("PurchaseOrders").getProperty("/TimeSheetSet"),
        //   { RowExcel: false }
        // );
        runningConfirmations = _.filter(
          oConfirmations,
          jQuery.proxy(function (conf) {
            if (conf && oObject.PlId !== conf.PlId) {
              if (
                conf.PlDate &&
                (!conf.Quantity && conf.Quantity!==0) &&
                this.checkIncluded(oObject.Pernr, conf.Pernr)
              ) {
                return true;
              }
              return false;
            }
          }, this)
        );
        //	path="/ConfirmationSet/"+path;
        if (runningConfirmations.length > 0) {
          for (var i = 0; i < runningConfirmations.length; i++) {
            var personDisplayed = "",
              PersName = "";
            if (oObject.Pernr) {
              var persNoArray = oObject.Pernr.split(",");
              if (persNoArray.length > 0) {
                persNoArray.forEach(
                  jQuery.proxy(function (person) {
                    if (
                      person &&
                      runningConfirmations[i].Pernr.includes(person)
                    ) {
                      if (personDisplayed)
                        personDisplayed = personDisplayed + "," + person;
                      else personDisplayed = person;
                      var partcipants = _.filter(
                        this.getSharedModel().getProperty("/ParticipantSet"),
                        {
                          Pernr: person,
                        }
                      );
                      if (PersName) {
                        PersName = PersName + "," + partcipants[0].Sname;
                      } else PersName = partcipants[0].Sname;
                    }
                  }, this)
                );
              }
            }
            var slashText = runningConfirmations[i].PoNr +'/'+ runningConfirmations[i].PoPosNr+'/'+runningConfirmations[i].Service
            
            MBox.error(
              this.getModel("i18n").getResourceBundle().getText("TimesheetBlockText", [
                personDisplayed,
                PersName,
                // runningConfirmations[i].PoNr,
                slashText,
                // runningConfirmations[i].PoPosNr,
              ])
            );
          }
          //To Stop Confirmation Time Start button from starting
          // if (dateTimePicker) {
            PurchaseOrders.setProperty(sPath + "/PlDate", "");
          // }
          // if (participantChange) {
            return true;
          // }
        } else {
          if (participantChange) {
            return false;
          }
          if (dateTimePicker) {
            PurchaseOrders.setProperty(sPath + "/PlDate", dateTimePicker);
          } else {
            PurchaseOrders.setProperty(
              sPath + "/PlDate",
              new moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
            );
            let PlanItem = this.getDBService().getPlanItemEntity();
            this.getDBService().updateObject( "PlanItem",
                      oObject,
                      PlanItem,
                      PlanItem.key.propertyRef);
          }
        }
      },

      checkIncluded: function (main, row) {
        var persNoArray;
        if (main) {
          persNoArray = persNoArray = main.split(",");
          if (persNoArray.length == 1) {
            return row.includes(main);
          } else {
            if (
              persNoArray.find(function (person) {
                if (person && row.includes(person)) {
                  return true;
                }
              })
            ) {
              return true;
            }
          }
        }
        return false;
      }
      /*END: Date: 21/03/2024 AMID: A0866990 13.1 MWX Bug Number: 43*/

    });
  }
);
