/*global moment:true*/
/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "mobilework/libs/moment",
    "mobilework/libs/lodash",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
    "sap/ui/core/Fragment",
    "mobilework/controller/purchase/PurchaseHelper",
  ],
  function (
    Controller,
    MBox,
    Mo,
    Lo,
    Filter,
    FilterOperator,
    JSONModel,
    Sorter,
    Fragment,
    PurchaseHelper
  ) {
    "use strict";

    return Controller.extend("mobilework.controller.purchase.PurchaseMaster", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      /** @type sap.m.Dialog */
      oAddConfirmationDialog: null,

      /** @type sap.m.List */
      oMasterList: null,

      bFromOrderList: false,

      //---------------------------//
      // LIFECYCLE
      //---------------------------//

      /**
       * Called when a controller is instantiated and its View controls (if available) are already created.
       * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
       * @memberOf mobilework.view.ConfirmationsMaster
       */
      onInit: function () {
        this._initModels();
        this.getRouter()
          .getRoute("purchaseMaster")
          .attachMatched(this.onRouteMatched, this);
        this.getEventBus().subscribe(
          "scanner",
          "scannedPurchaseMaster",
          this.onExtScanSuccess,
          this
        );

        if (!this.getOwnerComponent().PurchaseHelper) {
          this.getOwnerComponent().PurchaseHelper = new PurchaseHelper();
        }
        this.collaped = false;
      },

      /**
       * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
       * @memberOf mobilework.view.ConfirmationsMaster
       */
      onExit: function () {
        // nothing yet
      },

      onRouteMatched: async function (oEvent) {
        //set scanner location
        this.getScanHandler().setLocation("PurchaseMaster");

        //set connection property
        this.getConnection();
        //this._getConfirmationsFromDb();
        this.changeColorOfDeviceId();
        let oPromPurOrders =
          this.getDBService().getEntitySet("xARMPxMW_POType"),
          oPromTimeSheets = this.getDBService().getEntitySet("PlanItem"),
          oPromService = this.getDBService().getEntitySet(
            "xARMPxMW_PO_SERVICESType"
          ),
          self = this,
          sqlCustom = this.getLastTimeReg(),
          oTimeRegistration = this.getDBService().getEntitySet(
            "TimeRegistration",
            sqlCustom
          ),
          owParticipants = this.getDBService().getEntitySet("wParticipants"),
          oParticipant = this.getDBService().getEntitySet("Participant");
        Promise.all([
          oPromPurOrders,
          oPromTimeSheets,
          oPromService,
          oTimeRegistration,
          owParticipants,
          oParticipant,
        ])
          .then((results) => {
            let oPurchaseOrders = self.getHelper().rowsToArray(results[0]),
              oPlanItems = self.getHelper().rowsToArray(results[1]),
              oService = self.getHelper().rowsToArray(results[2]);
            this.getView()
              .getModel("PurchaseOrders")
              .setProperty("/TimeSheetSet", oPlanItems);
            let aTimeRegistration = self.getHelper().rowsToArray(results[3]);
            let awParticipants = self.getHelper().rowsToArray(results[4]);
            let oParticipants = self.getHelper().rowsToArray(results[5]);
            this.createPurchaseOrder(
              oPurchaseOrders,
              oPlanItems,
              oService,
              oParticipants
            );
            if(this.collaped === false){
              this.onExpandTreetable();
            }

            let bParticipants = oParticipants.filter(function (row) {
              if (row.Pernr) {
                let found = _.find(awParticipants, { amei: row.Pernr });
                if (found && found.hash) {
                  let foundTimReg = _.find(aTimeRegistration, {
                    Pernr: row.Pernr,
                  });
                  if (
                    foundTimReg &&
                    foundTimReg.InOut === "01" &&
                    foundTimReg.TrZone
                  ) {
                    
                    return true;
                  }
                }
              }
            });
            self.getSharedModel().setProperty("/ParticipantSet", oParticipants);
            self
              .getModel("PurchaseOrders")
              .setProperty("/ZonedPartcipants", bParticipants);
            self
              .getModel("PurchaseOrders")
              .setProperty("/AllPartcipants", oParticipants);

             // Issue 33 for MWX 13.1
             self.onPOTabPressed(); 
          })
          .catch(function (err) {
            debugger;
            console.error(err.message);
          });
        //  //MWX 13.1 bug 24
        //  if(this.appliedFilters){
        // 	this._applyFilterSearch(this.appliedFilters);
        // }

        this.oSearch = null;
        /*BEGIN: Date: 01/03/2024 AMID: Sambit 13.1 Bug Number:27*/
        var oModel = new JSONModel({
          PONum: "",
        });
        this.getView().setModel(oModel, "PurchaseOrd");
        /*END: Date: 01/03/2024 AMID: Sambit 13.1 Bug Number:27*/

      },

      onNavBack: function () {
        // remove all non saved confirmations from local set
        //var aLocalConfSet = this.getModel("local").getProperty("/ConfirmationSet");

        // $.when(this.getDBService().getEntitySet("Confirmation")).done(jQuery.proxy(function (aConfirmations) {
        // 	var aConfirmationSet = this.getHelper().rowsToArray(aConfirmations);

        // 	_.each(aConfirmationSet, function (oConf) {
        // 		for (var sProp in oConf) {
        // 			if (oConf[sProp] === "true" || oConf[sProp] === "false") {
        // 				oConf[sProp] = oConf[sProp] === "true" ? true : false;
        // 			}
        // 		}
        // 	});

        // 	// if (aConfirmationSet.length > 0) {
        // 	_.each(aLocalConfSet, jQuery.proxy(function (oLocalConf) {
        // 		var oConfFound = _.find(aConfirmationSet, jQuery.proxy(function (oConf) {
        // 			return oConf.Handle === oLocalConf.Handle;
        // 		}, this));

        // 		if (!oConfFound) {
        // 			var aConfSet = this.getModel("local").getProperty("/ConfirmationSet");

        // 			aConfSet = _.remove(aConfSet, jQuery.proxy(function (oConf) {
        // 				return oConf.Handle !== oLocalConf.Handle;
        // 			}, this));

        // 			this.getView().getModel("local").setProperty("/ConfirmationSet", aConfSet);
        // 		}
        // 	}, this));

        // 	// }
        // }, this));
        //MWX Version 13.1 Bug 24
        this.clearFilters();
        this.getView().byId("idIconTabBar").setSelectedKey("all");
        try {
          sap.ui.getCore().byId('ViewSettingPurchase--ViewSettingPurchase')._getResetButton().firePress();
        }
        catch (error) {
          console.debug('Filter Clear Failed')
        }
        this.getModel("PurchaseOrders").setProperty("/addedPOnumbers", []);
        this.collaped = false;
        //MWX Version 13.1 Bug 24
        this.getRouter().navTo("main");
      },
      _getViewSettingsDialog: function () {
        if (!this.getOwnerComponent().oViewSettingsPurchase) {
          this.getOwnerComponent().oViewSettingsPurchase = sap.ui.xmlfragment("ViewSettingPurchase",
            "mobilework.view.fragments.ViewSettingPurchase",
            this);
          this.getView().addDependent(this.getOwnerComponent().oViewSettingsPurchase);
        }
        return this.getOwnerComponent().oViewSettingsPurchase;
      },
      onOpenViewSettings: function () {
        if(this.tabFilterPurchaseOrder !== undefined && this.getView().byId("idIconTabBar").getSelectedKey() !== "all"){
          var oPurchaseOrders = this.tabFilterPurchaseOrder || [];
        }else {
          var oPurchaseOrders = this.PurchaseOrdersSet || []; //this.getModel('local').getProperty('/PurchaseOrdersSet');
        }
        if (this.oSearch) {
          oPurchaseOrders = oPurchaseOrders.filter((row) => { return row.PoNumber.includes(this.oSearch) });
        }

        this._createFilterModels(oPurchaseOrders);
        this._getViewSettingsDialog().open();
      },

      _createFilterModels: function (data) {
        let filterPoNumber = [],
          filterPoShText = [],
          filterContractNumber = [],
          filterContractShText = [],
          filterServiceText = [],
          filterServiceNum = [],
          filterParticipant = [];
        var self = this;
        Promise.all([this.getDBService().getEntitySet("xARMPxMW_PO_SERVICESType")]).then((results) => {
          let oPlanItems = self.getHelper().rowsToArray(results[0]);
          if (this.oSearch)
            oPlanItems = oPlanItems.filter((row) => { return row.PoNumber.includes(this.oSearch) });
          /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/  
          // oPlanItems.forEach(
          //   function (row) {
          //     if (row.ServiceText) {
          //       filterServiceText.push({ ServiceText: row.ServiceText });
          //     }
          //     if (row.ServiceNum) {
          //       filterServiceNum.push({ ServiceNum: row.ServiceNum });
          //     }
          //   }.bind(this)
          // );
          /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
          
        });
        data.forEach(
          function (row) {
            if (row.PoNumber) {
              filterPoNumber.push({ PoNumber: row.PoNumber });
            }
            if (row.ContractNumber) {
              filterContractNumber.push({ ContractNumber: row.ContractNumber });
            }
            if (row.ContractShText) {
              filterContractShText.push({ ContractShText: row.ContractShText });
            }
            if (row.PoShText) {
              filterPoShText.push({ PoShText: row.PoShText });
            }
            /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
            row.nodes.forEach(
              function (row2) {
                if (row2.ServiceText) {
                    filterServiceText.push({ ServiceText: row2.ServiceText });
                }
                if (row2.ServiceNum) {
                     filterServiceNum.push({ ServiceNum: row2.ServiceNum });
                }
              }.bind(this)
            );
            filterServiceText = _.uniqBy(filterServiceText, function (row) {
              if (row.ServiceText) {
                return row.ServiceText;
              }
            });
            filterServiceNum = _.uniqBy(filterServiceNum, function (row) {
              if (row.ServiceNum) {
                return row.ServiceNum;
              }
            });
            this.getView()
              .getModel("filters")
              .setProperty("/filterServiceNum", filterServiceNum);
            this.getView()
              .getModel("filters")
              .setProperty("/filterServiceText", filterServiceText);
            /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/

            // Begin -- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
            row.nodes.forEach(
              function (row2) {
                row2.nodes.forEach(
                  function (row3) {
                    if (row3.Pernr) {
                      if(row3.Pernr.split(",").length > 1){
                        for(var z = 0; z < row3.Pernr.split(",").length; z++){
                          filterParticipant.push({ Pernr: row3.Pernr.split(",")[z] });
                        }
                      }else {                        
                        filterParticipant.push({ Pernr: row3.Pernr });
                      }
                    }
                  }.bind(this)
                );
              }.bind(this)
            );
            // End -- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
          }.bind(this)
        );
        filterPoNumber = _.uniqBy(filterPoNumber, function (row) {
          if (row.PoNumber) {
            return row.PoNumber;
          }
        });
        filterContractNumber = _.uniqBy(filterContractNumber, function (row) {
          if (row.ContractNumber) {
            return row.ContractNumber;
          }
        });
        filterContractShText = _.uniqBy(filterContractShText, function (row) {
          if (row.ContractShText) {
            return row.ContractShText;
          }
        });
        filterPoShText = _.uniqBy(filterPoShText, function (row) {
          if (row.PoShText) {
            return row.PoShText;
          }
        });

        // Begin -- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
        filterParticipant = _.uniqBy(filterParticipant, function (row) {
          if (row.Pernr) {
            return row.Pernr;
          }
        });

        this.getView()
          .getModel("filters")
          .setProperty("/filterParticipant", filterParticipant);

        // End -- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
        this.getView()
          .getModel("filters")
          .setProperty("/filterPoNumber", filterPoNumber);
        this.getView()
          .getModel("filters")
          .setProperty("/filterContractNumber", filterContractNumber);
        this.getView()
          .getModel("filters")
          .setProperty("/filterContractShText", filterContractShText);
        this.getView()
          .getModel("filters")
          .setProperty("/filterPoShText", filterPoShText);
      },

      _initModels: function () {
        // if (!this.getView().getModel("newConf")) {
        // 	this.getView().setModel(new JSONModel(), "newConf");
        // }
        if (!this.getView().getModel("filters")) {
          this.getView().setModel(new JSONModel(), "filters");
        }
      },

      onConfirmViewSettingsDialog: function (oEvent) {
        var aFilterItems = oEvent.getParameters().filterItems,
          aFilters = [],
          PoNumber = [],
          PoShText = [],
          ContractNumber = [],
          ContractShText = [],
          ServiceNum = [],
          ServiceText = [],
          aCaptions = [],

          // Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
          Pernr = [];

        // update filter state:
        // combine the filter array and the filter string
        aFilterItems.forEach(function (oItem) {
          switch (oItem.getKey()) {
            case "PoNumber":
              PoNumber.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            case "PoShText":
              PoShText.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            case "ContractNumber":
              ContractNumber.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            case "ContractShText":
              ContractShText.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            case "ServiceText":
              ServiceText.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            case "ServiceNum":
              ServiceNum.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            // Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
            case "Pernr":
              Pernr.push(
                new Filter(
                  oItem.getKey(),
                  FilterOperator.Contains,
                  oItem.getText()
                )
              );
              break;
            // case "FinishedFinConf":
            // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "green"));
            // 	break;
            // case "FinConf":
            // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "purple"));
            // 	break;
            // case "IsFinished":
            // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "blue"));
            // 	break;
            // case "Ongoing":
            // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "orange"));
            // 	break;
            // case "NotStarted":
            // 	aFilters.push(new Filter("Color", FilterOperator.EQ, "default"));
            default:
              break;
          }
        });

        // if(colors)
        // 	aFilters.push(new Filter("Color", FilterOperator.EQ, colors))
        // if(this.filtersAdded&& this.filtersAdded["Equipment"]){
        // 	aFilters.push(this.filtersAdded["Equipment"]);
        // }
        // if(this.filtersAdded && this.filtersAdded["FunctLoc"]){
        // 	aFilters.push(this.filtersAdded["FunctLoc"]);
        // }
        if (PoNumber.length) {
          aFilters.push(PoNumber);
        }
        if (PoShText.length) {
          aFilters.push(PoShText);
        }
        if (ContractNumber.length) {
          aFilters.push(ContractNumber);
        }
        if (ContractShText.length) {
          aFilters.push(ContractShText);
        }
        if (ServiceNum.length) {
          aFilters.push(ServiceNum);
        }
        if (ServiceText.length) {
          aFilters.push(ServiceText);
        }
        // Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
        if (Pernr.length) {
          aFilters.push(Pernr);
        }

        this.appliedFilters = aFilters;
        this._applyFilterSearch(aFilters,"","",true);
      },

      clearFilters: function () {
        var aFilters = [],
          aCaptions = [];

        this.appliedFilters = undefined;
        // if(sap.ui.getCore().byId("ViewSettingsDialog--flocList"))
        // 	sap.ui.getCore().byId("ViewSettingsDialog--flocList").removeSelections(true);
        // if(sap.ui.getCore().byId("ViewSettingsDialog--eqpmtList"))
        // 	sap.ui.getCore().byId("ViewSettingsDialog--eqpmtList").removeSelections(true);
        // if(sap.ui.getCore().byId("ViewSettingsDialog--colorList"))
        // 	sap.ui.getCore().byId("ViewSettingsDialog--colorList").removeSelections(true);
        // if(sap.ui.getCore().byId("ViewSettingsDialog"))
        // sap.ui.getCore().byId("ViewSettingsDialog").getFilterItems()[0].getCustomControl().removeSelections()
        this._applyFilterSearch(aFilters);
        this.onPOTabPressed();
      },

      _applyFilterSearch: function (aFilters,bTabFilter,oSelectedTab, oFromFilterIcon) {
        /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        if(oFromFilterIcon && this.tabFilterPurchaseOrder !== undefined && this.getView().byId("idIconTabBar").getSelectedKey() !== "all"){
          var aFilteredList = this.tabFilterPurchaseOrder;
        }else {
          var aFilteredList = this.PurchaseOrdersSet; //this.getModel('local').getProperty('/PurchaseOrdersSet');
        }
        /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        if (!aFilteredList) {
          return;
        }
        var aFilteredList = JSON.parse(JSON.stringify(aFilteredList));
        var aData = JSON.parse(JSON.stringify(aFilteredList)), plannedParticipant, aTempArray = [];
        if (aFilters.length > 0) {
          this.getView().byId("filter").setAggregation().setType("Emphasized");
        } else {
          this.getView().byId("filter").setAggregation().setType("Default");
        }
        let aSearch = this.oSearch,
          oFilters;
        if (aSearch) {
          aSearch = [
            [new Filter("PoNumberCustom", FilterOperator.Contains, aSearch)],
          ];
          oFilters = aSearch.concat(aFilters);
        } else {
          oFilters = aFilters;
        }

        //this.getView().byId("orderMasterTreeTable").getBinding("rows").filter(aFilters, "Application");

        /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        if(bTabFilter){
          if(oSelectedTab === "assigned"){
            var deviceId = this.getModel("shared").getProperty("/sapSettings/deviceName");
            aData = _.filter(
              aData,
              jQuery.proxy(function (row) {
                return row.AssignedDevice.includes(deviceId);
              }, this)
            );
          }else if(oSelectedTab === "planned"){
            var aParticipants  = this.getModel("shared").getProperty("/ParticipantSet");
            _.each(
              aParticipants,
              jQuery.proxy(function (oParticipants) {
                // let combo = oParticipants.map((row) => row.Pernr);
                plannedParticipant = _.filter(
                  aData,
                  jQuery.proxy(function (row) {                    
                      return row.PlannedParticipant.includes(oParticipants.Pernr);
                  }, this)
                );
                Array.prototype.push.apply(aTempArray,plannedParticipant);
              }, this)
            );         
              aData = aTempArray;
          }
          this.tabFilterPurchaseOrder = aData;
        }
        /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        _.each(
          oFilters,
          jQuery.proxy(function (oFilter) {
            if (
              oFilter[0].sPath === "ServiceNum" ||
              oFilter[0].sPath === "ServiceText"
            ) {
              let combo = oFilter.map((row) => row.oValue1);
              aData = _.filter(
                aData,
                jQuery.proxy(function (row) {
                  if (combo.length) {
                    let nodes = row.nodes.filter((service) => {
                      return combo.includes(service[oFilter[0].sPath]);
                    });
                    if (nodes.length) {
                      row.nodes = nodes;
                    }
                    return nodes.length;
                  }
                }, this)
              );
            }
            // Begin --- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
            else if (
              oFilter[0].sPath === "Pernr"
            ) {
              let combo = oFilter.map((row) => row.oValue1);
              aData = _.filter(
                aData,
                jQuery.proxy(function (row) {
                  if (combo.length) {
                    row.nodes = _.filter(
                      row.nodes,
                      jQuery.proxy(function (row1) {
                        let nodes = row1.nodes.filter((service) => {
                          if(service.Pernr.split(",").length > 1){
                            for(var z = 0; z < service.Pernr.split(",").length; z++){
                              if(combo[0] === service.Pernr.split(",")[z]){
                                return combo.includes(service[oFilter[0].sPath].split(",")[z]);
                              }
                            }
                          }else {
                            return combo.includes(service[oFilter[0].sPath]);
                          }
                        });
                        if (nodes.length) {
                          row1.nodes = nodes;
                          row.nodes = row1;
                        }
                        return nodes.length;
                      }, this));

                    if (row.nodes.length) {
                      return row.nodes.length;
                    }
                  }
                }, this)
              );
            }
            // End ---- Dev : A1015320 || V2024- MWX- ARM185- FE- Extra filter by AMEI Nr for timesheet
            else {
              if (oFilter[0].sPath === "PoNumberCustom") {
                aData = _.filter(
                  aData,
                  jQuery.proxy(function (row) {
                    return row.PoNumber.includes(oFilter[0].oValue1);
                  }, this)
                );
              } else {
                //var atplnr = "Tplnr",aqmtxt = "Qmtxt";
                let combo = oFilter.map((row) => row.oValue1);
                aData = _.filter(
                  aData,
                  jQuery.proxy(function (row) {
                    // if(oFilter.oValue1&&this.findConfirmation(row).length){
                    if (combo.length) {
                      return combo.includes(row[oFilter[0].sPath]);
                      // return row[oFilter.sPath] === oFilter.oValue1;
                    }
                  }, this)
                );
              }
            }
          }, this)
        );
          /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        const unique = (arr, props = []) => [...new Map(arr.map(entry => [props.map(k => entry[k]).join('|'), entry])).values()];
        aData = unique(aData, ['PoNumber', 'PoItem']);
          /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
        this.getModel("PurchaseOrders").setProperty(
          "/PurchaseOrdersSet",
          aData
        );
        let oFilter = new sap.ui.model.Filter(
          "RowExcel",
          sap.ui.model.FilterOperator.NE,
          "X"
        );
        this.getView().byId("PurchaseOrderTree").getBinding().filter([oFilter]);
      },
      onExpandTreetable: function (oEvent) {
        this.getView().byId("PurchaseOrderTree").expandToLevel(3);
        this.collaped = false;
      },

      onCollapseTreetable: function (evt) {
        var oTree = this.getView().byId("PurchaseOrderTree");
        oTree.collapseAll();
        // Issue 36 MWX 13.1
        this.collaped = true;

      },

      onSearchLiveChange: function (oEvent) {
        let value = oEvent.getParameter('value');
        this.oSearch = value
        this._applyFilterSearch(this.appliedFilters || []);


      },
      onAddPress: function () {
        var oView = this.getView();
        // create dialog lazily
        if (!this.byId("AddPO")) {
          // set the view to busy state
          oView.setBusy(true);
          // load asynchronous XML fragment
          Fragment.load({
            controller: this,
            id: oView.getId(),
            name: "mobilework.view.fragments.AddPO"
          }).then(function (oDialog) {
            // remove the busy state
            oView.setBusy(false);
            // connect dialog to the root view of this component (models, lifecycle)
            oView.addDependent(oDialog);
            oDialog.open();
          });
        } else {
          this.byId("AddPO").open();
        }
      },
      onPOSave: function (oEvent, value) {
        
        if (oEvent) {
          oEvent.getSource().setEnabled(false)
          let that = oEvent.getSource();
          setTimeout(function () { that.setEnabled(true) }, 3000)

        }

        this.getView().setBusy(true);
        let self = this
        var oDialogModel = this.getModel("PurchaseOrd");
        let poValue = oDialogModel.getProperty("/PONum");
        let accpoValue = value ? value : poValue.trim();
        var oModel = self.getModel('PurchaseOrders').getProperty('/PurchaseOrdersSet');
        let foundPO = oModel.find(po => po.PoNumber === accpoValue);

        if (!accpoValue) {
          MBox.error(this.getModel("i18n").getResourceBundle().getText("GivePONo"));
          if (!value)
            this.byId("AddPO").close();
          this.getView().setBusy(false);
          // this.getView().byId("PO").setValue("");
          this.getModel("PurchaseOrd").setProperty("/PONum", "");
        } else if (foundPO) {
          MBox.error(this.getModel("i18n").getResourceBundle().getText("POExist"))
          if (!value)
            this.byId("AddPO").close();
          this.getView().setBusy(false);
          this.getModel("PurchaseOrd").setProperty("/PONum", "");
        } else {
          let oPromiseOrders = this.getService().getPurOrderItems(accpoValue);
          //oPromiseOperation = this.getService().getPurOrderService();
          //oPromiseOrders = this.getService().getPurOrderService();
          Promise.all([oPromiseOrders
            //,oPromiseOperation
          ]).then((results) => {
            
            var service = [];
            //let oPurchaseOrders = self.getHelper().rowsToArray(results[0]);
            let MW_PO_SERVICES = results[0].entity.find(enity => enity.name === "xARMPxMW_PO_SERVICESType")
            let MW_PO = results[0].entity.find(enity => enity.name === "xARMPxMW_POType")
            let PlanItemm = [];
            results[0].data.forEach(function (oPurOrd) {
              service = service.concat(oPurOrd.to_POServices.results);
            })
            if (results[0].data.length === 0) {
              MBox.error(this.getModel("i18n").getResourceBundle().getText("InvalidPO"));
              if (!value)
                this.byId("AddPO").close();
              this.getView().setBusy(false);
              // this.getView().byId("PO").setValue("");
              this.getModel("PurchaseOrd").setProperty("/PONum", "");
            } else {
              this.getModel("PurchaseOrd").setProperty("/PONum", "");
              let poNumbers = this.getModel("PurchaseOrders").getProperty("/addedPOnumbers") || [];
              poNumbers.unshift(accpoValue);
              this.getModel("PurchaseOrders").setProperty("/addedPOnumbers", poNumbers);
              // delete reqPO[0].to_POServices ;
              // this.addNewPurchaseOrder(reqPO,PlanItemm,service);
              this.addNewPurchaseOrder(results[0].data, PlanItemm, service);
              // this.createPurchaseOrder(results[0].data,PlanItemm,service);
              this.onExpandTreetable();
              self._saveTableToDB(results[0].data, MW_PO);
              self._saveTableToDB(service, MW_PO_SERVICES);
              if (!value)
                this.byId("AddPO").close();
              this.getView().setBusy(false);

            }
          }).catch(function (err) {
            self.getView().setBusy(false);
            if (err)
              MBox.error(err.message);
          });;
        }
      },
      onPOClose: function () {
        this.getView().setBusy(false);
        this.byId("AddPO").close();
        // this.getView().byId("PO").setValue("");
        this.getModel("PurchaseOrd").setProperty("/PONum", "");
      },
      addNewPurchaseOrder: function (oPurchaseOrders, OPlanItems, oService) {
        
        // let bOrder=Array.from(new Set(oPurchaseOrders.map(order=>order.PoNumber))) 
        OPlanItems.forEach(oTs => {
          if (oTs.PlDate && (oTs.Quantity || oTs.Quantity === 0)&& oTs.Unit) {
            if (oTs.RowExcel !== "X") {
              let dates = this._calcExecStartFin(oTs.Quantity, oTs.Unit, oTs.PlDate)
              oTs.EndDate = dates.ExecFin;
            }
          }
          if (oTs.Pernr) {
            if (oTs.Pernr.split(",").length > 1) {
              oTs.nameVisible = false;
            } else {
              oTs.nameVisible = true;
            }
            oTs.PersName = "";
            oTs.Pernr.split(",").forEach(function (Pernr) {
              for (var i = 0; i < oParticipantsSet.length; i++) {
                if (Pernr === oParticipantsSet[i].Pernr) {
                  oTs.PersName = oTs.PersName + oParticipantsSet[i].Sname + ",";
                }
              }
            });
            oTs.multiplePers = false;
            oTs.PersName = oTs.PersName.slice(0, -1);
          }
        })
        oPurchaseOrders.forEach(function (row) {
          let aServices = oService.filter(service => { return row.PoNumber === service.PoNumber && row.PoItem === service.PoItem })
          row.nodes = aServices;
          row.RowExcel = "";
          row.nodes.forEach(function (oService) {
            oService.nodes = []
            oService.RowExcel = "";
            let oCurrent = OPlanItems.filter((oPlanItem) => { return oPlanItem.PoNr === oService.PoNumber && oPlanItem.PoPosNr === oService.PoItem && oPlanItem.Service === oService.ServiceNum })
            // OPlanItems.filter((oPlanItem)=>{return oPlanItem.PoNr === oService.PoNumber &&   oPlanItem.PoPosNr === oService.PoItem &&  oPlanItem.Service === oService.ServiceNum && !(oPlanItem.RowExcel || !oPlanItem.RowExcel==="X")})
            if (oCurrent.length) {
              oCurrent.forEach((currentPlantItem)=>{ currentPlantItem.AllZone = oService.AllZone })
              oService.nodes = oService.nodes.concat(oCurrent);
            }
          })
        })
        var oModel = this.getModel('PurchaseOrders').getProperty('/PurchaseOrdersSet');
        // oModel.forEach(function(row){
        // 	row.nodes=aServices;
        // 	row.RowExcel="";
        // 	row.nodes.forEach(function(oService){
        // 		oService.nodes=[]
        // 		oService.RowExcel="";
        // 		let oCurrent =OPlanItems.filter((oPlanItem)=>{return oPlanItem.PoNr === oService.PoNumber &&   oPlanItem.PoPosNr === oService.PoItem &&  oPlanItem.Service === oService.ServiceNum })
        // 		// OPlanItems.filter((oPlanItem)=>{return oPlanItem.PoNr === oService.PoNumber &&   oPlanItem.PoPosNr === oService.PoItem &&  oPlanItem.Service === oService.ServiceNum && !(oPlanItem.RowExcel || !oPlanItem.RowExcel==="X")})
        // 		if(oCurrent.length){
        // 			oService.nodes = oService.nodes.concat(oCurrent);
        // 		}
        // 	})
        // })

        let POtoFInd = oPurchaseOrders[0].PoNumber;

        let oPromPurOrders = this.getDBService().getEntitySet("xARMPxMW_POType");
        oPurchaseOrders.forEach(function (row) {
          oModel.unshift(row);
        })
        this.getModel('PurchaseOrders').setProperty('/PurchaseOrdersSet', oModel);
        MBox.success(this.getModel("i18n").getResourceBundle().getText("POAdded"));
        // this.getModel('PurchaseOrders').setProperty('/PurchaseOrdersSet',oPurchaseOrders);
        let oFilter = [];
        oFilter.push(new sap.ui.model.Filter("RowExcel", sap.ui.model.FilterOperator.NE, "X"));
        this.getView().byId('PurchaseOrderTree').getBinding().filter(oFilter);

      },
      onSelectOrder: function (oEvent) {
        //let order= oEvent.getSource().getText();
        // let path = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getBindingContextPath(),
        // let path = oEvent.oSource.oParent.oParent.oParent.oParent.oParent.oParent.oParent.oBindingContexts.PurchaseOrders.sPath
        let path = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getBindingContext('PurchaseOrders').getPath()
        let oOrder = this.getModel('PurchaseOrders').getProperty(path);




        this.getModel('PurchaseOrders').setProperty('/selectedPurchaseOrder', path);
        // let path = oEvent.getParameter('id').slice(oEvent.getParameter('id').lastIndexOf('-')+1)

        this.getRouter().navTo("purchaseOrderDetail", {
          order: oOrder.PoNumber,
        });
      },
      onSelectPurOrder: function (oEvent) {
        let path = oEvent
          .getParameter("listItem")
          .getBindingContext("PurchaseOrders")
          .getPath(),
          oOrder = this.getModel("PurchaseOrders").getProperty(path);
        this.getModel("PurchaseOrders").setProperty(
          "/selectedPurchaseOrder",
          path
        );
        if (oOrder.Pernr) {
          this.getModel("PurchaseOrders").setProperty(
            "/createConfirmationSelected",
            path
          );
          this.getRouter().navTo("timeSheet", {
            order: oOrder.PoNr,
            operation: oOrder.PoPosNr,
            service: oOrder.Service,
            Id: oOrder.PlId,
          });
        }
        // else if(!oOrder.PoItem){
        // 	this.getRouter().navTo('purchaseOrderDetail',{
        // 		order: oOrder.PoNumber
        // 	});
        // }
        else if (!oOrder.ServiceNum) {
          this.getRouter().navTo("purchaseItemDetail", {
            order: oOrder.PoNumber,
            operation: oOrder.PoItem,
          });
        }
      },

      createPurchaseOrder: function (oPurchaseOrders, OPlanItems, oService, oParticipantsSet) {
        // let bOrder=Array.from(new Set(oPurchaseOrders.map(order=>order.PoNumber)))
        var oModel = this.getModel('PurchaseOrders').getProperty('/PurchaseOrdersSet');
        
        OPlanItems.forEach(oTs => {
          if (oTs.PlDate && (oTs.Quantity || oTs.Quantity === 0) && oTs.Unit) {
            if (oTs.RowExcel !== "X") {
              let dates = this._calcExecStartFin(oTs.Quantity, oTs.Unit, oTs.PlDate)
              oTs.EndDate = dates.ExecFin;
            }
          }
          if (oTs.Pernr) {
            if (oTs.Pernr.split(",").length > 1) {
              oTs.nameVisible = false;
            } else {
              oTs.nameVisible = true;
            }
            oTs.PersName = "";
            oTs.Pernr.split(",").forEach(function (Pernr) {
              for (var i = 0; i < oParticipantsSet.length; i++) {
                if (Pernr === oParticipantsSet[i].Pernr) {
                  oTs.PersName = oTs.PersName + oParticipantsSet[i].Sname + ",";
                }
              }
            });
            oTs.multiplePers = false;
            oTs.PersName = oTs.PersName.slice(0, -1);
          }

        })
        oPurchaseOrders.forEach(function (row) {
          let aServices = oService.filter(service => { return row.PoNumber === service.PoNumber && row.PoItem === service.PoItem })
          row.nodes = aServices;
          row.RowExcel = "";
          row.nodes.forEach(function (oService) {
            oService.nodes = []
            oService.RowExcel = "";
            let oCurrent = OPlanItems.filter((oPlanItem) => { return oPlanItem.PoNr === oService.PoNumber && oPlanItem.PoPosNr === oService.PoItem && oPlanItem.Service === oService.ServiceNum })
            // OPlanItems.filter((oPlanItem)=>{return oPlanItem.PoNr === oService.PoNumber &&   oPlanItem.PoPosNr === oService.PoItem &&  oPlanItem.Service === oService.ServiceNum && !(oPlanItem.RowExcel || !oPlanItem.RowExcel==="X")})
            if (oCurrent.length) {
              oCurrent.forEach((currentPlantItem)=>{ currentPlantItem.AllZone = oService.AllZone })
              oService.nodes = oService.nodes.concat(oCurrent);
            }
          })
        })

        let poNumbers = this.getModel("PurchaseOrders").getProperty("/addedPOnumbers") || [],
          sortedPurchaseOrders;
        if (poNumbers && poNumbers.length) {

          let orderIndices = new Map();
          poNumbers.forEach((num, index) => {
            orderIndices.set(num, index);
          });

          sortedPurchaseOrders = oPurchaseOrders.sort((a, b) => {
            const indexA = orderIndices.get(a.PoNumber);
            const indexB = orderIndices.get(b.PoNumber);
            if (indexA !== undefined && indexB !== undefined) {
              return indexA - indexB;
            }
            if (indexA !== undefined) {
              return -1;
            }
            if (indexB !== undefined) {
              return 1;
            }
            return 0;
          });
        } else {
          sortedPurchaseOrders = oPurchaseOrders;
        }
        this.PurchaseOrdersSet = sortedPurchaseOrders;
        // BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33
        const unique = (arr, props = []) => [...new Map(arr.map(entry => [props.map(k => entry[k]).join('|'), entry])).values()];
        oPurchaseOrders = unique(oPurchaseOrders, ['PoNumber', 'PoItem']);
        // End: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33
        if (this.appliedFilters) {
          this._applyFilterSearch(this.appliedFilters);
        } else {
          this.getModel('PurchaseOrders').setProperty('/PurchaseOrdersSet', oPurchaseOrders);
          let oFilter = [];
          oFilter.push(new sap.ui.model.Filter("RowExcel", sap.ui.model.FilterOperator.NE, "X"));
          this.getView().byId('PurchaseOrderTree').getBinding().filter(oFilter);
        }


      },

      confirmationCreatePress: function (oEvent) {
        let path = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getBindingContextPath();
        let oOrder = this.getModel('PurchaseOrders').getProperty(path);
        if (oOrder.ServiceNum) {
          this.getModel('PurchaseOrders').setProperty('/createConfirmationSelected', path)
          this.getRouter().navTo("timeSheet", { order: oOrder.PoNumber, operation: oOrder.PoItem, service: oOrder.ServiceNum });
        } else if (oOrder.PoItem) {
          this.getModel('PurchaseOrders').setProperty('/createConfirmationSelected', path)
          this.getRouter().navTo("timeSheet", { order: oOrder.PoNumber, operation: oOrder.PoItem });
        }
      },


      onScanPress: function (oEvent) {
        $.when(this.getScanHandler().scan())
          .done(jQuery.proxy(this.onScanSuccess, this))
          .fail(jQuery.proxy(function (oError) { }, this));
        // this.onScanSuccess({

        //     "text": "4200000042",

        // 	"format": "QR_CODE",

        // 	"cancelled": false

        // })
      },
      onExtScanSuccess: function (sChannel, sEvent, oData) {

        if (!oData.result.error) {
          this.onScanSuccess({
            text: oData.result.barcode
          });
        } else {
          MBox.error(oData.result.errorMessage);
        }
      },

      onScanSuccess: function (oData) {
        if (!oData.cancelled) {
          this.onPOSave(null, oData.text)
        }
      },

      /*BEGIN: Date: 01/03/2024 AMID: A0866990 13.1 Bug Number: 22*/
      formatHeaderDate: function (sDateString) {
        if (sDateString) {
          return new moment(sDateString).format("DD/MM/YYYY HH:mm");
        }

        return "-";
      },
      /*END: Date: 01/03/2024 AMID: A0866990 13.1 Bug Number: 22*/

      /*BEGIN: Date: 12/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/
      onPOTabPressed: function(oEvent){
        if(oEvent){
        var selectedTab = oEvent.getSource().mProperties.selectedKey;
        }else {
          var selectedTab = this.getView().byId("idIconTabBar").getSelectedKey();
        }
        this.appliedFilters = undefined;
        if(selectedTab === "all"){
          this._applyFilterSearch([]);
        }else if(selectedTab === "assigned" || selectedTab === "planned"){
          this._applyFilterSearch([],true,selectedTab);
        }
      },
      /*END: Date: 01/03/2024 AMID: A1015320 13.1 MWX Bug Number: 33*/

    });
  });
