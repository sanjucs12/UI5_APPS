sap.ui.define(
  ["mobilework/controller/BaseController", "sap/ui/model/json/JSONModel"],
  function (BaseController, JSONModel) {
    "use strict";

    return BaseController.extend("mobilework.controller.dialogs.YesNoDialog", {
      openYesNoDialog: function (view, text, title, yesCallback, noCallback) {
        if (!text) {
          return;
        }

        this.view = view;
        this.yesCallback = yesCallback;
        this.noCallback = noCallback;

        this._fragment = sap.ui.xmlfragment(
          "mobilework.view.dialogs.YesNoDialog",
          this
        );
        // version >= 1.20.x
        view.getView().addDependent(this._fragment);

        this._fragment.setModel(
          new JSONModel({
            text: text,
            title: title,
          }),
          "ynmodel"
        );

        setTimeout(
          jQuery.proxy(function () {
            this._fragment.open();
          }, this),
          100
        );
      },
      yesDialog: function () {
        if (this._fragment.isOpen()) {
          this._fragment.close();
        }
        this.yesCallback.call(this.view);
      },
      noDialog: function () {
        if (this._fragment.isOpen()) {
          this._fragment.close();
        }
        this.noCallback.call(this.view);
      },
    });
  }
);
