/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
    "mobilework/model/tables/OrderSyncTime",
  ],
  function (Controller, MToast, Filter, Lo, MBox, OrderSyncTime) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.orders.OrdersOperationsDetail",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        orderId: "",

        operationId: "",

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onInit: function () {
          this._initModels();
          this.getRouter()
            .getRoute("ordersOperationsDetail")
            .attachMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function (oEvent) {
          var sID = oEvent.getParameter("arguments").ID,
            sOrderID = oEvent.getParameter("arguments").OrderID;

          //set connection property
          this.getConnection();

          this.orderId = sOrderID;

          this.operationId = sID;

          if (!this.oIconBar) {
            this.oIconBar = this.getView().byId("OrderOperationDetailTabBar");
          }
          if (this.getScanHandler()._sLocation !== "ComponentDetail") {
            this.oIconBar.setSelectedKey("header");
          }
          this._bindView(sOrderID, sID);
          this.changeColorOfDeviceId();
        },

        onNavBack: function () {
          if (this.getScanHandler()._sLocation === "confirmationsMaster") {
            this.getRouter().navTo("confirmationsMaster");
          } else {
            this.getRouter().navTo("ordersDetail", {
              ID: this.orderId,
            });
          }
        },

        onComponentRowPress: function (oEvent) {
          var sID = oEvent
            .getSource()
            .getBindingContext("local")
            .sPath.split("/")[6];

          this.getRouter().navTo("ordersOperationsComponentDetail", {
            OrderID: this.orderId,
            OperationID: this.operationId,
            ID: sID,
          });
        },

        onCreateConfirmationPress: function (oEvent) {
          var oObject = this.getView().getBindingContext("local").getObject(),
            sAufnr = oObject.Orderid,
            sVornr = oObject.Activity,
            sUnWork = oObject.DurationNormalUnitIso,
            sWorkCntr = oObject.WorkCntr,
            sPlant = oObject.Plant,
            sConfText = oObject.ConfText,
            sOrderDescription = "",
            sSubActivity = oObject.SubActivity,
            sOperationDescription = oObject.Description,
            sParentHandle = oObject.Handle,
            oPromConfirmations =
              this.getDBService().getEntitySet("Confirmation"),
            oPromGetOrder = this.getDBService().getOrder(oObject.Orderid),
            oView = this.getView().setBusy(true);

          $.when(oPromConfirmations, oPromGetOrder).done(
            jQuery.proxy(function (oConfirmations, oOrder) {
              var aConfirmations = this.getHelper().rowsToArray(oConfirmations),
                aOrder = this.getHelper().rowsToArray(oOrder);

              sOrderDescription = aOrder[0].ShortText;

              oView.setBusy(false);

              _.each(aConfirmations, function (oConf) {
                for (var sProp in oConf) {
                  if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                    oConf[sProp] = oConf[sProp] === "true" ? true : false;
                  }
                }
              });

              if (
                !this.getHelper().checkFinalConfExists(
                  aConfirmations,
                  sAufnr,
                  sVornr,
                  sSubActivity
                )
              ) {
                var oCheckOperation = this.getHelper().checkOperationValid(
                  sAufnr,
                  oObject
                );
                if (
                  oCheckOperation.ControlKeyIsValid === true &&
                  oCheckOperation.PMEXValid === true
                ) {
                  this.getRouter().navTo("createConfirmationFromOrder", {
                    Aufnr: sAufnr,
                    Vornr: sVornr,
                    SubActivity: sSubActivity,
                    UnWork: sUnWork,
                    WorkCntr: sWorkCntr,
                    Plant: sPlant,
                    ConfText: sConfText,
                    OrderDescription: sOrderDescription,
                    OperationDescription: sOperationDescription,
                    ParentHandle: sParentHandle,
                  });
                } else {
                  if (!oCheckOperation.ControlKeyIsValid === true) {
                    MBox.error(
                      this.getText("IncorrectControlKeyForConfCreation", [
                        oObject.ControlKey,
                      ])
                    );
                  } else {
                    MBox.error(this.getText("InvalidPMEXOperation"));
                  }
                }
              } else {
                MBox.error(
                  this.getText("FinalConfirmationExistsOnOperation", [
                    sAufnr,
                    sVornr,
                  ])
                );
              }
            }, this)
          );
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {},

        _bindView: function (sOrderdID, sID) {
          var sBindingPath =
              "/PMOrderSetDataWithConf/" + sOrderdID + "/NavOperation/" + sID,
            oTablePRT = this.getView().byId("OperationPRTTable"),
            oTableComponent = this.getView().byId("OperationComponentTable");

          this.getView().bindElement({
            path: sBindingPath,
            model: "local",
          });

          if (
            this.getModel("local").getProperty(sBindingPath).SubActivity === ""
          ) {
            oTableComponent.bindItems(
              "local>" + sBindingPath + "/NavComponent",
              new sap.m.ColumnListItem({
                cells: [
                  new sap.m.Text({
                    text: "{local>MatlDesc}",
                  }),
                  new sap.m.Text({
                    text: "{local>RequirementQuantity}",
                  }),
                  new sap.m.Text({
                    text: "{local>CommitedQuan}",
                  }),
                  new sap.m.Text({
                    text: "{local>WithdQuan}",
                  }),
                  new sap.m.Text({
                    text: "{local>RequirementQuantityUnit}",
                  }),
                ],
                type: "Navigation",
                press: jQuery.proxy(this.onComponentRowPress, this),
              })
            );

            oTablePRT.bindItems(
              "local>" + sBindingPath + "/NavPRT",
              new sap.m.ColumnListItem({
                cells: [
                  new sap.m.Text({
                    text: "{local>ItemNoOfProductionResource}",
                  }),
                  new sap.m.Text({
                    text: "{local>PrtCategory}",
                  }),
                  new sap.m.Text({
                    // text: "{local>PrtDescription}"
                    text: "{local>Description}",
                  }),
                  new sap.m.Text({
                    text: "{local>StdUsageValueForPrt}",
                  }),
                  new sap.m.Text({
                    text: "{local>PrtUsageValueUnit}",
                  }),
                ],
              })
            );
          } else {
            oTableComponent.unbindItems();

            oTablePRT.unbindItems();
          }
          let oLocalModel = this.getView().getModel("local"),
            oObject = this.getView().getBindingContext("local").getObject();
          // if(!oLocalModel.getProperty(sBindingPath+'/WCADataFetched')){
          // 	this.wcaData(oObject)
          // }
          const gdlLinks = oLocalModel.getProperty("/GdlLinks");
          if (gdlLinks && gdlLinks.length) {
            const exists = gdlLinks.find((gdlLink) => {
              return (
                oObject.Orderid == parseInt(gdlLink.sObjId) &&
                gdlLink.HasLinksFlags === "true"
              );
            });
            oLocalModel.setProperty(
              sBindingPath + "/GdlPresent",
              exists ? "Positive" : "Default"
            );
          }
        },

        onCreateNotificationPress: function () {
          var orderTypeModel = new sap.ui.model.json.JSONModel();
          this.orderFound = _.find(
            this.getView()
              .getModel("local")
              .getProperty("/PMOrderSetDataWithConf"),
            jQuery.proxy(function (oOrder) {
              return (
                oOrder.Orderid ===
                this.getView().getBindingContext("local").getObject().Orderid
              );
            }, this)
          );
          var orderType = this.orderFound.OrderType;
          this.getView().setModel(orderTypeModel, "orderTypeModel");
          $.when(this.getHelper().getNotificationTypeOrderTypeLinkage())
            .done(
              jQuery.proxy(function (oResult) {
                oResult.OrderType[orderType].forEach(
                  jQuery.proxy(function (oRes) {
                    oRes.Description = this.getText(oRes.Description);
                  }, this)
                );
                orderTypeModel.setProperty(
                  "/NotifType",
                  oResult.OrderType[orderType]
                );
                orderTypeModel.setProperty("/Qmcod", orderType);
                this.getDialogManager().open(
                  "notifications.NotificationTypePopUp",
                  this.getView()
                );
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                console.debug("Error: " + oError);
              }, this)
            );
        },

        onNotificationTypeSelected: function (oEvent) {
          this.getDialogManager().close(
            "notifications.NotificationTypePopUp",
            this.getView()
          );
          var orderTypeModel = this.getView().getModel("orderTypeModel"),
            oOperation = this.getView().getBindingContext("local").getObject(),
            notifPath = oEvent.getSource().getSelectedItem().getId();
          notifPath = notifPath.slice(notifPath.lastIndexOf("-") + 1);
          var notifData = orderTypeModel.getData().NotifType[notifPath];
          if (oOperation.FunctLoc) {
            orderTypeModel.setProperty("/Tplnr", oOperation.FunctLoc);
          } else {
            orderTypeModel.setProperty("/Tplnr", this.orderFound.FunctLoc);
          }
          if (oOperation.Equipment) {
            orderTypeModel.setProperty("/Equnr", oOperation.Equipment);
          } else {
            orderTypeModel.setProperty("/Equnr", this.orderFound.Equipment);
          }
          //orderTypeModel.setProperty("/Text", notifData.Description + " number " + this.orderFound.Orderid);
          orderTypeModel.setProperty(
            "/Text",
            this.getText("FollowUpNotifDesc", [this.orderFound.Orderid])
          );
          orderTypeModel.setProperty("/Qmtxt", this.orderFound.ShortText);
          orderTypeModel.setProperty(
            "/Qmart",
            notifData.Type + "," + notifData.Code
          );
          orderTypeModel.setProperty("/Qmgrp", notifData.CodeGrp);
          orderTypeModel.setProperty("/Codgrr", notifData.CodeGrp);
          // orderTypeModel.setProperty("/Qmcod", notifData.Code);
          orderTypeModel.setProperty("/OrderHandle", this.orderFound.Orderid);
          orderTypeModel.setProperty("/DisabledForNotifFromOrder", false);
          if (notifData.Type === "30,DEFE") {
            orderTypeModel.setProperty("/Msaus", true);
          }
          this.getView()
            .getModel("local")
            .setProperty("/NotBoundNotifFromOrder", orderTypeModel.getData());
          //this.getView().getModel("orderTypeModel").setProperty("/","");
          this.getRouter().navTo("CreateNotificationFromOrder");
        },

        onNotificationTypePopUpCancelPress: function () {
          this.getDialogManager().close(
            "notifications.NotificationTypePopUp",
            this.getView()
          );
        },
        onShowGDLAppPress: function () {
          var sOrderId = this.getView()
            .getBindingContext("local")
            .getObject().Orderid;

          $.when(this.getGdlApi().showDocument(sOrderId)).fail(
            jQuery.proxy(function (oError) {
              MBox.error(oError.message);
            }, this)
          );
        },

        wcaData: function (object) {
          const sqlWCAOpeRisks = this.getDBService().getSqlEntity(
              "WCAOpeRisks",
              {
                Vornr: object.Activity,
                Objid: object.Orderid,
              }
            ),
            sqlWCAOpeData = this.getDBService().getSqlEntity("WCAOpeData", {
              Vornr: object.Activity,
              Objid: object.Orderid,
            }),
            sqlWCARisks = this.getDBService().getSqlEntity("WCARisks", {
              Objid: object.Orderid,
            });
          const oPromWCAOpeRisks = this.getDBService().getEntitySet(
              "WCAOpeRisks",
              sqlWCAOpeRisks
            ),
            oPromWCAOpeData = this.getDBService().getEntitySet(
              "WCAOpeData",
              sqlWCAOpeData
            ),
            self = this,
            oPromOrderSyncTime =
              this.getDBService().getEntitySet("OrderSyncTime");
          //delete wca data while deleting orders#todo
          Promise.all([
            oPromWCAOpeRisks,
            oPromWCAOpeData,
            oPromOrderSyncTime,
          ]).then((results) => {
            let WCAOpeData = self.getHelper().rowsToArray(results[1]),
              WCAOpeRisks = self.getHelper().rowsToArray(results[0]),
              OrderSyncTime = self.getHelper().rowsToArray(results[2]),
              // WCARisks = self.getHelper().rowsToArray(results[2]),
              riskdata = self.createTreeForWCA(WCAOpeRisks);
            OrderSyncTime = OrderSyncTime.filter((time) => {
              return (
                object.Orderid === time.Orderid &&
                time.Operation === object.Activity
              );
            });

            const sPath = self.getView().getBindingContext("local").getPath();
            self
              .getView()
              .getModel("local")
              .setProperty(sPath + "/WCAData", WCAOpeData);
            self
              .getView()
              .getModel("local")
              .setProperty(sPath + "/WCARiskData", riskdata);
            if (OrderSyncTime)
              self
                .getView()
                .getModel("local")
                .setProperty(sPath + "/OrderSyncTime", OrderSyncTime[0].Date);
            self
              .getView()
              .getModel("local")
              .setProperty(sPath + "/WCADataFetched", true);
          });
        },

        onIconBarSelect: function (oEvent) {
          var sKey = oEvent.getParameter("key");
          if (sKey === "wcm") {
            let busyDialog = new sap.m.BusyDialog();
            busyDialog.open();
            setTimeout(function () {
              busyDialog.close();
            }, 10000);
            let oObject = this.getView().getBindingContext("local").getObject();
            $.when(
              this.getService().getWCAData(oObject.Orderid, oObject.Activity)
            )
              .done(
                function (oData) {
                  this.onWCARetrieved(
                    oData.NavWCMSyncOpeData.results,
                    oData.NavWCMSyncOpeRisk.results
                  );
                  this.getDBService().multipleDataDb(
                    "WCARisks",
                    oData.NavWCMSyncRisk.results,
                    null,
                    "Replace"
                  );
                  this.getDBService().multipleDataDb(
                    "WCAData",
                    oData.NavWCMSyncData.results,
                    null,
                    "Replace"
                  );
                  this.getDBService().multipleDataDb(
                    "WCAOpeRisks",
                    oData.NavWCMSyncOpeRisk.results,
                    null,
                    "Replace"
                  );
                  this.getDBService().multipleDataDb(
                    "WCAOpeData",
                    oData.NavWCMSyncOpeData.results,
                    null,
                    "Replace"
                  );
                  let wcmTime = this.createTimeofSyncIn(
                    oObject.Orderid,
                    oObject.Activity
                  );
                  this._saveTableToDB(wcmTime, OrderSyncTime, "Replace");
                  busyDialog.close();
                }.bind(this)
              )
              .fail(
                function (oError) {
                  let oLocalModel = this.getView().getModel("local"),
                    sBindingPath = this.getView()
                      .getBindingContext("local")
                      .getPath();
                  if (
                    !oLocalModel.getProperty(sBindingPath + "/WCADataFetched")
                  ) {
                    this.wcaData(oObject);
                  }
                  busyDialog.close();
                }.bind(this)
              );
          }
        },

        onWCARetrieved: function (WCAOpenData, WCAOpeRisks) {
          let self = this;
          let riskdata = self.createTreeForWCA(WCAOpeRisks);
          let sPath = self.getView().getBindingContext("local").getPath();
          // V13.1 P555S - Bug 48589 - UAT issue 228 - WCM data - permits and 4th level is missing
          if (WCAOpenData.length > 0) {
            for (var x = 0; x < WCAOpenData.length; x++) {
              if (
                WCAOpenData[x].Need20 !== "X" &&
                WCAOpenData[x].Need21 !== "X" &&
                WCAOpenData[x].Need22 !== "X"
              ) {
                WCAOpenData[x].requirementsVisible = false;
              } else {
                WCAOpenData[x].requirementsVisible = true;
              }
              if (WCAOpenData[x].Need20 === "X") {
                WCAOpenData[x].Need20 = self.getText("NonStartUpTest");
              }
              if (WCAOpenData[x].Need21 === "X") {
                WCAOpenData[x].Need21 = self.getText("CheckAbsenceHazard");
              }
              if (WCAOpenData[x].Need22 === "X") {
                WCAOpenData[x].Need22 = self.getText("MachinePositioning");
              }
              if (
                WCAOpenData[x].Wk01 !== "X" &&
                WCAOpenData[x].Wk03 !== "X" &&
                WCAOpenData[x].Wk14 !== "X" &&
                WCAOpenData[x].Wk17 !== "X" &&
                WCAOpenData[x].Wk18 !== "X" &&
                WCAOpenData[x].Wk19 !== "X" &&
                WCAOpenData[x].Wk20 !== "X" &&
                WCAOpenData[x].Wk23 !== "X"
              ) {
                WCAOpenData[x].exPermitVisible = false;
              } else {
                WCAOpenData[x].exPermitVisible = true;
              }
              if (WCAOpenData[x].Wk01 === "X") {
                WCAOpenData[x].Wk01 = self.getText("HotWorksFire");
              }
              if (WCAOpenData[x].Wk03 === "X") {
                WCAOpenData[x].Wk03 = self.getText("ConfinedSpace");
              }
              if (WCAOpenData[x].Wk14 === "X") {
                WCAOpenData[x].Wk14 = self.getText("Excavation");
              }
              if (WCAOpenData[x].Wk17 === "X") {
                WCAOpenData[x].Wk17 = self.getText("ElectricalRoom");
              }
              if (WCAOpenData[x].Wk18 === "X") {
                WCAOpenData[x].Wk18 = self.getText("RestrictedArea");
              }
              if (WCAOpenData[x].Wk19 === "X") {
                WCAOpenData[x].Wk19 = self.getText("Hoist");
              }
              if (WCAOpenData[x].Wk20 === "X") {
                WCAOpenData[x].Wk20 = self.getText("AccessOnRoof");
              }
              if (WCAOpenData[x].Wk23 === "X") {
                WCAOpenData[x].Wk23 = self.getText("HighVoltage");
              }
            }
          }
          // End Bug 48589
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCAData", WCAOpenData);
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCARiskData", riskdata);
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCADataFetched", true);
          self
            .getView()
            .getModel("local")
            .setProperty(
              sPath + "/OrderSyncTime",
              new moment(new Date()).format("DD/MM/YYYY HH:mm:ss")
            );
        },

        createTimeofSyncIn: function (order, operation) {
          let timeOfSync = [];

          timeOfSync.push({
            Orderid: order,
            Operation: "",
            Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
          });
          timeOfSync.push({
            Orderid: order,
            Operation: operation,
            Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
          });

          return timeOfSync;
        },
      }
    );
  }
);
