/*global _:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
    "mobilework/model/tables/OrderSyncTime",
  ],
  function (Controller, MToast, Filter, Lo, MBox, OrderSyncTime) {
    "use strict";

    return Controller.extend("mobilework.controller.orders.OrdersDetail", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      orderId: "",

      //---------------------------//
      // LIFECYCLE
      //---------------------------//

      /**
       * Called when a controller is instantiated and its View controls (if available) are already created.
       * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
       * @memberOf mobilework.view.NotificationsDetail
       */
      onInit: function () {
        this._initModels();
        this.getRouter()
          .getRoute("ordersDetail")
          .attachMatched(this.onRouteMatched, this);
      },

      /**
       * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
       * @memberOf mobilework.view.NotificationsDetail
       */
      onExit: function () {},

      //---------------------------//
      // EVENT HANDLERS
      //---------------------------//

      onRouteMatched: function (oEvent) {
        var sID = oEvent.getParameter("arguments").ID;

        //set connection property
        this.getConnection();

        this.orderId = sID;

        this.getScanHandler().setLocation("OrderDetail");

        if (!this.oIconBar) {
          this.oIconBar = this.getView().byId("OrderDetailTabBar");
        }

        this.oIconBar.setSelectedKey("operations");

        this._bindView(sID);
        this.changeColorOfDeviceId();
      },

      onCreateConfirmationPress: function () {
        var sAufnr = this.getView()
            .getBindingContext("local")
            .getObject().Orderid,
          sMnWkCtr = this.getView()
            .getBindingContext("local")
            .getObject().MnWkCtr,
          oPromConfirmations = this.getDBService().getEntitySet("Confirmation"),
          oView = this.getView().setBusy(true);

        $.when(oPromConfirmations).done(
          jQuery.proxy(function (oConfirmations) {
            var aConfirmations = this.getHelper().rowsToArray(oConfirmations);

            _.each(aConfirmations, function (oConf) {
              for (var sProp in oConf) {
                if (oConf[sProp] === "true" || oConf[sProp] === "false") {
                  oConf[sProp] = oConf[sProp] === "true" ? true : false;
                }
              }
            });

            oView.setBusy(false);

            if (
              this.getHelper().checkFinalConfExists(aConfirmations, sAufnr) ===
              false
            ) {
              this.getRouter().navTo("createConfirmationFromOrder", {
                Aufnr: sAufnr,
                WorkCntr: sMnWkCtr,
              });
            } else {
              MBox.error(this.getText("FinalConfirmationExists", [sAufnr]));
            }
          }, this)
        );
      },

      onOperationPress: function (oEvent) {
        var sID = oEvent
          .getSource()
          .getBindingContext("local")
          .sPath.split("/")[4];

        this.getRouter().navTo("ordersOperationsDetail", {
          OrderID: this.orderId,
          ID: sID,
        });
      },

      onShowGDLAppPress: function () {
        var sOrderId = this.getView()
          .getBindingContext("local")
          .getObject().Orderid;

        $.when(this.getGdlApi().showDocument(sOrderId)).fail(
          jQuery.proxy(function (oError) {
            MBox.warning(oError.message);
            // MBox.error(oError.message);
          }, this)
        );
      },

      onNavBack: function () {
        this.getRouter().navTo("confirmationsMaster");
      },

      //---------------------------//
      // FORMATTING
      //---------------------------//

      //---------------------------//
      // PRIVATES
      //---------------------------//

      _initModels: function () {},

      _bindView: function (sID) {
        var sBindingPath = "/PMOrderSetDataWithConf/" + sID,
          oOperationTable = this.getView().byId("OrderOperationTable"),
          oLevelTreeTable = this.getView().byId("OrderLevelTreeTable");

        this.getView().bindElement({
          path: sBindingPath,
          model: "local",
        });

        oOperationTable.bindItems(
          "local>" + sBindingPath + "/NavOperation",
          new sap.m.ColumnListItem({
            type: "Navigation",
            cells: [
              new sap.m.Text({
                text: "{local>Activity}",
              }),
              new sap.m.Text({
                text: "{local>SubActivity}",
              }),
              new sap.m.Text({
                text: "{local>ControlKey}",
              }),
              new sap.m.Text({
                text: "{local>WorkCntr}",
              }),
              new sap.m.Text({
                text: "{local>Description}",
              }),
            ],
            press: jQuery.proxy(this.onOperationPress, this),
          })
        );

        oLevelTreeTable.bindRows({
          path: "local>" + sBindingPath + "/NavLevelTree",
          parameters: {
            arrayNames: ["Children"],
          },
        });
        let oLocalModel = this.getView().getModel("local");
        if (!parseInt(oLocalModel.getProperty(sBindingPath).PersNo)) {
          oLocalModel.setProperty(sBindingPath + "/PersNo", "");
        }
        let oObject = this.getView().getBindingContext("local").getObject();
        // $.when(this.getService().getWCAData('4000587','0010,0020')).done(
        // 	function(oData){
        // 		this.onWCARetrieved()
        // 	}.bind(this)
        // ).fail(
        // 	function(oError){

        // 	}.bind(this)
        // );
        // if(!oLocalModel.getProperty(sBindingPath+'/WCADataFetched')){
        // 	this.wcaData(oObject)
        // }
        const gdlLinks = oLocalModel.getProperty("/GdlLinks");
        if (gdlLinks && gdlLinks.length) {
          const exists = gdlLinks.find((gdlLink) => {
            return (
              oObject.Orderid == parseInt(gdlLink.sObjId) &&
              gdlLink.HasLinksFlags === "true"
            );
          });
          oLocalModel.setProperty(
            sBindingPath + "/GdlPresent",
            exists ? "Positive" : "Default"
          );
        }
        let aConfirmations =
            this.getModel("local").getProperty("/ConfirmationSet"),
          oOrder = aConfirmations.find((aConf) => {
            return aConf.Aufnr === oObject.Orderid;
          });
        oLocalModel.setProperty(
          sBindingPath + "/ConfirmationPresent",
          oOrder ? false : true
        );
      },

      onCreateNotificationConfirmPress: function () {
        var ordertypeModel = new sap.ui.model.json.JSONModel();
        var orderType = this.getView()
          .getBindingContext("local")
          .getObject().OrderType;
        this.getView().setModel(ordertypeModel, "orderTypeModel");
        $.when(this.getHelper().getNotificationTypeOrderTypeLinkage())
          .done(
            jQuery.proxy(function (oResult) {
              oResult.OrderType[orderType].forEach(
                jQuery.proxy(function (oRes) {
                  oRes.Description = this.getText(oRes.Description);
                }, this)
              );
              ordertypeModel.setProperty(
                "/NotifType",
                oResult.OrderType[orderType]
              );
              ordertypeModel.setProperty("/Qmcod", orderType);
              this.getDialogManager().open(
                "notifications.NotificationTypePopUp",
                this.getView()
              );
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              console.debug("Error: " + oError);
            }, this)
          );
      },

      onNotificationTypeSelected: function (oEvent) {
        this.getDialogManager().close(
          "notifications.NotificationTypePopUp",
          this.getView()
        );
        var ordertypeModel = this.getView().getModel("orderTypeModel");
        var oOrderType = this.getView().getBindingContext("local").getObject();
        var notifPath = oEvent.getSource().getSelectedItem().getId();
        notifPath = notifPath.slice(notifPath.lastIndexOf("-") + 1);
        var notifData = ordertypeModel.getData().NotifType[notifPath];
        ordertypeModel.setProperty("/Tplnr", oOrderType.FunctLoc);
        ordertypeModel.setProperty("/Equnr", oOrderType.Equipment);
        //ordertypeModel.setProperty("/Text", notifData.Description + " number " + oOrderType.Orderid);
        ordertypeModel.setProperty(
          "/Text",
          this.getText("FollowUpNotifDesc", [oOrderType.Orderid])
        );
        ordertypeModel.setProperty("/Qmtxt", oOrderType.ShortText);
        ordertypeModel.setProperty(
          "/Qmart",
          notifData.Type + "," + notifData.Code
        );
        ordertypeModel.setProperty("/Qmgrp", notifData.CodeGrp);
        ordertypeModel.setProperty("/Codgrr", notifData.CodeGrp);
        // ordertypeModel.setProperty("/Qmcod", notifData.Code);
        ordertypeModel.setProperty("/OrderHandle", oOrderType.Orderid);
        ordertypeModel.setProperty("/DisabledForNotifFromOrder", false);
        if (notifData.Type === "30,DEFE") {
          ordertypeModel.setProperty("/Msaus", true);
        }
        this.getView()
          .getModel("local")
          .setProperty("/NotBoundNotifFromOrder", ordertypeModel.getData());
        this.getRouter().navTo("CreateNotificationFromOrder");
      },

      onNotificationTypePopUpCancelPress: function () {
        this.getDialogManager().close(
          "notifications.NotificationTypePopUp",
          this.getView()
        );
      },

      onIconBarSelect: function (oEvent) {
        var sKey = oEvent.getParameter("key");
        if (sKey === "location") {
          this._onLevelTreeRequested();
        } else if (sKey === "wcm") {
          let busyDialog = new sap.m.BusyDialog();
          busyDialog.open();
          setTimeout(function () {
            busyDialog.close();
          }, 10000);
          let oObject = this.getView().getBindingContext("local").getObject();
          let errorFn = function (oError) {
            let oLocalModel = this.getView().getModel("local"),
              sBindingPath = this.getView()
                .getBindingContext("local")
                .getPath();
            if (!oLocalModel.getProperty(sBindingPath + "/WCADataFetched")) {
              this.wcaData(oObject);
            }
          }.bind(this);
          let operationNo;
          oObject.NavOperation.forEach(function (oper) {
            operationNo = operationNo
              ? operationNo + "," + oper.Activity
              : oper.Activity;
          });
          if (this.getService && this.getService()) {
            $.when(this.getService().getWCAData(oObject.Orderid, operationNo))
              .done(
                function (oData) {
                  this.onWCARetrieved(
                    oData.NavWCMSyncData.results,
                    oData.NavWCMSyncRisk.results,
                    oData.NavWCMSyncOpeRisk.results
                  );
                  this.saveWCAToDb(oData, oObject.Orderid, operationNo);
                  busyDialog.close();
                }.bind(this)
              )
              .fail(errorFn);
          } else {
            errorFn();
            busyDialog.close();
          }
        }
      },
      _onLevelTreeRequested: function () {
        var d = jQuery.Deferred();
        $.when(this._onInstallationTreeRequest())
          .done(
            jQuery.proxy(function () {
              var bomTree,
                oOrder = this.getView().getBindingContext("local").getObject(),
                FLData = { Tplnr: oOrder.FunctLoc },
                tree = this.getSharedModel().getProperty("/tree");
              if (tree && tree.length > 0 && tree[0]) {
                bomTree = this.getHelper().findChildTree(
                  this.getSharedModel().getProperty("/tree"),
                  FLData,
                  "Tplnr"
                );
              }
              var aLevelArray = this.createLevelArray(oOrder);
              _.forEach(aLevelArray, function (level) {
                level.TechObjectType = "FL";
              });
              var aLevelTree = this.getHelper().createTree(
                aLevelArray,
                "Index",
                "Parent",
                "Children"
              );
              if (bomTree) {
                this.getHelper().findChildTree(
                  aLevelTree,
                  aLevelArray[aLevelArray.length - 1],
                  "Index"
                ).Children = bomTree.Children;
              }
              var sPath = this.getView().getBindingContext("local").getPath();
              this.getView()
                .getModel("local")
                .setProperty(sPath + "/NavLevelTree", aLevelTree);
            }, this)
          )
          .fail(
            jQuery.proxy(function () {
              var oOrder = this.getView()
                  .getBindingContext("local")
                  .getObject(),
                aLevelArray = this.createLevelArray(oOrder),
                aLevelTree = this.getHelper().createTree(
                  aLevelArray,
                  "Index",
                  "Parent",
                  "Children"
                );
              var sPath = this.getView().getBindingContext("local").getPath();
              this.getView()
                .getModel("local")
                .setProperty(sPath + "/NavLevelTree", aLevelTree);
            }, this)
          );
        return d.promise();
      },

      setInstallationIcon: function (sType) {
        if (sType) {
          switch (sType.toUpperCase()) {
            case "FL":
              return "sap-icon://functional-location";
            case "IF":
              return "sap-icon://functional-location";
            case "EQ":
              return "sap-icon://technical-object";
            case "GR":
              return "sap-icon://group-2";
            case "MA":
              return "sap-icon://product"; //"sap-icon://suitcase" "sap-icon://product"
            default:
              return "sap-icon://question-mark";
          }
        } else {
          return "sap-icon://question-mark";
        }
      },

      onBomTreeSelected: function (oEvent) {
        var oObject = oEvent.getParameter("rowContext").getObject();
        if (!oObject.Matnr) {
          MToast.show(this.getText("NoBomForFlEQ"));
          return;
        }
        $.when(this.getDBService().getEntitySet("BomData"))
          .done(
            jQuery.proxy(function (oData) {
              var data = this.getHelper().rowsToArray(oData);
              var bomData = _.find(data, {
                Parent: oObject.Parent,
                Matnr: oObject.Matnr,
              });
              if (bomData) {
                this.getDialogManager().open(
                  "notifications.BomInfo",
                  this.getView()
                );
                this.getModel("local").setProperty("/BomData", bomData);
              } else MToast.show(this.getText("MaterialNotFound", oObject.Ktx01));
            }, this)
          )
          .fail(jQuery.proxy(function () {}, this));
      },

      onBomDataColse: function () {
        this.getDialogManager().close("notifications.BomInfo", this.getView());
      },

      createLevelArray: function (oOrder) {
        var aLevelArray = [];

        for (var i = 3; i < 8; i++) {
          if (oOrder["Level" + i]) {
            aLevelArray.push({
              Level: oOrder["Level" + i],
              Index: i,
              Parent: i - 1,
            });
          }
        }
        if (aLevelArray[0]) {
          aLevelArray[0].Parent = "";
        }
        return aLevelArray;
      },

      wcaData: function (object) {
        const sqlWCARisks = this.getDBService().getSqlEntity("WCARisks", {
            Objid: object.Orderid,
          }),
          sqlWCAData = this.getDBService().getSqlEntity("WCAData", {
            Objid: object.Orderid,
          }),
          sqlWCAOpeRisks = this.getDBService().getSqlEntity("WCAOpeRisks", {
            Objid: object.Orderid,
          });
        const oPromWCAOpeRisks = this.getDBService().getEntitySet(
          "WCAOpeRisks",
          sqlWCAOpeRisks
        );
        const oPromWCARisks = this.getDBService().getEntitySet(
            "WCARisks",
            sqlWCARisks
          ),
          oPromOrderSyncTime =
            this.getDBService().getEntitySet("OrderSyncTime"),
          oPromWCAData = this.getDBService().getEntitySet(
            "WCAData",
            sqlWCAData
          ),
          self = this;
        Promise.all([
          oPromWCARisks,
          oPromWCAData,
          oPromWCAOpeRisks,
          oPromOrderSyncTime,
        ]).then((results) => {
          let WCAData = self.getHelper().rowsToArray(results[1]),
            WCARisks = self.getHelper().rowsToArray(results[0]),
            WCAOpeRisks = self.getHelper().rowsToArray(results[2]),
            OrderSyncTime = self.getHelper().rowsToArray(results[3]),
            riskdata = self.createTreeForWCA(WCARisks.concat(WCAOpeRisks));
          let sPath = self.getView().getBindingContext("local").getPath();
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCAData", WCAData);
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCARiskData", riskdata);
          self
            .getView()
            .getModel("local")
            .setProperty(sPath + "/WCADataFetched", true);
          OrderSyncTime = OrderSyncTime.filter((time) => {
            return object.Orderid === time.Orderid && time.Operation === "";
          });
          if (OrderSyncTime)
            self
              .getView()
              .getModel("local")
              .setProperty(sPath + "/OrderSyncTime", OrderSyncTime[0].Date);
        });
      },

      onOrderDeassign: function () {
        let oSettings = this.getSharedModel().getProperty("/sapSettings"),
          sAufnr = this.getView()
            .getBindingContext("local")
            .getObject().Orderid;
        // let aConfirmations= this.getModel('local').getProperty('/ConfirmationSet');
        // let aPresent =  aConfirmations.find((aConf)=>{return aConf.IsFinished && aConf.Aufnr === sAufnr});
        this.toBeDeletedOrders = [sAufnr];

        MBox.confirm(
          this.getText("ConfirmDeassignWithOrder", this.toBeDeletedOrders),
          {
            onClose: jQuery.proxy(function (sAction) {
              if (sAction === "OK") {
                sAufnr = sAufnr.padStart(12, "0");
                $.when(
                  this.getService().deassignAllData(
                    oSettings.deviceName,
                    this.getHelper().isDevModeActive(),
                    sAufnr
                  )
                )
                  .done(
                    function () {
                      var oPromDelOrder = this.getDBService().deleteIncluding(
                        "PMOrder",
                        "Orderid",
                        this.toBeDeletedOrders
                      );
                      var oPromDelOrder = this.getDBService().deleteIncluding(
                        "Operation",
                        "Orderid",
                        this.toBeDeletedOrders
                      );
                      this.onNavBack();
                      MBox.success(
                        this.getText(
                          "OrderDeassignSuccessOrder",
                          this.toBeDeletedOrders
                        )
                      );
                    }.bind(this)
                  )
                  .fail(
                    function (oError) {
                      MBox.error(
                        this.getText(
                          "OrderDeassignFailedOrder",
                          this.toBeDeletedOrders
                        )
                      );
                    }.bind(this)
                  );
              }
            }, this),
          }
        );
      },

      onWCARetrieved: function (WCAData, WCARisks, WCAOpeRisks) {
        let self = this;
        let riskdata = self.createTreeForWCA(WCARisks.concat(WCAOpeRisks));
        let sPath = self.getView().getBindingContext("local").getPath();
        // V13.1 P555S - Bug 48589 - UAT issue 228 - WCM data - permits and 4th level is missing
        if (WCAData.length > 0) {
          WCAData[0].requirementsVisible = false;
          WCAData[0].exPermitVisible = false;
        }
        self
          .getView()
          .getModel("local")
          .setProperty(sPath + "/WCAData", WCAData);
        self
          .getView()
          .getModel("local")
          .setProperty(sPath + "/WCARiskData", riskdata);
        self
          .getView()
          .getModel("local")
          .setProperty(sPath + "/WCADataFetched", true);
        self
          .getView()
          .getModel("local")
          .setProperty(
            sPath + "/OrderSyncTime",
            new moment(new Date()).format("DD/MM/YYYY HH:mm:ss")
          );
      },

      saveWCAToDb: function (oData, order, operation) {
        this.getDBService().multipleDataDb(
          "WCARisks",
          oData.NavWCMSyncRisk.results,
          null,
          "Replace"
        );
        this.getDBService().multipleDataDb(
          "WCAData",
          oData.NavWCMSyncData.results,
          null,
          "Replace"
        );
        this.getDBService().multipleDataDb(
          "WCAOpeRisks",
          oData.NavWCMSyncOpeRisk.results,
          null,
          "Replace"
        );
        this.getDBService().multipleDataDb(
          "WCAOpeData",
          oData.NavWCMSyncOpeData.results,
          null,
          "Replace"
        );
        let wcmTime = this.createTimeofSyncIn(order, operation);
        this._saveTableToDB(wcmTime, OrderSyncTime, "Replace");
        // oData.NavWCMSyncRisk.results.filter((wcaRisk)=>{ return wcaRisk.Objid === oPMOrder.Orderid}).forEach((wcaRisk)=>{
        // 	aSQL.push({
        // 		sql: that._getSQLForReplaceObject("WCARisks", wcaRisk,null,CustomKeys[2].key.propertyRef),
        // 		values: that._getValueArrayForInsert("WCARisks", wcaRisk,null,CustomKeys[2].key.propertyRef)
        // 	});
        // });
        // oData.NavWCMSyncData.results.filter((WCAData)=>{ return WCAData.Objid === oPMOrder.Orderid}).forEach((WCAData)=>{
        // 	aSQL.push({
        // 		sql: that._getSQLForReplaceObject("WCAData", WCAData,null,CustomKeys[0].key.propertyRef),
        // 		values: that._getValueArrayForInsert("WCAData", WCAData,null,CustomKeys[0].key.propertyRef)
        // 	});
        // });
        // oData.NavWCMSyncOpeRisk.results.filter((WCAOpeRisks)=>{ return WCAOpeRisks.Objid === oPMOrder.Orderid}).forEach((WCAOpeRisks)=>{
        // 	aSQL.push({
        // 		sql: that._getSQLForReplaceObject("WCAOpeRisks", WCAOpeRisks,null,CustomKeys[3].key.propertyRef),
        // 		values: that._getValueArrayForInsert("WCAOpeRisks", WCAOpeRisks,null,CustomKeys[3].key.propertyRef)
        // 	});
        // });
        // oData.NavWCMSyncOpeData.results.filter((WCAOpeData)=>{ return WCAOpeData.Objid === oPMOrder.Orderid}).forEach((WCAOpeData)=>{
        // 	aSQL.push({
        // 		sql: that._getSQLForReplaceObject("WCAOpeData", WCAOpeData,null,CustomKeys[1].key.propertyRef),
        // 		values: that._getValueArrayForInsert("WCAOpeData", WCAOpeData,null,CustomKeys[1].key.propertyRef)
        // 	});
        // });
      },

      createTimeofSyncIn: function (order, operation) {
        let timeOfSync = [];
        timeOfSync.push({
          Orderid: order,
          Operation: "",
          Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
        });
        operation.split(",").forEach((oper) => {
          // timeOfSync.push({
          // 	Orderid:orders.Orderid,
          // 	Operation: '',
          // 	Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss")
          // })
          // orders.NavOperation && orders.NavOperation.results.forEach((operation)=>{
          timeOfSync.push({
            Orderid: order,
            Operation: oper,
            Date: new moment(new Date()).format("DD/MM/YYYY HH:mm:ss"),
          });
          // })
        });
        return timeOfSync;
      },

      // onOrderToBeDeassigned : function(oOrder){
      // 	if(!oOrder){
      // 		return true;
      // 	}
      // 	let aConfirmations= this.getModel('local').getProperty('/ConfirmationSet');
      // 	 oOrder =  aConfirmations.find((aConf)=>{return aConf.Aufnr === oOrder});
      // 	return oOrder?false:true;
      // }
    });
  }
);
