// /*global _:true*/
// sap.ui.define([
// 	"mobilework/controller/BaseController",
// 	"sap/ui/core/routing/History",
// 	"sap/ui/model/Filter",
// 	"sap/ui/model/FilterOperator",
// 	"mobilework/libs/lodash",
// 	"sap/m/MessageBox",
// 	"mobilework/libs/moment",
// 	"sap/ui/model/Sorter",
// 	"sap/ui/model/json/JSONModel",
// ], function (Controller, History, Filter, FilterOperator, Lo, MBox, Mo, Sorter, JSONModel) {
// 	"use strict";

// 	return Controller.extend("mobilework.controller.orders.OrdersMaster", {

// 		//---------------------------//
// 		// PROPERTIES
// 		//---------------------------//

// 		//---------------------------//
// 		// LIFECYCLE
// 		//---------------------------//

// 		/**
// 		 * Called when a controller is instantiated and its View controls (if available) are already created.
// 		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
// 		 * @memberOf mobilework.view.NotificationsMaster
// 		 */
// 		onInit: function () {
// 			this._initModels();
// 			this.getRouter().getRoute("ordersMaster").attachMatched(this.onRouteMatched, this);
// 		},

// 		/**
// 		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
// 		 * @memberOf mobilework.view.NotificationsMaster
// 		 */
// 		onExit: function () {

// 		},

// 		//---------------------------//
// 		// EVENT HANDLERS
// 		//---------------------------//

// 		onRouteMatched: function (oEvent) {
// 			//set scanner location
// 			this.getScanHandler().setLocation("OrderMaster");

// 			//set connection property
// 			this.getConnection();

// 			if (!this.oMasterList) {
// 				this.oMasterList = this.getView().byId("orderMasterTreeTable");
// 			}

// 			this._getOrdersFromDb();
// 			this.filtersAdded={
// 				"FunctLoc":null,
// 				"Equipment":null
// 			};
// 			this.listItem={
// 				"FunctLoc":null,
// 				"Equipment":null
// 			};
// 			// this.filtersforEQ=[];

// 			this.changeColorOfDeviceId();
// 		},

// 		onMasterSelectionChange: function (oEvent) {//Done
// 			var oBindingContext = oEvent.getParameter("rowContext");

// 			this.oMasterList.clearSelection();

// 			if (oBindingContext.sPath.indexOf("NavOperation") === -1)
// 				this.getRouter().navTo("ordersDetail", {
// 					ID: oBindingContext.sPath.split("/")[2]
// 				});
// 			else {
// 				this.getRouter().navTo("ordersOperationsDetail", {
// 					OrderID: oBindingContext.sPath.split("/")[2],
// 					ID: oBindingContext.sPath.split("/")[4]
// 				});
// 			}
// 		},

// 		onCreateFromActivityPress: function (oEvent) {
// 			var oBindingContext = oEvent.getSource().getParent().getBindingContext("local"),
// 				sSelectedActivity = oBindingContext.getProperty("SelectedActivity");

// 			// var oSelectedOperation = _.find(this.getView().byId("orderMasterTreeTable").getAggregation("rows"), function(oRow) {
// 			// 	return oRow.getId() === oEvent.getSource().getParent().getParent().getId();
// 			// })

// 			// if (oSelectedOperation) {
// 			var sPath = oBindingContext.sPath;
// 			var oSelectedActivity = this.getModel("local").getProperty(sPath);
// 			sSelectedActivity = oSelectedActivity.Activity;
// 			var sSelectedSubActivity = oSelectedActivity.SubActivity;
// 			var oCorrespondingOrderPath = sPath.split("/NavOperation")[0];
// 			var oCorrespondingOrder = this.getModel("local").getProperty(oCorrespondingOrderPath);
// 			// }

// 			if (sSelectedActivity) {
// 				var oView = this.getView().setBusy(true),
// 					oPromConfirmations = this.getDBService().getEntitySet("Confirmation"),
// 					sAufnr = oCorrespondingOrder.Orderid,
// 					aOperations = oCorrespondingOrder.NavOperation;

// 				$.when(oPromConfirmations)
// 					.done(jQuery.proxy(function (oConfirmations) {
// 						var aConfirmations = this.getHelper().rowsToArray(oConfirmations),
// 							oOperation = _.find(aOperations, {
// 								Activity: sSelectedActivity,
// 								SubActivity: sSelectedSubActivity
// 							});

// 						_.each(aConfirmations, function (oConf) {
// 							for (var sProp in oConf) {
// 								if (oConf[sProp] === "true" || oConf[sProp] === "false") {
// 									oConf[sProp] = oConf[sProp] === "true" ? true : false;
// 								}
// 							}
// 						});

// 						oView.setBusy(false);

// 						if (!this.getHelper().checkFinalConfExists(aConfirmations, sAufnr, oOperation.Activity, sSelectedSubActivity)) {
// 							var oCheckOperation = this.getHelper().checkOperationValid(sAufnr, oOperation);
// 							var cnfOperation= (oOperation.ConfFinal === "X" );
// 							if (oCheckOperation.ControlKeyIsValid === true && oCheckOperation.PMEXValid === true&&cnfOperation=== false) {
// 								this.getRouter().navTo("createConfirmationFromOrder", {
// 									Aufnr: sAufnr,
// 									WorkCntr: oOperation.WorkCntr,
// 									Vornr: oOperation.Activity,
// 									SubActivity: oOperation.SubActivity,
// 									UnWork: oOperation.DurationNormalUnitIso,
// 									Plant: oOperation.Plant,
// 									ConfText: oOperation.ConfText,
// 									ParentHandle: oOperation.Handle,
// 									ControlKey: oOperation.ControlKey
// 								});
// 							} else {
// 								if (!oCheckOperation.ControlKeyIsValid === true) {
// 									MBox.error(this.getText("IncorrectControlKeyForConfCreation", [oOperation.ControlKey]));
// 								}else if(cnfOperation){
// 										MBox.error(this.getText("CNFOperation"));
// 								}else {
// 									MBox.error(this.getText("InvalidPMEXOperation"));
// 								}
// 							}
// 						} else {
// 							if (this.getHelper().checkFinalConfExistsOnOperation(aConfirmations, sAufnr, oOperation.Activity, sSelectedSubActivity)) {
// 								MBox.error(this.getText("FinalConfirmationExistsOnOperation", [sAufnr, oOperation.Activity]));
// 							} else {
// 								MBox.error(this.getText("FinalConfirmationExists", [sAufnr]));
// 							}

// 						}
// 					}, this));
// 			} else {
// 				MBox.error(this.getText("SelectActivityFirst"));
// 			}
// 		},

// 		onCreateFromHeaderPress: function (oEvent) {
// 			var oView = this.getView().setBusy(true),
// 				oPromConfirmations = null,
// 				oBindingContext = oEvent.getSource().getParent().getBindingContext("local"),
// 				sAufnr = oBindingContext.getProperty("Orderid"),
// 				sMnWkCtr = oBindingContext.getProperty("MnWkCtr"),
// 				aOperations = oBindingContext.getProperty("NavOperation");

// 			// check if operations have same workcenter
// 			var sWorkCenter = aOperations[0].WorkCntr,
// 				aOperWorkCnt = _.filter(aOperations, {
// 					WorkCntr: sWorkCenter
// 				});

// 			if (aOperations.length !== aOperWorkCnt.length) {
// 				oView.setBusy(false);
// 				MBox.error(this.getText("NotAllOperSameWorkCntr"));
// 			} else {
// 				oPromConfirmations = this.getDBService().getEntitySet("Confirmation");
// 				$.when(oPromConfirmations)
// 					.done(jQuery.proxy(function (oConfirmations) {
// 						var aConfirmations = this.getHelper().rowsToArray(oConfirmations);

// 						_.each(aConfirmations, function (oConf) {
// 							for (var sProp in oConf) {
// 								if (oConf[sProp] === "true" || oConf[sProp] === "false") {
// 									oConf[sProp] = oConf[sProp] === "true" ? true : false;
// 								}
// 							}
// 						});

// 						oView.setBusy(false);

// 						if (!this.getHelper().checkFinalConfExists(aConfirmations, sAufnr)) {
// 							if (aOperations.length > 0) {
// 								sMnWkCtr = aOperations[0].WorkCntr;
// 							}
// 							this.getRouter().navTo("createConfirmationFromOrder", {
// 								Aufnr: sAufnr,
// 								WorkCntr: sMnWkCtr
// 							});
// 						} else {
// 							MBox.error(this.getText("FinalConfirmationExists", [sAufnr]));
// 						}
// 					}, this));
// 			}
// 		},

// 		onSearch: function (oEvent) {//Done N/A

// 		},

// 		onNavBack: function () { //Done N/A
// 			// this.getDialogManager().close("fragments.ViewSettingsDialog", this.getView());
// 			this.getDialogManager().destroyDialog("fragments.ViewSettingsDialog", this.getView());
// 			this.clearFilters();

// 			this.getRouter().navTo("main", true);
// 		},

// 		onSort: function (oEvent) {
// 			var sorts = [],
// 				treetable = this.getView().byId("orderMasterTreeTable");

// 			if (oEvent && oEvent.getSource()) {
// 				var sKey = oEvent.getSource().getSelectedItem().getKey();
// 			} else if (this.getSharedModel().getProperty("/sortKey")) {
// 				sKey = this.getSharedModel().getProperty("/sortKey");
// 			} else {
// 				sKey = "Default";
// 			}

// 			// if (sKey) {
// 			//     this.getSharedModel().setProperty("/sortKey", sKey);
// 			// }

// 			treetable.getBinding("rows").sort(null);

// 			if (sKey === "Default") {

// 				// sorts = this._createCustomSort();
// 				treetable.getBinding("rows").sort(null);
// 			} else if (sKey === "StartDateDt") {
// 				sorts.push(new Sorter(sKey, false));
// 				treetable.getBinding("rows").sort(sorts);
// 			} else if (sKey === "FunctLoc") {
// 				sorts.push(new Sorter(sKey, false));
// 				treetable.getBinding("rows").sort(sorts);
// 			}

// 		},

// 		onOpenViewSettings: function () {
// 			if (!this.getDialogManager().getDialogEntry("fragments.ViewSettingsDialog", this.getView())) {
// 				var data = this.getModel("local").getProperty("/PMOrderSet");
// 				this._createFilterModels(data);
// 				/*var filteraufnr = _.chain(data)
// 					.uniq(function (row) {
// 						return row.Aufnrit;
// 					})
// 					.map(function (row) {
// 						return {
// 							Aufnrit: row.Aufnrit
// 						};
// 					}).value();
// 				this.setModel(new JSONModel({
// 					table: filteraufnr
// 				}), "filteraufnr");*/
// 				// this.setModel(new JSONModel({
// 				// 	Tplnrit: "",
// 				// 	Pltxtit: ""
// 				// }), "cstmFilters");
// 			}

// 			this.getDialogManager().open("fragments.ViewSettingsDialog", this.getView(), this);
// 			sap.ui.getCore().byId("ViewSettingsDialog")._detailResetButton.setEnabled(true);
// 		},

// 		onConfirmViewSettingsDialog: function (oEvent) {
// 			var aFilterItems = oEvent.getParameters().filterItems,
// 				aFilters = [];

// 			// update filter state:
// 			// combine the filter array and the filter string
// 			aFilterItems.forEach(function (oItem) {
// 				switch (oItem.getKey()) {
// 				case "FunctLoc":
// 					aFilters.push(new Filter(oItem.getKey(), FilterOperator.Contains, oItem.getText()));
// 					break;
// 				case "Equipment":
// 					aFilters.push(new Filter(oItem.getKey(), FilterOperator.Contains, oItem.getText()));
// 					break;
// 				case "ShortText":
// 					aFilters.push(new Filter(oItem.getKey(), FilterOperator.Contains, oItem.getText()));
// 					break;
// 				// case "FinishedFinConf":
// 				// 	aFilters.push(new Filter("Color", FilterOperator.EQ, "green"));
// 				// 	break;
// 				// case "FinConf":
// 				// 	aFilters.push(new Filter("Color", FilterOperator.EQ, "purple"));
// 				// 	break;
// 				// case "IsFinished":
// 				// 	aFilters.push(new Filter("Color", FilterOperator.EQ, "blue"));
// 				// 	break;
// 				// case "Ongoing":
// 				// 	aFilters.push(new Filter("Color", FilterOperator.EQ, "orange"));
// 				// 	break;
// 				// case "NotStarted":
// 				// 	aFilters.push(new Filter("Color", FilterOperator.EQ, "default"));
// 				default:
// 					break;
// 				}
// 			});
// 			let selectedPathsCS=oEvent.getSource().getFilterItems()[0].getCustomControl().getSelectedContextPaths();
// 			let colors=_.forEach(selectedPathsCS,function(a){
// 				a&&aFilters.push(new Filter("Color", FilterOperator.EQ, this.getView().getModel("filters").getProperty(a+'/color')))
// 			}.bind(this));
// 			if(this.filtersAdded&& this.filtersAdded["Equipment"]){
// 				aFilters.push(this.filtersAdded["Equipment"]);
// 			}
// 			if(this.filtersAdded && this.filtersAdded["FunctLoc"]){
// 				aFilters.push(this.filtersAdded["FunctLoc"]);
// 			}
// 			if (aFilters.length > 0) {
// 				this.getView().byId("filter")._getControl().setType("Emphasized");
// 			} else {
// 				this.getView().byId("filter")._getControl().setType("Default");
// 			}

// 			this._applyFilterSearch(aFilters);
// 		},

// 		onCollapseOperations: function () {
// 			var oTreeTable = this.getView().byId("orderMasterTreeTable");
// 			oTreeTable.collapseAll();
// 		},

// 		onExpandOperations: function () {
// 			var oTreeTable = this.getView().byId("orderMasterTreeTable");
// 			oTreeTable.expandToLevel(1);
// 		},

// 		//---------------------------//
// 		// FORMATTING
// 		//---------------------------//
// 		// formatUpperCase: function(sValue){
// 		// 	if(sValue){
// 		// 		return ((sValue.substring(0,1)).toUpperCase()+sValue.substring(1,sValue.length));
// 		// 	}
// 		// },

// 		//---------------------------//
// 		// PRIVATES
// 		//---------------------------//

// 		_initModels: function () {

// 		},

// 		_getOrdersFromDb: function () {
// 			var oPromOrders = this.getDBService().getEntitySet("PMOrder"),
// 				oPromOperations = this.getDBService().getEntitySet("Operation"),
// 				oPromComponents = this.getDBService().getEntitySet("Component"),
// 				oPromPRT = this.getDBService().getEntitySet("PRT");

// 			$.when(oPromOrders, oPromOperations, oPromComponents, oPromPRT)
// 				.done(jQuery.proxy(function (oDataOrder, oDataOperation, oDataComponent, oDataPRT) {
// 					var oLocalModel = this.getView().getModel("local"),
// 						aOrderSet = this.getHelper().rowsToArray(oDataOrder),
// 						aOperationSet = this.getHelper().rowsToArray(oDataOperation),
// 						aComponentSet = this.getHelper().rowsToArray(oDataComponent),
// 						aPRTSet = this.getHelper().rowsToArray(oDataPRT);

// 					if (!oLocalModel.getProperty("/PMOrderSet")) {
// 						oLocalModel.setProperty("/PMOrderSet", []);
// 					}

// 					var oPromConfirmations = this.getDBService().getEntitySet("Confirmation");

// 					$.when(oPromConfirmations).done(jQuery.proxy(function (oConfirmations) {
// 						var aConfirmationSet = this.getHelper().rowsToArray(oConfirmations);

// 						_.each(aConfirmationSet, function (oConf) {
// 							for (var sProp in oConf) {
// 								if (oConf[sProp] === "true" || oConf[sProp] === "false") {
// 									oConf[sProp] = oConf[sProp] === "true" ? true : false;
// 								}
// 							}
// 						});

// 						this._aConfirmations = aConfirmationSet;

// 						var oResult = this._determineColors(aOrderSet, aOperationSet, aConfirmationSet);

// 						aOrderSet = oResult.aOrderSet;
// 						aOperationSet = oResult.aOperationSet;

// 						aOrderSet = this._linkOrdersToOperations(aOrderSet, aOperationSet, aComponentSet, aPRTSet);

// 						this.aOrderSet = aOrderSet;

// 						oLocalModel.setProperty("/PMOrderSet", aOrderSet);
// 					}, this));

// 					// aOrderSet = this._linkOrdersToOperations(aOrderSet, aOperationSet, aComponentSet, aPRTSet);

// 					// this.aOrderSet = aOrderSet;

// 					// oLocalModel.setProperty("/PMOrderSet", aOrderSet);

// 				}, this))
// 				.fail(jQuery.proxy(function (oError) {
// 					MBox.error(this.getText("OrderDBRetrieveFailed"));
// 				}, this));
// 		},

// 		_determineColors: function (aOrderSet, aOperationSet, aConfirmationSet) {

// 			_.each(aOrderSet, jQuery.proxy(function (oOrder) {
// 				var bAllOrderChildConfFinished = true;

// 				var aFoundConfForOrder = _.filter(aConfirmationSet, function (oConf) {
// 					return oConf.Aufnr === oOrder.Orderid && !oConf.Vornr && !oConf.Hidden;
// 				});

// 				if (aFoundConfForOrder.length > 0) {
// 					var aFoundChildConfirmations = _.filter(aConfirmationSet, function (oConfirmation) {
// 						return oConfirmation.ParentHndl === aFoundConfForOrder[0].Handle;
// 					});

// 					if (aFoundChildConfirmations.length > 0) {
// 						_.each(aFoundChildConfirmations, jQuery.proxy(function (oChildConfirmation) {
// 							if (!oChildConfirmation.IsFinished || oChildConfirmation.IsFinished === "false") {
// 								bAllOrderChildConfFinished = false;
// 							}
// 						}, this));
// 					} else {
// 						bAllOrderChildConfFinished = false;
// 					}
// 				} else {
// 					bAllOrderChildConfFinished = false;
// 				}

// 				var oNonFinConfOrder = _.find(aFoundConfForOrder, function (oConf) {
// 					return oConf.FinConf !== true ;
// 				});

// 				var oNonFinishedConfOrder = _.find(aFoundConfForOrder, function (oConf) {
// 					return oConf.IsFinished !== true;
// 				});
// 				var oNonFinishedConfOrderbutNotFinal = _.find(aFoundConfForOrder, function (oConf) {
// 					return oConf.IsFinished !== true && oConf.FinConf !== true;
// 				});

// 				if (aFoundConfForOrder.length > 0) {
// 					//Check if every confirmation is in dinal confirmation
// 					if (oNonFinConfOrder) {
// 						//Check if every confirmation is finished and doesn't have final Conf
// 						if (oNonFinishedConfOrderbutNotFinal|| bAllOrderChildConfFinished) {
// 							oOrder.Color = "orange";
// 						} else {
// 							oOrder.Color = "blue";
// 						}
// 					} else {
// 						if (oNonFinishedConfOrder) {
// 							oOrder.Color = "purple";
// 						} else {
// 							oOrder.Color = "green";
// 						}
// 					}
// 				}else oOrder.Color = "default";

// 			}, this));

// 			_.each(aOperationSet, jQuery.proxy(function (oOperation) {
// 				var bAllOperationChildConfFinished = true;

// 				var aFoundConfirmation = _.filter(aConfirmationSet, function (oConf) {
// 					return oConf.ParentHndl === oOperation.Handle && !oConf.Hidden;
// 				});

// 				// Check if confirmation has child confirmations
// 				if (aFoundConfirmation.length > 0) {
// 					var aFoundChildConfirmations = _.filter(aConfirmationSet, function (oConfirmation) {
// 						return oConfirmation.ParentHndl === aFoundConfirmation[0].Handle;
// 					});

// 					if (aFoundChildConfirmations.length > 0) {
// 						_.each(aFoundChildConfirmations, jQuery.proxy(function (oChildConfirmation) {
// 							if (!oChildConfirmation.IsFinished || oChildConfirmation.IsFinished === false) {
// 								bAllOperationChildConfFinished = false;
// 							}
// 						}, this));
// 					} else {
// 						bAllOperationChildConfFinished = false;
// 					}
// 				} else {
// 					bAllOperationChildConfFinished = false;
// 				}

// 				var oFoundNonFinConf = _.find(aFoundConfirmation, function (oConf) {
// 					return oConf.FinConf !== true ;
// 				});

// 				var oFoundNonFinished = _.find(aFoundConfirmation, function (oConf) {
// 					return oConf.IsFinished !== true;
// 				});
// 				var oNonFinishedConfOrderbutNotFinal = _.find(aFoundConfirmation, function (oConf) {
// 					return oConf.IsFinished !== true && oConf.FinConf !== true;
// 				});

// 				if (aFoundConfirmation.length > 0) {
// 					if (oFoundNonFinConf) {
// 						if (oNonFinishedConfOrderbutNotFinal || bAllOperationChildConfFinished) {
// 							oOperation.Color = "orange";
// 						} else {
// 							oOperation.Color = "blue";
// 						}
// 					} else {
// 						if (oFoundNonFinished) {
// 							oOperation.Color = "purple";
// 						} else {
// 							oOperation.Color = "green";
// 						}
// 					}
// 				}else{
// 					var oCheckOperation = this.getHelper().checkOperationValid(oOperation.Orderid, oOperation);
// 					var cnfOperation=  (oOperation.ConfFinal === "X" );
// 					if (oCheckOperation.ControlKeyIsValid === false || oCheckOperation.PMEXValid === false|| cnfOperation === true) {
// 						oOperation.Color = "red";
// 					} else {
// 						oOperation.Color = "default";
// 					}
// 				}
// 			}, this));

// 			var oResult = {};

// 			oResult.aOrderSet = aOrderSet;
// 			oResult.aOperationSet = aOperationSet;

// 			return oResult;
// 		},

// 		_createFilterModels: function (data) {
// 			// Functional location
// 			var uniqueFunctLocArray = _.uniqBy(data, function (row) {
// 				return row.FunctLoc;
// 			});

// 			var filterFunctLoc = _.map(uniqueFunctLocArray, function (row) {
// 				return {
// 					FunctLoc: row.FunctLoc,
// 					FunctionLocName : row.Pltxt
// 				};
// 			});

// 			// Order short text
// 			var uniqueShortTextArray = _.uniqBy(data, function (row) {
// 				return row.ShortText;
// 			});

// 			var filterShortText = _.map(uniqueShortTextArray, function (row) {
// 				return {
// 					ShortText: row.ShortText
// 				};
// 			});

// 			filterShortText = _.remove(filterShortText, function (row) {
// 				return row.ShortText !== "";
// 			});

// 			// Equipment
// 			var uniqueEqpmtArray = _.uniqBy(data, function (row) {
// 				return row.Equipment;
// 			});

// 			var filterEqpmt = _.map(uniqueEqpmtArray, function (row) {
// 				return {
// 					Equipment: row.Equipment,
// 					Eqktx : row.Eqktx
// 				};
// 			});
// 			var confStatus = [
// 				{text:this.getText('FinishedFinalConfirmation'),color:"green"},
// 				{text:this.getText('FinalConfirmation'),color:"purple"},
// 				{text:this.getText('FinishedConfirmation'),color:"blue"},
// 				{text:this.getText('ConfirmationOngoing'),color:"orange"},
// 				{text:this.getText('ConfirmationNotStarted'),color:"default"}
// 			];

// 			this.setModel(new JSONModel({
// 				filterEqpmt: filterEqpmt,
// 				filterShortText: filterShortText,
// 				filterFunctLoc: filterFunctLoc,
// 				confStatus: confStatus
// 			}), "filters");
// 		},

// 		clearFilters: function () {
// 			var aFilters = [],
// 				aCaptions = [];
// 			this.filtersAdded={
// 				"FunctLoc":null,
// 				"Equipment":null
// 			};
// 			this.listItem={
// 				"FunctLoc":null,
// 				"Equipment":null
// 			};
// 			if(sap.ui.getCore().byId("flocList"))
// 				sap.ui.getCore().byId("flocList").removeSelections(true);
// 			if(sap.ui.getCore().byId("eqpmtList"))
// 				sap.ui.getCore().byId("eqpmtList").removeSelections(true);
// 			if(sap.ui.getCore().byId("ViewSettingsDialog"))
// 				sap.ui.getCore().byId("ViewSettingsDialog").getFilterItems()[0].getCustomControl().removeSelections()
// 			this._applyFilterSearch(aFilters);
// 		},

// 		_applyFilterSearch: function (aFilters) {
// 			var aOperationFilters = [];

// 			if (aFilters.length > 0) {
// 				this.getView().byId("filter")._getControl().setType("Emphasized");
// 			} else {
// 				this.getView().byId("filter")._getControl().setType("Default");
// 			}

// 			//this.getView().byId("orderMasterTreeTable").getBinding("rows").filter(aFilters, "Application");
// 			var aFilteredList = this.aOrderSet;

// 			_.each(aFilters, jQuery.proxy(function (oFilter) {

// 				if (oFilter.sPath === "Color") {
// 					if (oFilter.oValue1 === "default") {
// 						_.each(aFilteredList, jQuery.proxy(function (oFiltered) {
// 							if (oFiltered.Color === oFilter.oValue1) {
// 								var oDefaultOperationFound = _.find(oFiltered.NavOperation, jQuery.proxy(function (oOperation) {
// 									return oOperation.Color === oFilter.oValue1;
// 								}, this));

// 								if (oDefaultOperationFound) {
// 									aOperationFilters.push(new Filter("Orderid", FilterOperator.EQ, oDefaultOperationFound.Orderid));
// 								}
// 							}
// 						}, this));
// 					} else {
// 						aOperationFilters.push(oFilter);
// 					}
// 				} else {

// 					aFilteredList = _.filter(aFilteredList, jQuery.proxy(function (oOrder) {
// 						return oOrder[oFilter.sPath] === oFilter.oValue1 || (oFilter.oValue2 && oOrder[oFilter.sPath] === oFilter.oValue2);
// 					}, this));
// 				}

// 			}));

// 			this.getModel("local").setProperty("/PMOrderSet", aFilteredList);
// 			this.getView().byId("orderMasterTreeTable").getBinding("rows").filter(aOperationFilters, "Application");
// 		},

// 		_linkOrdersToOperations: function (aOrders, aOperations, aComponents, aPRTs) {

// 			var _aOrders = aOrders,
// 				_aOperations = aOperations,
// 				oHelper = this.getHelper();

// 			_aOperations.forEach(function (oOperation) {

// 				oOperation.NavComponent = _.filter(aComponents, {
// 					Orderid: oOperation.Orderid,
// 					Activity: oOperation.Activity
// 				});

// 				oOperation.NavPRT = _.filter(aPRTs, {
// 					Orderid: oOperation.Orderid,
// 					Activity: oOperation.Activity
// 				});

// 			});

// 			_aOrders.forEach(function (oOrder) {

// 				oOrder.NavOperation = _.filter(_aOperations, {
// 					Orderid: oOrder.Orderid
// 				});

// 				oOrder.NavLevelTree=[];

// 			});

// 			return _aOrders;
// 		},

// 		onSelectionChange:function(oEvent){
// 			let filter=oEvent.getSource().getId()==="flocList"?"FunctLoc":"Equipment";
// 			this.filtersAdded[filter]=new Filter(filter, FilterOperator.Contains,oEvent.getParameter('listItem').getProperty("title"));
// 			this.listItem[filter]=oEvent.getSource().getSelectedItem();
// 			sap.ui.getCore().byId("ViewSettingsDialog")._detailResetButton.setEnabled(true);
// 		},

// 		onFinished: function(oEvent) {
// 				let filter=oEvent.getSource().getId()==="flocList"?"FunctLoc":"Equipment";
// 		        var oList = oEvent.getSource();
// 		        oList.setSelectedItem(this.listItem[filter]);
// 		        if(this.listItem&&this.listItem.length&&this.listItem[filter])
// 					this.filtersAdded[filter]=new Filter(filter, FilterOperator.Contains,this.listItem.getProperty("title"));
//     			sap.ui.getCore().byId("ViewSettingsDialog")._detailResetButton.setEnabled(true);
// 		},

//     	onLegendPress:function(){
// 			var oData={
// 					ColorData : [ {
// 						"text" : this.getText("ConfirmationOngoing"),
// 						"status":"orange"
// 					},
// 					{
// 						"text" :  this.getText("FinishedConfirmation"),
// 						"status":"blue"

// 					},
// 					{
// 						"text" : this.getText("FinalConfirmation") ,
// 						"status":"purple"
// 					},
// 					{
// 						"text" :  this.getText("FinishedFinalConfirmation") ,
// 						"status":"green"
// 					},
// 					{
// 						"text" :  this.getText("ConfirmationNotPossible"),
// 						"status":"red"
// 					}]
// 					};
// 			var oColorJsonModel = new sap.ui.model.json.JSONModel(oData);
// 			this.getView().setModel(oColorJsonModel,"colorModel");
// 			this._getLegendDialog().open();
// 		},

// 		onLegendDialogColse : function(){
// 			this._getLegendDialog().close();
// 		},

// 		_getLegendDialog: function () {
// 			if (!this.getOwnerComponent().oLegendDialog) {
// 				this.getOwnerComponent().oLegendDialog = sap.ui.xmlfragment("LegendDialog",
// 					"mobilework.view.fragments.LegendDialog",
// 					this);
// 				this.getView().addDependent(this.getOwnerComponent().oLegendDialog);
// 			}
// 			return this.getOwnerComponent().oLegendDialog;
// 		},

// 		onSelectionChangeStatus: function(){
// 			sap.ui.getCore().byId("ViewSettingsDialog")._detailResetButton.setEnabled(true);
// 		}

// 	});
// });
//Should be removed at the end of release- Just keeping it make sure everything is working correctly
