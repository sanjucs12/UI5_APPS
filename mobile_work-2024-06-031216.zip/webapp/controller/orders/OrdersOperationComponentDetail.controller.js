sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
  ],
  function (Controller, MToast, Filter, Lo, MBox) {
    "use strict";

    return Controller.extend(
      "mobilework.controller.orders.OrdersOperationComponentDetail",
      {
        //---------------------------//
        // PROPERTIES
        //---------------------------//

        orderId: "",

        operationId: "",

        //---------------------------//
        // LIFECYCLE
        //---------------------------//

        /**
         * Called when a controller is instantiated and its View controls (if available) are already created.
         * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onInit: function () {
          this._initModels();
          this.getRouter()
            .getRoute("ordersOperationsComponentDetail")
            .attachMatched(this.onRouteMatched, this);
        },

        /**
         * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
         * @memberOf mobilework.view.NotificationsDetail
         */
        onExit: function () {},

        //---------------------------//
        // EVENT HANDLERS
        //---------------------------//

        onRouteMatched: function (oEvent) {
          var sID = oEvent.getParameter("arguments").ID,
            sOperationID = oEvent.getParameter("arguments").OperationID,
            sOrderID = oEvent.getParameter("arguments").OrderID;

          this.getScanHandler().setLocation("ComponentDetail");

          //set connection property
          this.getConnection();

          this.orderId = sOrderID;
          this.operationId = sOperationID;

          this._bindView(sOrderID, sOperationID, sID);
          this.changeColorOfDeviceId();
        },

        onNavBack: function () {
          this.getRouter().navTo("ordersOperationsDetail", {
            OrderID: this.orderId,
            ID: this.operationId,
          });
        },

        //---------------------------//
        // FORMATTING
        //---------------------------//

        //---------------------------//
        // PRIVATES
        //---------------------------//

        _initModels: function () {},

        _bindView: function (sOrderID, sOperationID, sID) {
          var sBindingPath =
            "/PMOrderSetDataWithConf/" +
            sOrderID +
            "/NavOperation/" +
            sOperationID +
            "/NavComponent/" +
            sID;

          this.getView().bindElement({
            path: sBindingPath,
            model: "local",
          });
        },
      }
    );
  }
);
