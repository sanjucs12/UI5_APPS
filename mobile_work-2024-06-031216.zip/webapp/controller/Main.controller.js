/*global Connection:true*/
sap.ui.define(
  [
    "mobilework/controller/BaseController",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/core/routing/HashChanger",
    "mobilework/model/wParticipants",
    "mobilework/model/zoneData",
    "mobilework/model/tables/TimeInOut",
    "sap/ui/core/Fragment",
    "sap/ui/core/BusyIndicator",
    "mobilework/model/LoginMethod",
    "mobilework/model/tables/TimeSheet",
  ],
  function (
    Controller,
    MBox,
    MToast,
    HashChanger,
    wParticipants,
    zoneData,
    TimeInOut,
    Fragment,
    BusyIndicator,
    LoginMethod,
    TimeSheet
  ) {
    "use strict";
    /**
     * Controller for Main View
     * @namespace mobilework.controller.Main
     * @param {sap.ui.core.mvc.Controller} Controller - Sap Core Controller
     * @param {sap/ui/core/routing/HashChanger} HashChanger - Hashchanger
     * @param {mobilework/model/wParticipants} wParticipants - Table type of Partcipants data for Public Mobile Work
     * @param {mobilework/model/zoneData} zoneData - Table type of Zone data for Public Mobile Work
     * @param {mobilework/model/tables/TimeInOut} TimeInOut -Table type of Timeinout data for Public Mobile Work.
     * Used to double check the time in and out for confirmation data
     * @param {sap/ui/core/Fragment} Fragment - SapUI5 control for fragment
     * @param {sap.m.MessageBox} MBox - SapUI5 Message Box Control
     * @param {sap.m.MToast} MToast - SapUI5 Message toast Control
     * @param {sap/ui/core/BusyIndicator} BusyIndicator - SapUI5 Busy Indicator
     * @returns {mobilework.controller.Main} The instance of the Main controller class.
     */
    return Controller.extend("mobilework.controller.Main", {
      //---------------------------//
      // PROPERTIES
      //---------------------------//

      //---------------------------//
      // LIFECYCLE
      //---------------------------//

      onInit: function () {
        this.busyDialog = new sap.m.BusyDialog();
        this.setModel(new sap.ui.model.json.JSONModel(), "login");
        this.getView().getModel("login").setProperty("/pinCodeState", false);
        this.getView()
          .getModel("login")
          .setProperty("/sapPasswordVisible", true);
        this.getView()
          .getModel("login")
          .setProperty("/sapPincodeVisible", false);
        var oHashChangerInstance = HashChanger.getInstance(),
          me = this;
        oHashChangerInstance.init();
        document.addEventListener(
          "pause",
          jQuery.proxy(this.onAppPause, this),
          false
        );

        this.getOwnerComponent().ViewLocation = this;
        var bConfigFailed = this.getSharedModel().getProperty("/configFailed");
        if (!bConfigFailed) {
          setTimeout(
            jQuery.proxy(function () {
              document.addEventListener(
                "offline",
                jQuery.proxy(this.offline, this),
                false
              );
              document.addEventListener(
                "online",
                jQuery.proxy(this.online, this),
                false
              );
            }, this),
            1000
          );
        }
        this.loginMethod = this.getOwnerComponent().loginMethod;
        this.getRouter()
          .getRoute("main")
          .attachMatched(this.onRouteMatched, this);
        // this.getRouter().getRoute("login").attachMatched(this.onLoginRouteMatched, this);
        this.getRouter()
          .getRoute("reload")
          .attachMatched(
            $.proxy(function () {
              if (location.hash.indexOf("reload") !== -1) {
                var oPromDelNotif =
                    this.getDBService().deleteAllObjects("PMNotification"),
                  oPromDelConf =
                    this.getDBService().deleteAllObjects("Confirmation"),
                  oPromDelPic = this.getDBService().deleteAllObjects("Picture"),
                  oPromDelOrder =
                    this.getDBService().deleteAllObjects("PMOrder"),
                  oPromDelPartic =
                    this.getDBService().deleteAllObjects("Participant"),
                  oPromDelOper =
                    this.getDBService().deleteAllObjects("Operation"),
                  oPromDeleteTechObj =
                    this.getDBService().deleteAllObjects("TechnicalObject"),
                  oPromDelSetting = 
                   this.getDBService().deleteAllObjects("Setting"),
                  oPromDeleteTechObjGroups =
                    this.getDBService().deleteAllObjects(
                      "TechnicalObjectGroupnameVH"
                    ),
                  oPromDeleteFuncLocCraft =
                    this.getDBService().deleteAllObjects("FuncLocCraft");
                var oPromTimeRegistration,
                  oPromDeletewParticipants,
                  oPromDeletezoneData,
                  oPromDeleteTimeInOut,
                  oPromSERVICESType,
                  oPromMW_POType,
                  oPromTimeRegistration1,
                  oPromPlanItem;
                if (this.getSharedModel().getProperty("/publicRelease")) {
                  oPromTimeRegistration =
                    this.getDBService().deleteAllObjects("TimeRegistration");
                  oPromDeletewParticipants =
                    this.getDBService().deleteAllObjects("wParticipants");
                  oPromDeletezoneData =
                    this.getDBService().deleteAllObjects("zoneData");
                  oPromDeleteTimeInOut =
                    this.getDBService().deleteAllObjects("TimeInOut");
                  oPromSERVICESType = this.getDBService().deleteAllObjects(
                    "xARMPxMW_PO_SERVICESType"
                  );
                  oPromMW_POType =
                    this.getDBService().deleteAllObjects("xARMPxMW_POType");
                  oPromTimeRegistration1 =
                    this.getDBService().deleteAllObjects("TimeRegistration1");
                  oPromPlanItem =
                    this.getDBService().deleteAllObjects("PlanItem");
                }
                this.getSharedModel().setProperty("/reloadedRun", true);
                $.when(
                  oPromDelConf,
                  oPromDelNotif,
                  oPromDelOper,
                  oPromDelOrder,
                  oPromDelPartic,
                  oPromDelPic,
                  oPromDeleteTechObj,
                  oPromDelSetting,
                  oPromDeleteTechObjGroups,
                  oPromDeleteFuncLocCraft,
                  oPromTimeRegistration,
                  oPromDeletewParticipants,
                  oPromDeletezoneData,
                  oPromDeleteTimeInOut
                )
                  .done(
                    $.proxy(function () {
                      //oHashChangerInstance.replaceHash("");
                      // if (!this.getHelper().isDevModeActive()) {
                      // this.getService().logoff();
                      //}

                      // window.location.reload();
                      this.onInitPart1();
                      this.onAfterRenderingPart1("reload");
                    }, this)
                  )
                  .fail(
                    $.proxy(function () {
                      //oHashChangerInstance.replaceHash("");
                      // if (!this.getHelper().isDevModeActive()) {
                      // 	this.getService().logoff();
                      // }

                      // window.location.reload();
                      this.onInitPart1();
                      this.onAfterRenderingPart1();
                    }, this)
                  );
              }
            }, this),
            this
          );
        this.onInitPart1();
        /*BEGIN: Date: 21/02/2024 AMID: A0866990 13.1 Bug Number: IN MW the purchase order tile need not be placed
			But when visible property is set to false the main screen had an empty space. So the whole content of purchase order tile have been removed*/
        let MainPageGrid = this.getView().byId("MainPageGrid"),
          slideTilePurchaseOrders = this.getView().byId(
            "slideTilePurchaseOrders"
          ),
          sharedModel = this.getSharedModel() ;
          // poActive = sharedModel.getData().sapSettings.POActive ;
        if (
          (slideTilePurchaseOrders &&
          MainPageGrid &&
          sharedModel &&
          !sharedModel.getProperty("/publicRelease"))
          
        ) {
          let count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);
          if (count >= 0) {
            MainPageGrid.removeContent(count);
          }
        }
        // if (poActive === false) {
        //   let count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);
        //   if (count >= 0) {
        //     MainPageGrid.removeContent(count);
        //   }
        // }
        /*BEGIN: Date: 21/02/2024 AMID: A0866990 13.1 Bug Number: No Bug No.*/
      },

      onInitPart1: function () {
        if (
          this.getService() &&
          !this.getSharedModel().getProperty("/publicRelease")
        ) {
          // && !this.getHelper().isDevModeActive()) {
          $.when(
            this.getOwnerComponent().createParticipant(
              this.getSharedModel().getProperty("/sapSettings/sapUser")
            )
          )
            .done(
              jQuery.proxy(function () {
                this.getOwnerComponent().getParticipantsFromDb();
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                if (oError) {
                  if (oError.offline === true) {
                    // MBox.error(this.getText("NoNetwork"));
                    MBox.error(this.getText("NoNetwork"));
                    // this.getView().setBusy(false);
                  } else if (oError.connection === false) {
                    MBox.error(
                      this.getText("ConnectionUnknown") +
                        "\n" +
                        this.getText("NoConnectionToSap")
                    );
                    // this.getView().setBusy(false);
                  }
                }
              }, this)
            );
        }
        if (this.getSharedModel().getProperty("/publicRelease")) {
          this.initPublicVersion();
        }
      },

      onAfterRenderingPart1: function (sMode) {
        if (this.getSharedModel().getProperty("/sapSettings")) {
          $.when(this.getDBService().getSAPSettings()).done(
            jQuery.proxy(function (settings) {
              if (
                this.getSharedModel().getProperty("/sapSettings") &&
                (settings.policy === undefined ||
                  settings.policy === "LOGON_STRT" ||
                  (settings.policy === "FUNC_USER" &&
                    this.getSharedModel().getProperty("/sapSettings")
                      .sapUser === ""))
              ) {
                // Device has been onboarded before & user is logged off -- scenario 5 & 6
                // WR - call component > _start_procedure_offline
                if (sMode === "reload") {
                  // Refresh model

                  // this.getView().getModel('onboarding').refresh();
                  // this.getView().getModel('shared').refresh();
                  // settings.sapUser = this.getModel("shared").setProperty("/sapSettings/sapUser");
                  // settings.sapPass = this.getModel("shared").setProperty("/sapSettings/sapPass");
                  // settings.sapBearer = this.getModel("shared").setProperty("/sapSettings/sapBearer");
                  // this.getModel("shared").setProperty("/sapSettings", settings);

                  let bConfigFailed =
                    this.getSharedModel().getProperty("/configFailed");

                  if (bConfigFailed) {
                    // Clear all user settings because a new onboarding is launched

                    // this.getSharedModel().setProperty("/sapSettings", {});
                    this.getOwnerComponent().tokenService.clearToken();

                    $.when(this.getDBService().dropAllTables())
                      .done(
                        jQuery.proxy(function () {
                          this._openOnboarding();
                        }, this)
                      )
                      .fail(
                        jQuery.proxy(function () {
                          MBox.error(this.getText("SettingsTableCreateError"));
                        }, this)
                      );
                  }
                } else {
                  //this.getOwnerComponent()._start_procedure_offline();
                  this._openLogin();
                }
              } else {
                // Functional user policy logic

                // Device has been onboarded before & user is logged on -- scenario 1 & 2
                // WR - call component > _start_procedure_functional_user or also execute the _start_procedure_offline ??

                // User & Pass not know at this point in case of public release
                if (
                  this.getSharedModel().getProperty("/sapSettings").sapUser &&
                  this.getSharedModel().getProperty("/sapSettings").sapPass
                ) {
                  $.when(
                    this.getService().createModelWithUser(
                      this.getSharedModel().getProperty("/sapSettings").sapUser,
                      this.getSharedModel().getProperty("/sapSettings").sapPass
                    )
                  )
                    .done(
                      jQuery.proxy(function (oData) {
                        this.getOwnerComponent()._start_procedure_functional_user(
                          this.getView(),
                          true
                        );
                        this.getOwnerComponent()._start_procedure_offline();
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function () {
                        this.genericSetDeviceIdColor("Red");
                        this.genericReplaceStyleClass(this.getView(), "Red");
                        this.getOwnerComponent()._start_procedure_offline();
                      }, this)
                    );
                } else {
                  this.getOwnerComponent()._start_procedure_offline();
                }
              }
              var sAppVersion =
                this.getOwnerComponent().getManifestObject()._oManifest
                  ._version;

              if (
                this.getOwnerComponent().service &&
                this.getSharedModel().getProperty("/sapSettings").deviceName !==
                  undefined
              ) {
                this.getService().setVersion(
                  this.getSharedModel().getProperty("/sapSettings").deviceName,
                  this.getSharedModel().getProperty("/sapSettings").plant,
                  sAppVersion
                );
              }
            }, this)
          );
        }
      },

      /**
       * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
       */
      onExit: function () {},

      onAfterRendering: function (oEvent) {
        if (oEvent.getSource().getParent().oToPage !== undefined)
          var callingPage = oEvent.getSource().getParent().oToPage.sViewName;
        if (callingPage === undefined || callingPage === "")
          this.onAfterRenderingPart1();
        // if(this.getSharedModel().getProperty("/publicRelease")){
        // 	this.getDBService().deleteAllObjects("wParticipants");
        // }
      },

      onAppPause: function () {
        if (!this.getSharedModel().getProperty("/publicRelease")) {
          // Panasonic scanner plugin not available in public release
          this.getOwnerComponent().scanHandler.deactivatePanasonicScanner();
        }
      },
      /**
       * Set username in login model.
       * @memberOf mobilework.controller.Main
       * @public
       * @param  oEvent - SAPUI5 Event
       */
      onUserChange: function (oEvent) {
        var sValue = oEvent.getParameter("newValue");

        this.getView()
          .getModel("login")
          .setProperty("/sapUser", sValue.toUpperCase());
      },

      //---------------------------//
      // EVENT HANDLERS
      //---------------------------//

      // onLoginRouteMatched: function(oEvent) {
      // 	// Show login screen
      // 	//
      // 	// this._openLogin();
      // 	// this.onRouteMatched();
      // 	this._logOff();
      // 	// After login procedure navigate back to the original route
      // 	this._navigateBackTarget = oEvent.getParameter("arguments").source;
      // },

      onRouteMatched: function (oController) {
        //set scanner location
        this.getScanHandler().setLocation("main");
        var oSharedModel = this.getView().getModel("shared"),
          bConfigFailed = oSharedModel.getProperty("/configFailed"),
          bMetaFailed = oSharedModel.getProperty("/metaFailed"),
          sMetaFailedMsg = oSharedModel.getProperty("/metaFailedMessage");

        //set connection property
        this.getConnection();

        if (bMetaFailed !== true && bMetaFailed !== false) {
          if (
            this.getService() &&
            this.getService().getModel() &&
            this.getService().getModel().oMetadata &&
            this.getService().getModel().oMetadata.bLoaded === true
          ) {
            bMetaFailed = false;
          } else {
            bMetaFailed = true;
          }
        }
        if (
          oSharedModel &&
          oSharedModel.getProperty("/sapSettings/sapUser") !== "" &&
          oSharedModel.getProperty("/sapSettings/sapUser") !== undefined
        ) {
          if (
            this.getOwnerComponent().getModel("i18n").getResourceBundle()
              .sLocale !== "fr"
          ) {
            oSharedModel.setProperty(
              "/loggedInAsMsg",
              this.getText("LoggedInAs", [
                oSharedModel.getProperty("/sapSettings/sapUser"),
              ])
            );
          } else {
            oSharedModel.setProperty(
              "/loggedInAsMsg",
              oSharedModel.getProperty("/sapSettings/sapUser")
            );
          }
          oSharedModel.setProperty("/bUserIconVisible", true);
        } else {
          oSharedModel.setProperty("/loggedInAsMsg", "");
          oSharedModel.setProperty("/bUserIconVisible", false);
        }

        //In logging User - Everytime Notification is created- asking to create participant.
        //		if ((oSharedModel && oSharedModel.getProperty("/sapSettings/sapUser") !== undefined && oSharedModel.getProperty("/sapSettings/sapUser") !== "")||(this.getSharedModel().getProperty('/publicRelease')===false)) {
        // User is logged in
        oSharedModel.setProperty("/isBusy", true);
        $.when(this.getDBService().getEntitySet("Participant"))
          .done(
            jQuery.proxy(function (oData) {
              console.debug("get participant set success", oData);
              oSharedModel.setProperty(
                "/hasParticipants",
                oData.rows.length !== 0
              );
              // if (oData.rows.length === 0&&!this.getSharedModel().getProperty("/publicRelease")) {
              // 	$.when(this.getOwnerComponent().createParticipant(oSharedModel.getProperty("/sapSettings/sapUser"))).done(jQuery.proxy(
              // 		function () {
              // 			oSharedModel.setProperty("/hasParticipants", true);
              // 		}, this)).fail(function (oError) {
              // 			oSharedModel.setProperty("/isBusy", false);
              // 			console.log("Failed to create participant");
              // 			console.log(oError);
              // 		});
              // }
              oSharedModel.setProperty("/isBusy", false);
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              console.error("get participant set failed", oError);
              oSharedModel.setProperty("/isBusy", false);
            }, this)
          );

        //	}

        if (bConfigFailed) {
          $.when(this.getDBService().dropAllTables())
            .done(
              jQuery.proxy(function () {
                // Scenario 3,4,7,8
                this._openOnboarding();
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                MBox.error(this.getText("SettingsTableCreateError"));
              }, this)
            );
            
          // Below not needed in public release
          // else if ((bMetaFailed || bMetaFailed === undefined) && this.getHelper().isOnline()) {
          // 	jQuery.sap.delayedCall(500, this, function () {
          // 		console.log(bMetaFailed);
          // 		if (!this.getSharedModel().getProperty("/sapSettings") || (this.getSharedModel().getProperty("/sapSettings") && this.getSharedModel()
          // 			.getProperty("/sapSettings").policy === "FUNC_USER")) {
          // 			MBox.error(this.getText("MetadataError") + "\n" + this.getModel("i18n").getResourceBundle().getText("NoConnectionToSap"));
          // 		}
          // 	});
          // }
        }
      let poActive = oSharedModel.getProperty("/sapSettings/POActive") ;
        this.addPOTile(poActive);
        this.changeColorOfDeviceId();
        this.updateConfTile();
      },
      addPOTile: function(poActive) {
       let  MainPageGrid = this.getView().byId("MainPageGrid"),
            slideTilePurchaseOrders,
            genericTilePurchaseOrders,
          tiles = MainPageGrid.getContent(),
          allCustomData = [];
        tiles.forEach(function(tile) {
          // Get the custom data objects of the current tile
          var customDataArray = tile.getCustomData();
      
          // Iterate over each custom data object within the current tile
          customDataArray.forEach(function(customData) {
              // Extract key and value from each custom data object
              var key = customData.getKey();
              var value = customData.getValue();
              if (key === "Key" && value === "slideTilePurchaseOrders") {
                slideTilePurchaseOrders = tile;
            }
              // Store the key-value pair in the allCustomData array
              allCustomData.push({ key: key, value: value });
          });
      });
      let count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);
      // //   aContent.forEach(function(oControl) {
      //     aIDs.push(oControl.getId());
      // // });
      // console.log (aIDs);
        if(!poActive){
          
                if (count >= 0  && allCustomData.length) {
                MainPageGrid.getContent()[count].destroy();
                // MainPageGrid.removeContent(count);
               }
        }
        else{
            if(count < 0 && allCustomData.length === 0){
              var slideTile = new sap.m.SlideTile({
                displayTime: 5000,
                transitionTime: 100,
                class: "sapUiTinyMarginBegin sapUiTinyMarginTop"
            });
    
             var genericTile = new sap.m.GenericTile({
                header: "{i18n>GetPurOrder}",
                press: this.onTilePress.bind(this)
            });

            slideTile.addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginTop");
            
            // slideTile.addStyleClass("sapUiTinyMargin");
            var tileContent = new sap.m.TileContent();
    
            /* Uncomment the following section if you want to include ImageContent */
            var imageContent = new sap.m.ImageContent({
                src: "sap-icon://accelerated"
            });
            tileContent.setContent(imageContent);
            // var tileContent = new sap.m.TileContent({
            //   content: imageContent
            // });
    
            // var numericContent = new sap.m.NumericContent({
            //     value: "{shared>/counts/Notifications}",
            //     valueColor: sap.ui.core.ValueColor.Critical,
            //     icon: "sap-icon://accelerated"
            // });
            // tileContent.addContent(numericContent);
    
            genericTile.addTileContent(tileContent);
    
            var layoutData = new sap.ui.layout.GridData({
                spanS: 6,
                spanM: 4,
                spanL: 3
            });
            slideTile.setLayoutData(layoutData);
    
            slideTile.addTile(genericTile);
            slideTile.data("Key","slideTilePurchaseOrders")
  
            MainPageGrid.insertContent(slideTile, 2);
            
            }
        }
      },

    //   addPOTile: function(poActive) {
    //     let MainPageGrid = this.getView().byId("MainPageGrid");
    //     let slideTilePurchaseOrders = this.slideTilePurchaseOrders,
    //     tiles = MainPageGrid.getContent(),
    //     allCustomData = [];
    //     var idsArray = tiles.map(function(item) {
    //       return item.sId;
    //     });
      
    
    //     // Find the index of the slide tile in the MainPageGrid
    //     let count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);

    //     tiles.forEach(function(tile) {
    //       // Get the custom data objects of the current tile
    //       var customDataArray = tile.getCustomData();
      
    //       // Iterate over each custom data object within the current tile
    //       customDataArray.forEach(function(customData) {
    //           // Extract key and value from each custom data object
    //           var key = customData.getKey();
    //           var value = customData.getValue();
      
    //           // Store the key-value pair in the allCustomData array
    //           allCustomData.push({ key: key, value: value });
    //       });
    //   });
    
    //     // If slide tile exists and poActive is false, remove it from the MainPageGrid
    //     if (!poActive) {
    //         if(slideTilePurchaseOrders && count>0 && allCustomData.length){
    //         MainPageGrid.removeContent(slideTilePurchaseOrders);
    //         // Set slideTilePurchaseOrders to undefined
    //         this.slideTilePurchaseOrders = undefined;
    //     }
    //   } else {
    //     if(!slideTilePurchaseOrders && count < 0 && allCustomData.length === 0){
        
    //         // Create the slide tile
    //         let  slideTilePurchaseOrders = new sap.m.SlideTile({
    //             displayTime: 5000,
    //             transitionTime: 100,
    //             class: "sapUiTinyMarginBegin sapUiTinyMarginTop"
    //         });
    
    //         let genericTile = new sap.m.GenericTile({
    //             header: "{i18n>GetPurOrder}",
    //             press: this.onTilePress.bind(this)
    //         });
    
    //         let tileContent = new sap.m.TileContent();
    //         let imageContent = new sap.m.ImageContent({
    //             src: "sap-icon://accelerated"
    //         });
    //         tileContent.setContent(imageContent);
    //         genericTile.addTileContent(tileContent);
    
    //         let layoutData = new sap.ui.layout.GridData({
    //             spanS: 6,
    //             spanM: 4,
    //             spanL: 3
    //         });
    //         slideTilePurchaseOrders.setLayoutData(layoutData);
    
    //         slideTilePurchaseOrders.addTile(genericTile);
    //         slideTile.data("Key","slideTilePurchaseOrders")
    //         // Add the slide tile to the MainPageGrid
    //         MainPageGrid.insertContent(slideTile, 2);
    
    //         // Store a reference to the slide tile
    //         this.slideTilePurchaseOrders = slideTilePurchaseOrders;
    //     }
    //   }
    // },
      onConfigErrorClose: function () {
        this.getDBService()
          .saveSAPSettings({
            host: "",
            gdlApi: "",
            GDL_API_URL: "",
            deviceName: "",
            sapSysId: "",
            sapUser: "",
            sapPass: "",
            sapClient: "",
            langu: "",
            rfidMand: false,
            // "enableLogin": false,
            enableOrderConfCreation: true,
            enableDownloadBoms: false,
            notifFields: {
              Text: false,
              Craft: false,
              Fecod: false,
              Fetxt: false,
              Urcod: false,
              Urtxt: false,
              Mfcod: false,
              Mftxt: false,
              Mncod: false,
              Matxt: false,
              Msaus: false,
              AusvnDatetime: false,
              AusbsDatetime: false, //,
              // "Ingrp": false,
              // "Arbpl": false,
              // "Qmnam": false
            },
            MAND_DAMAG: "",
            MAND_CAUSE: "",
            MAND_ACTIV: "",
            IWERK: "",
            SWERK: "",
            INGRP: "",
            ARBPL: "",
            PERNR: "",
          })
          .done(
            jQuery.proxy(function () {
              this.getRouter().navTo("settingsLoadConfig");
              // if (!this.qsDialog) {
              // 	this.qsDialog = sap.ui.xmlfragment("qsDialog", "mobilework.view.settings.QuickEntrySettings", this);
              // 	this.getView().setModel(new sap.ui.model.json.JSONModel(), "qs");
              // 	this.getView().addDependent(this.qsDialog);
              // }
              // this.qsDialog.open();
            }, this)
          )
          .fail(
            jQuery.proxy(function () {
              MBox.error(this.getText("SettingsTableCreateError"));
            }, this)
          );
      },

      onTilePress: function (oEvent) {
        var sTileId = oEvent.getSource().getId(),
            // that = this ,
          // oSettings = this.getSharedModel().getProperty("/sapSettings");
          oSettings = this.getModel("shared").getProperty("/sapSettings");

          let  MainPageGrid = this.getView().byId("MainPageGrid"),
          slideTilePurchaseOrders ,
          tiles = MainPageGrid.getContent(),
             allCustomData = [];
             tiles.forEach(function(tile) {
               // Get the custom data objects of the current tile
               var customDataArray = tile.getCustomData();
           
               // Iterate over each custom data object within the current tile
               customDataArray.forEach(function(customData) {
                   // Extract key and value from each custom data object
                   var key = customData.getKey();
                   var value = customData.getValue();
                   if (key === "Key" && value === "slideTilePurchaseOrders") {
                     slideTilePurchaseOrders = tile;
                 }
                   // Store the key-value pair in the allCustomData array
                   allCustomData.push({ key: key, value: value });
               });
           });

        if (sTileId.indexOf("notifications") !== -1) {
          this.getRouter().navTo("notificationsMaster");
        } else if (sTileId.indexOf("confirmations") !== -1) {
          this.getRouter().navTo("confirmationsMaster");
        } else if (sTileId.indexOf("orders") !== -1) {
          this.getRouter().navTo("ordersMaster");
        } else if (sTileId.indexOf("settings") !== -1) {
          this.getRouter().navTo("settingsMaster");
        } else if (sTileId.indexOf("synchronize") !== -1) {
          this.getRouter().navTo("synchronize");
        } else if (sTileId.indexOf("participants") !== -1) {
          this.getRouter().navTo("participantsMaster");
        } else if (sTileId.indexOf("amlog") !== -1) {
          this.getRouter().navTo(
            "LogModule",
            {},
            { 'amlog': { route: "amloghome" } }
          );
        } else if (sTileId.indexOf("logoff") !== -1) {
          if (oSettings.sapUser !== "" && oSettings.sapPass !== "")
            this._onLogOffPress();
          else this._openLogin(true);
        } else if (sTileId.indexOf("purchaseOrders") !== -1) {
          this.getRouter().navTo("purchaseMaster");
        } else if (slideTilePurchaseOrders) {
          this.getRouter().navTo("purchaseMaster");
        }
      // } else if (sTileId.indexOf("purchaseOrders") !== -1 || sTileId === '__tile8' ) {
      //   this.getRouter().navTo("purchaseMaster");
      // }
      },
      onResetTilePress: function () {
        var oView = this.getView(),
          sPassword = this.getSharedModel().getProperty("/sapSettings/sapPass"),
          sUser = this.getSharedModel().getProperty("/sapSettings/sapUser");

        if (!sUser || !sPassword) {
          MBox.error(this.getText("SettingsMissing"));
          return;
        }
        if (!this.getHelper().isOnline()) {
          MBox.error(this.getText("ConnectionUnknown"));
          return;
        }
        oView.setBusy(true);

        $.when(this.getService().logoff())
          .done(
            jQuery.proxy(function () {
              $.when(this.getService().createModelWithUser(sUser, sPassword))
                .done(
                  jQuery.proxy(function () {
                    this.connectionCheckTogiveColour();
                    oView.setBusy(false);
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    if (oError.getParameters().statusCode === 401) {
                      var oShared = this.getModel("shared"),
                        oSettings = oShared.getProperty("/sapSettings");
                      MBox.error(
                        this.getText("UserNotAuthorized", oSettings.sapSysId)
                      );
                    } else if (oError.getParameters().statusCode === 0) {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                    } else {
                      MBox.error(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap")
                      );
                    }
                    oView.setBusy(false);
                    this.getLogs().addLog(
                      "onResetConnectionPress Fail - createModelWithUser",
                      "Errror",
                      "Synchronize"
                    );
                  }, this)
                );
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              // 						$.when(this.getService().createModelWithUser(sUser, sPassword)).done(jQuery.proxy(function () {
              // 									this._connectionCheck(sUser, sPassword, oView);
              // 								}, this)).fail(jQuery.proxy(function (oError) {
              if (oError.status === 401) {
                var oShared = this.getModel("shared"),
                  oSettings = oShared.getProperty("/sapSettings");
                MBox.error(
                  this.getText("UserNotAuthorized", oSettings.sapSysId)
                );
              } else if (oError.status === 0) {
                MBox.error(this.getText("SAPSettingsIncorrect"));
              } else {
                MBox.error(
                  this.getText("ConnectionUnknown") +
                    "\n" +
                    this.getText("NoConnectionToSap")
                );
              }
              this.getLogs().addLog(
                "onResetConnectionPress Fail - logoff",
                "Errror",
                "Synchronize"
              );
              oView.setBusy(false);
            }, this)
          );
      },
      onQuickSettingsSave: function () {
        this.qsDialog.close();
        this._updateSettingsInDb();
      },

      //---------------------------//
      // PRIVATES
      //---------------------------//

      _updateSettingsInDb: function () {
        var aSettingsArrary = [],
          oUSettingModel = this.getView().getModel("qs"),
          oSettingData = oUSettingModel.getProperty("/");

        for (var sProp in oSettingData) {
          if (oSettingData.hasOwnProperty(sProp)) {
            aSettingsArrary.push({
              SKey: sProp,
              SValue: oSettingData[sProp],
            });
          }
        }

        $.when(this.getDBService().updateSAPSettings(aSettingsArrary))
          .done(
            jQuery.proxy(function () {
              MBox.success(this.getText("QSettingSuccess"));
            }, this)
          )
          .fail(
            jQuery.proxy(function () {
              MBox.error(this.getText("SettingsTableCreateError"));
            }, this)
          );
      },

      _onLogOffPress: function () {
        var yesnodialog = sap.ui.controller(
          "mobilework.controller.dialogs.YesNoDialog"
        );

        // yesnodialog.openYesNoDialog(this,
        // 	this.getText("ConfirmLogOff"),
        // 	this.getText("Confirm"),
        // 	function () {
        // 		this._logOff();
        // 		this.offline();
        // 	},
        // 	function () {
        // 		//this.closeFragments();
        // 	});

        // STATUS Questions

        // log on > only possible when online
        // > device onboarded > login procedure
        // > device offboarder > onboarding procedure

        // log off > always possible

        // Connection > if no connection >
        // >> Device onboarded ?? 	> shared>/ ?? 				> login dialog vs onboarding dialog
        // >> User logged in ??  	>  shared>/loggedInAsMsg 	> log on or log off

        let oShared = this.getView().getModel("shared").getData();
        let sLoggedInUser = oShared.loggedInAsMsg;

        if (sLoggedInUser === "") {
          // Login scenario > only proceed when device is online

          if (
            oShared &&
            oShared.sapSettings &&
            oShared.sapSettings.deviceName !== "" &&
            oShared.sapSettings.deviceName !== undefined &&
            !oShared.configFailed
          ) {
            //    oShared.configFailed) {
            // Device is already onboarder > use login procedure
            this._openLogin();
            // this._login();
          } else {
            // Device is not yet onboarded > start onboarding procedure
            this._openOnboarding();
          }
        } else {
          // Logoff scenario

          yesnodialog.openYesNoDialog(
            this,
            this.getText("ConfirmLogOff"),
            this.getText("Confirm"),
            async function () {
              
              this.getView().setBusy(true);
              this._logOff();
              this.offline();
              this.getView().setBusy(false);
            }.bind(this),
            function () {
              //this.closeFragments();
            }.bind(this)
          );
        }
      },

      onOpenCamera: function () {
        $.when(this.getScanHandler().scan())
          .done(jQuery.proxy(this.onScanSuccess, this))
          .fail(
            jQuery.proxy(function (oError) {
              MToast.show(this.getText("ScanIssue"));
            }, this)
          );
      },

      onScanSuccess: function (oData) {
        // Max 12 chars
        let sInputUser = oData.text.slice(0, 12);
        this.getModel("login").setProperty("/sapUser", sInputUser);
      },

      _logOff: async function () {
        var oSettings = this.getSharedModel().getProperty("/sapSettings"),
          aSettingsArray = [];

        if (oSettings && oSettings.sapUser !== "") {
          for (var sProp in oSettings) {
            if (oSettings.hasOwnProperty(sProp)) {
              let sValue = oSettings[sProp];
              if (sProp === "sapPass" || sProp === "sapUser") {
                sValue = "";
              }
              aSettingsArray.push({
                SKey: sProp,
                SValue: sValue,
              });
            }
          }

          // if (!this.getHelper().isDevModeActive()) {

          try {
            await this.getService().logoff();
          } catch (oError) {
            // Logoff tile should always work even when device is offline !!
            // if (oError.responseText !== undefined) {
            // 	sap.m.MessageToast.show(oError.responseText);
            // } else if (oError.message !== undefined) {
            // 	sap.m.MessageToast.show(oError.message);
            // }
            // else if (oError.statusText === "error" ){
            // 	sap.m.MessageToast.show("No connection to the SAP system");
            // }
            // // if (oError.message === this.getText("InvalidToken")) {
            // // 	// No valid token to perform the logoff procedure
            // // }
            // this.getView().setBusy(false);
            // return;
          }

          this.getOwnerComponent().tokenService.clearToken();
          oSettings.sapUser = "";
          oSettings.sapPass = "";

          // }

          $.when(this.getDBService().getSAPSettings())
            .done(
              jQuery.proxy(function () {
                $.when(
                  this.getDBService().updateSAPSettings(aSettingsArray)
                ).done(
                  jQuery.proxy(function () {
                    sap.m.MessageToast.show(this.getText("LogoffSuccess"));
                    this.getSharedModel().setProperty("/loggedInAsMsg", "");
                    this.getSharedModel().setProperty("/bUserIconVisible", false);

                    this.getView().setBusy(false);

                    // Device has been onboarded before & user is logged off -- scenario 5 & 6
                    // WR - call component > _start_procedure_offline
                    // this.getOwnerComponent._start_procedure_offline();
                    // this._openLogin();
                  }, this)
                );
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                $.when(this.getDBService().saveSAPSettings(oSettings)).done(
                  jQuery.proxy(function () {
                    sap.m.MessageToast.show(this.getText("LogoffSuccess"));

                    this.getView().setBusy(false);

                    // this.getService().component.tokenService.clearToken();
                    // Device has been onboarded before & user is logged off -- scenario 5 & 6
                    // WR - call component > _start_procedure_offline
                    // this.getOwnerComponent._start_procedure_offline();
                    // this._openLogin();
                  }, this)
                );
              }, this)
            );
        } else {
          sap.m.MessageToast.show(this.getText("LogoffFailed"));
          this.getView().setBusy(false);
        }
      },

      //---------------------------//
      //			 LOGIN			 //
      //---------------------------//

      _openLogin: async function (logintile) {
        // this.getService().component.tokenService.clearToken();
        this.getOwnerComponent()._start_procedure_offline();

        this.getView().getModel("login").setProperty("/sapUser", "");
        this.getView().getModel("login").setProperty("/sapPass", "");
        this.getView().getModel("login").setProperty("/sapPinCode", "");
        // this.getView().getModel("login").setProperty("/sapBearer", "");

        if (this.getSharedModel().getProperty("/sapSettings/langu")) {
          this.getView()
            .getModel("login")
            .setProperty(
              "/langu",
              this.getSharedModel()
                .getProperty("/sapSettings/langu")
                .toUpperCase()
            );
        } else {
          this.getView().getModel("login").setProperty("/langu", "EN");
        }

        let sFragment = "";
        if (this.getSharedModel().getProperty("/publicRelease")) {
          sFragment = "fragments.PublicLogin";
          if (logintile) {
            this.onBearerLogin();
            return;
          }
        } else {
          sFragment = "fragments.Login";
        }
        var sSystemID = this.getSharedModel().getProperty(
          "/sapSettings/sapSysId"
        );
        this.getModel("login").setProperty("/sapSysId", sSystemID);

        let oPincodeServerResult =
          await this.getHelper().getPincodeServerMapping();
        this.getModel("login").setProperty(
          "/pincodeServerMapping",
          oPincodeServerResult
        );

        if (
          this.getModel("login").getProperty("/pincodeServerMapping") !==
          undefined
        ) {
          let sPincodeServerDomain = this.getModel("login").getProperty(
            "/pincodeServerMapping"
          ).Mapping[sSystemID];
          this.getModel("login").setProperty(
            "/pincodeServerDomain",
            sPincodeServerDomain
          );
          var bDeviceRegistered =
            await this.loginMethod.checkDeviceRegistration(
              sPincodeServerDomain
            );
        }
        // const sPincodeServerDomain = this.getModel('login').getProperty('/pincodeServerDomain');
        if (bDeviceRegistered) {
          this.getModel("login").setProperty("/pinCodeState", true);
          this.getModel("login").setProperty("/sapPincodeVisible", true);
          this.getModel("login").setProperty("/sapPasswordVisible", false);

          this.getModel("login").setProperty("/sapPass", "");
          this.getModel("login").setProperty("/sapPinCode", "");
        } else {
          // WR 29.11.2023
          this.getModel("login").setProperty("/pinCodeState", false);
          this.getModel("login").setProperty("/sapPincodeVisible", false);
          this.getModel("login").setProperty("/sapPasswordVisible", true);

          this.getModel("login").setProperty("/sapPass", "");
          this.getModel("login").setProperty("/sapPinCode", "");
        }

        this.getDialogManager().openWithModel(
          sFragment,
          this.getView(),
          this.getView().getModel("login")
        );
      },

      _openOnboarding: async function () {
        // this.getOwnerComponent().OnboardingProcedure = true;
        this._clearOnboarding();
        let oPincodeServerResult =
          await this.getHelper().getPincodeServerMapping();
        this.getModel("login").setProperty(
          "/pincodeServerMapping",
          oPincodeServerResult
        );
        let sFragment = "";
        if (this.getSharedModel().getProperty("/publicRelease")) {
          sFragment = "fragments.PublicOnboarding";
        } else {
          sFragment = "fragments.Onboarding";
        }
        this.getDialogManager().openWithModel(
          sFragment,
          this.getView(),
          this.getOnboardingModel()
        );
        /*
				When default language and conuntry set
			*/
        var _sCountry = this.getModel("onboarding").getProperty("/country");
        if (_sCountry) {
          this.onOnboardingCountryChanged();
        }
      },

      _getNewToken: async function () {
        let sHost = "";
        if (!this.getHelper().isDevModeActive()) {
          // sHost = this.getView().getModel('shared').getProperty('/sapSettings/host');
          sHost = this.getView().getModel("onboarding").getProperty("/host");
          if (sHost === undefined) {
            sHost = this.getView()
              .getModel("shared")
              .getProperty("/sapSettings/host");
          }
        }

        // sUserName = await this.getOwnerComponent().tokenService.checkTokenAtLogin(sToken, sHost).catch(function (oError) {
        // 	throw oError;
        // });

        let bLogInSuccess =
          await this.getOwnerComponent().tokenService.retrieveNewToken(sHost);

        return bLogInSuccess;
      },

      onBearerLogin: async function (oEvent) {
        let oEventCopy, oDialog;
        if (oEvent) {
          oEventCopy = Object.assign({}, oEvent);
          oEventCopy.__proto__ = oEvent.__proto__;
          
          oDialog = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getParent()
            .getParent();
          oDialog.setBusy(true);
        }

        let bLogInSuccess = await this._getNewToken();

        let tokenService = this.getOwnerComponent().tokenService;
        let oLoginModel = this.getModel("login");

        if (bLogInSuccess && tokenService.valid) {
          oLoginModel.setProperty("/sapUser", tokenService.username);

          if (this.getHelper().isDevModeActive())
            oLoginModel.setProperty("/sapUser", "5373");
          oLoginModel.setProperty("/sapPass", tokenService.newValidToken);
          // oLoginModel.setProperty("/sapBearer", tokenService.newValidToken);
          oLoginModel.setProperty("/showLoginButton", false);

          // oOnboardingModel.setProperty("/deviceName", null);
          // oOnboardingModel.setProperty("/SysAuth", true);
          // oOnboardingModel.setProperty("/sapBearer", tokenService.newValidToken);
          // oOnboardingModel.setProperty("/sapPass", tokenService.newValidToken);
          // oOnboardingModel.setProperty("/sapUser", tokenService.username);
          // oOnboardingModel.setProperty("/showLoginButton", false );
          if (oDialog) oDialog.setBusy(false);
          this.onProcessLogin(oEventCopy);
          this.createPublicTables();
        } else {
          oLoginModel.setProperty("/sapUser", "");
          oLoginModel.setProperty("/sapPass", "");
          // oLoginModel.setProperty("/sapBearer", "");
          oLoginModel.setProperty("/showLoginButton", true);
          
          // oOnboardingModel.setProperty("/sapUser", "");
          // oOnboardingModel.setProperty("/SysAuth", false);
          // oOnboardingModel.setProperty("/showLoginButton", true );
          if (oDialog) oDialog.setBusy(false);
        }
      },

      onBearerOnboarding: async function (oEvent) {
        // After a restart of the app this is not user friendly ...
        // See if we can keep a global variable living in the cache >> security issue ??

        // Call authenticator app to retrieve a bearer token

        let oEventCopy = Object.assign({}, oEvent);
        oEventCopy.__proto__ = oEvent.__proto__;

        let oDialog = oEvent
          .getSource()
          .getParent()
          .getParent()
          .getParent()
          .getParent();

        oDialog.setBusy(true);
        let bLogInSuccess = await this._getNewToken();

        //

        let tokenService = this.getOwnerComponent().tokenService;
        let oOnboardingModel = this.getModel("onboarding");
        let oSharedModel = this.getModel("shared");

        if (bLogInSuccess && tokenService.valid) {
          // this.getModel("login").setProperty("/sapUser", tokenService.username);
          // this.getModel("login").setProperty("/sapPass", tokenService.newValidToken);
          // this.getModel("login").setProperty("/sapBearer", tokenService.newValidToken);
          // oOnboardingModel.setProperty("/sapBearer", tokenService.newValidToken);

          oOnboardingModel.setProperty("/deviceName", null);
          oOnboardingModel.setProperty("/SysAuth", true);
          oOnboardingModel.setProperty("/sapPass", tokenService.newValidToken);
          oOnboardingModel.setProperty("/sapUser", tokenService.username);
          oOnboardingModel.setProperty("/showLoginButton", false);

          // oSharedModel.setProperty("/sapSettings/sapUser", tokenService.username);
          // oSharedModel.setProperty("/loggedInAsMsg", this.getText("LoggedInAs", [ tokenService.username ]));

          oDialog.setBusy(false);
          this.onOnboardingPasswordChanged(oEventCopy, true);
          this.createPublicTables();
        } else {
          // this.getModel("login").setProperty("/sapUser", "");
          // this.getModel("login").setProperty("/sapPass", "");
          // this.getModel("login").setProperty("/sapBearer", "");

          oOnboardingModel.setProperty("/sapUser", "");
          oOnboardingModel.setProperty("/SysAuth", false);

          oOnboardingModel.setProperty("/showLoginButton", true);

          // oSharedModel.setProperty("/sapSettings/sapUser", "");
          // oSharedModel.setProperty("/loggedInAsMsg", "");

          oDialog.setBusy(false);
        }
      },

      onProcessLogin: async function (oEvent) {
        let sNetworkState = navigator.connection.type,
          oDialog;
        var that = this;
        this.getModel("login").setProperty("/show-connection-ok", false);
        this.getModel("login").setProperty("/show-connection-nok", false);
        this.getModel("login").setProperty("/show-authorization-text", false);
        this.getModel("login").setProperty("/show-authorization-ok", false);
        this.getModel("login").setProperty("/show-authorization-nok", false);
        this.getModel("login").setProperty("/show-data-text", false);
        this.getModel("login").setProperty("/show-data-ok", false);
        this.getModel("login").setProperty("/show-data-nok", false);
        this.getModel("login").setProperty("/show-cancel-LoginProgress", false);
        this.getModel("login").setProperty("/show-retry-LoginProgress", false);

        if (oEvent) {
          oDialog = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getParent()
            .getParent(); // ==> login screen
          // let oDialog = oEvent.getSource().getParent();
          // this._handleBusyIndicator("SHOW");
          this.getDialogManager().openWithModel(
            "fragments.LoginProgress",
            this.getView(),
            this.getView().getModel("login")
          );
          let oEventCopy = {};
          oEventCopy.oSource = oEvent.getSource();
          oEventCopy.getSource = oEvent.getSource;
          // this.getDialogManager().openWithModel("fragments.LoginProgress", this.getView(), this.getView().getModel("login"));
          if (!this.getHelper().isOnline()) {
            MToast.show(this.getText("NoSAPSystemConnection"));
            this.getModel("login").setProperty(
              "/show-cancel-LoginProgress",
              true
            );
            this.getModel("login").setProperty(
              "/show-retry-LoginProgress",
              true
            );
            this.getModel("login").setProperty("/show-connection-nok", true);
            return;
          }
          if (
            this.getModel("login").getProperty("/pinCodeState") === true &&
            !this.getSharedModel().getProperty("/publicRelease") &&
            !this.getSharedModel().getProperty("/publicRelease")
          ) {
            try {
              // this._handleBusyIndicator("HIDE");
              await this.loginMethod.onLoginPincodeLoginPress(this, oEventCopy);
            } catch (oError) {
              console.error(oError);
              // Pincode logon has failed
              console.error("Pincode login failed");
              // this._handleBusyIndicator("HIDE");
              this.getModel("login").setProperty(
                "/show-cancel-LoginProgress",
                true
              );
              this.getModel("login").setProperty(
                "/show-retry-LoginProgress",
                true
              );
              this.getModel("login").setProperty("/show-connection-nok", true);
              // this.getDialogManager().close("fragments.LoginProgress", this.getView());
              // this.getDialogManager().destroyDialog("fragments.LoginProgress", this.getView());
              // throw oError;
              return;
            }
          }
        }

        if (
          (this.getModel("login").getData().sapUser &&
            this.getModel("login").getData().sapUser !== "") ||
          (this.getModel("login").getData().sapPass &&
            this.getModel("login").getData().sapPass !== "") ||
          (this.getModel("login").getData().sapBearer &&
            this.getModel("login").getData().sapBearer !== "")
        ) {
          let sToken = this.getModel("login").getData().sapPass;
          let sUserName = this.getModel("login").getData().sapUser;

          // if (sToken) {
          // 	try {

          // 		let sHost = "";
          // 		if (!this.getHelper().isDevModeActive())
          // 			sHost = this.getView().getModel('shared').getProperty('/sapSettings/host');

          // 		sUserName = await this.getOwnerComponent().tokenService.checkTokenAtLogin(sToken, sHost).catch(function (oError) {
          // 			throw oError;
          // 		});
          // 		this.getModel("login").setProperty("/sapUser", sUserName);
          // 		this.getModel("login").setProperty("/sapPass", sToken);
          // 		this.getModel("login").setProperty("/sapBearer", sToken);
          // 		MToast.show(this.getText("ValidToken"));

          // 	} catch (oError) {
          // 		MToast.show(oError.message);
          // 		return;
          // 	}
          // }

          this.getModel("login").getData().sapUser = this.getModel("login")
            .getData()
            .sapUser.toUpperCase();

          // if (this.getModel("login").getProperty("/langu")) {
          // 			sap.ui.getCore().getConfiguration().setLanguage(this.getModel("login").getProperty("/langu"));
          // }

          if (this.getModel("login").getProperty("/langu")) {
            this.getSharedModel().setProperty(
              "/sapSettings/langu",
              this.getModel("login").getProperty("/langu").toLowerCase()
            );

            sap.ui
              .getCore()
              .getConfiguration()
              .setLanguage(
                this.getModel("login").getProperty("/langu").toLowerCase()
              );
          }

          if (this.getService()) {
            // this.getService().updateLanguage(this.getModel("login").getProperty("/langu").toLowerCase());
            this.getSharedModel().setProperty(
              "/sapSettings/langu",
              this.getModel("login").getProperty("/langu").toLowerCase()
            );

            this.getService().updateIndex();
            //this.getService().createModelWithUser(this.getModel("login").getData().sapUser, this.getModel("login").getData().sapPass);
          } else {
            this.getSharedModel().setProperty(
              "/sapSettings/sapUser",
              this.getModel("login").getData().sapUser
            );
            this.getSharedModel().setProperty(
              "/sapSettings/sapPass",
              this.getModel("login").getData().sapPass
            );
            this.getOwnerComponent()._onUserDataLoaded(
              this.getSharedModel().getProperty("/sapSettings")
            );
          }
          if (this.getSharedModel().getProperty("/publicRelease")) {
            this._handleBusyIndicator("SHOW");
            let agreement = await this.selectAgreementwithCheck(
              true,
              sUserName
            );
            if (!agreement) {
              MBox.error(this.getText("ConnectionUnknown"));
            } else if (agreement === "F") {
              agreement = await this.selectAgreement();
              if (!agreement) {
                this._handleBusyIndicator("HIDE");
                this.getSharedModel().setProperty("/sapSettings/sapUser", "");
                this.getSharedModel().setProperty("/sapSettings/sapPass", "");
                this.getModel("login").setProperty("/showLoginButton", true);
                return;
              }
            }
          }

          if (this.getSharedModel().getProperty("/publicRelease")) {
            this._handleBusyIndicator("SHOW");
            if (sUserName !== undefined) {
              this.getModel("login").setProperty("/show-connection-ok", true);
              this.getModel("login").setProperty(
                "/show-authorization-text",
                true
              );
              MToast.show(this.getText("LoginSuccessful"));
              this._login();

              this.genericSetDeviceIdColor("Green");
              this.genericReplaceStyleClass(this.getView(), "Green");

              this.createParticipants(this.getModel("login").getData().sapUser);
            } else {
              MToast.show(this.getText("InvalidToken"));
            }

            this._handleBusyIndicator("HIDE");
            $.when(this.getService().getPlanItemService())
              .done(
                function (oData) {
                  this.getDBService()._savePlanItemSetSettings(oData);
                  this.getDBService()._createTable([oData]);
                }.bind(this)
              )
              .fail(function (oError) {}.bind(this));

            return;
          }

          
          if (
            this.getHelper().isDevModeActive() ||
            (Connection &&
              sNetworkState !== Connection.UNKNOWN &&
              sNetworkState !== Connection.NONE)
          ) {
            $.when(
              this.getService().createModelWithUser(
                this.getModel("login").getData().sapUser,
                this.getModel("login").getData().sapPass,
                that,
                true
              )
            )
              .done(
                jQuery.proxy(function (oData) {
                  $.when(this._checkLogin())
                    .done(
                      jQuery.proxy(function (oData) {
                        // this.getModel('login').setProperty("/show-connection-ok", true);
                        // this.getModel('login').setProperty("/show-authorization-text", true);
                        
                        if (oData && oData.ConnectionCheck) {
                          var sMessageType = oData.ConnectionCheck.Type,
                            sMessage = oData.ConnectionCheck.Message;

                          if (sMessageType === "S") {
                            MToast.show(sMessage);
                            this.getModel("login").setProperty(
                              "/show-authorization-ok",
                              true
                            );
                            this.getModel("login").setProperty(
                              "/show-data-text",
                              true
                            );
                            this._login();

                            this.genericSetDeviceIdColor("Green");
                            this.genericReplaceStyleClass(
                              this.getView(),
                              "Green"
                            );
                          } else {
                            that
                              .getModel("login")
                              .setProperty("/show-cancel-LoginProgress", true);
                            this.getModel("login").setProperty(
                              "/show-retry-LoginProgress",
                              true
                            );
                            that
                              .getModel("login")
                              .setProperty("/show-authorization-nok", true);
                            // that.getModel("login").setProperty("/show-data-nok", true);
                            MToast.show(
                              sMessage +
                                "\n" +
                                this.getText("ConnectionCheckWarning")
                            );
                          }
                        } else if (oData && oData.settings === false) {
                          // that.getModel("login").setProperty("/show-data-nok", true);
                          MToast.show(this.getText("SettingsMissing"));
                          this._login();
                        } else if (oData && oData.loginNotFull === true) {
                          MToast.show(this.getText("LoginNotFullyEntered"));
                          that
                            .getModel("login")
                            .setProperty("/show-cancel-LoginProgress", true);
                          this.getModel("login").setProperty(
                            "/show-retry-LoginProgress",
                            true
                          );
                          that
                            .getModel("login")
                            .setProperty("/show-authorization-nok", true);
                        } else {
                          if (!oData) {
                            this._login();
                          } else {
                            // that.getModel("login").setProperty("/show-data-nok", true);
                            that
                              .getModel("login")
                              .setProperty("/show-cancel-LoginProgress", true);
                            this.getModel("login").setProperty(
                              "/show-retry-LoginProgress",
                              true
                            );
                            that
                              .getModel("login")
                              .setProperty("/show-authorization-nok", true);
                            MToast.show(this.getText("UnknownGateWayError"));
                          }
                        }
                        // this._handleBusyIndicator( "HIDE");
                      }, this)
                    )
                    .fail(
                      jQuery.proxy(function (oError) {
                        MToast.show(oError);
                        // this._handleBusyIndicator( "HIDE");
                      }, this)
                    );
                  var logUri = this.getManifestEntry(
                    "/sap.app/dataSources/logs"
                  ).uri;
                  this.getModel("login").setProperty(
                    "/sapClient",
                    this.getSharedModel().getProperty("/sapSettings/sapClient")
                  );
                  this.getModel("login").setProperty(
                    "/host",
                    this.getSharedModel().getProperty("/sapSettings/host")
                  );
                  this.getLogs().createLogModelWithUser(
                    logUri,
                    this.getModel("login").getData()
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  this.getModel("login").setProperty(
                    "/show-cancel-LoginProgress",
                    true
                  );
                  this.getModel("login").setProperty(
                    "/show-retry-LoginProgress",
                    true
                  );
                  this.getModel("login").setProperty(
                    "/show-connection-nok",
                    true
                  );
                  if (oError.getParameters().statusCode === 401) {
                    MBox.error(
                      this.getText(
                        "UserNotAuthorized",
                        this.getSharedModel().getProperty(
                          "/sapSettings/sapSysId"
                        )
                      )
                    );
                  } else if (oError.getParameters().statusCode === 0) {
                    MToast.show(this.getText("NoSAPSystemConnection"));
                  } else if (oError.getParameters().statusCode === 500) {
                    MToast.show(this.getText("NoSAPSystemConnection"));
                  } else {
                    MBox.error(
                      this.getText("ConnectionUnknown") +
                        "\n" +
                        this.getText("NoConnectionToSap")
                    );
                  }
                  // this._handleBusyIndicator( "HIDE");
                }, this)
              );
          } else {
            // this._login(); >> do not proceed login while device is not connected
            MToast.show(this.getText("NoNetwork"));
            that
              .getModel("login")
              .setProperty("/show-cancel-LoginProgress", true);
            this.getModel("login").setProperty(
              "/show-retry-LoginProgress",
              true
            );
            this.getModel("login").setProperty("/show-connection-nok", true);
            // this._handleBusyIndicator( "HIDE");
          }
        } else {
          MToast.show(this.getText("NoLoginData"));
          that
            .getModel("login")
            .setProperty("/show-cancel-LoginProgress", true);
          this.getModel("login").setProperty("/show-retry-LoginProgress", true);
          this.getModel("login").setProperty("/show-connection-nok", true);
          // this._handleBusyIndicator( "HIDE");
        }
      },

      _login: function () {
        var oSettings = this.getSharedModel().getProperty("/sapSettings"),
          aSettingsArray = [],
          bLanguageChanged = false,
          that = this;

        
        
        if (
          oSettings.langu.toUpperCase() !==
          this.getModel("login").getProperty("/langu")
        ) {
          bLanguageChanged = true;
        }

        if (
          this.getModel("login").getProperty("/sapUser") !== "" &&
          this.getModel("login").getProperty("/sapPass") !== "" &&
          this.getModel("login").getProperty("/langu") !== ""
        ) {
          oSettings.sapUser = this.getModel("login").getProperty("/sapUser");
          oSettings.sapPass = this.getModel("login").getProperty("/sapPass");
          oSettings.langu = this.getModel("login").getProperty("/langu");

          for (var sProp in oSettings) {
            if (oSettings.hasOwnProperty(sProp)) {
              aSettingsArray.push({
                SKey: sProp,
                SValue: oSettings[sProp],
              });
            }
          }
          $.when(this.getDBService().getSAPSettings())
            .done(
              jQuery.proxy(function () {
                $.when(
                  this.getDBService().updateSAPSettings(aSettingsArray)
                ).done(
                  jQuery.proxy(function () {
                    this.getModel("login").setProperty(
                      "/show-authorization-ok",
                      true
                    );
                    this.getModel("login").setProperty("/show-data-text", true);
                    // Internal version code
                    $.when(
                      this.getDBService().getPermanentData(
                        true,
                        oSettings.sapUser
                      )
                    )
                      .done(
                        jQuery.proxy(function () {
                          this.getModel("login").setProperty(
                            "/show-data-ok",
                            true
                          );
                          this.onDataDownloadSuccess();
                          // this.getView().setBusy(false);
                        }, this)
                      )
                      .fail(
                        function () {
                          this.getModel("login").setProperty(
                            "/show-authorization-nok",
                            false
                          );
                          // this.getView().setBusy(false);
                        }.bind(this)
                      );
                    if (this.getService().getUser() == oSettings.sapUser)
                      this.getService().createModelWithUser(
                        oSettings.sapUser,
                        oSettings.sapPass
                      );
                    if (this.getSharedModel().getProperty("/publicRelease")) {
                      this.timeRegistrationOffline();
                      this.exitTimeCheck(false);
                    }

                    // Public release code
                    // $.when(this.getDBService().getPermanentData())
                    // 	.done(jQuery.proxy(function () {
                    // 		this.onDataDownloadSuccess();
                    // 	}, this));

                    if (
                      this.getOwnerComponent()
                        .getModel("i18n")
                        .getResourceBundle().sLocale !== "fr"
                    ) {
                      this.getSharedModel().setProperty(
                        "/loggedInAsMsg",
                        this.getText("LoggedInAs", [
                          this.getSharedModel().getProperty(
                            "/sapSettings/sapUser"
                          ),
                        ])
                      );
                    } else {
                      this.getSharedModel().setProperty(
                        "/loggedInAsMsg",
                        this.getSharedModel().getProperty(
                          "/sapSettings/sapUser"
                        )
                      );
                    }
                    this.getSharedModel().setProperty("/bUserIconVisible", true);

                    this.getService()
                      .getModel()
                      .metadataLoaded()
                      .then(
                        jQuery.proxy(function () {
                          console.debug("metadata loaded");

                          this.getView()
                            .getModel("shared")
                            .setProperty("/metaFailed", false);
                          this.getDBService()._createTablesFromMetadata();
                          this.getOwnerComponent().sqlDataBaseUpdate();
                        }, this)
                      );

                    this._onCloseLoginFragment();
                    if (bLanguageChanged) {
                      MBox.show(this.getText("BewareOfFlocLangu"));
                    }

                    // this.getView().setBusy(false); ==> login flow , should not stop here yet
                    this.updateDeviceSettings();
                  }, this)
                );
              }, this)
            )
            .fail(
              jQuery.proxy(function () {
                $.when(this.getDBService().saveSAPSettings(oSettings)).done(
                  jQuery.proxy(function () {
                    if (this.getModel("login").getProperty("/langu")) {
                      this.busyDialog.open();
                      sap.ui
                        .getCore()
                        .getConfiguration()
                        .setLanguage(
                          this.getModel("login")
                            .getProperty("/langu")
                            .toLowerCase()
                        );

                      this.getOwnerComponent()._copyValueHelpToSharedModel();
                      this.busyDialog.close();
                    }
                    this._onCloseLoginFragment();
                    this.getView().setBusy(false);
                  }, this)
                );
              }, this)
            );
        }
      },

      _checkLogin: function () {
        var d = jQuery.Deferred(),
          oUser = this.getModel("login").getData(),
          that = this;
        if (
          this.getSharedModel().getProperty("/sapSettings") &&
          this.getSharedModel().getProperty("/sapSettings").host !== ""
        ) {
          var oSettings = this.getSharedModel().getProperty("/sapSettings");

          if (oUser.sapUser && oUser.sapPass && oUser.langu) {
            $.when(
              this.getService().connectionCheck(
                oUser.sapUser,
                oUser.sapPass,
                this.getHelper().isDevModeActive(),
                this
              )
            )
              .done(
                jQuery.proxy(function (oData) {
                  if (oData.ConnectionCheck.Type === "E") {
                    // Authorization not ok
                  } else {
                    this.getModel("login").setProperty(
                      "/show-authorization-ok",
                      true
                    );
                  }
                  d.resolve(oData);
                }, this)
              )
              .fail(
                jQuery.proxy(function (oData) {
                  this.getModel("login").setProperty(
                    "/show-authorization-nok",
                    true
                  );
                  if (
                    oData.getParameters() &&
                    oData.getParameters().statusCode === 401
                  ) {
                    d.resolve(
                      this.getView()
                        .getModel("i18n")
                        .getResourceBundle()
                        .getText("IncorrectLogin") +
                        "\n" +
                        this.getView()
                          .getModel("i18n")
                          .getResourceBundle()
                          .getText("ConnectionCheck")
                    );
                  } else {
                    d.resolve(
                      this.getView()
                        .getModel("i18n")
                        .getResourceBundle()
                        .getText("ErrorNetwork")
                    );
                  }
                }, this)
              );
          } else {
            d.resolve({
              loginNotFull: true,
            });
          }
        } else {
          d.resolve({
            settings: false,
          });
        }

        return d.promise();
      },

      _clearLogin: function () {
        this.getView().getModel("login").setProperty("/sapUser", "");
        this.getView().getModel("login").setProperty("/showLoginButton", true);
        this.getView().getModel("login").setProperty("/sapPass", "");
        this.getView().getModel("login").setProperty("/sapPinCode", "");
        // this.getView().getModel("login").setProperty("/sapBearer", "");
      },

      _onCloseLoginFragment: function (alreadyLogged) {
        this._clearLogin();

        let sFragment = "";
        if (this.getSharedModel().getProperty("/publicRelease"))
          sFragment = "fragments.PublicLogin";
        else sFragment = "fragments.Login";
        this.getDialogManager().close(sFragment, this.getView());
        if (alreadyLogged) {
          this.genericSetDeviceIdColor("Red");
          this.genericReplaceStyleClass(this.getView(), "Red");

          // this.getView().getModel("shared").setProperty("/sapSettings/sapUser","");
          // this.getView().getModel("shared").setProperty("/sapSettings/sapPass","");
          if (!this.doneExitCheck) this.exitTimeCheck(true);
          this.doneExitCheck = true;
        }
        // if (this._navigateBackTarget !== undefined){
        // 	let sTarget = this._navigateBackTarget;
        // 	this._navigateBackTarget = undefined;
        // 	this.getRouter().navTo(sTarget);
        // }
      },

      onDataDownloadSuccess: function () {
        
        let oPromCatalog = this.getDBService().getEntitySet("Catalog"),
          oPromQmart = this.getDBService().getEntitySet(
            "PMNotificationQmartVH"
          ),
          oPromShift = this.getDBService().getEntitySet(
            "PMNotificationShiftVH"
          ),
          oPromLangu = this.getDBService().getEntitySet(
            "PMNotificationLanguVH"
          ),
          oPromUnWork = this.getDBService().getEntitySet(
            "ConfirmationsUnWorkVH"
          ),
          oPromCraft = this.getDBService().getEntitySet(
            "PMNotificationCraftVH"
          ),
          oPromSettings = this.getDBService().getSAPSettings(),
          oPromActType = this.getDBService().getEntitySet(
            "ConfirmationsPMActTypeVH"
          ),
          oPromPmenvr = this.getDBService().getEntitySet(
            "PMNotificationPmenvrVH"
          ),
          oPromPmqual = this.getDBService().getEntitySet(
            "PMNotificationPmqualVH"
          ),
          oPromPmsafe = this.getDBService().getEntitySet(
            "PMNotificationPmsafeVH"
          ),
          oPromQuotCoR = this.getDBService().getEntitySet(
            "PMNotificationQuotCoRVH"
          ),
          oPromQuotDeR = this.getDBService().getEntitySet(
            "PMNotificationQuotDeRVH"
          ),
          oPromQuotPrR = this.getDBService().getEntitySet(
            "PMNotificationQuotPrRVH"
          ),
          oPromQuotWcR = this.getDBService().getEntitySet(
            "PMNotificationQuotWcRVH"
          ),
          oPromImpactOblCustomizing = this.getDBService().getEntitySet(
            "ImpactOblCustomizing"
          ),
          oPromNotifcationType = this.getHelper().getNotificationTypes();

        $.when(
          oPromQmart,
          oPromCatalog,
          oPromShift,
          oPromLangu,
          oPromUnWork,
          oPromCraft,
          oPromSettings,
          oPromActType,
          oPromPmenvr,
          oPromPmqual,
          oPromPmsafe,
          oPromQuotCoR,
          oPromQuotDeR,
          oPromQuotPrR,
          oPromQuotWcR,
          oPromImpactOblCustomizing,
          oPromNotifcationType
        ).done(
          jQuery.proxy(function (
            _oQmartData,
            _oCatalogData,
            _oShiftData,
            _oLanguData,
            _oUnWorkData,
            _oCraftData,
            _oSettingData,
            _oActyTpeData,
            _oPmenvrData,
            _oPmqualData,
            _oPmsafeData,
            _oQuotCoRData,
            _oQuotDeRData,
            _oQuotPrRData,
            _oQuotWcRData,
            _oImpactOblData,
            oNotifcationType
          ) {
            let oSharedModel = this.getView().getModel("shared"),
              aQmart = [],
              aCatalog = [],
              aShift = [],
              aLangu = [],
              aUnWork = [],
              aCraft = [],
              aActType = [],
              aPmqual = [],
              aPmsafe = [],
              aQuotCoR = [],
              aQuotDeR = [],
              aQuotPrR = [],
              aQuotWcR = [],
              aPmenvr = [],
              aImpactObl = [];

            // for (var i = 0; i < _oQmartData.rows.length; i++) {
            // 	aQmart.push(_oQmartData.rows.item(i));
            // }

            for (var j = 0; j < _oCatalogData.rows.length; j++) {
              aCatalog.push(_oCatalogData.rows.item(j));
            }

            for (var k = 0; k < _oShiftData.rows.length; k++) {
              aShift.push(_oShiftData.rows.item(k));
            }

            for (var l = 0; l < _oLanguData.rows.length; l++) {
              aLangu.push(_oLanguData.rows.item(l));
            }

            for (var m = 0; m < _oUnWorkData.rows.length; m++) {
              aUnWork.push(_oUnWorkData.rows.item(m));
            }

            for (var n = 0; n < _oCraftData.rows.length; n++) {
              aCraft.push(_oCraftData.rows.item(n));
            }

            for (var o = 0; o < _oActyTpeData.rows.length; o++) {
              aActType.push(_oActyTpeData.rows.item(o));
            }

            for (var o = 0; o < _oPmenvrData.rows.length; o++) {
              aPmenvr.push(_oPmenvrData.rows.item(o));
            }
            for (var o = 0; o < _oPmqualData.rows.length; o++) {
              aPmqual.push(_oPmqualData.rows.item(o));
            }
            for (var o = 0; o < _oPmsafeData.rows.length; o++) {
              aPmsafe.push(_oPmsafeData.rows.item(o));
            }
            for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
              aQuotCoR.push(_oQuotCoRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
              aQuotDeR.push(_oQuotDeRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
              aQuotPrR.push(_oQuotPrRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
              aQuotWcR.push(_oQuotWcRData.rows.item(o));
            }

            for (var o = 0; o < _oImpactOblData.rows.length; o++) {
              aImpactObl.push(_oImpactOblData.rows.item(o));
            }

            oSharedModel.setProperty("/vh", {});
            oSharedModel.setProperty("/vh/Qmart", oNotifcationType.Types);
            oSharedModel.setProperty("/vh/Catalog", aCatalog);
            oSharedModel.setProperty("/vh/Shift", aShift);
            oSharedModel.setProperty("/vh/Langu", aLangu);
            oSharedModel.setProperty("/vh/UnWork", aUnWork);
            oSharedModel.setProperty("/vh/Craft", aCraft);
            oSharedModel.setProperty("/vh/Pmenvr", aPmenvr);
            oSharedModel.setProperty("/vh/Pmqual", aPmqual);
            oSharedModel.setProperty("/vh/Pmsafe", aPmsafe);
            oSharedModel.setProperty("/vh/QuotCoR", aQuotCoR);
            oSharedModel.setProperty("/vh/QuotDeR", aQuotDeR);
            oSharedModel.setProperty("/vh/QuotPrR", aQuotPrR);
            oSharedModel.setProperty("/vh/QuotWcR", aQuotWcR);
            oSharedModel.setProperty("/vh/ImpactObl", aImpactObl);
            oSharedModel.setProperty(
              "/vh/headerLines",
              aCatalog.filter((aCat) => {
                return aCat.Code === "";
              })
            );

            // if (_oSettingData.sapUser === undefined && _oSettingData.sapPass === undefined) {
            
            _oSettingData.sapUser = oSharedModel.getProperty(
              "/sapSettings/sapUser"
            );
            _oSettingData.sapPass = oSharedModel.getProperty(
              "/sapSettings/sapPass"
            );
            // }
            oSharedModel.setProperty("/sapSettings", _oSettingData);

            oSharedModel.setProperty("/vh/ActType", aActType);

            MToast.show(this.getText("PermanentDataSuccess"));
            this.getDialogManager().close(
              "fragments.LoginProgress",
              this.getView()
            );
            this.getDialogManager().destroyDialog(
              "fragments.LoginProgress",
              this.getView()
            );
            if (!this.getSharedModel().getProperty("/publicRelease")) {
              $.when(
                this.getOwnerComponent().createParticipant(
                  _oSettingData.sapUser
                )
              )
                .done(
                  jQuery.proxy(function () {
                    this._getParticipantsFromDb();

                    
                    this.getView().setBusy(false); // Login flow has finished
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    if (oError) {
                      if (oError.offline === true) {
                        // MBox.error(this.getText("NoNetwork"));
                        MBox.error(this.getText("NoNetwork"));
                        // this.getView().setBusy(false);
                      } else if (oError.connection === false) {
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                        // this.getView().setBusy(false);
                      }
                    }

                    
                    this.getView().setBusy(false); // Login flow has finished
                  }, this)
                );
            }
          },
          this)
        );
      },

      _getParticipantsFromDb: function () {
        $.when(this.getDBService().getEntitySet("Participant"))
          .done(
            jQuery.proxy(function (oData) {
              var oLocalModel = this.getView().getModel("local"),
                oSharedModel = this.getSharedModel(),
                aLocalParticipantSet = [];

              if (!oLocalModel.getProperty("/ParticipantSet")) {
                oLocalModel.setProperty("/ParticipantSet", []);
              }

              for (var x = 0; x < oData.rows.length; x++) {
                aLocalParticipantSet.push(oData.rows.item(x));
              }

              if (aLocalParticipantSet.length > 0) {
                oSharedModel.setProperty("/hasParticipants", true);
              } else {
                oSharedModel.setProperty("/hasParticipants", false);
              }

              oLocalModel.setProperty("/ParticipantSet", aLocalParticipantSet);
              oSharedModel.setProperty("/ParticipantSet", aLocalParticipantSet);
            }, this)
          )
          .fail(jQuery.proxy(function (oError) {}, this));
      },

      // ----------------------------------- //
      //             Onboarding              //
      // ----------------------------------- //

      onOnboardingLanguageChanged: function (oEvent) {
        var sLangu = oEvent.getParameters().selectedItem.getProperty("key");
        sap.ui.getCore().getConfiguration().setLanguage(sLangu);
        this.getOwnerComponent()._selectDefaultCountryByLangu(sLangu);
        this.onOnboardingCountryChanged();
      },

      onOnboardingCountryChanged: function (oEvent) {
        var sCountry;
        if (oEvent !== undefined) {
          sCountry = oEvent.getParameters().selectedItem.getProperty("key");
        } else {
          sCountry = this.getModel("onboarding").getProperty("/country");
        }
        var oCountryFound = _.find(
          this.getModel("defaults").getProperty("/settings/Country"),
          jQuery.proxy(function (oCountry) {
            return oCountry.Name === sCountry;
          }, this)
        );

        if (oCountryFound) {
          var aSites = oCountryFound.Details.Sites;

          this._sites = oCountryFound.Details.Sites;

          this.getModel("defaults").setProperty("/sites", aSites);

          this.getModel("onboarding").setProperty("/plant", "");
          this.getModel("onboarding").setProperty("/sapSystemId", "");

          this.getModel("onboarding").setProperty("/sapUser", "");
          this.getModel("defaults").setProperty("/devices");

          this.getModel("onboarding").setProperty("/showLoginButton", true);
          this.getModel("onboarding").setProperty("/sapPass", "");
          this.getModel("onboarding").setProperty("/deviceName", "");
          this.getModel("onboarding").setProperty("/SysAuth", "");

          this.getSharedModel().setProperty("/custom", false);
          this.getSharedModel().setProperty("/showSapDetails", false);
          this.getModel("onboarding").setProperty("/host", "");
          this.getModel("onboarding").setProperty("/sapSysId", "");
          this.getModel("onboarding").setProperty("/sapClient", "");
          this.getModel("onboarding").setProperty("/gdlApi", "");
          this.getModel("onboarding").setProperty("/GDL_API_URL", "");
          this.getModel("onboarding").refresh(true);
        }
      },

      onOnboardingPlantChanged: function (oEvent) {
        //var sPlant = oEvent.getParameters().selectedItem.getProperty("key");
        var sPlant;
        if (oEvent !== undefined) {
          sPlant = oEvent.getParameters().selectedItem.getProperty("key");
        } else {
          sPlant = this.getModel("onboarding").getProperty("/plant");
        }

        var oPlantFound = _.find(
          this._sites,
          jQuery.proxy(function (oSite) {
            return oSite.Plant === sPlant;
          }, this)
        );

        if (oPlantFound) {
          var aSystems = oPlantFound.Systems;

          this._systems = oPlantFound.Systems;

          this.getModel("defaults").setProperty("/Systems", aSystems);

          this.getModel("onboarding").setProperty(
            "/sapSystemId",
            aSystems[0].SapSysId
          );
          this.loadPincode(aSystems[0].SapSysId);

          var oSystem = _.find(
            this.getModel("defaults").getProperty("/systems"),
            jQuery.proxy(function (oSystem) {
              return oSystem[aSystems[0].SapSysId];
            }, this)
          );

          var oSystemDetails = oSystem[aSystems[0].SapSysId];

          for (var x in oSystemDetails) {
            this.getModel("onboarding").setProperty("/" + x, oSystemDetails[x]);
          }

          // Disable the custom input possibility -- only disable in case of public release
          if (
            !this.getSharedModel().getProperty("/publicRelease") &&
            aSystems &&
            aSystems.length > 0
          ) {
            var aArray = [];
            //	aArray.push(this.getText("Custom"));
            aArray.push({ SapSysId: "Custom", SysDesc: "Custom" });
            var aSystems2 = _.concat(aArray, aSystems);
            this.getModel("defaults").setProperty("/Systems", aSystems2);
          }

          this.getModel("onboarding").setProperty("/sapUser", "");
          this.getModel("defaults").setProperty("/devices");

          this.getModel("onboarding").setProperty("/showLoginButton", true);
          this.getModel("onboarding").setProperty("/sapPass", "");
          this.getModel("onboarding").setProperty("/deviceName", "");
          this.getModel("onboarding").setProperty("/SysAuth", "");

          this.getSharedModel().setProperty("/custom", false);
          this.getSharedModel().setProperty("/showSapDetails", false);
          // this.getModel("onboarding").setProperty("/host", "");
          // this.getModel("onboarding").setProperty("/sapSysId", "");
          // this.getModel("onboarding").setProperty("/sapClient", "");
          // this.getModel("onboarding").setProperty("/gdlApi", "");
        }
      },

      onOnboardingSystemChanged: function (oEvent) {
        //var sSystem = oEvent.getParameters().selectedItem.getProperty("key");
        var sSystem;
        if (oEvent !== undefined) {
          sSystem = oEvent.getParameters().selectedItem.getProperty("key");
        } else {
          sSystem = this.getModel("onboarding").getProperty("/sapSystemId");
        }

        this.getModel("onboarding").setProperty("/sapUser", "");
        this.getModel("defaults").setProperty("/devices");

        this.getModel("onboarding").setProperty("/showLoginButton", true);
        this.getModel("onboarding").setProperty("/sapPass", "");
        this.loadPincode(sSystem);
        var oSystem = _.find(
          this.getModel("defaults").getProperty("/systems"),
          jQuery.proxy(function (oSystem) {
            return oSystem[sSystem];
          }, this)
        );

        if (oSystem) {
          this.getSharedModel().setProperty("/custom", false);
          this.getSharedModel().setProperty("/showSapDetails", false);

          var oSystemDetails = oSystem[sSystem];

          for (var x in oSystemDetails) {
            this.getModel("onboarding").setProperty("/" + x, oSystemDetails[x]);
          }

          this.getModel("onboarding").setProperty("/sapSysId", sSystem);
        } else {
          this.getSharedModel().setProperty("/custom", true);
          this.getSharedModel().setProperty("/showSapDetails", true);
          this.getModel("onboarding").setProperty("/host", "");
          this.getModel("onboarding").setProperty("/sapSysId", "");
          this.getModel("onboarding").setProperty("/sapClient", "");
          this.getModel("onboarding").setProperty("/gdlApi", "");
          this.getModel("onboarding").setProperty("/GDL_API_URL", "");
        }

        this.getModel("onboarding").setProperty("/sapUser", "");
        this.getModel("defaults").setProperty("/devices");

        this.getModel("onboarding").setProperty("/showLoginButton", true);
        this.getModel("onboarding").setProperty("/sapPass", "");
        this.getModel("onboarding").setProperty("/deviceName", "");
        this.getModel("onboarding").setProperty("/SysAuth", "");
      },

      loadPincode: function (sSystemID) {
        console.debug("Pincode availability check");

        if (crypto.randomUUID === undefined) {
          console.error("Pincode login not available on Windows");
          this.getModel("onboarding").setProperty("/pincodeState", false);
          this.getModel("onboarding").setProperty("/pincodeAvailable", false);
          this.getModel("onboarding").setProperty("/sapOnboardingPass", true);
          return;
        }

        return new Promise(
          jQuery.proxy(async function (resolve, reject) {
            if (
              this.getModel("login").getProperty("/pincodeServerMapping") !==
              undefined
            ) {
              var sPincodeServerDomain = this.getModel("login").getProperty(
                "/pincodeServerMapping"
              ).Mapping[sSystemID];
              this.getModel("login").setProperty(
                "/pincodeServerDomain",
                sPincodeServerDomain
              );
            }
            if (sPincodeServerDomain !== undefined) {
              // Check if pincode login is available

              let bDeviceRegistered =
                await this.loginMethod.checkDeviceRegistration(
                  sPincodeServerDomain
                );

              this.getModel("onboarding").setProperty(
                "/pincodeState",
                bDeviceRegistered
              );
              this.getModel("onboarding").setProperty(
                "/pincodeAvailable",
                bDeviceRegistered
              );
              this.getModel("onboarding").setProperty(
                "/sapOnboardingPass",
                !bDeviceRegistered
              );
              this.getModel("onboarding").setProperty(
                "/showPinCodeInput",
                bDeviceRegistered
              );
              if (this.getModel("onboarding").getProperty("/pincodeState")) {
                this.getModel("onboarding").setProperty("/sapPinCode", "");
                this.getModel("onboarding").setProperty("/sapPass", "");
              }
              // this.getModel('home_login').setProperty('/showPincodeOption', bDeviceRegistered);

              // if (bDeviceRegistered) {
              // 	const sSapPincode = this.getModel("i18n").getResourceBundle().getText("SapPincode")
              // 	this.getModel("home_login").setProperty("/passwordLabel", sSapPincode);
              // } else {
              // 	const sSapPassword = this.getModel("i18n").getResourceBundle().getText("SapPassword")
              // 	this.getModel("home_login").setProperty("/passwordLabel", sSapPassword);
              // }
            } else {
              console.error("Pincode login not available for selected system ID");

              this.getModel("onboarding").setProperty("/pincodeState", false);
              this.getModel("onboarding").setProperty(
                "/pincodeAvailable",
                false
              );
              this.getModel("onboarding").setProperty(
                "/sapOnboardingPass",
                true
              );

              // const sSapPassword = this.getModel("i18n").getResourceBundle().getText("SapPassword")
              // this.getModel('home_login').setProperty('/passwordLabel', sSapPassword);
            }
            resolve();
          }, this)
        );
      },
      onOnboardingUserChange: function (oEvent) {
        var sValue = oEvent.getParameter("newValue"),
          oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = oOnboardingModel.getProperty("/");

        this.getModel("onboarding").setProperty(
          "/sapUser",
          sValue.toUpperCase()
        );

        if (
          oOnboardingModel.getProperty("/sapPass") &&
          oOnboardingModel.getProperty("/sapUser")
        ) {
          $.when(this.getService().logoff()).done(
            jQuery.proxy(function () {
              this.getOwnerComponent()._onUserDataLoaded(oOnboardingSettings);
              var uri = this.getManifestEntry(
                "/sap.app/dataSources/configserver"
              ).uri;
              var oShared = this.getModel("shared"),
                oSettings = oShared.getProperty("/sapSettings");
              $.when(this.getService().createConfigurationModel(uri, oSettings))
                .done(
                  jQuery.proxy(function () {
                    $.when(
                      this.getService().getUnassignedDevices(
                        oOnboardingModel.getProperty("/plant")
                      )
                    ).done(
                      jQuery.proxy(function (oResult) {
                        var sortDeviceIds = _.sortBy(
                          oResult.results,
                          "DeviceId"
                        );
                        this.getModel("defaults").setProperty(
                          "/devices",
                          sortDeviceIds
                        );
                        if (oResult.results.length === 0) {
                          MBox.error(this.getText("NoUnassignedDevice"));
                        }
                      }, this)
                    );
                  }, this)
                )
                .fail(
                  jQuery.proxy(function (oError) {
                    this.getModel("defaults").setProperty("/devices", null);
                    if (oError.getParameters().statusCode === 401) {
                      MBox.error(
                        this.getText(
                          "UserNotAuthorized",
                          oOnboardingModel.getProperty("/sapSysId")
                        )
                      );
                    } else if (oError.getParameters().statusCode === 0) {
                      MBox.error(this.getText("SAPSettingsIncorrect"));
                    } else {
                      MBox.error(
                        this.getText("ConnectionUnknown") +
                          "\n" +
                          this.getText("NoConnectionToSap")
                      );
                    }
                  }, this)
                );
            }, this)
          );
        }
      },

      _addOnboardingDefaultProperties: function () {
        var oOnboardingModel = this.getModel("onboarding");

        oOnboardingModel.setProperty("/rfidMand", false);
        // oOnboardingModel.setProperty("/enableLogin", false); // replaced by policy
        oOnboardingModel.setProperty("/enableOrderConfCreation", false);
        oOnboardingModel.setProperty("/enableDownloadBoms", false);
        oOnboardingModel.setProperty("/persNoNotRequired", true);
        oOnboardingModel.setProperty("/Notifstatus_tbp", true);
        oOnboardingModel.setProperty("/ZoneBadging", true);
        oOnboardingModel.setProperty("/Connected", true);
        oOnboardingModel.setProperty("/TrCheckError", true);
        oOnboardingModel.setProperty("/POActive", true);
        oOnboardingModel.setProperty("/notifFields", {
          Text: true,
          Craft: true,
          Fecod: true,
          Fetxt: true,
          Urcod: true,
          Urtxt: true,
          Mfcod: true,
          Mftxt: true,
          Mncod: true,
          Matxt: true,
          Msaus: true,
          AusvnDatetime: true,
          AusbsDatetime: true,
          Ingrp: true,
          Qmnam: true,
        });
        oOnboardingModel.setProperty("/MAND_DAMAG", false);
        oOnboardingModel.setProperty("/MAND_CAUSE", false);
        oOnboardingModel.setProperty("/MAND_ACTIV", false);
        oOnboardingModel.setProperty("/CONF_M_DMG", false);
        oOnboardingModel.setProperty("/CONF_M_CSE", false);
        oOnboardingModel.setProperty("/CONF_M_BRD", false);
        oOnboardingModel.setProperty(
          "/SWERK",
          oOnboardingModel.getProperty("/SWERK")
            ? oOnboardingModel.getProperty("/SWERK")
            : ""
        );
        oOnboardingModel.setProperty(
          "/IWERK",
          oOnboardingModel.getProperty("/IWERK")
            ? oOnboardingModel.getProperty("/IWERK")
            : ""
        );
        oOnboardingModel.setProperty(
          "/INGRP",
          oOnboardingModel.getProperty("/INGRP")
            ? oOnboardingModel.getProperty("/INGRP")
            : ""
        );
        oOnboardingModel.setProperty(
          "/ARBPL",
          oOnboardingModel.getProperty("/ARBPL")
            ? oOnboardingModel.getProperty("/ARBPL")
            : ""
        );
        oOnboardingModel.setProperty(
          "/ISTWERK",
          oOnboardingModel.getProperty("/ISTWERK")
            ? oOnboardingModel.getProperty("/ISTWERK")
            : ""
        );
        oOnboardingModel.setProperty(
          "/GEWRK",
          oOnboardingModel.getProperty("/GEWRK")
            ? oOnboardingModel.getProperty("/GEWRK")
            : ""
        );
        oOnboardingModel.setProperty(
          "/REP_BY_WC",
          oOnboardingModel.getProperty("/REP_BY_WC")
            ? oOnboardingModel.getProperty("/REP_BY_WC")
            : ""
        );
        oOnboardingModel.setProperty("/PERNR", "");
      },

      onProcessOnboarding: async function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = this.getModel("onboarding").getProperty("/");
        let oDialog;
        // if (oEvent !== undefined) {
        // 	oDialog = oEvent.getSource().getParent();
        // }

        // Do NOT STORE Logon credentials

        this._handleBusyIndicator("SHOW");

        var oPromDelSettings = this.getDBService().deleteAllObjects("Setting"),
          oSharedModel = this.getView().getModel("shared"),
          sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
          sUrl = oOnboardingSettings.host + sUri,
          notifFields = {};

        this._addOnboardingDefaultProperties();

        
        for (var x in this._aDeviceSettings) {
          if (
            this._aDeviceSettings[x].Fieldname.indexOf("notifFields") !== -1
          ) {
            var aNotifField = this._aDeviceSettings[x].Fieldname.split("_");
            var sNotifField = aNotifField[1];
            notifFields[sNotifField] =
              this._aDeviceSettings[x].Type === "BOOL"
                ? this._aDeviceSettings[x].ValueBool
                : this._aDeviceSettings[x].ValueString;
          } else {
            this.getModel("onboarding").setProperty(
              "/" + this._aDeviceSettings[x].Fieldname,
              this._aDeviceSettings[x].Type === "BOOL"
                ? this._aDeviceSettings[x].ValueBool
                : this._aDeviceSettings[x].ValueString
            );
          }
        }
        this.getModel("onboarding").setProperty("/notifFields", notifFields);

        var oData = this.getModel("onboarding").getProperty("/");

        // delete oData.sapSystemId;

        // this.getModel("onboarding").setProperty("/", oData);

        this.getModel("onboarding").setProperty(
          "/langu",
          this.getModel("onboarding").getProperty("/langu").toUpperCase()
        );
        var sAppVersion =
          this.getOwnerComponent().getManifestObject()._oManifest._version;
        
        $.when(
          this.getService().assignDevice(
            oOnboardingModel.getProperty("/deviceName"),
            oOnboardingModel.getProperty("/plant")
          ),
          this.getService().getValueHelpSet(),
          this.getService().setVersion(
            oOnboardingModel.getProperty("/deviceName"),
            oOnboardingModel.getProperty("/plant"),
            sAppVersion
          )
        )
          .done(
            jQuery.proxy(function (oResult, oValueHelp) {
              if (oResult.setAssign.Type === "E") {
                MBox.error(oResult.setAssign.Message);
                this._handleBusyIndicator("HIDE");
                // oDialog.setBusy(false);
              } else {
                $.when(
                  this.getDBService().deleteAllObjects("ValueHelpSet")
                ).done(
                  jQuery.proxy(function () {
                    this.getDBService().initValueHelpSet(oValueHelp);
                  }, this)
                );
                $.when(
                  this.getDBService().saveSAPSettings(oOnboardingSettings)
                ).done(
                  jQuery.proxy(function () {
                    // if (this.getHelper().isDevModeActive() || !this.getService()) {
                    // MBox.success(this.getText("QSettingSuccess"), {
                    // onClose: async function () {

                    // if ( jQuery.isEmptyObject(oSharedModel.getProperty('/sapSettings')) )
                    if (
                      JSON.stringify(
                        oSharedModel.getProperty("/sapSettings")
                      ) !== JSON.stringify(oOnboardingSettings)
                    ) {
                      
                    }

                    oSharedModel.setProperty(
                      "/sapSettings",
                      oOnboardingSettings
                    );

                    let oOnboardingModel =
                      this.getView().getModel("onboarding");
                    //if(this.getSharedModel().getProperty("/publicRelease"))
                    this.createParticipants(
                      oOnboardingModel.getProperty("/sapUser")
                    );
                    // Save user name  > this.getModel("onboarding").getProperty("/langu") > oData
                    // oSharedModel.setProperty("/sapSettings/sapUser", this._deepCopy(oOnboardingModel.getProperty('/sapUser')));
                    //
                    
                    oSharedModel.setProperty(
                      "/sapSettings/sapPass",
                      oOnboardingModel.getProperty("/sapPass")
                    );
                    oSharedModel.setProperty(
                      "/sapSettings/sapUser",
                      oOnboardingModel.getProperty("/sapUser")
                    );
                    // oSharedModel.setProperty("/sapSettings/sapBearer", oOnboardingModel.getProperty('/sapBearer')) ;
                    if (
                      this.getOwnerComponent()
                        .getModel("i18n")
                        .getResourceBundle().sLocale !== "fr"
                    ) {
                      oSharedModel.setProperty(
                        "/loggedInAsMsg",
                        this.getText("LoggedInAs", [
                          oOnboardingModel.getProperty("/sapUser"),
                        ])
                      );
                    } else {
                      oSharedModel.setProperty(
                        "/loggedInAsMsg",
                        oOnboardingModel.getProperty("/sapUser")
                      );
                    }
                    oSharedModel.setProperty("/bUserIconVisible", true);

                    
                    this.getOwnerComponent()._start_procedure_functional_user(
                      this.getView()
                    );
                    this._onCloseOnboardingFragment();
                  }, this)
                );
                if (this.getSharedModel().getProperty("/publicRelease")) {
                  $.when(this.getService().getPlanItemService())
                    .done(
                      function (oData) {
                        this.getDBService()._savePlanItemSetSettings(oData);
                        this.getDBService()._createTable([oData]);
                      }.bind(this)
                    )
                    .fail(function (oError) {}.bind(this));
                }

                this._handleBusyIndicator("HIDE");
              }
            }, this)
          )
          .fail(
            function () {
              this._handleBusyIndicator("HIDE");
            }.bind(this)
          );
      },

      _deepCopy: function (sValue) {
        return JSON.parse(JSON.stringify(sValue));
      },

      _clearLogin: function () {
        let oLoginModel = this.getModel("login");
        oLoginModel.setProperty("/sapUser", "");
        oLoginModel.setProperty("/sapPass", "");
        // oLoginModel.setProperty("/sapBearer", "");
        oLoginModel.setProperty("/showLoginButton", true);
      },

      _clearOnboarding: function () {
        this.getModel("onboarding").setProperty("/showLoginButton", true);
        this.getModel("onboarding").setProperty("/country", "");
        this.getModel("onboarding").setProperty("/plant", "");
        this.getModel("onboarding").setProperty("/sapSysId", "");

        this.getModel("onboarding").setProperty("/sapUser", "");
        this.getModel("defaults").setProperty("/devices");

        this.getModel("onboarding").setProperty("/sapPass", "");
        // this.getModel("onboarding").setProperty("/sapBearer", "");
        this.getModel("onboarding").setProperty("/deviceName", "");
        this.getModel("onboarding").setProperty("/SysAuth", "");
        this.getModel("onboarding").setProperty("/host", null);
        this.getModel("onboarding").setProperty("/sapSysId", null);
        this.getModel("onboarding").setProperty("/sapClient", null);
        this.getModel("onboarding").setProperty("/gdlApi", null);
        this.getModel("onboarding").setProperty("/GDL_API_URL", null);
        this.getSharedModel().setProperty("/showSapDetails", false);

        if (navigator) {
          var aLangu = navigator.language.split("-");
          this.getModel("onboarding").setProperty("/langu", aLangu[0]);
          this.getOwnerComponent()._selectDefaultCountryByLangu(aLangu[0]);
          sap.ui.getCore().getConfiguration().setLanguage(aLangu[0]);
          this.onOnboardingCountryChanged();
        }
      },

      _onCloseOnboardingFragment: function () {
        // this._clearOnboarding(); >> data is cleared when creating the fragment again

        let sFragment = "";
        
        if (this.getSharedModel().getProperty("/publicRelease")) {
          sFragment = "fragments.PublicOnboarding";
        } else {
          sFragment = "fragments.Onboarding";
        }
        // this.getDialogManager().close(sFragment, this.getView());
        this.getDialogManager().destroyDialog(sFragment, this.getView());
      },

      onSystemSettingsChange: function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding");

        if (
          oOnboardingModel.getProperty("/host") !== "" &&
          oOnboardingModel.getProperty("/sapSysId") !== "" &&
          oOnboardingModel.getProperty("/sapClient") !== "" &&
          oOnboardingModel.getProperty("/gdlApi") !== ""
        ) {
          this.getSharedModel().setProperty("/showSapDetails", false);
        } else {
          this.getSharedModel().setProperty("/showSapDetails", true);
        }
      },

      onShowSapSettingDetails: function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding");

        if (
          oOnboardingModel.getProperty("/host") !== "" &&
          oOnboardingModel.getProperty("/sapSysId") !== "" &&
          oOnboardingModel.getProperty("/sapClient") !== "" &&
          oOnboardingModel.getProperty("/gdlApi") !== ""
        ) {
          if (this.getSharedModel().getProperty("/showSapDetails") === true) {
            this.getSharedModel().setProperty("/showSapDetails", false);
          } else {
            this.getSharedModel().setProperty("/showSapDetails", true);
          }
        }
      },

      onDeviceNameChange: function (oEvent) {
        // var oOnboardingModel = this.getModel("onboarding"),
        // 	deviceName = oEvent.getParameters().selectedItem.getProperty("key"),
        // 	sValue = deviceName.replace(/%/g, "%25");
        // if (sValue) {
        // 	oOnboardingModel.setProperty("/deviceName", deviceName.toUpperCase());
        // 	oOnboardingModel.setProperty("/SysAuth", false); // make connect button disable.

        let deviceName = oEvent.getParameters().selectedItem.getProperty("key"),
          oOnboardingModel = this.getModel("onboarding");

        let sValue = deviceName.replace(/%/g, "%25");

        if (sValue) {
          oOnboardingModel.setProperty("/deviceName", deviceName.toUpperCase());

          let oDialog = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getParent()
            .getParent();
          oDialog.setBusy(true);

          $.when(
            this.getService().getDeviceSettings(
              sValue.toUpperCase(),
              oOnboardingModel.getProperty("/plant")
            )
          ).done(
            jQuery.proxy(function (oResult) {
              
              this._aDeviceSettings = oResult.navDeviceSettings.results;
              oOnboardingModel.setProperty("/SysAuth", false); // make connect button disable.
              oDialog.setBusy(false);
            }, this)
          );
        }
      },

      _handleBusyIndicator: function (sAction) {
        if (sAction === "SHOW") {
          //BusyIndicator.show();
          this.busyDialog.open();
        } else if (sAction === "HIDE") {
          this.busyDialog.close();
          //BusyIndicator.hide();
        }
      },

      onOnboardingPasswordChanged: async function (oEvent, agree, tap) {
        let oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = oOnboardingModel.getProperty("/"),
          oSharedModel = this.getView().getModel("shared"),
          sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
          sUrl = oOnboardingSettings.host + sUri;

        let oDialog;

        this.getModel("login").setProperty("/show-connection-ok", false);
        this.getModel("login").setProperty("/show-connection-nok", false);
        this.getModel("login").setProperty("/show-authorization-text", false);
        this.getModel("login").setProperty("/show-authorization-ok", false);
        this.getModel("login").setProperty("/show-authorization-nok", false);
        this.getModel("login").setProperty("/show-data-text", false);
        this.getModel("login").setProperty("/show-data-ok", false);
        this.getModel("login").setProperty("/show-data-nok", false);
        this.getModel("login").setProperty("/show-cancel-LoginProgress", false);
        this.getModel("login").setProperty("/show-retry-LoginProgress", false);

        if (oEvent !== undefined) {
          var oEventCopy = {};
          oEventCopy.oSource = oEvent.getSource();
          oEventCopy.getSource = oEvent.getSource;
        }
        const bPincodeActive =
          this.getModel("onboarding").getProperty("/pincodeState");
        if (oEvent !== undefined) {
          oDialog = oEvent
            .getSource()
            .getParent()
            .getParent()
            .getParent()
            .getParent(); // -> onboarding login
          // oDialog = oEvent.getSource().getParent();
        }

        if (!this.getSharedModel().getProperty("/publicRelease")) {
          // if (!tap)
          // this._handleBusyIndicator( "SHOW");
          if (!tap) {
            this.getDialogManager().openWithModel(
              "fragments.LoginProgress",
              this.getView(),
              this.getView().getModel("login")
            );
          }

          if (!this.getHelper().isOnline()) {
            MBox.error(this.getText("ConnectionUnknown"));
            return;
          }
          if (oEvent !== undefined) {
            const sPincodeServerDomain = this.getModel("login").getProperty(
              "/pincodeServerDomain"
            );
            let bDeviceRegistered =
              await this.loginMethod.checkDeviceRegistration(
                sPincodeServerDomain
              );

            if (
              !bDeviceRegistered &&
              sPincodeServerDomain !== undefined &&
              !bPincodeActive
            ) {
              const sPass = oOnboardingSettings.sapPass;
              const sPinCode = oOnboardingSettings.sapPinCode;

              try {
                // 2. execute registration
                // Will RESET the password
                await this.loginMethod.onRegisterDevicePress(this);
              } catch (oError) {
                if (oError.message === "SAP_LOGIN_TEST_FAILED_401") {
                  // Clear password to disable sending logs with the wrong password again
                  this.getModel("onboarding").setProperty("/sapPass", "");
                  this.getModel("onboarding").setProperty("/sapPinCode", "");
                  // console.log(oError);
                  // this._handleBusyIndicator("HIDE");
                  throw oError;
                }

                console.error(oError);
                // Continue execution of onboarding > failing pincode may not stop the onboarding process !
              }
              // this.getModel('home_login').setProperty('/pincodeAvailable', false);
              this.getModel("onboarding").setProperty(
                "/pincodeAvailable",
                bDeviceRegistered
              );
              this.getModel("onboarding").setProperty(
                "/pincodeState",
                bDeviceRegistered
              );
              this.getModel("onboarding").setProperty(
                "/sapOnboardingPass",
                !bDeviceRegistered
              );

              // Don't show the pincode login option when user has just logged on using SAP password
              this.getModel("onboarding").setProperty(
                "/showPincodeOption",
                false
              );

              // SET the password again since it is reset during the onRegisterDevicePress method
              this.getOwnerComponent()
                .getModel("onboarding")
                .setProperty("/sapPinCode", sPinCode);
              this.getOwnerComponent()
                .getModel("onboarding")
                .setProperty("/sapPass", sPass);
              // this.getModel("onboarding").setProperty('/sapPinCode','')
            }
            if (bPincodeActive) {
              try {
                await this.loginMethod.onPincodeLoginPress(this, oEventCopy);
              } catch (oError) {
                this.getModel("login").setProperty(
                  "/show-cancel-LoginProgress",
                  true
                );
                this.getModel("login").setProperty(
                  "/show-connection-nok",
                  true
                );
                console.error(oError);
                // Pincode logon has failed
                console.error("Pincode login failed");
                // this._handleBusyIndicator("HIDE");
                // this.getDialogManager().close("fragments.LoginProgress", this.getView());
                // this.getDialogManager().destroyDialog("fragments.LoginProgress", this.getView());
                return;
              }
            }
          }
        }

        if (
          oOnboardingModel.getProperty("/sapPass") &&
          oOnboardingModel.getProperty("/sapUser")
        ) {
          this.getView().setBusy(true);
          //this.getOwnerComponent()._onUserDataLoaded(oOnboardingSettings);
          try {
            await this.getOwnerComponent()._onUserDataLoaded(
              oOnboardingSettings
            );
            this.getModel("login").setProperty("/show-connection-ok", true);
            this.getModel("login").setProperty(
              "/show-authorization-text",
              true
            );
          } catch (oError) {
            oOnboardingModel.setProperty("/deviceName", null);
            oOnboardingModel.setProperty("/SysAuth", true);
            this.getModel("defaults").setProperty("/devices", null);
            if (
              oError.getParameters() &&
              oError.getParameters().statusCode === 401
            ) {
              MBox.error(
                this.getText(
                  "UserNotAuthorized",
                  oOnboardingModel.getProperty("/sapSysId")
                )
              );
            } else if (
              oError.getParameters() &&
              oError.getParameters().statusCode === 0
            ) {
              MBox.error(this.getText("SAPSettingsIncorrect"));
            } else {
              MBox.error(
                this.getText("ConnectionUnknown") +
                  "\n" +
                  this.getText("NoConnectionToSap")
              );
            }

            // this._handleBusyIndicator("HIDE");
            this.getModel("login").setProperty(
              "/show-cancel-LoginProgress",
              true
            );
            this.getModel("login").setProperty("/show-connection-nok", true);
            this.getDialogManager().close(
              "fragments.LoginProgress",
              this.getView()
            );
            this.getDialogManager().destroyDialog(
              "fragments.LoginProgress",
              this.getView()
            );
          }

          // if(!oError){
          var uri = this.getManifestEntry(
            "/sap.app/dataSources/configserver"
          ).uri;
          var oShared = this.getModel("shared"),
            oSettings = oShared.getProperty("/sapSettings");

          if (this.getSharedModel().getProperty("/publicRelease") && agree) {
            this._handleBusyIndicator("SHOW");
            let agreement = await this.selectAgreementwithCheck(
              true,
              oOnboardingSettings.sapUser
            );
            if (!agreement) {
              this._handleBusyIndicator("HIDE");
              MBox.error(this.getText("ConnectionUnknown"));
            } else if (agreement === "F") {
              agreement = await this.selectAgreement();
              this._handleBusyIndicator("HIDE");
              if (!agreement) {
                this.getView().setBusy(false);
                oOnboardingModel.setProperty("/sapUser", "");
                oOnboardingModel.setProperty("/sapPass", "");
                oOnboardingModel.setProperty("/SysAuth", false);
                oOnboardingModel.setProperty("/showLoginButton", true);
                return;
              }
            } else {
              this._handleBusyIndicator("HIDE");
            }
          }

          this._checkDevMode()
            .then(
              function () {
                this.getModel("login").setProperty(
                  "/show-authorization-ok",
                  true
                );
                this.getModel("login").setProperty("/show-data-text", true);
                $.when(
                  this.getService().createConfigurationModel(
                    uri,
                    oSettings,
                    this,
                    true
                  )
                )
                  .done(
                    jQuery.proxy(function () {
                      $.when(
                        this.getService().getUnassignedDevices(
                          oOnboardingModel.getProperty("/plant")
                        )
                      ).done(
                        jQuery.proxy(function (oResult) {
                          var sortDeviceIds = _.sortBy(
                            oResult.results,
                            "DeviceId"
                          );
                          this.getModel("defaults").setSizeLimit(2000);
                          this.getModel("defaults").setProperty(
                            "/devices",
                            sortDeviceIds
                          );
                          this.getView().setBusy(false);
                          this._handleBusyIndicator("HIDE");
                          this.getDialogManager().close(
                            "fragments.LoginProgress",
                            this.getView()
                          );
                          this.getDialogManager().destroyDialog(
                            "fragments.LoginProgress",
                            this.getView()
                          );
                          if (oResult.results.length === 0) {
                            MBox.error(this.getText("NoUnassignedDevice"));
                          }
                          var foundDeviceId = _.find(
                            oResult.results,
                            jQuery.proxy(function (device) {
                              return device.DeviceId === this.scanDeviceId;
                            }, this)
                          );
                          if (foundDeviceId) {
                            this.getModel("onboarding").setProperty(
                              "/deviceName",
                              this.scanDeviceId
                            );
                          } else {
                            if (this.scanDeviceId) {
                              MBox.error(
                                this.getText("UnassignedDevicesWhileScanning", [
                                  this.scanDeviceId,
                                ])
                              );
                            }
                          }
                          this.scanDeviceId = null;
                          var oSelect = sap.ui.getCore().byId("deviceId");
                          var oCurrentInd = this;
                          sap.ui
                            .getCore()
                            .byId("deviceId")
                            .getSimpleFixFlex()
                            .getFlexContent()[0]
                            .setBusy(false);
                          //Maybe for updating the list
                          oSelect.ontap = function (oEvent) {
                            if (!oSelect.isOpen()) {
                              sap.ui
                                .getCore()
                                .byId("deviceId")
                                .getSimpleFixFlex()
                                .getFlexContent()[0]
                                .setBusy(true);
                              oCurrentInd.onOnboardingPasswordChanged(
                                undefined,
                                null,
                                true
                              );
                            }
                            sap.m.Select.prototype.ontap.apply(this, arguments);
                          };
                        }, this)
                      );
                      // if (foundDeviceId) {
                      // 	this.getModel("onboarding").setProperty("/deviceName", this.scanDeviceId);
                      // }
                    }, this)
                  )
                  .fail(
                    jQuery.proxy(function (oError) {
                      console.error(oError);
                      oOnboardingModel.setProperty("/deviceName", null);
                      oOnboardingModel.setProperty("/SysAuth", true);
                      this.getModel("defaults").setProperty("/devices", null);
                      if (oError.getParameters().statusCode === 401) {
                        //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                        MBox.error(
                          this.getText(
                            "UserNotAuthorized",
                            oOnboardingModel.getProperty("/sapSysId")
                          )
                        );
                      } else if (oError.getParameters().statusCode === 0) {
                        //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                        MToast.show(this.getText("NoSAPSystemConnection"));
                      } else {
                        //this.getSharedModel().setProperty("/connectionErrorCode", "");
                        MBox.error(
                          this.getText("ConnectionUnknown") +
                            "\n" +
                            this.getText("NoConnectionToSap")
                        );
                      }
                      this.getDialogManager().close(
                        "fragments.LoginProgress",
                        this.getView()
                      );
                      this.getDialogManager().destroyDialog(
                        "fragments.LoginProgress",
                        this.getView()
                      );
                      this._handleBusyIndicator("HIDE");
                    }, this)
                  );
              }.bind(this)
            )
            .catch(
              function (oError) {
                this.getModel("login").setProperty(
                  "/show-cancel-LoginProgress",
                  true
                );
                this.getModel("login").setProperty(
                  "/show-authorization-nok",
                  true
                );
                oOnboardingModel.setProperty("/deviceName", null);
                oOnboardingModel.setProperty("/SysAuth", true);
                this.getModel("defaults").setProperty("/devices", null);

                let oParameters;
                try {
                  oParameters = oError.getParameters();
                } catch (oError) {
                  oParameters = undefined;
                }

                if (
                  oParameters !== undefined &&
                  oParameters.statusCode === 401
                ) {
                  //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                  MBox.error(
                    this.getText(
                      "UserNotAuthorized",
                      oOnboardingModel.getProperty("/sapSysId")
                    )
                  );
                } else if (
                  oParameters !== undefined &&
                  oParameters.statusCode === 0
                ) {
                  //this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
                  MBox.error(this.getText("SAPSettingsIncorrect"));
                } else {
                  //this.getSharedModel().setProperty("/connectionErrorCode", "");
                  console.error(oError);
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                }

                this._handleBusyIndicator("HIDE");
                this.getDialogManager().close(
                  "fragments.LoginProgress",
                  this.getView()
                );
                this.getDialogManager().destroyDialog(
                  "fragments.LoginProgress",
                  this.getView()
                );
              }.bind(this)
            );
          // }else{
          // oOnboardingModel.setProperty("/deviceName", null);
          // oOnboardingModel.setProperty("/SysAuth", true);
          // this.getModel("defaults").setProperty("/devices", null);
          // if (oError.getParameters()&&oError.getParameters().statusCode === 401) {
          // 	MBox.error(this.getText("UserNotAuthorized", oOnboardingModel.getProperty("/sapSysId")));
          // } else if (oError.getParameters()&&oError.getParameters().statusCode === 0) {
          // 	MBox.error(this.getText("SAPSettingsIncorrect"));
          // } else {
          // 	MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
          // 			}, this));
          // 	} else {
          // 		$.when(this.getService().createConfigurationModel(uri, oSettings)).done(jQuery.proxy(function () {
          // 			$.when(this.getService().getUnassignedDevices(oOnboardingModel.getProperty("/plant"))).done(jQuery.proxy(function (
          // 				oResult) {
          // 				var sortDeviceIds = _.sortBy(oResult.results, "DeviceId");
          // 				this.getModel("defaults").setProperty("/devices", sortDeviceIds);
          // 				this.getView().setBusy(false);
          // 				if (oResult.results.length === 0) {
          // 					MBox.error(this.getText("NoUnassignedDevice"));
          // 				}
          // 				var foundDeviceId = _.find(oResult.results, jQuery.proxy(function (device) {
          // 					return device.DeviceId === this.scanDeviceId;
          // 				}, this));
          // 				if (foundDeviceId) {
          // 					this.getModel("onboarding").setProperty("/deviceName", this.scanDeviceId);
          // 				} else {
          // 					if (this.scanDeviceId && oResult.results.length !== 0) {
          // 						MBox.error(this.getText("UnassignedDevicesWhileScanning", [this.scanDeviceId]));
          // 					}
          // 				}
          // 				this.scanDeviceId = null;
          // 				var oSelect = sap.ui.getCore().byId("deviceId");
          // 				var oCurrentInd = this;
          // 				oSelect.ontap = function (oEvent) {
          // 					if (!oSelect.isOpen()) {
          // 						oCurrentInd.onOnboardingPasswordChanged();
          // 					}
          // 					sap.m.Select.prototype.ontap.apply(this, arguments);
          // 				};
          // 			}, this));
          // 		}, this)).fail(jQuery.proxy(function (oError) {
          // 			oOnboardingModel.setProperty("/deviceName", null);
          // 			oOnboardingModel.setProperty("/SysAuth", true);
          // 			this.getModel("defaults").setProperty("/devices", null);
          // 			if (oError.getParameters().statusCode === 401) {
          // 				//this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
          // 				MBox.error(this.getText("UserNotAuthorized", oOnboardingModel.getProperty("/sapSysId")));
          // 			} else if (oError.getParameters().statusCode === 0) {
          // 				//this.getSharedModel().setProperty("/connectionErrorCode", oError.getParameters().statusCode);
          // 				MBox.error(this.getText("SAPSettingsIncorrect"));
          // 			} else {
          // 				//this.getSharedModel().setProperty("/connectionErrorCode", "");
          // 				MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
          // 			}
          // 		}, this));
          // 	}
          // }, this)).fail(jQuery.proxy(function (oError) {
          // 	oOnboardingModel.setProperty("/deviceName", null);
          // 	oOnboardingModel.setProperty("/SysAuth", true);
          // 	this.getModel("defaults").setProperty("/devices", null);
          // 	if (oError.getParameters().statusCode === 401) {
          // 		MBox.error(this.getText("UserNotAuthorized", oOnboardingModel.getProperty("/sapSysId")));
          // 	} else if (oError.getParameters().statusCode === 0) {
          // 		MBox.error(this.getText("SAPSettingsIncorrect"));
          // 	} else {
          // 		MBox.error(this.getText("ConnectionUnknown") + "\n" + this.getText("NoConnectionToSap"));
          // 	}
          // }, this));
          // }

          // this._handleBusyIndicator("HIDE");

          // }
          // .catch(function (oError) {
          // 	//
          // 	console.log(oError);

          // 	this._handleBusyIndicator(oDialog, "HIDE");

          // });
        }
      },

      _checkDevMode: async function () {
        if (!this.getHelper().isDevModeActive()) {
          await this.getService().logoff();
        }
      },

      onSysAuthPwdLiveChange: function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = oOnboardingModel.getProperty("/");
        oOnboardingModel.setProperty("/SysAuth", false);
        if (oOnboardingSettings.sapUser && oEvent.getParameters().value) {
          oOnboardingModel.setProperty("/deviceName", null);
          oOnboardingModel.setProperty("/SysAuth", true);
          oOnboardingModel.setProperty(
            "/sapPass",
            oEvent.getParameters().value
          );
        }
      },

      onSysAuthPincodeLiveChange: function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = oOnboardingModel.getProperty("/");
        oOnboardingModel.setProperty("/SysAuth", false);
        if (oOnboardingSettings.sapUser && oEvent.getParameters().value) {
          oOnboardingModel.setProperty("/deviceName", null);
          oOnboardingModel.setProperty("/SysAuth", true);
          oOnboardingModel.setProperty(
            "/sapPinCode",
            oEvent.getParameters().value
          );
        }
      },

      onOnBoardingPincodeChange: function () {
        if (this.getModel("onboarding").getProperty("/pincodeState") === true) {
          this.getModel("onboarding").setProperty("/pincodeState", true);
          this.getModel("onboarding").setProperty("/pincodeAvailable", true);
          this.getModel("onboarding").setProperty("/sapOnboardingPass", !true);
          this.getModel("onboarding").setProperty("/showPinCodeInput", true);
        } else {
          this.getModel("onboarding").setProperty("/pincodeState", false);
          this.getModel("onboarding").setProperty("/pincodeAvailable", true);
          this.getModel("onboarding").setProperty("/sapOnboardingPass", !false);
          this.getModel("onboarding").setProperty("/showPinCodeInput", false);
        }
        this.getModel("onboarding").setProperty("/sapPass", "");
        this.getModel("onboarding").setProperty("/sapPinCode", "");
      },
      // _processToken: async function (sToken) {

      // 	let sUserName;

      // 	try {

      // 		let sHost = "";
      // 		if (!this.getHelper().isDevModeActive())
      // 			sHost = this.getView().getModel('shared').getProperty('/sapSettings/host');

      // 		sUserName = await this.getOwnerComponent().tokenService.checkTokenAtLogin(sToken, sHost ).catch(function (oError) {
      // 			throw oError;
      // 		});
      // 		MToast.show(this.getText("ValidToken"));
      // 	} catch (oError) {
      // 		MToast.show(oError.message);
      // 		return;
      // 	}

      // 	// let base64Url = sToken.split('.')[1];
      // 	// let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      // 	// let jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function (c) {
      // 	// 	return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      // 	// }).join(''));

      // 	// let oToken = JSON.parse(jsonPayload);
      // 	// if (oToken.user_name === undefined)
      // 	// 	return;

      // 	var oOnboardingModel = this.getModel("onboarding");
      // 	oOnboardingModel.setProperty("/deviceName", null);
      // 	oOnboardingModel.setProperty("/SysAuth", true);
      // 	oOnboardingModel.setProperty("/sapBearer", sToken);
      // 	oOnboardingModel.setProperty("/sapPass", sToken);
      // 	oOnboardingModel.setProperty("/sapUser", sUserName);

      // },

      onSysAuthBearerLiveChange: function (oEvent) {
        // var oOnboardingModel = this.getModel("onboarding");
        // // oOnboardingSettings = oOnboardingModel.getProperty("/");
        // oOnboardingModel.setProperty("/SysAuth", false);
        // let sToken = oEvent.getParameters().value;
        // if (sToken) {
        // 	this._processToken(sToken);
        // }
      },

      onSysAuthUsrLiveChange: function (oEvent) {
        var oOnboardingModel = this.getModel("onboarding"),
          oOnboardingSettings = oOnboardingModel.getProperty("/");
        oOnboardingModel.setProperty("/SysAuth", false);
        if (oOnboardingSettings.sapPass && oEvent.getParameters().value) {
          oOnboardingModel.setProperty("/deviceName", null);
          oOnboardingModel.setProperty("/SysAuth", true);
        }
      },

      onScanConfigSettings: function (oEvent) {
        $.when(this.getScanHandler().scan())
          .done(
            jQuery.proxy(function (oData) {
              alert("Scan functionality not allowed in public release");
              return;

              if (!oData.cancelled && oData.text !== null) {
                this.onCFGDetails(JSON.parse(oData.text));
              }
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              MBox.error(this.getText("ScanIssue"));
            }, this)
          );
      },

      onCFGDetails: function (oConfSettings) {
        var oPlantFound, oSystemFound;
        this.scanDeviceId = null;
        var oCompanyFound = _.find(
          this.getModel("defaults").getProperty("/settings/Country"),
          jQuery.proxy(function (oCountry) {
            return oCountry.Code === oConfSettings.company;
          }, this)
        );
        if (oCompanyFound) {
          this.getModel("onboarding").setProperty(
            "/country",
            oCompanyFound.Name
          );
          this.onOnboardingCountryChanged();
          oPlantFound = _.find(
            oCompanyFound.Details.Sites,
            jQuery.proxy(function (oPlant) {
              return oPlant.Plant === oConfSettings.plant;
            }, this)
          );
        } else if (oConfSettings.plant) {
          var i = -1,
            indexCompany = -1;
          this.getModel("defaults")
            .getProperty("/settings/Country")
            .filter(function (company) {
              i += 1;
              company.Details.Sites.filter(function (sites) {
                if (sites.Plant === oConfSettings.plant) {
                  indexCompany = i;
                }
              });
            });
          if (indexCompany !== -1) {
            oCompanyFound =
              this.getModel("defaults").getProperty("/settings/Country")[
                indexCompany
              ];
            this.getModel("onboarding").setProperty(
              "/country",
              oCompanyFound.Name
            );
            this.onOnboardingCountryChanged();
            oPlantFound = _.find(
              oCompanyFound.Details.Sites,
              jQuery.proxy(function (oPlant) {
                return oPlant.Plant === oConfSettings.plant;
              }, this)
            );
          }
        }
        if (oCompanyFound && oPlantFound) {
          this.getModel("onboarding").setProperty(
            "/plant",
            oConfSettings.plant
          );
          this.onOnboardingPlantChanged();
          oSystemFound = _.find(
            oPlantFound.Systems,
            jQuery.proxy(function (oSystem) {
              return oSystem.SapSysId === oConfSettings.sapSysId;
            }, this)
          );
        } else {
          MToast.show(this.getText("InvalidCompPlant"));
          return;
        }
        if (oCompanyFound && oPlantFound && oSystemFound) {
          this.getModel("onboarding").setProperty(
            "/sapSystemId",
            oConfSettings.sapSysId
          );
          this.onOnboardingSystemChanged();
        }

        // if (!this.getSharedModel().getProperty('/publicRelease')) {
        if (
          oCompanyFound &&
          oPlantFound &&
          oSystemFound &&
          oConfSettings.sapUser
        ) {
          this.getModel("onboarding").setProperty(
            "/sapUser",
            oConfSettings.sapUser
          );
          //this.onOnboardingSystemChanged();
        }
        if (
          oCompanyFound &&
          oPlantFound &&
          oSystemFound &&
          oConfSettings.sapUser &&
          oConfSettings.sapPass
        ) {
          this.getModel("onboarding").setProperty(
            "/sapPass",
            atob(oConfSettings.sapPass.split("").reverse().join(""))
          );
          if (oConfSettings.deviceName) {
            this.scanDeviceId = oConfSettings.deviceName;
          }
          this.onOnboardingPasswordChanged(undefined, true);
        }

        // }
      },

      offline: function () {
        var controller = this.getOwnerComponent().ViewLocation;

        this.genericSetDeviceIdColor("Red");
        this.genericReplaceStyleClass(controller.getView(), "Red");
      },

      online: function (oEvent) {
        $.when(this.connectionCheckTogiveColour()).done(
          function () {
            this.timeRegistrationOffline();
          }.bind(this)
        );
      },

      onPressSeePassword: function (oEvent) {
        
        // var oInput = sap.ui.getCore().byId("passWord");
        let oInput;
        oEvent.oSource
          .getParent()
          .getAggregation("items")
          .forEach(
            function (oItem) {
              if (oItem.mProperties["value"] !== undefined) {
                oInput = oItem;
              }
            }.bind(this)
          );

        var oType = oInput.getProperty("type"),
          oIcon = oEvent.getSource().getProperty("icon");
        if (oType === "Password") oInput.setProperty("type", "Text");
        else oInput.setProperty("type", "Password");
        if (oIcon === "sap-icon://show")
          oEvent.getSource().setProperty("icon", "sap-icon://hide");
        else oEvent.getSource().setProperty("icon", "sap-icon://show");
      },

      onPressSeeRegisterPincode: function (oEvent) {
        
        // var oInput = sap.ui.getCore().byId("passWord");
        let oInput;
        if (oEvent.oSource.getParent().getAggregation("items") === undefined) {
          oEvent.oSource.getParent().mAggregations.fields.forEach(
            function (oItem) {
              if (oItem.mProperties["value"] !== undefined) {
                oInput = oItem;
              }
            }.bind(this)
          );
        } else {
          oEvent.oSource
            .getParent()
            .getAggregation("items")
            .forEach(
              function (oItem) {
                if (oItem.mProperties["value"] !== undefined) {
                  oInput = oItem;
                }
              }.bind(this)
            );
        }

        var oType = oInput.getProperty("type"),
          oIcon = oEvent.getSource().getProperty("icon");
        if (oType === "Password") oInput.setProperty("type", "Text");
        else oInput.setProperty("type", "Password");
        if (oIcon === "sap-icon://show")
          oEvent.getSource().setProperty("icon", "sap-icon://hide");
        else oEvent.getSource().setProperty("icon", "sap-icon://show");
      },
      updateConfTile: function () {
        var count = {
          ConfirmationNotStarted: 0,
          FinalConfirmation: 0,
          ConfirmationOngoing: 0,
          FinishedConfirmation: 0,
          Notifications: 0,
          FinishedFinalConfirmation: 0,
        };
        $.when(
          this.getDBService().getEntitySet("Confirmation"),
          this.getDBService().getEntitySet("PMOrder"),
          this.getDBService().getEntitySet("PMNotification"),
          this.getDBService().getEntitySet("Operation"),
          this.getDBService().getEntitySet("Operation")
        )
          .done(
            function (
              oConfirmations,
              oOrderSet,
              aNotifications,
              oOperationSet
            ) {
              // this.getSharedModel().setProperty("/changed",false);
              let aConfirmations = _.filter(
                  this.getHelper().rowsToArray(oConfirmations),
                  { Hidden: "" }
                ),
                aOrderSet = _.filter(this.getHelper().rowsToArray(oOrderSet)),
                aOperationSet = _.filter(
                  this.getHelper().rowsToArray(oOperationSet)
                );
              count.Notifications = _.filter(
                this.getHelper().rowsToArray(aNotifications),
                { Qmnum: "" }
              ).length;
              count.Operations = aOperationSet.length;
              aConfirmations.forEach(function (aConf) {
                if (aConf.IsFinished === "true" && aConf.FinConf === "true") {
                  count.FinishedFinalConfirmation++;
                } else if (aConf.IsFinished === "true") {
                  count.FinishedConfirmation++;
                } else if (aConf.FinConf === "true") {
                  count.FinalConfirmation++;
                } else {
                  count.ConfirmationOngoing++;
                }
              });
              var a = [];
              aOrderSet.forEach(function (order) {
                let confExist = _.find(aConfirmations, {
                  Aufnr: order.Orderid,
                  Vornr: "",
                });
                if (!confExist) {
                  a.push(order.Orderid);
                }
              });
              aOperationSet.forEach(
                function (oOperation) {
                  let oCheckOperation = this.getHelper().checkOperationValid(
                    oOperation.Orderid,
                    oOperation
                  );
                  let cnfOperation = oOperation.ConfFinal === "X";
                  if (
                    oCheckOperation.ControlKeyIsValid === false ||
                    oCheckOperation.PMEXValid === false ||
                    cnfOperation === true
                  ) {
                    count.Operations--;
                  } else {
                    if (a.includes(oOperation.Orderid)) {
                      if (
                        !_.find(aConfirmations, {
                          Aufnr: oOperation.Orderid,
                          Vornr: oOperation.Activity,
                          SubActivity: oOperation.SubActivity,
                        })
                      ) {
                        count.ConfirmationNotStarted++;
                      }
                    }
                  }
                }.bind(this)
              );
              this.getSharedModel().setProperty("/counts", count);
            }.bind(this)
          )
          .fail(
            function () {
              this.getSharedModel().setProperty("/counts", count);
            }.bind(this)
          );
      },

      createParticipants: function (sapUser) {
        this.LoggedInUser = sapUser;
        $.when(this.getOwnerComponent().createParticipant(sapUser))
          .done(
            jQuery.proxy(function () {
              $.when(this.getOwnerComponent().getParticipantsFromDb())
                .done(
                  jQuery.proxy(function (oData) {
                    if (oData.length > 0) {
                      this.genericSetDeviceIdColor("Green");
                      this.genericReplaceStyleClass(this.getView(), "Green");
                      let selected = oData.find((oPart) => {
                        return oPart.Pernr === this.LoggedInUser.padStart(8, 0);
                      });
                      let oSettingData = { Vendor: selected.Lifnr },
                        aSettingsArray = [];
                      for (var sProp in oSettingData) {
                        if (oSettingData.hasOwnProperty(sProp)) {
                          aSettingsArray.push({
                            SKey: sProp,
                            SValue: oSettingData[sProp],
                          });
                        }
                      }
                      this.getDBService().updateSAPSettings(aSettingsArray);
                    } else {
                      if (this.getSharedModel().getProperty("/publicRelease")) {
                        this.genericSetDeviceIdColor("Red");
                        this.genericReplaceStyleClass(this.getView(), "Red");
                      }
                    }
                  }, this)
                )
                .fail(jQuery.proxy(function (oError) {}, this));
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              if (oError) {
                if (oError.offline === true) {
                  // MBox.error(this.getText("NoNetwork"));
                  MBox.error(this.getText("NoNetwork"));
                  // this.getView().setBusy(false);
                } else if (oError.connection === false) {
                  MBox.error(
                    this.getText("ConnectionUnknown") +
                      "\n" +
                      this.getText("NoConnectionToSap")
                  );
                  // this.getView().setBusy(false);
                }
              }
              if (this.getSharedModel().getProperty("/publicRelease")) {
                this.genericSetDeviceIdColor("Red");
                this.genericReplaceStyleClass(this.getView(), "Red");
              }
            }, this)
          );
      },

      createPublicTables: function () {
        if (this.getSharedModel().getProperty("/publicRelease")) {
          let metadataObj = this.getDBService()._getMetaObject(),
            //Timesheet table seems to be not used at all.
            toCreate = [zoneData, TimeInOut, TimeSheet];
          if (metadataObj) {
            let TimeReg = _.find(
              metadataObj.dataServices.schema[0].entityType,
              { name: "TimeRegistration" }
            );

            if (TimeReg) {
              let timeReg = JSON.parse(JSON.stringify(TimeReg));
              timeReg.name = "TimeRegistration1";
              toCreate.push(timeReg);
            }
          }
          let loginWAIData =
            this.getModel("shared").getProperty("/loginWAIData");
          if (loginWAIData && loginWAIData.hash && loginWAIData.amei) {
            loginWAIData.amei = loginWAIData.amei.toString().padStart(8, "0");
            this._saveTableToDB(loginWAIData, wParticipants, "Replace");
          } else {
            toCreate.push(wParticipants);
          }
          this.getDBService()._createTable(toCreate);
        }
      },

      closeMessageLog: function () {
        this.getDialogManager().close(
          "fragments.MessageFragment",
          this.getView()
        );
      },

      initPublicVersion: function () {
        $.when(this.getDBService().getEntitySet("TimeInOut"))
          .done(
            function (oData) {
              this.getModel("local").setProperty(
                "/TimeInOut",
                this.getHelper().rowsToArray(oData)
              );
            }.bind(this)
          )
          .fail(function () {
            console.error("CPM:Table TimeInOut not updated.");
          });
      },

      timeRegistrationOffline: function () {
        if (this.getSharedModel().getProperty("/publicRelease")) {
          $.when(this.getDBService().getEntitySet("TimeRegistration1")).done(
            function (oData) {
              oData = this.getHelper().rowsToArray(oData);
              if (oData.length === 0) {
                return;
              }
              var tempData = JSON.parse(JSON.stringify(oData));
              $.when(this.getService().setZonebadging(tempData))
                .done(
                  function (oData) {
                    this.messageLog = [];
                    if (oData) {
                      let messages = _.forEach(
                        oData.NavTimeRegistration.results,
                        function (row) {
                          if (row.Message) {
                            this.messageLog.push({
                              Message:
                                " For Participant " +
                                row.Pernr +
                                " in zone " +
                                row.TrZone +
                                " " +
                                row.Message,
                              Severity: "Error",
                            });
                          }
                        }.bind(this)
                      );
                      this.getDBService().deleteAllObjects("TimeRegistration1");
                      if (this.messageLog.length > 0) {
                        this.getModel("local").setProperty(
                          "/messages",
                          this.messageLog
                        );
                        this.getDialogManager().open(
                          "fragments.MessageFragment",
                          this.getView()
                        );
                      } else {
                        MBox.success("Zone Registration success");
                      }
                    }
                  }.bind(this)
                )
                .fail(function () {
                  //this.getDBService().deleteAllObjects("TimeRegistration1");
                });
            }.bind(this)
          );
        }
      },

      updateDeviceSettings: function () {
        var uri = this.getManifestEntry(
          "/sap.app/dataSources/configserver"
        ).uri;
        var oShared = this.getModel("shared"),
          oSettings = oShared.getProperty("/sapSettings");
        $.when(this.getService().createConfigurationModel(uri, oSettings)).done(
          jQuery.proxy(function () {
            $.when(
              this.getService().getDeviceSettings(
                oShared.getProperty("/sapSettings/deviceName"),
                oShared.getProperty("/sapSettings/plant")
              ),
              this.getService().getValueHelpSet()
            ).done(
              jQuery.proxy(function (oResult, oValueHelp) {
                
                var notifFields = {};
                this._aDeviceSettings = oResult.navDeviceSettings.results;
                let PoActive = this._aDeviceSettings.find (settingActive => settingActive.Fieldname === "POActive")
                // if (!this._aDeviceSettings.find (settingActive => settingActive.Fieldname === "POActive")){
                //   let MainPageGrid = this.getView().byId("MainPageGrid"),
                //       slideTilePurchaseOrders = this.getView().byId("slideTilePurchaseOrders"),
                //       count = MainPageGrid.indexOfContent(slideTilePurchaseOrders);
                //       if (count >= 0) {
                //         MainPageGrid.removeContent(count);
                //       }

                // }

                this.addPOTile(PoActive);
                for (var x in this._aDeviceSettings) {
                  if (
                    this._aDeviceSettings[x].Fieldname.indexOf(
                      "notifFields"
                    ) !== -1
                  ) {
                    var aNotifField =
                      this._aDeviceSettings[x].Fieldname.split("_");
                    var sNotifField = aNotifField[1];
                    notifFields[sNotifField] =
                      this._aDeviceSettings[x].Type === "BOOL"
                        ? this._aDeviceSettings[x].ValueBool
                        : this._aDeviceSettings[x].ValueString;
                  } else {
                    this.getModel("onboarding").setProperty(
                      "/" + this._aDeviceSettings[x].Fieldname,
                      this._aDeviceSettings[x].Type === "BOOL"
                        ? this._aDeviceSettings[x].ValueBool
                        : this._aDeviceSettings[x].ValueString
                    );
                  }
                }
                var enableDownloadBoms = _.find(this._aDeviceSettings, {
                  Fieldname: "enableDownloadBoms",
                });
                var enableOrderConfCreation = _.find(this._aDeviceSettings, {
                  Fieldname: "enableOrderConfCreation",
                });
                var persNoNotRequired = _.find(this._aDeviceSettings, {
                  Fieldname: "persNoNotRequired",
                });
                var rfidMand = _.find(this._aDeviceSettings, {
                  Fieldname: "rfidMand",
                });
                var hideLogOffButton = _.find(this._aDeviceSettings, {
                  Fieldname: "hideLogOffButton",
                });
                var Notifstatus_tbp = _.find(this._aDeviceSettings, {
                  Fieldname: "Notifstatus_tbp",
                });
                /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1
                Trcheckerror prop in backend table was not updated when turing it off.
                To get sync right, this code is written*/
                var ZoneBadging = _.find(this._aDeviceSettings, {
                  Fieldname: "ZoneBadging",
                });
                var Connected = _.find(this._aDeviceSettings, {
                  Fieldname: "Connected",
                });
                var TrCheckError = _.find(this._aDeviceSettings, {
                  Fieldname: "TrCheckError",
                });
                var POActive = _.find(this._aDeviceSettings, {
                  Fieldname: "POActive",
                });
                /*END: Date: 17/03/2024 AMID: A0866990 Version */
                if (!enableDownloadBoms) {
                  this.getModel("onboarding").setProperty(
                    "/enableDownloadBoms",
                    false
                  );
                }
                var Notifstatus_tbp = _.find(this._aDeviceSettings, {
                  Fieldname: "Notifstatus_tbp",
                });
                var ZoneBadging = _.find(this._aDeviceSettings, {
                  Fieldname: "ZoneBadging",
                });
                var Connected = _.find(this._aDeviceSettings, {
                  Fieldname: "Connected",
                });
                var TrCheckError = _.find(this._aDeviceSettings, {
                  Fieldname: "TrCheckError",
                });
                var POActive = _.find(this._aDeviceSettings, {
                  Fieldname: "POActive",
                });
                if (!enableOrderConfCreation) {
                  this.getModel("onboarding").setProperty(
                    "/enableOrderConfCreation",
                    false
                  );
                }
                if (!persNoNotRequired) {
                  this.getModel("onboarding").setProperty(
                    "/persNoNotRequired",
                    false
                  );
                }
                if (!rfidMand) {
                  this.getModel("onboarding").setProperty("/rfidMand", false);
                }
                if (!hideLogOffButton) {
                  this.getModel("onboarding").setProperty(
                    "/hideLogOffButton",
                    false
                  );
                }
                if (!Notifstatus_tbp) {
                  this.getModel("onboarding").setProperty(
                    "/Notifstatus_tbp",
                    false
                  );
                }
                if (!TrCheckError) {
                  this.getModel("onboarding").setProperty(
                    "/TrCheckError",
                    false
                  );
                }
                if (!POActive) {
                  this.getModel("onboarding").setProperty(
                    "/POActive",
                    false
                  );
                }
                if (!Connected) {
                  this.getModel("onboarding").setProperty("/Connected", false);
                }
                if (!ZoneBadging) {
                  this.getModel("onboarding").setProperty(
                    "/ZoneBadging",
                    false
                  );
                }
                notifFields = this.getHelper().onNotifFieldChange(notifFields);
                this.getModel("shared").setProperty(
                  "/sapSettings/notifFields",
                  notifFields
                );
                this.getModel("onboarding").setProperty(
                  "/notifFields",
                  notifFields
                );

                this.getModel("onboarding").setProperty(
                  "/langu",
                  this.getModel("onboarding")
                    .getProperty("/langu")
                    .toUpperCase()
                );
                if (
                  this.getModel("shared").getProperty(
                    "/sapSettings/sapUser"
                  ) !== undefined &&
                  this.getModel("shared").getProperty(
                    "/sapSettings/sapPass"
                  ) !== undefined &&
                  this.getModel("shared").getProperty(
                    "/sapSettings/sapClient"
                  ) !== undefined
                ) {
                  this.getDBService().saveSAPSettings(
                    this.getModel("onboarding").getProperty("/")
                  );
                }

                $.when(
                  this.getDBService().deleteAllObjects("ValueHelpSet")
                ).done(
                  jQuery.proxy(function () {
                    this.getDBService().initValueHelpSet(oValueHelp);
                  }, this)
                );
                var sAppVersion =
                  this.getOwnerComponent().getManifestObject()._oManifest
                    ._version;
                if (
                  this.getOwnerComponent().service &&
                  this.getSharedModel().getProperty("/sapSettings")
                    .deviceName !== undefined
                ) {
                  this.getService().setVersion(
                    this.getSharedModel().getProperty("/sapSettings")
                      .deviceName,
                    this.getSharedModel().getProperty("/sapSettings").plant,
                    sAppVersion
                  );
                }
              }, this)
            );
          }, this)
        );
      },

      selectAgreement: function () {
        
        var that = this;
        return new Promise(function (resolve, reject) {
          var oView = that.getView();
          //var popupModel= that.getView().getModel('popupModel');

          //   oView.setModel(new sap.ui.model.json.JSONModel({
          // 	checkboxText1:`<p> 1. I agree to the &#160;<a href=\"//europe.arcelormittal.com/repository/terms_conditions/mobile/mobile_work/TermsAndConditionsMobileWorkX.pdf\" style=\"color:blue; font-weight:600;\"> Terms and Conditions</a>    and I confirm that I have read the  <a href=\"//europe.arcelormittal.com/repository/privacy_policy/mobile/mobile_work/PrivacyPolicyMobileWorkX.pdf\" style=\"color:blue; font-weight:600;\">  Privacy Policy</a> for the application  ‘Mobile Work’ ’. </p>`,
          // 	checkboxText2: `<p>2. I agree to the &#160;<a href=\"//europe.arcelormittal.com/repository/terms_conditions/mobile/whoami/TermsAndConditionsWhoAMI.pdf\" style=\"color:blue; font-weight:600;\"> Terms and Conditions</a>    and I confirm that I have read the  <a href=\"//europe.arcelormittal.com/repository/privacy_policy/mobile/whoami/PrivacyPolicyWhoAMI.pdf\" style=\"color:blue; font-weight:600;\">  Privacy Policy</a> for the application  ‘Who Am I’. </p>`
          //   }), "popupModel");
          var Iagree = that.getText("Iagree"),
            TermsandConditions = that.getText("TermsandConditionsForText"),
            IConfirm = that.getText("IConfirm"),
            PrivacyPolicy = that.getText("PrivacyPolicy"),
            ForWAI = that.getText("ForWAI"),
            ForMW = that.getText("ForMW"),
            ClickToContinue = that.getText("ClickToContinue");
          oView.setModel(
            new sap.ui.model.json.JSONModel({
              checkboxText1: ` <h4> ${ClickToContinue}</h4>
									<ol>
										<li>
											<p> ${Iagree} &#160;<a href=\"https://europe.arcelormittal.com/repository/terms_conditions/mobile/mobile_work/TermsAndConditionsMobileWorkX.pdf\" style=\"color:blue; font-weight:600;\"> ${TermsandConditions}</a>    ${IConfirm}  <a href=\"https://europe.arcelormittal.com/repository/privacy_policy/mobile/mobile_work/PrivacyPolicyMobileWorkX.pdf\" style=\"color:blue; font-weight:600;\">   ${PrivacyPolicy}</a>  ${ForMW}</p>
										</li>
										<li>
											<p> ${Iagree} &#160;<a href=\"https://europe.arcelormittal.com/repository/terms_conditions/mobile/whoami/TermsAndConditionsWhoAMI.pdf\" style=\"color:blue; font-weight:600;\"> ${TermsandConditions}</a>    ${IConfirm}  <a href=\"https://europe.arcelormittal.com/repository/privacy_policy/mobile/whoami/PrivacyPolicyWhoAMI.pdf\" style=\"color:blue; font-weight:600;\">   ${PrivacyPolicy}</a>  ${ForWAI} </p>
										</li>
									</ol>`,
            }),
            "popupModel"
          );
          Fragment.load({
            name: "mobilework.view.fragments.Agreement",
            controller: that,
          })
            .then(function (oDialog) {
              if (!that.oMPDialog) {
                that.oMPDialog = oDialog;
              }
              oView.addDependent(oDialog);
              that.oMPDialog.open();

              that.oMPDialog.attachAfterClose(function (oEvent) {
                if (
                  oEvent.getParameter("origin").sParentAggregationName ===
                  "endButton"
                )
                  resolve(false);
                else resolve(true);
              });
            })
            .catch(function (error) {
              reject(error);
            });
        });
      },

      onContinue: function () {
        this.oMPDialog.setBusy(true);
        let user =
          this.getSharedModel().getProperty("/sapSettings/sapUser") ||
          this.getModel("login").getProperty("/sapUser");
        $.when(this.getService().sendAgreement(user))
          .done(
            function () {
              this.oMPDialog.close();
              MBox.success(this.getText("AgreeSuccess"));
              this.oMPDialog.setBusy(false);
            }.bind(this)
          )
          .fail(
            function (oError) {
              this.oMPDialog.setBusy(false);
              if (oError) {
                if (typeof oError.message === "string") {
                  MBox.error(oError.message);
                } else {
                  MBox.error(this.getText("ConnectionUnknown"));
                }
              }
            }.bind(this)
          );
      },

      onCancel: function () {
        this.oMPDialog.close();
      },

      selectAgreementwithCheck: async function (config, username) {
        var d = $.Deferred();
        var uri = this.getManifestEntry(
          "/sap.app/dataSources/configserver"
        ).uri;
        var oShared = this.getModel("shared"),
          oSettings = oShared.getProperty("/sapSettings"),
          configCall = true;
        if (config) {
          configCall = this.getService().createConfigurationModel(
            uri,
            oSettings
          );
        }
        $.when(configCall)
          .done(
            jQuery.proxy(
              function () {
                $.when(
                  this.getService() && this.getService().getAgreement(username)
                )
                  .done(function (oData) {
                    if (oData && oData.Agreement) d.resolve("S");
                    else d.resolve("F");
                  })
                  .fail(function () {
                    //d.resolve("X")
                    d.resolve();
                  });
              }.bind(this)
            )
          )
          .fail(function () {
            d.resolve();
          });
        return d.promise();
      },
      onPincodeLoginSelected: async function (oEvent) {
        var that = this;

        if (crypto.randomUUID === undefined) {
          console.error("Pincode login not available on Windows");
          that.getView().getModel("login").setProperty("/pinCodeState", false);
          that
            .getView()
            .getModel("login")
            .setProperty("/sapPasswordVisible", true);
          that
            .getView()
            .getModel("login")
            .setProperty("/sapPincodeVisible", false);

          MBox.error(this.getText("PincodeNotAvailableOnWindows"));
          return;
        }

        // If no azure pincode server is defined, the pincode option cannot be activated
        const sPincodeServerDomain = this.getModel("login").getProperty(
          "/pincodeServerDomain"
        );
        if (sPincodeServerDomain === undefined) {
          const sTitle = this.getOwnerComponent().getText(
            "PincodeSetupNotAvailable"
          );
          MBox.warning(sTitle, {
            // actions: ["Register device", "Cancel"],
            onClose: jQuery.proxy(async function (sAction) {
              that
                .getView()
                .getModel("login")
                .setProperty("/pinCodeState", false);
              that
                .getView()
                .getModel("login")
                .setProperty("/sapPasswordVisible", true);
              that
                .getView()
                .getModel("login")
                .setProperty("/sapPincodeVisible", false);
            }, that),
          });

          return;
        }
        // Check if device is registered
        let bDeviceRegistered = await this.loginMethod.checkDeviceRegistration(
          sPincodeServerDomain
        );

        if (bDeviceRegistered) {
          if (
            this.getView().getModel("login").getProperty("/pinCodeState") ===
            true
          ) {
            this.getView()
              .getModel("login")
              .setProperty("/sapPasswordVisible", false);
            this.getView().getModel("login").setProperty("/pinCodeState", true);
            this.getView()
              .getModel("login")
              .setProperty("/sapPincodeVisible", true);
          } else {
            this.getView()
              .getModel("login")
              .setProperty("/pinCodeState", false);
            this.getView()
              .getModel("login")
              .setProperty("/sapPasswordVisible", true);
            this.getView()
              .getModel("login")
              .setProperty("/sapPincodeVisible", false);
          }
        } else {
          setTimeout(
            jQuery.proxy(function () {
              const sRegisterDevice = that
                .getModel("i18n")
                .getResourceBundle()
                .getText("RegisterDevice");
              const sCancel = that
                .getModel("i18n")
                .getResourceBundle()
                .getText("Cancel");

              MBox.warning(that.getOwnerComponent().getText("RegisterDevice"), {
                actions: [sRegisterDevice, sCancel],
                onClose: jQuery.proxy(async function (sAction) {
                  // this.oContext.oSwitch = oSwitch;

                  if (sAction === sRegisterDevice) {
                    var oBoardingUser =
                      this.getModel("onboarding").getProperty("/sapUser");
                    var oLoginUser =
                      this.getModel("login").getProperty("/sapUser");
                    if (oBoardingUser !== "" && oBoardingUser !== undefined) {
                      this.getView()
                        .getModel("login")
                        .setProperty("/sapUserDeviceRegister", oBoardingUser);
                    } else if (oLoginUser !== "" && oLoginUser !== undefined) {
                      this.getView()
                        .getModel("login")
                        .setProperty("/sapUserDeviceRegister", oLoginUser);
                    } else {
                      this.getView()
                        .getModel("login")
                        .setProperty("/sapUserDeviceRegister", "");
                    }
                    this.getView()
                      .getModel("login")
                      .setProperty("/sapPasswordDeviceRegister", "");

                    that
                      .getDialogManager()
                      .openWithModel(
                        "fragments.RegisterDevice",
                        that.getView(),
                        that.getView().getModel("login")
                      );
                  } else {
                    console.debug("Action cancelled by user");
                    that
                      .getView()
                      .getModel("login")
                      .setProperty("/pinCodeState", false);
                    that
                      .getView()
                      .getModel("login")
                      .setProperty("/sapPasswordVisible", true);
                    that
                      .getView()
                      .getModel("login")
                      .setProperty("/sapPincodeVisible", false);
                  }
                }, that),
              });
            }, that),
            1
          );
        }
      },
      onCloseRegisterDevice: function () {
        this.getDialogManager().close(
          "fragments.RegisterDevice",
          this.getView()
        );
        this.getDialogManager().destroyDialog(
          "fragments.RegisterDevice",
          this.getView()
        );
        this.getView().getModel("login").setProperty("/pinCodeState", false);
        this.getView()
          .getModel("login")
          .setProperty("/sapPasswordVisible", true);
        this.getView()
          .getModel("login")
          .setProperty("/sapPincodeVisible", false);
        // this.getView().getModel("login").setProperty("/pinCodeData", {});
      },
      onRegisterDevice: async function (oEvent) {
        this._handleBusyIndicator("SHOW");
        try {
          await this.loginMethod.onRegisterLoginDevicePress(this, oEvent);
          this.getDialogManager().close(
            "fragments.RegisterDevice",
            this.getView()
          );
          this.getDialogManager().destroyDialog(
            "fragments.RegisterDevice",
            this.getView()
          );
          this.getView()
            .getModel("login")
            .setProperty("/sapPasswordVisible", false);
          this.getView().getModel("login").setProperty("/pinCodeState", true);
          this.getView()
            .getModel("login")
            .setProperty("/sapPincodeVisible", true);
          this.getView().getModel("login").setProperty("/sapPass", "");
          this.getView().getModel("login").setProperty("/sapPinCode", "");
          this._handleBusyIndicator("HIDE");
        } catch (oError) {
          console.error(oError);
          this.getView().getModel("login").setProperty("/pinCodeState", false);
          this.getView()
            .getModel("login")
            .setProperty("/sapPasswordVisible", true);
          this.getView()
            .getModel("login")
            .setProperty("/sapPincodeVisible", false);
          this._handleBusyIndicator("HIDE");
        }
      },
      onOpenRegisterPinCode: function () {
        // this.getView().getModel("login").setProperty("/pinCodeData", {});
        var oBoardingUser = this.getModel("onboarding").getProperty("/sapUser");
        var oLoginUser = this.getModel("login").getProperty("/sapUser");
        if (oBoardingUser !== "" && oBoardingUser !== undefined) {
          this.getView()
            .getModel("login")
            .setProperty("/sapUserRegister", oBoardingUser);
        } else if (oLoginUser !== "" && oLoginUser !== undefined) {
          this.getView()
            .getModel("login")
            .setProperty("/sapUserRegister", oLoginUser);
        } else {
          this.getView().getModel("login").setProperty("/sapUserRegister", "");
        }
        this.getView()
          .getModel("login")
          .setProperty("/sapPasswordRegister", "");
        this.getView().getModel("login").setProperty("/sapPinCodeRegister", "");
        this.getDialogManager().openWithModel(
          "fragments.PincodeRegister",
          this.getView(),
          this.getView().getModel("login")
        );
      },
      onCloseRegisterPinCode: function () {
        this.getDialogManager().close(
          "fragments.PincodeRegister",
          this.getView()
        );
        this.getDialogManager().destroyDialog(
          "fragments.PincodeRegister",
          this.getView()
        );
        this.getView().getModel("login").setProperty("/sapUserRegister", "");
        this.getView()
          .getModel("login")
          .setProperty("/sapPasswordRegister", "");
        this.getView().getModel("login").setProperty("/sapPinCodeRegister", "");
        // this.getView().getModel("login").setProperty("/pinCodeData", {});
      },

      onRegisterPinCode: async function (oEvent) {
        var oModel = this.getModel("login");
        if (
          oModel.getProperty("/sapUserRegister") === "" ||
          oModel.getProperty("/sapPasswordRegister") === "" ||
          oModel.getProperty("/sapPinCodeRegister") === "" ||
          oModel.getProperty("/sapUserRegister") === undefined ||
          oModel.getProperty("/sapPasswordRegister") === undefined ||
          oModel.getProperty("/sapPinCodeRegister") === undefined
        ) {
          MToast.show(this.getText("CredentialMissing"));
          return;
        }
        var inputValue = oModel.getProperty("/sapPinCodeRegister");
        var pattern = /^\d{4,}$/;
        if (!pattern.test(inputValue)) {
          var sMessage = this.getText("PincodeRequirementWarning");
          console.debug(sMessage);
          MToast.show(sMessage);
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "Error");
          return;
        } else {
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "None");
        }
        this._handleBusyIndicator("SHOW");
        try {
          await this.loginMethod.onRegisterUserPress(this, oEvent);
          this.onCloseRegisterPinCode();
          this._handleBusyIndicator("HIDE");
        } catch (oError) {
          console.error(oError);
          this._handleBusyIndicator("HIDE");
        }
      },
      onsapUserRegister: function (oEvent) {
        var sValue = oEvent.getParameter("newValue");
        this.getView()
          .getModel("login")
          .setProperty("/sapUserRegister", sValue.toUpperCase());
      },
      onCancelLoginProgress: function () {
        this.getDialogManager().close(
          "fragments.LoginProgress",
          this.getView()
        );
        this.getDialogManager().destroyDialog(
          "fragments.LoginProgress",
          this.getView()
        );
      },
      pinCodeRegisterChange: function (oEvent) {
        var inputValue = oEvent.getParameter("value");
        var pattern = /^\d{4,}$/;
        if (!pattern.test(inputValue)) {
          // var sMessage = this.getModel("i18n").getResourceBundle().getText("PincodeRequirementInfo");
          // console.log(sMessage);
          // MToast.show(sMessage);
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "Error");
          // return;
        } else {
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "None");
        }
      },
      onLoginLanguageChanged: function () {
        if (this.getModel("login").getProperty("/langu")) {
          this.getSharedModel().setProperty(
            "/sapSettings/langu",
            this.getModel("login").getProperty("/langu").toLowerCase()
          );
          sap.ui
            .getCore()
            .getConfiguration()
            .setLanguage(
              this.getModel("login").getProperty("/langu").toLowerCase()
            );
        }
      },

      pinCodeRegisterChange: function (oEvent) {
        var inputValue = oEvent.getParameter("value");
        var pattern = /^\d{4,}$/;
        if (!pattern.test(inputValue)) {
          // var sMessage = this.getModel("i18n").getResourceBundle().getText("PincodeRequirementInfo");
          // console.log(sMessage);
          // MToast.show(sMessage);
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "Error");
          // return;
        } else {
          this.getView()
            .getModel("login")
            .setProperty("/sapPinCodeRegisterValueState", "None");
        }
      },
    });
  }
);
