sap.ui.define(["mobilework/controller/BaseController"], function (Controller) {
  "use strict";

  return Controller.extend("mobilework.controller.App", {
    //---------------------------//
    // PROPERTIES
    //---------------------------//

    /** @type sap.f.FlexibleColumnLayout */
    oFlexColumnLayout: null,

    //---------------------------//
    // LIFECYCLE
    //---------------------------//

    /**
     * Called when a controller is instantiated and its View controls (if available) are already created.
     * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
     * @memberOf mobilework.view.TileOverview
     */
    onInit: function () {
      this._initProperties();
    },

    /**
     * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
     * @memberOf mobilework.view.TileOverview
     */
    onExit: function () {},

    //---------------------------//
    // EVENT HANDLERS
    //---------------------------//

    //---------------------------//
    // PRIVATES
    //---------------------------//

    _initProperties: function () {
      if (!this.oFlexColumnLayout) {
        this.oFlexColumnLayout = this.getView().byId("fcl");
      }
    },
  });
});
