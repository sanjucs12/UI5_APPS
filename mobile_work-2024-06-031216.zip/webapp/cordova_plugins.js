cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
        {
            "id": "cordova-plugin-device.device",
            "file": "plugins/cordova-plugin-device/www/device.js",
            "pluginId": "cordova-plugin-device",
            "clobbers": [
                "device"
            ]
        },
        {
            "id": "cordova-plugin-device.DeviceProxy",
            "file": "plugins/cordova-plugin-device/src/windows/DeviceProxy.js",
            "pluginId": "cordova-plugin-device",
            "runs": true
        },
        {
            "id": "cordova-plugin-file.DirectoryEntry",
            "file": "plugins/cordova-plugin-file/www/DirectoryEntry.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.DirectoryEntry"
            ]
        },
        {
            "id": "cordova-plugin-file.DirectoryReader",
            "file": "plugins/cordova-plugin-file/www/DirectoryReader.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.DirectoryReader"
            ]
        },
        {
            "id": "cordova-plugin-file.Entry",
            "file": "plugins/cordova-plugin-file/www/Entry.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.Entry"
            ]
        },
        {
            "id": "cordova-plugin-file.File",
            "file": "plugins/cordova-plugin-file/www/File.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.File"
            ]
        },
        {
            "id": "cordova-plugin-file.FileEntry",
            "file": "plugins/cordova-plugin-file/www/FileEntry.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileEntry"
            ]
        },
        {
            "id": "cordova-plugin-file.FileError",
            "file": "plugins/cordova-plugin-file/www/FileError.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileError"
            ]
        },
        {
            "id": "cordova-plugin-file.FileReader",
            "file": "plugins/cordova-plugin-file/www/FileReader.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileReader"
            ]
        },
        {
            "id": "cordova-plugin-file.FileSystem",
            "file": "plugins/cordova-plugin-file/www/FileSystem.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileSystem"
            ]
        },
        {
            "id": "cordova-plugin-file.FileUploadOptions",
            "file": "plugins/cordova-plugin-file/www/FileUploadOptions.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileUploadOptions"
            ]
        },
        {
            "id": "cordova-plugin-file.FileUploadResult",
            "file": "plugins/cordova-plugin-file/www/FileUploadResult.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileUploadResult"
            ]
        },
        {
            "id": "cordova-plugin-file.FileWriter",
            "file": "plugins/cordova-plugin-file/www/FileWriter.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.FileWriter"
            ]
        },
        {
            "id": "cordova-plugin-file.Flags",
            "file": "plugins/cordova-plugin-file/www/Flags.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.Flags"
            ]
        },
        {
            "id": "cordova-plugin-file.LocalFileSystem",
            "file": "plugins/cordova-plugin-file/www/LocalFileSystem.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.LocalFileSystem"
            ],
            "merges": [
                "window"
            ]
        },
        {
            "id": "cordova-plugin-file.Metadata",
            "file": "plugins/cordova-plugin-file/www/Metadata.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.Metadata"
            ]
        },
        {
            "id": "cordova-plugin-file.ProgressEvent",
            "file": "plugins/cordova-plugin-file/www/ProgressEvent.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.ProgressEvent"
            ]
        },
        {
            "id": "cordova-plugin-file.fileSystems",
            "file": "plugins/cordova-plugin-file/www/fileSystems.js",
            "pluginId": "cordova-plugin-file"
        },
        {
            "id": "cordova-plugin-file.requestFileSystem",
            "file": "plugins/cordova-plugin-file/www/requestFileSystem.js",
            "pluginId": "cordova-plugin-file",
            "clobbers": [
                "window.requestFileSystem"
            ]
        },
        {
            "id": "cordova-plugin-file.resolveLocalFileSystemURI",
            "file": "plugins/cordova-plugin-file/www/resolveLocalFileSystemURI.js",
            "pluginId": "cordova-plugin-file",
            "merges": [
                "window"
            ]
        },
        {
            "id": "cordova-plugin-file.isChrome",
            "file": "plugins/cordova-plugin-file/www/browser/isChrome.js",
            "pluginId": "cordova-plugin-file",
            "runs": true
        },
        {
            "id": "cordova-plugin-file.FileProxy",
            "file": "plugins/cordova-plugin-file/src/windows/FileProxy.js",
            "pluginId": "cordova-plugin-file",
            "runs": true
        },
        {
            "id": "cordova-plugin-file.fileSystemPaths",
            "file": "plugins/cordova-plugin-file/www/fileSystemPaths.js",
            "pluginId": "cordova-plugin-file",
            "merges": [
                "cordova"
            ],
            "runs": true
        },
        {
            "id": "cordova-plugin-keyboard.keyboard",
            "file": "plugins/cordova-plugin-keyboard/www/keyboard.js",
            "pluginId": "cordova-plugin-keyboard",
            "clobbers": [
                "window.Keyboard"
            ]
        },
        {
            "id": "cordova-plugin-network-information.network",
            "file": "plugins/cordova-plugin-network-information/www/network.js",
            "pluginId": "cordova-plugin-network-information",
            "clobbers": [
                "navigator.connection",
                "navigator.network.connection"
            ]
        },
        {
            "id": "cordova-plugin-network-information.Connection",
            "file": "plugins/cordova-plugin-network-information/www/Connection.js",
            "pluginId": "cordova-plugin-network-information",
            "clobbers": [
                "Connection"
            ]
        },
        {
            "id": "cordova-plugin-network-information.NetworkInfoProxy",
            "file": "plugins/cordova-plugin-network-information/src/windows/NetworkInfoProxy.js",
            "pluginId": "cordova-plugin-network-information",
            "runs": true
        },
        {
            "id": "cordova-sqlite-storage.SQLitePlugin",
            "file": "plugins/cordova-sqlite-storage/www/SQLitePlugin.js",
            "pluginId": "cordova-sqlite-storage",
            "clobbers": [
                "SQLitePlugin"
            ]
        },
        {
            "id": "cordova-sqlite-storage.SQLiteProxy",
            "file": "plugins/cordova-sqlite-storage/src/windows/sqlite-proxy.js",
            "pluginId": "cordova-sqlite-storage",
            "runs": true
        },
        {
            "id": "cordova-sqlite-storage.SQLite3",
            "file": "plugins/cordova-sqlite-storage/src/windows/SQLite3-WinRT-sync/SQLite3JS/js/SQLite3.js",
            "pluginId": "cordova-sqlite-storage",
            "runs": true
        },
        {
            "id": "dff-cordova-plugin-common.common",
            "file": "plugins/dff-cordova-plugin-common/www/common.js",
            "pluginId": "dff-cordova-plugin-common",
            "clobbers": [
                "CommonPlugin"
            ]
        },
        {
            "id": "dff-cordova-plugin-honeywell.honeywell",
            "file": "plugins/dff-cordova-plugin-honeywell/www/honeywell.js",
            "pluginId": "dff-cordova-plugin-honeywell",
            "clobbers": [
                "Honeywell"
            ]
        },
        {
            "id": "PanasonicScanner.PanasonicScanner",
            "file": "plugins/PanasonicScanner/www/PanasonicScanner.js",
            "pluginId": "PanasonicScanner",
            "clobbers": [
                "cordova.plugins.PanasonicScanner"
            ]
        },
        {
            "id": "PanasonicScanner.PanasonicScannerProxy",
            "file": "plugins/PanasonicScanner/src/windows/PanasonicScannerProxy.js",
            "pluginId": "PanasonicScanner",
            "merges": [
                ""
            ]
        },
        {
            "id": "phonegap-nfc.NFC",
            "file": "plugins/phonegap-nfc/www/phonegap-nfc.js",
            "pluginId": "phonegap-nfc",
            "runs": true
        },
        {
            "id": "phonegap-nfc.NfcPlugin",
            "file": "plugins/phonegap-nfc/src/windows/nfc-plugin.js",
            "pluginId": "phonegap-nfc",
            "merges": [
                ""
            ]
        },
        {
            "id": "phonegap-plugin-barcodescanner.BarcodeScanner",
            "file": "plugins/phonegap-plugin-barcodescanner/www/barcodescanner.js",
            "pluginId": "phonegap-plugin-barcodescanner",
            "clobbers": [
                "cordova.plugins.barcodeScanner"
            ]
        },
        {
            "id": "phonegap-plugin-barcodescanner.BarcodeScannerProxy",
            "file": "plugins/phonegap-plugin-barcodescanner/src/windows/BarcodeScannerProxy.js",
            "pluginId": "phonegap-plugin-barcodescanner",
            "merges": [
                ""
            ]
        },
        {
            "id": "GatesPlugin.GatesPlugin",
            "file": "plugins/GatesPlugin/www/GatesPlugin.js",
            "pluginId": "GatesPlugin",
            "clobbers": [
                "cordova.plugins.GatesPlugin"
            ]
        },
        {
            "id": "cordova-plugin-secure-storage-echo.SecureStorage",
            "file": "plugins/cordova-plugin-secure-storage-echo/www/securestorage.js",
            "pluginId": "cordova-plugin-secure-storage-echo",
            "clobbers": [
                "SecureStorage"
            ]
        },
        {
            "id": "cordova-plugin-secure-storage-echo.SecureStorageWindowsImpl",
            "file": "plugins/cordova-plugin-secure-storage-echo/src/windows/SecureStorage.js",
            "pluginId": "cordova-plugin-secure-storage-echo",
            "runs": true
        },
        {
            "id": "cordova-plugin-camera.Camera",
            "file": "plugins/cordova-plugin-camera/www/CameraConstants.js",
            "pluginId": "cordova-plugin-camera",
            "clobbers": [
                "Camera"
            ]
        },
        {
            "id": "cordova-plugin-camera.CameraPopoverOptions",
            "file": "plugins/cordova-plugin-camera/www/CameraPopoverOptions.js",
            "pluginId": "cordova-plugin-camera",
            "clobbers": [
                "CameraPopoverOptions"
            ]
        },
        {
            "id": "cordova-plugin-camera.camera",
            "file": "plugins/cordova-plugin-camera/www/Camera.js",
            "pluginId": "cordova-plugin-camera",
            "clobbers": [
                "navigator.camera"
            ]
        },
        {
            "id": "cordova-plugin-camera.CameraPopoverHandle",
            "file": "plugins/cordova-plugin-camera/www/CameraPopoverHandle.js",
            "pluginId": "cordova-plugin-camera",
            "clobbers": [
                "CameraPopoverHandle"
            ]
        },
        {
            "id": "cordova-plugin-camera.CameraProxy",
            "file": "plugins/cordova-plugin-camera/src/windows/CameraProxy.js",
            "pluginId": "cordova-plugin-camera",
            "runs": true
        },
        {
            "id": "gdl-plugin.GDLPlugin",
            "file": "plugins/gdl-plugin/www/GDLPlugin.js",
            "pluginId": "gdl-plugin",
            "clobbers": [
                "cordova.plugins.GDLPlugin"
            ]
        },
        {
            "id": "gdl-plugin.Semaphore",
            "file": "plugins/gdl-plugin/www/semaphore.js",
            "pluginId": "gdl-plugin",
            "clobbers": [
                "cordova.plugins.GDLSemaphore"
            ]
        },
        {
            "id": "gdl-plugin.GDLPluginProxy",
            "file": "plugins/gdl-plugin/src/windows/GDLPluginProxy.js",
            "pluginId": "gdl-plugin",
            "merges": [
                ""
            ]
        }
    ];
    module.exports.metadata = 
    // TOP OF METADATA
    {
        "cordova-android-support-gradle-release": "1.4.3",
        "cordova-plugin-compat": "1.2.0",
        "cordova-plugin-device": "2.0.3",
        "cordova-plugin-file": "4.3.3",
        "cordova-plugin-keyboard": "1.2.0",
        "cordova-plugin-network-information": "2.0.2",
        "cordova-plugin-whitelist": "1.3.4",
        "cordova-sqlite-storage": "3.4.0",
        "dff-cordova-plugin-common": "1.0.0",
        "dff-cordova-plugin-honeywell": "1.0.0",
        "PanasonicScanner": "0.0.1",
        "phonegap-nfc": "1.0.3",
        "phonegap-plugin-barcodescanner": "6.0.8",
        "GatesPlugin": "1.0",
        "cordova-plugin-secure-storage-echo": "5.1.1",
        "cordova-plugin-camera": "6.0.0",
        "gdl-plugin": "1.4.0",
        "cordova-plugin-androidx-adapter": "1.1.3"
    };
    // BOTTOM OF METADATA
    });