sap.ui.define(
  ["sap/ui/base/Object", "sap/m/Dialog"],
  function (Object, Dialog) {
    "use strict";

    return Object.extend("mobilework.util.dialogManager", {
      constructor: function () {
        this._sBasePath = "mobilework.view.";
        this._oDialogModel = new sap.ui.model.json.JSONModel();
      },

      close: function (sDialogName, oView) {
        var sFragmentPath = this._sBasePath + sDialogName,
          oDialogEntry = this._oDialogModel.getProperty(
            "/" + oView.getId() + "/" + sFragmentPath
          );

        if (oDialogEntry) {
          oDialogEntry.close();
        }
      },

      destroyDialog: function (sDialogName, oView) {
        var sFragmentPath = this._sBasePath + sDialogName,
          sViewId = oView.getId(),
          oViewEntry = this._oDialogModel.getProperty("/" + sViewId),
          oDialogEntry = this._oDialogModel.getProperty(
            "/" + sViewId + "/" + sFragmentPath
          );

        if (oDialogEntry) {
          oDialogEntry.destroy();
          delete oViewEntry[sFragmentPath];
        }
      },

      open: function (sDialogName, oView, oController) {
        var sFragmentPath = this._sBasePath + sDialogName,
          sViewId = oView.getId(),
          oViewEntry = this._oDialogModel.getProperty("/" + sViewId),
          oDialogEntry = null,
          _oController = oController || oView.getController();

        if (oViewEntry) {
          oDialogEntry = this._oDialogModel.getProperty(
            "/" + sViewId + "/" + sFragmentPath
          );
          if (oDialogEntry) {
            oDialogEntry.open();
          } else {
            this._createDialogEntry(true, oView, sFragmentPath, _oController);
          }
        } else {
          this._oDialogModel.setProperty("/" + sViewId, {});
          this._createDialogEntry(true, oView, sFragmentPath, _oController);
        }
      },

      getDialogEntry: function (sDialogName, oView) {
        var sFragmentPath = this._sBasePath + sDialogName,
          sViewId = oView.getId(),
          oViewEntry = this._oDialogModel.getProperty("/" + sViewId),
          oDialogEntry = null;

        if (oViewEntry) {
          oDialogEntry = this._oDialogModel.getProperty(
            "/" + sViewId + "/" + sFragmentPath
          );
        }

        return oDialogEntry;
      },

      openWithModel: function (sDialogName, oView, oModel, oController) {
        var sFragmentPath = this._sBasePath + sDialogName,
          sViewId = oView.getId(),
          oViewEntry = this._oDialogModel.getProperty("/" + sViewId),
          oDialogEntry = null,
          _oController = oController || oView.getController();

        if (oViewEntry) {
          oDialogEntry = this._oDialogModel.getProperty(
            "/" + sViewId + "/" + sFragmentPath
          );
          if (oDialogEntry) {
            if (oModel) {
              oDialogEntry.setModel(oModel);
            }
            oDialogEntry.open();
          } else {
            this._createDialogEntryWithModel(
              true,
              oView,
              sFragmentPath,
              oModel,
              _oController
            );
          }
        } else {
          this._oDialogModel.setProperty("/" + sViewId, {});
          this._createDialogEntryWithModel(
            true,
            oView,
            sFragmentPath,
            oModel,
            _oController
          );
        }
      },

      openGeneric: function (
        sTitle,
        sType,
        sMessage,
        fnCallback,
        oController,
        sBtnCancel,
        sBtnSubmit
      ) {
        var _oDialog = new Dialog({
          title: sTitle,
          type: sType,
          content: [
            new sap.m.Text({
              text: sMessage,
            }),
          ],
          beginButton: new sap.m.Button({
            text: sBtnSubmit,
            press: function () {
              fnCallback.call(oController);
              _oDialog.close();
            },
          }),
          endButton: new sap.m.Button({
            text: sBtnCancel,
            press: function () {
              _oDialog.close();
            },
          }),
          afterClose: function () {
            _oDialog.destroy();
          },
        });

        _oDialog.open();
      },

      _createDialogEntry: function (bOpen, oView, sFragmentPath, oController) {
        var oDialog = sap.ui.xmlfragment(sFragmentPath, oController);

        oView.addDependent(oDialog);

        this._oDialogModel.setProperty(
          "/" + oView.getId() + "/" + sFragmentPath,
          oDialog
        );

        if (bOpen) {
          oDialog.open();
        }
      },

      _createDialogEntryWithModel: function (
        bOpen,
        oView,
        sFragmentPath,
        oModel,
        oController
      ) {
        //
        var oDialog = sap.ui.xmlfragment(sFragmentPath, oController);

        oView.addDependent(oDialog);
        oDialog.setModel(
          oController.getOwnerComponent().getModel("i18n"),
          "i18n"
        );

        if (oModel) {
          oDialog.setModel(oModel);
        }

        this._oDialogModel.setProperty(
          "/" + oView.getId() + "/" + sFragmentPath,
          oDialog
        );

        if (bOpen) {
          oDialog.open();
        }
      },
    });
  }
);
