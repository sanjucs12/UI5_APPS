/*global moment:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "mobilework/libs/moment",
    "mobilework/libs/xml2json",
    "mobilework/libs/lodash",
  ],
  function (Object, Mo, Xml2, Lo) {
    "use strict";

    return {
      dateStringToEUFormat: function (sDateString) {
        if (sDateString) {
          var oDate = new Date(sDateString),
            oMoment = new moment(oDate);

          if (oMoment) {
            return oMoment.format("DD/MM/YYYY HH:mm");
          } else {
            return "invalid date";
          }
        }
      },

      toUpperCase: function (sValue) {
        sValue = sValue.toUpperCase();
        return sValue;
      },

      toSapIcon: function (icon, text) {
        let WcaSapPhaseIcon;
        switch (icon) {
          case "@8X@":
            return "sap-icon://employee-approvals";

          case "@DF@":
            return "sap-icon://flag";

          case "@IF@":
            return "sap-icon://document-text";

          case "@0Z@":
            return "sap-icon://edit";

          case "@F1@":
            return "sap-icon://flag-2";

          case "@06@":
            return "sap-icon://locked";

          case "@0X@":
            return "sap-icon://print";
        }
        //This code has to be changed based on a key// Copied from MI -
        switch (text) {
          case "Safety approval revoked":
            return "sap-icon://sys-cancel-2";
          case "Safety Attestation can be Handed Out":
            return "sap-icon://color-fill";
          case "Safety Attestation Handed Out":
            return "sap-icon://flag-2";
          default:
            return "sap-icon://account";
        }
      },
      removetime(value) {
        if (value) {
          var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
            pattern: "dd-MM-yyyy",
          });
          return oDateFormat.format(new Date(value));
        } else {
          return value;
        }
      },
      setPOLongText(value) {
        if (value !== "") {
          return value;
        } else {
          return this.getModel("i18n").getResourceBundle().getText("DataNotAvaialble");
        }
      },
      setPOItemLongText(value) {
        if (value !== "") {
          return value;
        } else {
          return this.getModel("i18n").getResourceBundle().getText("DataNotAvaialble");
        }
      },
      formatWCAData: function (value) {
        if (value !== "") {
          return true;
        } else {
          return false;
        }
      },
    };
  }
);
