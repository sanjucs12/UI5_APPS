sap.ui.define(["sap/ui/base/Object"], function (Object) {
  "use strict";

  return Object.extend("mobilework.util.KeyListener", {
    //-------------------------------------
    // GENERAL INFO
    //-------------------------------------

    // Created on: 03/2019
    // Contacts: Glenn De Groote, Jonis De Klerk
    // Domain: Arcelor Mittal ARMP (Herman De Vos)
    // Subscribe to broadcast: sap.ui.getCore().getEventBus().subscribe("KeyListener", "barcode", <function>, <listener>);

    //-------------------------------------
    // PRIVATE PROPERTIES
    //-------------------------------------

    _aDefaultSupportedScanners: [
      {
        name: "RS507",
        prefixKeyCode: 13,
        suffixKeyCode: 13,
      },
      {
        name: "C-Five",
        prefixKeyCode: 0,
        suffixKeyCode: null,
      },
      {
        name: "DEFAULT",
        prefixKeyCode: null,
        suffixKeyCode: null,
      },
    ],

    _aSupportedScanners: [],

    _bActivateLogging: false,

    _iReadTimeout: 200,

    //-------------------------------------
    // PUBLIC METHODS
    //-------------------------------------

    constructor: function (aSupportedScanners, bActivateLogging, iReadTimeout) {
      // Add additional scanners to default supported scanner
      if (
        aSupportedScanners &&
        aSupportedScanners.length &&
        aSupportedScanners.length > 0
      ) {
        this._aSupportedScanners =
          this._aDefaultSupportedScanners.concat(aSupportedScanners);
      } else {
        this._aSupportedScanners = this._aDefaultSupportedScanners;
      }

      // Set logging param
      this._bActivateLogging = bActivateLogging === true;

      // Set read timeout param
      this._iReadTimeout = iReadTimeout || this._iReadTimeout;
    },

    activate: function () {
      this._assignKeypressFunction();
    },

    deactivate: function () {
      this._deassignKeypressFunction();
    },

    //-------------------------------------
    // EVENT HANDLERS
    //-------------------------------------

    onKeyReceived: function (oEvent) {
      var oSourceElement = sap.ui.getCore().byId(oEvent.target.id),
        sBarcode = "",
        _oEvent = oEvent;

      if (oSourceElement) {
        var sSourceCompId = "",
          sTargetCompId = "";

        while (oSourceElement.getId().search("component") < 0) {
          oSourceElement = sap.ui
            .getCore()
            .byId(oSourceElement.getId())
            .getParent();
        }

        sSourceCompId = oSourceElement.getId().toLowerCase();
        sTargetCompId = _oEvent.target.id.toLowerCase();

        if (
          sSourceCompId.search("master") < 0 &&
          sSourceCompId.search("detail") < 0 &&
          sTargetCompId.search("master") < 0 &&
          sTargetCompId.search("detail") < 0
        ) {
          return _oEvent;
        }
      }

      for (var i = 0; i < this._aSupportedScanners.length; i++) {
        var oCurrConfig = this._aSupportedScanners[i];

        if (!oCurrConfig.aKeyBuffer) {
          oCurrConfig.aKeyBuffer = [];
        }

        // If a key exists older than 3 seconds, remove it
        if (
          oCurrConfig.aKeyBuffer.length > 0 &&
          new Date(oCurrConfig.aKeyBuffer[0].timestamp) <
            new Date(Date.now() - 3000)
        ) {
          oCurrConfig.aKeyBuffer = [];
          this._writeLog("KeyBuffer: value too old. Data cleared.");
        }

        // Add current key to KeyBuffer
        _oEvent.timestamp = Date.now();
        oCurrConfig.aKeyBuffer.push(_oEvent);
        this._writeLog(
          "KeyBuffer: key added to buffer > " +
            _oEvent.keyCode +
            " - " +
            oCurrConfig.name
        );

        // Check prefixcode
        if (
          oCurrConfig.aKeyBuffer[0].keyCode !== oCurrConfig.prefixKeyCode &&
          oCurrConfig.prefixKeyCode !== null
        ) {
          this._writeLog(
            "KeyBuffer: wrong prefix > " +
              oCurrConfig.name +
              " - " +
              oCurrConfig.aKeyBuffer[0].keyCode +
              " NE " +
              oCurrConfig.prefixKeyCode
          );
          oCurrConfig.aKeyBuffer = [];
          continue;
        }

        // Check suffixcode
        if (
          typeof oCurrConfig.suffixKeyCode === "undefined" ||
          oCurrConfig.suffixKeyCode === null
        ) {
          var iBufferCharCount = oCurrConfig.aKeyBuffer.length;
          // We set a timeout the make sure we have received all keys
          setTimeout(
            jQuery.proxy(function () {
              this._writeLog(
                "KeyBuffer: timeout entered. Keycode: " +
                  _oEvent.keyCode +
                  ". CharCount is " +
                  iBufferCharCount
              );

              if (iBufferCharCount + 1 === oCurrConfig.aKeyBuffer.length) {
                this._writeLog(
                  "KeyBuffer: concatenating keys. Config used: " +
                    oCurrConfig.name
                );

                for (var j = 0; j < oCurrConfig.aKeyBuffer.length; j++) {
                  // We exclude any enters
                  if (oCurrConfig.aKeyBuffer[j].keyCode !== 13) {
                    this._writeLog(
                      "KeyBuffer: added " +
                        oCurrConfig.aKeyBuffer[j].keyCode +
                        " to concatenation."
                    );
                    sBarcode += String.fromCharCode(
                      oCurrConfig.aKeyBuffer[j].keyCode
                    );
                  }
                }

                this._writeLog("KeyBuffer: resulting concat > " + sBarcode);
                // When the barcode is build we broadcast it via an event via the EventBus
                this._broadcastBarcode(sBarcode);
              }
            }, this),
            this._iReadTimeout
          );
        } else {
          //
        }
      }

      return _oEvent;
    },

    //-------------------------------------
    // PRIVATE METHODS
    //-------------------------------------

    _assignKeypressFunction: function () {
      $(document).keypress(jQuery.proxy(this.onKeyReceived, this));
    },

    _deassignKeypressFunction: function () {
      $(document).off("keypress");
    },

    _broadcastBarcode: function (sBarcode) {
      if (sBarcode && typeof sBarcode === "string") {
        sap.ui.getCore().getEventBus().publish("KeyListener", "barcode", {
          barcode: sBarcode,
        });
      }
    },

    _writeLog: function (sText) {
      if (this._bActivateLogging) {
        console.indo(sText);
      }
    },
  });
});
