sap.ui.define(
  [
    "sap/ui/base/Object",
    "sap/ui/Device",
    "mobilework/libs/moment",
    "mobilework/libs/xml2json",
    "mobilework/libs/lodash",
  ],
  function (Object, Device, Mo, Xml2, Lo) {
    "use strict";
    /**
     * Controller for GDL Plugin
     * @namespace mobilework.util.GdlDoc
     * @param {sap.ui.base.Object} Object - Base class for all SAPUI5 Objects.
     * @param {sap.ui.Device} Device - Device and Feature Detection AP
     * @param {mobilework.libs.moment} Mo - Moment Lirbary file
     * @param {mobilework.libs.xml2json} Xml2 - XML2 Library file
     * @param {mobilework.libs.lodash} Lo - Loadash Library file
     * @returns {mobilework.util.GdlDoc} The instance of the GdlDoc Plugin js file
     */

    return Object.extend("mobilework.util.GdlDoc", {
      constructor: function (
        sSystemId,
        sClient,
        sUrl,
        sObjType,
        sUser,
        oParams
      ) {
        if (Device.os.name === "win") this._sApplicationId = "mobilework";
        else this._sApplicationId = "com.arcelormittal.sapmobilework.ACE";

        this._sSystemId = sSystemId;
        this._sClient = sClient;
        this._sUrl = sUrl;
        this._sObjType = sObjType;
        this._sUser = sUser;
        this._publicRelease = oParams
          .getModel("shared")
          .getProperty("/publicRelease");
        this._shared = oParams.getModel("shared");
      },

      fetchDocuments: function (aObjIds) {
        var d = jQuery.Deferred(),
          that = this,
          aDocs = [],
          _aObjIds = this._formatId(aObjIds);

        _aObjIds.forEach(function (sId) {
          aDocs.push({
            sObjType: that._sObjType,
            sObjId: sId,
            bFollowIndirectLinks: true,
            offline: true,
          });
        });

        if (
          this._shared.getProperty("/sapSettings/GDL_API_URL") ===
          "NOT_SPECIFIED"
        ) {
          return;
        }

        if (this._publicRelease) {
          d.reject({
            message: "GDL feature not available in public release.",
            success: false,
          });
        }

        if (cordova.plugins && cordova.plugins.GDLPlugin) {
          cordova.plugins.GDLPlugin.fetchDocuments(
            this._sApplicationId,
            this._sSystemId,
            this._sClient,
            this._shared.getProperty("/sapSettings/GDL_API_URL"),
            this._sUser,
            aDocs,
            jQuery.proxy(function (oData1) {
              d.resolve({
                success: true,
              });
            }, that)
          );
        } else {
          d.reject({
            message: "GDL Plugin not available.",
            success: false,
          });
        }

        return d.promise();
      },

      showDocument: function (sObjId) {
        var d = jQuery.Deferred(),
          that = this,
          oDoc = {
            sObjType: that._sObjType,
            sObjId: sObjId,
            bFollowIndirectLinks: true,
            offline: true,
          };

        oDoc.sObjId = this._formatId(oDoc.sObjId);
        if (
          this._shared.getProperty("/sapSettings/GDL_API_URL") ===
          "NOT_SPECIFIED"
        ) {
          return;
        }

        if (this._publicRelease) {
          d.reject({
            message: "GDL feature not available in public release.",
            success: false,
          });
        }

        if (cordova.plugins && cordova.plugins.GDLPlugin) {
          cordova.plugins.GDLPlugin.showDocuments(
            this._sApplicationId,
            this._sSystemId,
            this._sClient,
            this._shared.getProperty("/sapSettings/GDL_API_URL"),
            this._sUser,
            [oDoc],
            jQuery.proxy(function (oData1) {
              d.resolve({
                success: true,
              });
            }, that),

            jQuery.proxy(function (oData1) {
              console.info(oData1);
              d.reject({
                success: false,
                message: "GDL Plugin failed",
              });
            }, that)
          );
        } else {
          d.reject({
            message: "GDL Plugin not available.",
            success: false,
          });
        }

        return d.promise();
      },

      _formatId: function (vId) {
        var iOrderTargetLength = 12,
          _vId = vId;

        if (typeof vId === "string") {
          while (_vId.length < iOrderTargetLength) {
            _vId = "0" + _vId;
          }
        } else {
          for (var i = 0; i < _vId.length; i++) {
            while (_vId[i].length < iOrderTargetLength) {
              _vId[i] = "0" + _vId[i];
            }
          }
        }

        return _vId;
      },
      /**
       * Create the the object to pass to the gdl plugin by adding order number and
       * object Type from array of order number
       * @public
       * @memberOf mobilework.util.GdlDoc
       * @param {array} aObjIds  Array of order numbers
       * @returns an array of below format
       * sObjId: Id of the Sap object (e.g.: "000000032400")
       * sObjType: Sap object Type (e.g.: "SAP_65106")
       * HaslinksFlags: composed by the following elements:
       * 	- bHasLinks: informs if documents are linked on the object or on related objects (can be direct links, links on item, or indirect links)
       * 	- bHasDirectLinks: informs if documents are linked the object (can be direct links or links on item)
       */
      fetchHashLinks: async function (aObjIds) {
        // return [{
        // 	"sObjId": "000004000015",
        // 	"sObjType": "BUS2007",
        // 	"HasLinksFlags": {
        // 		"bHasDirectLinks" :true,
        // 		"bHasLinks": true
        // 	}
        // }]
        var that = this,
          aDocsHash = [],
          _aObjIds = this._formatId(aObjIds);
        _aObjIds.forEach(function (sId) {
          aDocsHash.push({
            sObjType: that._sObjType,
            sObjId: sId,
          });
        });
        if (cordova.plugins && cordova.plugins.GDLPlugin) {
          try {
            var HasLinksResult = await this.getHashLinksData(
              this._sSystemId,
              this._sClient,
              this._sApplicationId,
              aDocsHash
            );
          } catch (error) {
            throw new Error(error.message);
          }
          return HasLinksResult;
        } else {
          throw new Error("Cordova GDLPlugin doesnot exist");
        }
      },

      /**
       * Calls the cordova gdl plugin to get the data if the attachment are present
       * @public
       * @memberOf mobilework.util.GdlDoc
       * @param {string} sSapSid  SAP System Identification as known by GDL (ex: ACE)
       * @param {string} sClient : ex: 010
       * @param {string} sApplicationId  : business app ID identifier or intent id : com.arcelormittal.armp.SafetyMobile
       * @param {object} aDocsHash : Array of {sObjType:'', sObjId:''}
       * @returns a promise of the array of objects
       * sObjId: Id of the Sap object (e.g.: "000000032400")
       * sObjType: Sap object Type (e.g.: "SAP_65106")
       * HaslinksFlags: composed by the following elements:
       * 	- bHasLinks: informs if documents are linked on the object or on related objects (can be direct links, links on item, or indirect links)
       * 	- bHasDirectLinks: informs if documents are linked the object (can be direct links or links on item)
       */

      getHashLinksData: async function (
        sSystemId,
        sClient,
        sApplicationId,
        aDocsHash
      ) {
        return new Promise((resolve) => {
          var HasLinksResult = cordova.plugins.GDLPlugin.hasLinks(
            sSystemId,
            sClient,
            sApplicationId,
            aDocsHash
          );
          resolve(HasLinksResult);
        });
      },
    });
  }
);
