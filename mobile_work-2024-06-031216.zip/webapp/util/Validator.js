/*global moment:true*/
sap.ui.define(["sap/ui/base/Object"], function (Object) {
  "use strict";

  return Object.extend("mobilework.util.Validator", {
    constructor: function (component) {
      if (component) {
        this.component = component;
      }
    },

    validateNotification: function (
      oNotification,
      sMandCause,
      sMandDamage,
      sMandActiv,
      oSharedModel
    ) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oNotification.Scanid) {
        if (!oNotification.Tplnr && !oNotification.Equnr) {
          oReturn.isValid = false;
          oReturn.aFields.push("Tplnr", "Equnr");
          oReturn.sMessage = "FillInRequiredFields";
        }
      }

      if (!oNotification.Qmart) {
        oReturn.isValid = false;
        oReturn.aFields.push("Qmart");
        oReturn.sMessage = "FillInRequiredFields";
      } else {
        var aQmart = oNotification.Qmart.split(",")[0] || "";
      }

      if (!oNotification.Qmtxt) {
        oReturn.isValid = false;
        oReturn.aFields.push("Qmtxt");
        oReturn.sMessage = "FillInRequiredFields";
      }

      // if (oNotification.isQmcodRequired && !oNotification.Qmcod) {
      // 	oReturn.isValid = false;
      // 	oReturn.aFields.push("Qmcod");
      // 	oReturn.sMessage = "FillInRequiredFields";
      // }

      if (!oNotification.Shift) {
        oReturn.isValid = false;
        oReturn.aFields.push("Shift");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oNotification.Ingpr) {
        oReturn.isValid = false;
        oReturn.aFields.push("Ingrp");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oNotification.Iwerk) {
        oReturn.isValid = false;
        oReturn.aFields.push("Iwerk");
        oReturn.sMessage = "FillInRequiredFields";
      }

      // if (!oNotification.Arbpl) {
      // 	oReturn.isValid = false;
      // 	oReturn.aFields.push("Arbpl");
      // 	oReturn.sMessage = "FillInRequiredFields";
      // }

      // Reported by(pers) field set mandatatory
      // if (!oNotification.Qmnam) {
      // 	if (oSharedModel.OrderDetails) {
      // 		if (oSharedModel.OrderDetails.FrontendNotif === true) {
      // 			oReturn.isValid = false;
      // 			oReturn.aFields.push("Qmnam");
      // 			oReturn.sMessage = "FillInRequiredFields";
      // 		}
      // 	} else {
      // 		oReturn.isValid = false;
      // 		oReturn.aFields.push("Qmnam");
      // 		oReturn.sMessage = "FillInRequiredFields";
      // 	}
      // }

      if (
        sMandDamage === "X" &&
        !oNotification.Fecod &&
        aQmart !== "60" &&
        aQmart !== "50" &&
        aQmart !== "70"
      ) {
        oReturn.isValid = false;
        oReturn.aFields.push("Fecod");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (
        sMandCause === "X" &&
        !oNotification.Urcod &&
        aQmart !== "60" &&
        aQmart !== "50" &&
        aQmart !== "70"
      ) {
        oReturn.isValid = false;
        oReturn.aFields.push("Urcod");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (
        sMandActiv === "X" &&
        !oNotification.Mfcod &&
        aQmart !== "60" &&
        aQmart !== "70"
      ) {
        oReturn.isValid = false;
        oReturn.aFields.push("Mfcod");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (oSharedModel.AICFound === true) {
        if (!oNotification.Fecod) {
          oReturn.isValid = false;
          oReturn.aFields.push("Fecod");
          oReturn.sMessage = "FillInRequiredFields";
        }
        if (!oNotification.Oteil && oSharedModel.OteilVisible) {
          oReturn.isValid = false;
          oReturn.aFields.push("Oteil");
          oReturn.sMessage = "FillInRequiredFields";
        }
      }
      if (!oNotification.RepByWc) {
        oReturn.isValid = false;
        oReturn.aFields.push("RepByWc");
        oReturn.sMessage = "FillInRequiredFields";
      }
      if (aQmart === "30,DEFE") {
        if (!oNotification.AusvnDatetime) {
          oReturn.isValid = false;
          oReturn.aFields.push("AusvnDatetime");
          oReturn.sMessage = "AusvnDatetime";
        }
      }

      let mandImpacts = _.find(oSharedModel.vh.ImpactObl, {
        Ingrp: oNotification.Ingpr,
        Qmart: aQmart,
      });
      if (mandImpacts) {
        if (mandImpacts.ImpOblCo && !oNotification.QuotCoR) {
          oReturn.isValid = false;
          oReturn.aFields.push("quotcor");
          oReturn.sMessage = "quotcor";
        }
        if (mandImpacts.ImpOblDe && !oNotification.QuotDeR) {
          oReturn.isValid = false;
          oReturn.aFields.push("quotder");
          oReturn.sMessage = "quotder";
        }
        if (mandImpacts.ImpOblPr && !oNotification.QuotPrR) {
          oReturn.isValid = false;
          oReturn.aFields.push("quotprr");
          oReturn.sMessage = "quotprr";
        }
        if (mandImpacts.ImpOblQa && !oNotification.Pmqual) {
          oReturn.isValid = false;
          oReturn.aFields.push("Pmqual");
          oReturn.sMessage = "Pmqual";
        }
        if (mandImpacts.ImpOblSa && !oNotification.Pmsafe) {
          oReturn.isValid = false;
          oReturn.aFields.push("Pmsafe");
          oReturn.sMessage = "Pmsafe";
        }
        if (mandImpacts.ImpOblEv && !oNotification.Pmenvr) {
          oReturn.isValid = false;
          oReturn.aFields.push("Pmenvr");
          oReturn.sMessage = "Pmenvr";
        }
        if (mandImpacts.ImpOblWc && !oNotification.QuotWcR) {
          oReturn.isValid = false;
          oReturn.aFields.push("quotwcr");
          oReturn.sMessage = "quotwcr";
        }
      }

      return oReturn;
    },

    validateNotificationBreakdown: function (oNotification) {
      if (oNotification.AusvnDatetime && oNotification.AusbsDatetime) {
        var sBrdStart = new moment(oNotification.AusvnDatetime)
          .utc()
          .toDate()
          .getTime();
        var sBrdEnd = new moment(oNotification.AusbsDatetime)
          .utc()
          .toDate()
          .getTime();

        if (sBrdEnd < sBrdStart) {
          return "InvalidBreakdown";
        }
      }
    },

    validateConfirmation: function (oConfirmation, oSharedModel, bValidate) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oConfirmation.NotifHandle && !oConfirmation.FromOrderHeader) {
        if (!oConfirmation.Aufnr) {
          oReturn.isValid = false;
          oReturn.aFields.push("Aufnr");
          oReturn.sMessage = "FillInRequiredFields";
        }
        if (!oConfirmation.Vornr && bValidate) {
          oReturn.isValid = false;
          oReturn.aFields.push("Vornr");
          oReturn.sMessage = "FillInRequiredFields";
        }
      } else {
        if (
          !oConfirmation.PersNo &&
          oSharedModel &&
          oSharedModel.getProperty("/sapSettings/persNoNotRequired") === false
        ) {
          oReturn.isValid = false;
          oReturn.aFields.push("PersNo");
          oReturn.sMessage = "FillInRequiredFields";
        }

        if (oConfirmation.NotifHandle) {
          if (!oConfirmation.Pmacttype) {
            oReturn.isValid = false;
            oReturn.aFields.push("PMActType");
            oReturn.sMessage = "FillInRequiredFields";
          }
        } else if (oConfirmation.FromOrderHeader) {
          if (!oConfirmation.Aufnr) {
            oReturn.isValid = false;
            oReturn.aFields.push("Aufnr");
            oReturn.sMessage = "FillInRequiredFields";
          }
        }
      }

      if (!oConfirmation.Plant) {
        oReturn.isValid = false;
        oReturn.aFields.push("Plant");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.WorkCntr) {
        oReturn.isValid = false;
        oReturn.aFields.push("WorkCntr");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.ConfText) {
        // oReturn.isValid = false;
        // oReturn.aFields.push("ConfText");
        // oReturn.sMessage = "FillInRequiredFields";
      } else if (oConfirmation.ConfText.length > 40) {
        oReturn.isValid = false;
        oReturn.aFields.push("ConfText");
        oReturn.sMessage = "ConfTextTooLong";
      }

      return oReturn;
    },

    validateConfirmationFinalize: function (oConfirmation, oSharedModel) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oConfirmation.NotifHandle && !oConfirmation.FromOrderHeader) {
        if (!oConfirmation.Aufnr) {
          oReturn.isValid = false;
          oReturn.aFields.push("Aufnr");
          oReturn.sMessage = "FillInRequiredFields";
        }
      } else {
        if (oConfirmation.NotifHandle) {
          if (!oConfirmation.Pmacttype) {
            oReturn.isValid = false;
            oReturn.aFields.push("PMActType");
            oReturn.sMessage = "FillInRequiredFields";
          }
        } else if (oConfirmation.FromOrderHeader) {
          if (!oConfirmation.Aufnr) {
            oReturn.isValid = false;
            oReturn.aFields.push("Aufnr");
            oReturn.sMessage = "FillInRequiredFields";
          }
        }
      }

      if (
        !oConfirmation.PersNo &&
        oSharedModel &&
        oSharedModel.getProperty("/sapSettings/persNoNotRequired") === false
      ) {
        oReturn.isValid = false;
        oReturn.aFields.push("PersNo");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Plant) {
        oReturn.isValid = false;
        oReturn.aFields.push("Plant");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.WorkCntr) {
        oReturn.isValid = false;
        oReturn.aFields.push("WorkCntr");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.ConfText) {
        if (
          oSharedModel &&
          oSharedModel.getProperty("/sapSettings/FILL_CONFT") === "X"
        ) {
          oReturn.isValid = false;
          oReturn.aFields.push("ConfText");
          oReturn.sMessage = "FillInRequiredFields";
        }
      } else if (oConfirmation.ConfText.length > 40) {
        oReturn.isValid = false;
        oReturn.aFields.push("ConfText");
        oReturn.sMessage = "ConfTextTooLong";
      }

      return oReturn;
    },

    validateQuickSettings: function (oSettings) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oSettings.host) {
        oReturn.isValid = false;
        oReturn.aFields.push("host");
      }

      if (!oSettings.deviceName) {
        oReturn.isValid = false;
        oReturn.aFields.push("device");
      }

      if (!oSettings.sapClient) {
        oReturn.isValid = false;
        oReturn.aFields.push("sapClient");
      }

      return oReturn;
    },

    validatePublicConfirmation: function (
      aConfirmation,
      shared,
      local,
      partcipants,
      timeNow
    ) {
      //PERRNNOTreq === false do this else disregard
      let order,
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        },
        execStart = "",
        execFin = "",
        currentTime = new moment().utc().toDate().getTime();
      if (!shared.getProperty("/sapSettings/ZoneBadging")) {
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        };
        return oReturn;
      }
      if (!partcipants) {
        partcipants = aConfirmation.PersNo
          ? typeof aConfirmation.PersNo === "object"
            ? aConfirmation.PersNo
            : [aConfirmation.PersNo]
          : [];
      } else {
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        };
      }
      if (aConfirmation.Aufnr) {
        order = _.find(local.getProperty("/PMOrderSetDataWithConf"), {
          Orderid: aConfirmation.Aufnr,
        });
      } else {
        let notif = _.find(local.getProperty("/PMNotificationSet"), {
          Handle: aConfirmation.NotifHandle,
        });
        if (notif.OrderHandle) {
          order = _.find(local.getProperty("/PMOrderSetDataWithConf"), {
            Orderid: notif.OrderHandle,
          });
        } else {
          order = _.find(local.getProperty("/PublicFuncLocOrg"), {
            Tplnr: notif.Tplnr,
          });
        }
      }

      let sPartcipants = [];
      if (order && order.TrZone) {
        /*BEGIN: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
        //Child Confirmation were taking parent confirmations's start time to check TRs
        let bConfirmations = [];
        if (aConfirmation.Split === true || aConfirmation.Split === "true") {
          bConfirmations = aConfirmation.ChildConfirmations.filter(
            (a) => a.ExecStart
          );
        } else {
          bConfirmations.push(aConfirmation);
        }
        let currentTimeEx = false;
        bConfirmations.forEach(
          function (oConfirmation) {
            if (
              oConfirmation.Hidden === true ||
              oConfirmation.Hidden === "true"
            ) {
              partcipants = [oConfirmation.PersNo];
            }

            execStart = "";
            execFin = "";
            /*END: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/

            if (oConfirmation.ExecStart) {
              execStart = new moment(oConfirmation.ExecStart)
                .utc()
                .toDate()
                .getTime();
              if (execStart > currentTime) {
                currentTimeEx = true;
                return (oReturn = {
                  isValid: false,
                  isImportant: true,
                  //sMessage: "Start date/time may not be after current date/time"
                  sMessage: this.component
                    .getModel("i18n")
                    .getResourceBundle()
                    .getText("PNotInZoneCurrentStart"),
                });
              }
            }
            if (oConfirmation.ExecFin) {
              execFin = new moment(oConfirmation.ExecFin)
                .utc()
                .toDate()
                .getTime();
              if (execFin > currentTime) {
                currentTimeEx = true;
                return (oReturn = {
                  isValid: false,
                  isImportant: true,
                  sMessage: this.component
                    .getModel("i18n")
                    .getResourceBundle()
                    .getText("PNotInZoneCurrent"),
                  //sMessage: "End date/time may not be after current date/time"
                });
              }
            }

            partcipants.forEach(function (pernr) {
              let oFilter = function (row) {
                if (
                  row.Pernr === pernr &&
                  row.TimeOut === "" &&
                  row.TimeIn &&
                  order.TrZone === row.TrZone
                ) {
                  let start, end;
                  if (oConfirmation.ExecStart) {
                    start = execStart;
                  } else if (
                    timeNow === "onStartPress" ||
                    timeNow === "onStartPersonPress"
                  ) {
                    start = currentTime;
                  }
                  if (start && row.TimeIn <= start) {
                    if (oConfirmation.ExecFin) {
                      end = new moment(oConfirmation.ExecFin)
                        .utc()
                        .toDate()
                        .getTime();
                    } else if (
                      timeNow === "onStopPress" ||
                      timeNow === "onStopPersonPress"
                    ) {
                      end = currentTime;
                    }
                    if (end) {
                      if (end <= currentTime) {
                        return true;
                      } else {
                        return false;
                      }
                    } else {
                      return true;
                    }
                  } else {
                    return !oConfirmation.ExecStart;
                  }
                } else {
                  return false;
                }
              };
              if (!local.getProperty("/TimeInOut").some(oFilter)) {
                if (pernr && !sPartcipants.includes(pernr)) {
                  sPartcipants.push(pernr);
                }
              }
            });
            /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 
            when splicing happens data gets erased from sPartcipants. Thus affecting foreach loop below*/
              let aPartcipants = sPartcipants.map((x) => x);
            /*END: Date: 17/03/2024 AMID: A0866990 Version */
           
            if (partcipants && aPartcipants) {
              _.forEach(aPartcipants, function (pernr) {
                let localTrs = local.getProperty("/TimeInOut").filter((trs)=>{return pernr === trs.Pernr})
                if (
                  !_.find(localTrs, function (row) {
                    let a = false,
                      b = false;
                    if (order.TrZone !== row.TrZone) {
                      return false;
                    }
                    if (oConfirmation.ExecStart) {
                      let start = execStart;
                      if (row.TimeIn <= start && row.TimeOut >= start) {
                        a = true;
                      }
                    }

                    if (
                      oConfirmation.ExecFin ||
                      timeNow === "onStopPress" ||
                      timeNow === "onStopPersonPress"
                    ) {
                      let end;
                      if (oConfirmation.ExecFin) {
                        end = execFin;
                      } else {
                        end = currentTime;
                      }

                      if (row.TimeIn <= end && row.TimeOut >= end) {
                        b = true;
                      }
                    } else {
                      b = true;
                    }
                    return a && b;
                  })
                ) {
                  if (pernr && !sPartcipants.includes(pernr)) {
                    sPartcipants.push(pernr);
                  }
                } else {
                  if (pernr) {
                    sPartcipants.splice(sPartcipants.indexOf(pernr), 1);
                  }
                }
              });
            }
          }.bind(this)
        );
        if (currentTimeEx) {
          return oReturn;
        }

        if (!sPartcipants.length) {
          oReturn = {
            isValid: true,
            isImportant: false,
            aFields: [],
            sMessage: "",
          };
        } else {
          var aParticipantNames = [],
            oParticipantsSet = shared.getProperty("/ParticipantSet");
          sPartcipants.forEach(function (sEmployeeId) {
            var oEmployee = oParticipantsSet.find(function (oParticipant) {
              return oParticipant.sKey === sEmployeeId;
            });
            if (oEmployee) {
              aParticipantNames.push(oEmployee.sName);
            } else {
              aParticipantNames.push(sEmployeeId);
            }
          });
          var message = "";
          if (aConfirmation.ExecStart) {
            message = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("PinZoneStart", [aParticipantNames, order.TrZone]);
          } else if (
            timeNow === "onStartPress" ||
            timeNow === "onStartPersonPress"
          ) {
            message = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("PinZoneStart", [aParticipantNames, order.TrZone]);
          }
          if (aConfirmation.ExecFin) {
            message = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("PinZoneEnd", [aParticipantNames, order.TrZone]);
          } else if (
            timeNow === "onStopPress" ||
            timeNow === "onStopPersonPress"
          ) {
            message = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("PinZoneEnd", [aParticipantNames, order.TrZone]);
          }
          if (!message) {
            message = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("PNotInZone", [aParticipantNames, order.TrZone]);
          }
          oReturn = {
            isValid: false,
            isImportant: false,
            aFields: [],
            sMessage: message,
          };
        }
      } else {
        oReturn = {
          isValid: false,
          isImportant: false,
          aFields: [],
          sMessage: this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("NoZoneForOrder"),
          //sMessage: "There is no zone linked to the functional location of the order. Time confirmation is not possible. Contact your key-user"
        };
      }
      return oReturn;
    },

    /*BEGIN: Date: 24/01/2024 AMID: A0866990 13.1 mwx Bug Number: 22*/
    validatePublicTS: function (
      aConfirmation,
      shared,
      local,
      partcipants,
      timeNow
    ) {
      //PERRNNOTreq === false do this else disregard
      let order,
        message,
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        },
        execStart = "",
        execFin = "",
        currentTime = new moment().utc().toDate().getTime();
      if (!shared.getProperty("/sapSettings/ZoneBadging")) {
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        };
        return oReturn;
      }
      if (!partcipants) {
        partcipants = aConfirmation.Pernr
          ? typeof aConfirmation.Pernr === "object"
            ? aConfirmation.Pernr
            : [aConfirmation.Pernr]
          : [];
      } else {
        oReturn = {
          isValid: true,
          isImportant: false,
          aFields: [],
          sMessage: "",
        };
      }

      let sPartcipants = [];

      // if (aConfirmation.TrZone) {
        let bConfirmations = [];
        if (aConfirmation.Split === true || aConfirmation.Split === "true") {
          bConfirmations = aConfirmation.ChildConfirmations.filter(
            (a) => a.PlDate
          );
        } else {
          bConfirmations.push(aConfirmation);
        }
        bConfirmations.forEach(
          function (oConfirmation) {
            sPartcipants = [];
            if (aConfirmation.RowExcel === "X") {
              partcipants = [oConfirmation.Pernr];
            }

            execStart = "";
            execFin = "";
            let forCurrent;
            if (oConfirmation.PlDate) {
              execStart = new moment(oConfirmation.PlDate)
                .utc()
                .toDate()
                .getTime();
                
              if (execStart > currentTime) {
                return (oReturn = {
                  isValid: false,
                  isImportant: true,
                  //sMessage: "Start date/time may not be after current date/time"
                  sMessage: this.component
                    .getModel("i18n")
                    .getResourceBundle()
                    .getText("PNotInZoneCurrentStart"),
                });
              }
            }
            if (oConfirmation.EndDate) {
              execFin = new moment(oConfirmation.EndDate)
                .utc()
                .toDate()
                .getTime();
              if (execFin > currentTime) {
                return (oReturn = {
                  isValid: false,
                  isImportant: true,
                  sMessage: this.component
                    .getModel("i18n")
                    .getResourceBundle()
                    .getText("PNotInZoneCurrent"),
                  //sMessage: "End date/time may not be after current date/time"
                });
              }
            }

            partcipants.forEach(function (pernr) {
              let oFilter = function (row) {
                if (
                  row.Pernr === pernr &&
                  row.TimeOut === "" &&
                  row.TimeIn &&
                  /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 Bug Number: 42
                  Zone need not be matched in case allzone is true. Just the partcipant have to be in zone that's it*/
                  (oConfirmation.TrZone === row.TrZone || oConfirmation.AllZone ==='true' || !oConfirmation.TrZone )
                ) {
                  let start, end;
                  if (oConfirmation.PlDate) {
                    start = execStart;
                  } else if (
                    timeNow === "onStartPress" ||
                    timeNow === "onStartPersonPress"
                  ) {
                    start = currentTime;
                  }
                  if (start && row.TimeIn <= start) {
                    if (oConfirmation.EndDate) {
                      end = new moment(oConfirmation.EndDate)
                        .utc()
                        .toDate()
                        .getTime();
                    } else if (
                      timeNow === "onStopPress" ||
                      timeNow === "onStopPersonPress"
                    ) {
                      end = currentTime;
                    }
                    if (end) {
                      if (end <= currentTime) {
                        return true;
                      } else {
                        return false;
                      }
                    } else {
                      return true;
                    }
                  } else {
                    return !oConfirmation.PlDate;
                  }
                } else {
                  return false;
                }
              };
              if (!local.getProperty("/TimeInOut").some(oFilter)) {
                if (pernr && !sPartcipants.includes(pernr)) {
                  sPartcipants.push(pernr);
                  forCurrent = true;
                }
              }
            });
            /*BEGIN: Date: 17/03/2024 AMID: A0866990 13.1 
            when splicing happens data gets erased from sPartcipants. Thus affecting foreach loop below*/
            let aPartcipants = sPartcipants.map((x) => x);
            /*END: Date: 17/03/2024 AMID: A0866990 Version */
            if (partcipants && aPartcipants) {
              _.forEach(aPartcipants, function (pernr) {
                let localTrs = local.getProperty("/TimeInOut").filter((trs)=>{return pernr === trs.Pernr})
                if (
                  !_.find(localTrs, function (row) {
                    let a = false,
                      b = false;
                    // if(oConfirmation.TrZone===''){
                    //   return false;
                    // }
                    // if(!oConfirmation.TrZone){
                    //   return false;
                    // }
                    if (oConfirmation.TrZone !== row.TrZone && (oConfirmation.AllZone ==='false' || oConfirmation.TrZone) ) {
                      return false;
                    }
                   
                    if (
                      oConfirmation.PlDate ||
                      timeNow === "onStartPress" ||
                      timeNow === "onStartPersonPress"
                    ) {
                      let start = execStart ? execStart : currentTime;
                      if (row.TimeIn <= start && row.TimeOut >= start) {
                        a = true;
                      }
                    }

                    if (
                      oConfirmation.EndDate ||
                      timeNow === "onStopPress" ||
                      timeNow === "onStopPersonPress"
                    ) {
                      let end;
                      if (oConfirmation.EndDate) {
                        end = execFin;
                      } else {
                        end = currentTime;
                      }

                      if (row.TimeIn <= end && row.TimeOut >= end) {
                        b = true;
                      }
                    } else {
                      b = true;
                    }
                    return a && b;
                  })
                ) {
                  if (pernr && !sPartcipants.includes(pernr)) {
                    sPartcipants.push(pernr);
                    forCurrent = true;
                  }
                } else {
                  if (pernr) {
                    sPartcipants.splice(sPartcipants.indexOf(pernr), 1);
                    forCurrent = false;
                  }
                }
              });
            }
            if (aConfirmation.RowExcel === "X" && forCurrent) {
              message = message
                ? message +
                  "\n" +
                  this.createMessage(
                    oConfirmation,
                    shared,
                    sPartcipants,
                    timeNow
                  )
                : this.createMessage(
                    oConfirmation,
                    shared,
                    sPartcipants,
                    timeNow
                  );
              oReturn = {
                isValid: false,
                isImportant: false,
                aFields: [],
                sMessage: message,
              };
            } else if (aConfirmation.RowExcel !== "X") {
              if (!sPartcipants.length) {
                oReturn = {
                  isValid: true,
                  isImportant: false,
                  aFields: [],
                  sMessage: "",
                };
              } else {
                message = this.createMessage(
                  oConfirmation,
                  shared,
                  sPartcipants,
                  timeNow
                );
                oReturn = {
                  isValid: false,
                  isImportant: false,
                  aFields: [],
                  sMessage: message,
                };
              }
            }
          }.bind(this)
        );
        /*BEGIN: Date: 11/05/2024 AMID: A0866990 13.1 Bug Number: 48 - New Scenario where no zone is treated as All Zone*/
      // } else {
      //   oReturn = {
      //     isValid: false,
      //     isImportant: true,
      //     aFields: [],
      //     sMessage: this.component
      //       .getModel("i18n")
      //       .getResourceBundle()
      //       .getText("NoZoneForOrder"),
      //     //sMessage: "There is no zone linked to the functional location of the order. Time confirmation is not possible. Contact your key-user"
      //   };
     // }
      return oReturn;
    },

    validateTimeSheets: function (oConfirmation, oSharedModel) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oConfirmation.PoNr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PoNr");
        oReturn.sMessage = "FillInRequiredFields";
      }
      if (!oConfirmation.PoPosNr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PoPosNr");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Pernr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PersNo");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Service) {
        oReturn.isValid = false;
        oReturn.aFields.push("Service");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Werks) {
        oReturn.isValid = false;
        oReturn.aFields.push("Plant");
        oReturn.sMessage = "FillInRequiredFields";
      }

      // if (!oConfirmation.PlComment) {
      // 	oReturn.isValid = false;
      // 	oReturn.aFields.push("PlComment");
      // 	oReturn.sMessage = "FillInRequiredFields";
      // }
      // if (!oConfirmation.TrZone) {
      //   oReturn.isValid = false;
      //   oReturn.aFields.push("TrZone");
      //   oReturn.sMessage = "FillInRequiredFields";
      // }

      return oReturn;
    },

    validateFinalTimeSheets: function (oConfirmation, oSharedModel) {
      var oReturn = {
        isValid: true,
        aFields: [],
        sMessage: "",
      };

      if (!oConfirmation.PoNr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PoNr");
        oReturn.sMessage = "FillInRequiredFields";
      }
      if (!oConfirmation.PoPosNr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PoPosNr");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Pernr) {
        oReturn.isValid = false;
        oReturn.aFields.push("PersNo");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Service) {
        oReturn.isValid = false;
        oReturn.aFields.push("Service");
        oReturn.sMessage = "FillInRequiredFields";
      }

      if (!oConfirmation.Werks) {
        oReturn.isValid = false;
        oReturn.aFields.push("Plant");
        oReturn.sMessage = "FillInRequiredFields";
      }

      // if (!oConfirmation.TrZone) {
      //   oReturn.isValid = false;
      //   oReturn.aFields.push("TrZone");
      //   oReturn.sMessage = "FillInRequiredFields";
      // }
      // if (!oConfirmation.PlComment) {
      //   oReturn.isValid = false;
      //   oReturn.aFields.push("PlComment");
      //   oReturn.sMessage = "FillInRequiredFields";
      // }
      if (!oConfirmation.Quantity && oConfirmation.Quantity !== 0 && oConfirmation.RowExcel !== "X") {
        oReturn.isValid = false;
        oReturn.aFields.push("Quantity");
        oReturn.sMessage = "FillInRequiredFields";
      }
      if (!oConfirmation.PlDate) {
        oReturn.isValid = false;
        oReturn.aFields.push("PlDate");
        oReturn.sMessage = "FillInRequiredFields";
      }
      // if (!oConfirmation.PlComment ) {
      // 	oReturn.isValid = false;
      // 	oReturn.aFields.push("PlComment");
      // 	oReturn.sMessage = "FillInRequiredFields";
      // }

      return oReturn;
    },
    createMessage: function (oConfirmation, shared, sPartcipants, timeNow) {
      var aParticipantNames = [],
        oParticipantsSet = shared.getProperty("/ParticipantSet");
      sPartcipants.forEach(function (sEmployeeId) {
        var oEmployee = oParticipantsSet.find(function (oParticipant) {
          return oParticipant.sKey === sEmployeeId;
        });
        if (oEmployee) {
          aParticipantNames.push(oEmployee.sName);
        } else {
          aParticipantNames.push(sEmployeeId);
        }
      });

      var message = "";
      if (oConfirmation.PlDate) {
        message = this.component
          .getModel("i18n")
          .getResourceBundle()
          .getText("PinZoneStart", [aParticipantNames, oConfirmation.TrZone]);
      } else if (
        timeNow === "onStartPress" ||
        timeNow === "onStartPersonPress"
      ) {
        message = this.component
          .getModel("i18n")
          .getResourceBundle()
          .getText("PinZoneStart", [aParticipantNames, oConfirmation.TrZone]);
      }
      if (oConfirmation.EndDate) {
        message = this.component
          .getModel("i18n")
          .getResourceBundle()
          .getText("PinZoneEnd", [aParticipantNames, oConfirmation.TrZone]);
      } else if (timeNow === "onStopPress" || timeNow === "onStopPersonPress") {
        message = this.component
          .getModel("i18n")
          .getResourceBundle()
          .getText("PinZoneEnd", [aParticipantNames, oConfirmation.TrZone]);
      } else if (!message && sPartcipants.length) {
        message = this.component
          .getModel("i18n")
          .getResourceBundle()
          .getText("PNotInZone", [aParticipantNames, oConfirmation.TrZone]);
      }
      return message;
    },
    /*END: Date: 24/01/2024 AMID: A0866990 13.1 mwx Bug Number: 22*/
  });
});
