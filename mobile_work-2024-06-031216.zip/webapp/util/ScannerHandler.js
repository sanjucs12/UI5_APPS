/*global device:true*/
/*global nfc:true*/
/*global Honeywell:true*/
sap.ui.define(
  ["sap/ui/base/Object", "sap/m/MessageBox", "mobilework/util/Helper"],
  function (Object, MBox, Helper) {
    "use strict";

    return Object.extend("mobilework.util.ScannerHandler", {
      constructor: function (oParams) {
        this._oHelper = new Helper();
        this._sLocation = "main";
        this._oEventBus = sap.ui.getCore().getEventBus();
        this._oResourceBundle = oParams.getModel("i18n").getResourceBundle();
        document.addEventListener(
          "resume",
          jQuery.proxy(this._activatePanasonic, this),
          false
        );

        let bPublicRelease = oParams
          .getModel("shared")
          .getProperty("/publicRelease");

        if (!this._oHelper.isDevModeActive() && !bPublicRelease) {
          switch (device.manufacturer.toUpperCase()) {
            case "HONEYWELL":
              this._activateHoneyAndroid();
              break;
            case "PANASONIC":
              this._activatePanasonic();
              break;
            default:
              this._activateKeyListener();
          }
          this._activateNFC();
        } else if (!this._oHelper.isDevModeActive() && bPublicRelease) {
          this._activateKeyListener();
          this._activateNFC();
        }
      },

      scan: function () {
        var d = jQuery.Deferred();

        cordova.plugins.barcodeScanner.scan(
          function (oData) {
            d.resolve(oData);
          },
          function (oError) {
            d.reject(oError);
          },
          {
            preferFrontCamera: false, // iOS and Android
            showFlipCameraButton: true, // iOS and Android
            prompt: this._oResourceBundle.getText("CameraScanPrompt"), // supported on Android only
            orientation: "landscape", // Android only (portrait|landscape), default unset so it rotates with the device
          }
        );

        return d.promise();
      },

      setLocation: function (sLocation) {
        this._sLocation = sLocation;
      },

      //---------------------------------
      // EXT. SCAN ACTIVATION
      //---------------------------------

      _broadcastScan: function (oResult) {
        this._oEventBus.publish("scanner", "scanned" + this._sLocation, {
          result: oResult,
        });
      },

      // Honeywell - dff-cordova-plugin-honeywell
      //==========================================

      _activateHoneyAndroid: function () {
        if (Honeywell && Honeywell.onBarcodeEvent) {
          Honeywell.onBarcodeEvent(
            //success
            jQuery.proxy(function (oData) {
              this._broadcastScan({
                error: false,
                barcode: oData.barcodeData,
              });
            }, this),
            //error
            jQuery.proxy(function (oError) {
              this._broadcastScan({
                error: true,
                errorMessage: oError,
              });
            }, this)
          );
        }
      },

      // Panasonic - PanasonicScanner
      //==========================================

      _activatePanasonic: function () {
        if (cordova.plugins !== undefined && cordova.plugins.PanasonicScanner) {
          cordova.plugins.PanasonicScanner.activate(
            {},
            jQuery.proxy(function (sBarcode) {
              this._broadcastScan({
                error: false,
                barcode: sBarcode,
              });
            }, this),
            jQuery.proxy(function (oError) {
              this._broadcastScan({
                error: true,
                errorMessage: oError.toString(),
              });
            }, this)
          );
        }
      },

      deactivatePanasonicScanner: function () {
        if (cordova.plugins !== undefined && cordova.plugins.PanasonicScanner) {
          cordova.plugins.PanasonicScanner.deactivate(
            {},
            jQuery.proxy(function (result) {
              //this.scannerHandler(result);
            }, this),
            jQuery.proxy(function (oError) {
              //this.panasonicScannerErrorHandler(error);
              // this._broadcastScan({
              // 	error: true,
              // 	errorMessage: oError.toString()
              // });
              console.error(oError.toString());
            }, this)
          );
        }
      },

      // Generic Key Listener - KeyListener.js
      //==========================================

      _activateKeyListener: function () {
        sap.ui
          .getCore()
          .getEventBus()
          .subscribe(
            "KeyListener",
            "barcode",
            jQuery.proxy(function (sChannel, sEvent, oResult) {
              this._broadcastScan({
                error: false,
                barcode: oResult.barcode,
              });
            }, this),
            this
          );
      },

      // NFC Tag Reader - phonegap-nfc
      //==========================================

      _activateNFC: function () {
        //	nfc.addTagDiscoveredListener(jQuery.proxy(this.onNfcRead, this), function () {}, jQuery.proxy(this.onNfcError, this));
        nfc.addNdefListener(
          jQuery.proxy(this.onNfcReadNDEF, this),
          function () {},
          jQuery.proxy(this.onNfcError, this)
        );
      },
      onNfcReadNDEF: function (oEvent) {
        if (ndef) {
          var result = ndef.textHelper.decodePayload(
            oEvent.tag.ndefMessage[0].payload
          );
        }
        //var result="00000004";
        if (result) {
          this._broadcastScan({
            error: false,
            barcode: result,
          });
        }
      },

      onNfcError: function (oEvent) {
        this._broadcastScan({
          error: true,
          barcode: oEvent,
        });
      },
    });
  }
);
