/*global moment:true*/
/*global Connection:true*/
/*global X2JS:true*/
/*global _:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel",
    "mobilework/libs/moment",
    "mobilework/libs/xml2json",
    "mobilework/libs/lodash",
    "sap/ui/model/odata/type/Time",
  ],
  function (Object, JSONModel, Mo, Xml2, Lo, UI5Date) {
    "use strict";

    return Object.extend("mobilework.util.Helper", {
      // publicRelease: true,

      constructor: function (oRunConfigurationModel) {
        if (oRunConfigurationModel !== undefined) {
          this.publicRelease =
            oRunConfigurationModel.getProperty("/publicRelease");
          this.cloudSystem = oRunConfigurationModel.getProperty("/cloudSystem");
        } else {
          // Only create 1 helper instance & provide the runconfigurationmodel input
          console.warn(
            "only use 1 helper instance that is created with the run configuration model"
          );
        }
      },

      isDevModeActive: function () {
        if (
          window.location.href.indexOf("webidetesting") !== -1 ||
          window.location.href.indexOf("hana.ondemand.com") !== -1 ||
          window.location.href.indexOf("localhost") !== -1 ||
          window.location.href.indexOf("-workspaces-") !== -1
        ) {
          return true;
        }

        return false;
      },

      isOnline: function () {
        // Replace by metadata object of oModel in service object ==> checks every 3 seconds for connection
        if (this.isDevModeActive()) {
          return true;
        } else {
          // TODO > check status with interval
          var sNetworkState = navigator.connection.type,
            aAllowedConnections = [
              Connection.WIFI,
              Connection.ETHERNET,
              Connection.CELL_4G,
              Connection.CELL,
            ];
          if (Connection) {
            if (aAllowedConnections.indexOf(sNetworkState) !== -1) {
              return true;
            } else {
              return false;
            }
          }
        }
      },

      checkFinalConfExists: function (
        aConfirmations,
        sAufnr,
        sVornr,
        sSubActivity
      ) {
        var bExists = false,
          aFinalConfirms;

        // get all finished confirmations for given order number
        aFinalConfirms = _.filter(aConfirmations, {
          Aufnr: sAufnr,
          FinConf: true,
        });

        // if sVornr is not provided, confirmation is done on order header level
        if (sAufnr && !sVornr) {
          // for order header level if a fin conf exists for either header or operation level -> bExists = true
          if (aFinalConfirms.length > 0) {
            bExists = true;
          }
        } else if (sAufnr && sVornr) {
          // for oper level if a fin conf exists for either header level or same operation -> bExists = true
          aFinalConfirms.forEach(function (oFinConf) {
            if (
              !oFinConf.Vornr ||
              (oFinConf.Vornr === sVornr &&
                oFinConf.SubActivity === sSubActivity)
            ) {
              bExists = true;
            }
          });
        }
        return bExists;
      },

      checkFinalConfExistsOnOperation: function (
        aConfirmations,
        sAufnr,
        sVornr,
        sSubActivity
      ) {
        var bExists = false,
          aFinalConfirms;

        // get all finished confirmations for given order number
        aFinalConfirms = _.filter(aConfirmations, {
          Aufnr: sAufnr,
          FinConf: true,
        });

        // if sVornr is not provided, confirmation is done on order header level
        if (sAufnr && !sVornr) {
          // for order header level if a fin conf exists for either header or operation level -> bExists = true
          if (aFinalConfirms.length > 0) {
            bExists = true;
          }
        } else if (sAufnr && sVornr) {
          // for oper level if a fin conf exists for either header level or same operation -> bExists = true
          aFinalConfirms.forEach(function (oFinConf) {
            if (
              oFinConf.Vornr === sVornr &&
              oFinConf.SubActivity === sSubActivity
            ) {
              bExists = true;
            }
          });
        }
        return bExists;
      },

      checkOperationValid: function (sAufnr, oOperation) {
        var bControlKeyIsValid = true,
          bPMEXValid = true,
          oReturn = {};

        if (
          oOperation.ControlKey === "PMST" ||
          oOperation.ControlKey === "WCM"
        ) {
          bControlKeyIsValid = false;
        } else {
          bControlKeyIsValid = true;
        }

        if (
          oOperation.ControlKey === "PMEX" &&
          oOperation.ContainsCosts &&
          (oOperation.ContainsCosts === "true" ||
            oOperation.ContainsCosts === true)
        ) {
          bPMEXValid = false;
        } else {
          bPMEXValid = true;
        }

        oReturn.ControlKeyIsValid = bControlKeyIsValid;
        oReturn.PMEXValid = bPMEXValid;

        return oReturn;
      },

      createTree: function (aData, sKey, sForeignKey, sChildProp, sort, type) {
        var aGroup = _.groupBy(aData, sForeignKey);
        for (var x = 0; x < aData.length; x++) {
          if (type && aData[x][type] === "MA") {
            var parent =
              "M" +
              aData[x][sKey].slice(
                0,
                aData[x][sKey].indexOf(aData[x][sForeignKey])
              );
            aData[x][sChildProp] = aGroup[parent];
          } else aData[x][sChildProp] = aGroup[aData[x][sKey]];
        }

        var aFinal = [];

        if (aData.length > 1) {
          for (var y = 0; y < aData.length; y++) {
            if (
              (aData[y][sChildProp] !== undefined &&
                aData[y]["TechObjectType"] === "IF") ||
              aData[y][sForeignKey] === ""
            ) {
              aFinal.push(aData[y]);
            }
          }
        } else {
          aFinal.push(aData[0]);
        }
        if (sort) {
          return this.onSortTreeTable(aFinal, "outsideLayerSort");
        } else {
          return aFinal;
        }
      },

      getCatalogKey: function (sProperty) {
        var _sProperty = sProperty.toUpperCase();
        switch (_sProperty) {
          case "QMCOD":
            return "D";
          case "FECOD":
            return "C";
          case "URCOD":
            return "5";
          case "MFCOD":
            return "A";
          // return "2";
          case "MNCOD":
            return "2";
          // return "A";
          case "OTEIL":
            return "B";
          default:
            return "";
        }
      },

      getBaseLocation: function () {
        if (!this.isDevModeActive()) {
          var sPlatform = cordova.platformId.toLowerCase(),
            sLocation = "";

          switch (sPlatform) {
            case "android":
              sLocation = cordova.file.externalDataDirectory;
              break;
            case "ios":
              sLocation = cordova.file.dataDirectory;
              break;
            case "windows":
              sLocation = cordova.file.dataDirectory;
              break;
            default:
              sLocation = "config/";
              break;
          }

          return sLocation;
        } else {
          return "config/";
        }
      },

      getConfigLocation: function () {
        var sLocation = this.getBaseLocation();

        return sLocation + "sapSettings.json";
      },

      getUUID: function () {
        var uuid = "",
          possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

        uuid = new Date().getTime().toString();

        for (var i = 0; i < 3; i++) {
          uuid += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        return uuid;
      },

      rowsToArray: function (oRows) {
        var aReturn = [];

        for (var i = 0; i < oRows.rows.length; i++) {
          aReturn.push(oRows.rows.item(i));
        }

        return aReturn;
      },

      mapNotifications: function (aNotifications, sWorkHandle, aConfitmations) {
        aNotifications.map(
          function (oItem) {
            var _oItem = oItem;
            _oItem.Workhandle = sWorkHandle;

            if (!oItem.AusvnDatetime) {
              delete _oItem.AusvnDatetime;
            } else {
              _oItem.AusvnDatetime = new moment(oItem.AusvnDatetime)
                .utc()
                .toDate();
            }

            if (!oItem.AusbsDatetime) {
              delete _oItem.AusbsDatetime;
            } else {
              _oItem.AusbsDatetime = new moment(oItem.AusbsDatetime)
                .utc()
                .toDate();
            }

            if (!oItem.Qmdat) {
              delete _oItem.Qmdat;
            } else {
              _oItem.Qmdat = new moment(oItem.Qmdat).utc().toDate();
            }

            if (!oItem.StrmnDatetime) {
              delete _oItem.StrmnDatetime;
            } else {
              _oItem.StrmnDatetime = new moment(oItem.StrmnDatetime)
                .utc()
                .toDate();
            }

            if (!oItem.LtrmnDatetime) {
              delete _oItem.LtrmnDatetime;
            } else {
              _oItem.LtrmnDatetime = new moment(oItem.LtrmnDatetime)
                .utc()
                .toDate();
            }

            if (!oItem.Auszt) {
              _oItem.Auszt = (0.0).toString();
            } else {
              _oItem.Auszt = oItem.Auszt.toString();
            }

            if (!oItem.Msaus || oItem.Msaus === "false") {
              _oItem.Msaus = " ";
            } else if (oItem.Msaus === "true") {
              _oItem.Msaus = "X";
            }

            if (oItem.Iwerk) {
              _oItem.Iwerk = oItem.Iwerk.toString();
            } else {
              _oItem.Iwerk = "";
            }

            if (oItem.Swerk) {
              _oItem.Swerk = oItem.Swerk.toString();
            } else {
              _oItem.Swerk = "";
            }
            //When complete is true NOCO should be send. else tbp status
            if (oItem.SendToGk && !oItem.Complete) {
              _oItem.SendToGk = oItem.SendToGk === "true";
            } else {
              _oItem.SendToGk = false;
            }

            if (!oItem.Hidden || oItem.Hidden === "false") {
              _oItem.Hidden = " ";
            } else if (oItem.Hidden === "true") {
              _oItem.Hidden = "X";
            }

            if (oItem.Complete) {
              _oItem.Complete = true;
            } else {
              _oItem.Complete = false;
            }
            if (oItem.Qmart) {
              let split = oItem.Qmart.split(",");
              _oItem.Qmart = split[0] || "";
              _oItem.Qmcod = split[1] || "";
            } else {
              _oItem.Qmart = "";
              _oItem.Qmcod = "";
            }
            if (oItem.Qmart === "30") {
              if (_.find(aConfitmations, { NotifHandle: _oItem.Handle })) {
                _oItem.Qmcod = "IMME";
              }
            }

            return _oItem;
          }.bind(this)
        );

        return aNotifications;
      },

      mapConfirmations: function (aConfirmations, sWorkHandle) {
        aConfirmations.map(function (oItem) {
          var _oItem = oItem;

          _oItem.Workhandle = sWorkHandle;

          if (oItem.ExecStart) {
            _oItem.ExecStart = new moment(oItem.ExecStart).utc().toDate();
          } else {
            _oItem.ExecStart = null;
          }

          if (oItem.ExecFin) {
            _oItem.ExecFin = new moment(oItem.ExecFin).utc().toDate();
          } else {
            _oItem.ExecFin = null;
          }

          if (!oItem.ActWork) {
            _oItem.ActWork = (0.0).toString();
          } else {
            _oItem.ActWork = oItem.ActWork.toString();
          }

          if (!oItem.ExecutantCnt) {
            _oItem.ExecutantCnt = (0.0).toString();
          } else {
            _oItem.ExecutantCnt = oItem.ExecutantCnt.toString();
          }

          if (oItem.UnWork) {
            _oItem.UnWorkIso = oItem.UnWork;
            _oItem.UnWork = "";
          }

          if (!oItem.FinConf || oItem.FinConf === "false") {
            _oItem.FinConf = " ";
          } else if (oItem.FinConf === "true") {
            _oItem.FinConf = "X";
          }

          if (oItem.Plant && typeof oItem.Plant !== "string") {
            _oItem.Plant = oItem.Plant.toString();
          }

          if (oItem.Hidden) {
            _oItem.Hidden = oItem.Hidden === "true";
          } else {
            _oItem.Hidden = false;
          }

          if (oItem.IsFinished) {
            _oItem.IsFinished = oItem.IsFinished === "true";
          } else {
            _oItem.IsFinished = false;
          }
          if (oItem.Complete) {
            _oItem.Complete = true;
          } else {
            _oItem.Complete = false;
          }

          if (oItem.Split) {
            _oItem.Split = oItem.Split === "true";
          } else {
            _oItem.Split = false;
          }

          if (!oItem.Text) {
            _oItem.Text = "";
          } else {
            _oItem.Text = oItem.Text;
          }

          return _oItem;
        });

        return aConfirmations;
      },

      mapParticipants: function (aParticipants, sWorkHandle) {
        aParticipants.map(function (oItem) {
          var _oItem = oItem;
          _oItem.Workhandle = sWorkHandle;

          if (oItem.Iwerk) {
            _oItem.Iwerk = oItem.Iwerk.toString();
          } else {
            _oItem.Iwerk = "";
          }

          if (oItem.Swerk) {
            _oItem.Swerk = oItem.Swerk.toString();
          } else {
            _oItem.Swerk = "";
          }

          return _oItem;
        });

        return aParticipants;
      },

      mapPictures: function (aPictures, sWorkHandle) {
        aPictures.map(function (oItem) {
          var _oItem = oItem;
          _oItem.Workhandle = sWorkHandle;
          if (_oItem.PicIndex) {
            _oItem.PicIndex = parseInt(_oItem.PicIndex).toString();
          } else {
            _oItem.PicIndex = "";
          }
          return _oItem;
        });

        return aPictures;
      },

      parseGateWayError: function (oError) {
        var oReturn = {
          unknown: false,
          message: "",
          failedHandles: [],
          orders: [],
          operations: [],
          parentHandles: [],
        };

        if (oError.statusCode === 401) {
          return oError;
        }

        if (oError.responseText.charAt(0) === "<") {
          oReturn.unknown = true;
        } else {
          try {
            var aErrors = JSON.parse(oError.responseText).error.innererror
              .errordetails;
            for (var x in aErrors) {
              var aErrorsDetails = aErrors[x].message.split("//");
              if (aErrors[x].severity === "error") {
                if (oReturn.message) {
                  oReturn.message = oReturn.message + "\n" + aErrorsDetails[0];
                } else {
                  oReturn.message = aErrorsDetails[0];
                  // var aErrors = JSON.parse(oError.responseText).error.innererror.errordetails;

                  // for (var x in aErrors) {
                  // 	var aErrorsDetails = aErrors[x].message.split("//");
                  // 	if (aErrors[x].severity === "error") {
                  // 		if (oReturn.message) {
                  // 			oReturn.message = oReturn.message + "\n" + aErrorsDetails[0];
                  // 		} else {
                  // 			oReturn.message = aErrorsDetails[0];
                }
                if (
                  aErrorsDetails[1] &&
                  !aErrorsDetails[2] &&
                  !aErrorsDetails[3]
                ) {
                  oReturn.failedHandles.push(aErrorsDetails[1]);
                } else {
                  // if (aErrorsDetails[1]) {
                  // 	oReturn.orders.push(parseInt(aErrorsDetails[1]).toString());
                  // }
                  // if (aErrorsDetails[1] && !aErrorsDetails[2] && !aErrorsDetails[3]) {
                  // 	oReturn.failedHandles.push(aErrorsDetails[1]);
                  // } else {
                  if (aErrorsDetails[1]) {
                    oReturn.orders.push(parseInt(aErrorsDetails[1]).toString());
                  }
                  if (aErrorsDetails[2]) {
                    oReturn.operations.push(
                      parseInt(aErrorsDetails[2]).toString()
                    );
                  }
                  if (aErrorsDetails[3]) {
                    oReturn.parentHandles.push(aErrorsDetails[3]);
                  }
                }
              }
            }
          } catch (_e) {
            oReturn.message = oError.responseText;
            if (oError.statusCode === 403 || oError.statusCode === 500) {
              oReturn.noAction = true;
            }
          }
        }

        return oReturn;
      },

      xml2json: function (sXml) {
        /*
			---------------- Andere mogelijkheid -----------------
			var parser = new DOMParser()
			var x = parser.parseFromString(oEvent.getParameters().responseText, "text/html");
			x.getElementsByClassName("errorTextHeader")[0].innerText ==> contains the error message.
			*/

        var Converter = new X2JS();
        return Converter.xml_str2json(sXml);
      },

      getDefaultsLocation: function () {
        var sLocation = "defaults/";

        return sLocation;
      },

      getPincodeServerMapping: function () {
        var d = jQuery.Deferred();

        let sSettings = "PincodeServer.json";

        var localModel = new JSONModel(this.getDefaultsLocation() + sSettings);
        localModel.attachRequestCompleted(function () {
          var oResult = localModel.getData();
          d.resolve(oResult);
        });
        return d.promise();
      },

      getDefaultSettings: function () {
        var d = jQuery.Deferred();

        let sSettings = "";
        if (this.publicRelease && this.cloudSystem === "DEV") {
          sSettings = "PublicSettingsDEV.json";
        } else if (this.publicRelease && this.cloudSystem === "UAT") {
          sSettings = "PublicSettingsUAT.json";
        } else if (this.publicRelease && this.cloudSystem === "PRD") {
          sSettings = "PublicSettingsPRD.json";
        } else {
          sSettings = "Settings.json";
        }

        var localModel = new JSONModel(this.getDefaultsLocation() + sSettings);
        localModel.attachRequestCompleted(function () {
          var oResult = localModel.getData();
          d.resolve(oResult);
        });
        return d.promise();
        //return this.getDefaultsLocation() + "/Settings.json";
      },

      getDefaultSystems: function () {
        var d = jQuery.Deferred();

        let sFile;
        if (this.publicRelease && this.cloudSystem === "DEV") {
          sFile = "PublicSystemsDEV.json";
        } else if (this.publicRelease && this.cloudSystem === "UAT") {
          sFile = "PublicSystemsUAT.json";
        } else if (this.publicRelease && this.cloudSystem === "PRD") {
          sFile = "PublicSystemsPRD.json";
        } else {
          sFile = "Systems.json";
        }

        var localModel = new JSONModel(this.getDefaultsLocation() + sFile);
        localModel.attachRequestCompleted(function () {
          var oResult = localModel.getData();
          d.resolve(oResult.Systems);
        });
        return d.promise();
        //return this.getDefaultsLocation() + "/Systems.json";
      },

      getNotificationTypeOrderTypeLinkage: function () {
        var d = jQuery.Deferred();
        var localModel = new JSONModel(
          this.getDefaultsLocation() + "NotificationTypeOrderTypeLinkage.json"
        );
        localModel.attachRequestCompleted(
          jQuery.proxy(function () {
            var oResult = localModel.getData();
            d.resolve(oResult);
          }, this)
        );
        return d.promise();
      },

      onNotifFieldChange: function (notifFields) {
        var fields = [
          "Text",
          "Fecod",
          "Craft",
          "Urcod",
          "Mncod",
          "Mfcod",
          "Fetxt",
          "Urtxt",
          "Matxt",
          "Mftxt",
          "Msaus",
          "AusbsDatetime",
          "AusvnDatetime",
        ];
        _.each(
          fields,
          jQuery.proxy(function (field) {
            if (_.isEmpty(notifFields)) {
              notifFields[field] = false;
            } else {
              _.each(
                notifFields,
                jQuery.proxy(function (notifField) {
                  if (!notifFields[field]) {
                    notifFields[field] = false;
                  } else {
                    notifFields[field] = true;
                  }
                })
              );
            }
          })
        );
        return notifFields;
      },

      onSortTreeTable: function (oData, Val, Val2) {
        //For Function Location Group Inside FL be sorted by Seqno and then by description
        //Issue 44 MW Tracker 12.0
        // if(Val2 ==="Seqno"){
        // 	if (oData) {
        // 		var withoutSeqno =oData.filter(function(row){
        // 				return !row.Seqno;
        // 			}),
        // 			withSeqno=oData.filter(function(row){
        // 				return row.Seqno;
        // 			});
        // 			withSeqno=_.sortBy(withSeqno, Val2);
        // 			withoutSeqno=_.sortBy(withoutSeqno, Val);
        // 			return withSeqno.concat(withoutSeqno);
        // 	}
        // }
        // if (Val2)
        // 	oData = _.sortBy(oData, Val2);
        if (oData) {
          oData.sort(function (a, b) {
            if (Val === "outsideLayerSort") {
              //Sorting on Outside Layer
              a.Value = a.Groupname
                ? a.Groupname.toUpperCase()
                : a.Ktx01.toUpperCase();
              b.Value = b.Groupname
                ? b.Groupname.toUpperCase()
                : b.Ktx01.toUpperCase();
            } else {
              //Different Sorting Field for Function Location and Group
              a.Value = a[Val];
              b.Value = b[Val];
            }
            if (!a.Value && b.Value) {
              return 1;
            } else if (a.Value && !b.Value) {
              return -1;
            } else if (a.Value < b.Value) {
              return -1;
            } else if (a.Value > b.Value) {
              return 1;
            } else return 0;
          });
        }

        if (Val === "Posnr") {
          var withoutPosnr = oData.filter(function (row) {
              return !row.Posnr;
            }),
            withPosnr = oData.filter(function (row) {
              return row.Posnr;
            });
          withPosnr = _.sortBy(withPosnr, "Posnr");
          withoutPosnr = _.sortBy(withoutPosnr, "Tplnr");
          oData = withoutPosnr.concat(withPosnr);
        }
        return oData;
      },

      findChildTree: function (oData, row, field, field1) {
        if (oData) {
          var childTree;
          oData.forEach(
            jQuery.proxy(function (loc) {
              if (loc[field] === row[field]) {
                childTree = loc;
                return;
              } else if (loc.Children) {
                if (this.findChildTree(loc.Children, row, field, field1)) {
                  childTree = this.findChildTree(
                    loc.Children,
                    row,
                    field,
                    field1
                  );
                }
              } else {
                return;
              }
            }, this)
          );
          if (childTree) return childTree;
          else return null;
        }
      },

      mapZoneBadging: function (zoneBadgings) {
        zoneBadgings.map(
          function (oItem) {
            var _oItem = oItem;

            if (!oItem.Werks) {
              delete _oItem.Werks;
            } else {
              _oItem.Werks = _oItem.Werks.toString();
            }
            if (oItem.TrZone) {
              _oItem.TrZone = _oItem.TrZone;
            } else {
              _oItem.TrZone = "";
            }

            if (oItem.Lifnr) {
              _oItem.Lifnr = _oItem.Lifnr;
            } else {
              //remove these testing codes
              if (this.isDevModeActive()) _oItem.Lifnr = "100005";
              else _oItem.Lifnr = "";
            }
            if (oItem.Timestamp) {
              if (typeof oItem.Timestamp === "string") {
                oItem.Timestamp = parseInt(oItem.Timestamp);
              }
              oItem.Timestamp = new moment.utc(oItem.Timestamp).format(
                "YYYYMMDDHHmmss"
              );
            } else {
              _oItem.Timestamp = "";
            }
            if (oItem.TrAuto) {
              _oItem.TrAuto = "X";
            } else {
              _oItem.TrAuto = "";
            }

            delete oItem.zoneName;
            return _oItem;
          }.bind(this)
        );

        return zoneBadgings;
      },

      convertEURtoUS: function (value) {
        return value
          .replace(/,/g, "♣")
          .replace(/\./g, "@")
          .replace(/\♣/g, ".")
          .replace(/@/g, ",");
      },

      getNotificationTypes: function () {
        var d = jQuery.Deferred();
        var localModel = new JSONModel(
          this.getDefaultsLocation() + "NotificationType.json"
        );
        localModel.attachRequestCompleted(
          jQuery.proxy(function () {
            var oResult = localModel.getData();
            d.resolve(oResult);
          }, this)
        );
        return d.promise();
      },

      mapTimeSheets: function (aTimeSheets, Partcipants) {
        let timeFormatter = new UI5Date();
        aTimeSheets.map(
          function (oItem) {
            var _oItem = oItem;
            if (!oItem.Werks) {
              delete _oItem.Werks;
            } else {
              if (parseInt(oItem.Werks)) {
                _oItem.Werks = parseInt(oItem.Werks).toString();
              } else {
                _oItem.Werks = oItem.Werks;
              }
            }
            // if (!oItem.Status) {
            delete _oItem.Status;
            // } else {
            // 	// _oItem.Werks = oItem.Werks;
            // 	 _oItem.Status =  oItem.Status;
            // }
            if (!oItem.TotalQnty) {
              delete _oItem.TotalQnty;
            } else {
              // _oItem.Werks = oItem.Werks;
              _oItem.TotalQnty = oItem.TotalQnty;
            }
            if (!oItem.Erdat) {
              delete _oItem.Erdat;
            } else {
              _oItem.Erdat = oItem.Erdat();
            }
            if (!oItem.Lifnr) {
              delete _oItem.Lifnr;
            } else {
              _oItem.Lifnr = oItem.Lifnr;
            }
            if (!oItem.PlDate) {
              delete _oItem.PlDate;
            } else {
              let date = oItem.PlDate.split(" ");
              _oItem.PlDate = new moment(date[0]).utc().toDate();
              _oItem.StartTime = timeFormatter.parseValue(date[1], "string");
              // _oItem.StartTime = "PT"+date[1].slice(0,2)+"H"+date[1].slice(3)+"M00S";
            }

            //_oItem.StartTime = "PT08H00M00S";

            if (!oItem.Pernr) {
              delete _oItem.Pernr;
            } else {
              _oItem.Pernr = oItem.Pernr;
            }
            if (!oItem.Quantity && oItem.Quantity!==0) {
              delete _oItem.Quantity;
            } else {
              _oItem.Quantity = oItem.Quantity.toString();
            }
            if (!oItem.Introw) {
              delete _oItem.Introw;
            } else {
              _oItem.Introw = oItem.Introw.toString();
            }
            if (!oItem.Packno) {
              delete _oItem.Packno;
            } else {
              _oItem.Packno = oItem.Packno.toString();
            }
            if (!oItem.Service) {
              delete _oItem.Service;
            } else {
              _oItem.Service = oItem.Service.toString();
            }
            if (!oItem.PoPosNr) {
              delete _oItem.PoPosNr;
            } else {
              _oItem.PoPosNr = oItem.PoPosNr.toString();
            }
            if (!oItem.PoNr) {
              delete _oItem.PoNr;
            } else {
              _oItem.PoNr = oItem.PoNr.toString();
            }
             if (!oItem.Unit) {
              delete _oItem.Unit;
             } 
             //else {
            //   _oItem.Unit = oItem.Unit.toString();
            // }

            if (!oItem.PlComment) {
              delete _oItem.PlComment;
            } else {
              _oItem.PlComment = oItem.PlComment.toString();
            }
            if (!oItem.TrZone) {
              delete _oItem.TrZone;
            } else {
              _oItem.TrZone = oItem.TrZone.toString();
            }

            // if (!oItem.Lifnr) {
            // 	delete _oItem.AusvnDatetime;
            // } else {
            // 	_oItem.AusvnDatetime = new moment(oItem.AusvnDatetime).utc().toDate();
            // }

            return _oItem;
          }.bind(this)
        );

        return aTimeSheets;
      },
      /*BEGIN: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/

      calcActualWork: function (oMomStart, oMomEnd) {
        var oReturn = {
            ActWork: 0,
            UnWork: "",
            bValid: true,
          },
          oDuration = moment.duration(oMomEnd.diff(oMomStart)),
          iDuration = 0,
          iDays = Math.round(oDuration.asDays() * 10) / 10,
          iHours = Math.round(oDuration.asHours() * 10) / 10,
          iMinutes = Math.round(oDuration.asMinutes() * 10) / 10;

        if (oDuration.asMilliseconds() < 0) {
          oReturn.bValid = false;
          return oReturn;
        }

        if (iDays % 1 !== 0 || iDays === 0) {
          if (iHours % 1 !== 0 || iHours === 0) {
            iDuration = iMinutes;
            oReturn.UnWork = "MIN";
          } else {
            iDuration = iHours;
            oReturn.UnWork = "HUR";
          }
        } else {
          iDuration = iDays;
          oReturn.UnWork = "DAY";
        }

        oReturn.ActWork = Math.round(iDuration);

        return oReturn;
      },

      /*END: Date: 26/02/2024 AMID: A0866990 13.1 Bug Number: 20*/
    });
  }
);
