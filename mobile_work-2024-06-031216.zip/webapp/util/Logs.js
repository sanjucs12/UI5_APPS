sap.ui.define(
  [
    "sap/ui/base/Object",
    "sap/ui/Device",
    "mobilework/util/Helper",
    "mobilework/libs/moment",
  ],
  function (Object, Device, Helper, Mo) {
    "use strict";

    return Object.extend("mobilework.util.Logs", {
      //-------------------------------------
      // GENERAL INFO
      //-------------------------------------

      // Created on: 05/2021
      // Contacts: Jonis De Klerk
      // Domain: Arcelor Mittal ARMP (Herman De Vos)

      //-------------------------------------
      // PRIVATE PROPERTIES
      //-------------------------------------

      _oLogger: null,

      _oFile: null,

      _oDataModel: null,

      _oListener: {
        onLogEntry: function (oLog) {
          var aLogs = {
            logs: [],
          };
          aLogs.logs.push(oLog);
          //this.Component.logs.addLogFromListener();
          // $.when(	this.Component.logs.postLogs(aLogs)).done(jQuery.proxy(function(){
          // 	this.Component.logs.clearLogs();
          // },this ));
        },
      },

      //-------------------------------------
      // PUBLIC METHODS
      //-------------------------------------

      constructor: function (
        sFileName,
        oLogger,
        sLoglevel,
        oOdataModel,
        Component
      ) {
        this._oHelper = new Helper();
        this._sFileName = sFileName;
        this._sPath = this._oHelper.getBaseLocation();
        this._getFile(); // create initial file

        this._oLogger = oLogger;
        this._oDataModel = oOdataModel;
        this.setLogLevel(sLoglevel);
        this._oListener.Component = Component;
        oLogger.addLogListener(this._oListener);

        // this._oLog = new Log();
      },

      readLogs: function () {
        var d = $.Deferred();
        $.when(this._getFile()).done(
          jQuery.proxy(function (oFile) {
            this._oFile = oFile;
            if (this._oFile) {
              this._oFile.file(function (oFile) {
                var oReader = new FileReader();

                oReader.onloadend = function () {
                  console.debug("Successful file read: ", this.result);
                  d.resolve(this.result);
                  //jQuery.proxy(this._updateDatabase(this.result), this);
                };
                oReader.readAsText(oFile);
              }),
                function (error) {
                  // no file found
                  d.reject(error);
                  console.error("onErrorReadFile", error);
                  //me.createInitFile();
                };
            }
          }, this)
        );
        return d.promise();
      },

      setLogLevel: function (sLogLevel) {
        this._sLogLevel = sLogLevel.toUpperCase();

        switch (this._sLogLevel) {
          case "ALL":
            this._oLogger.setLevel(this._oLogger.Level.ALL);
            break;
          case "INFO":
            this._oLogger.setLevel(this._oLogger.Level.INFO);
            break;
          case "FATAL":
            this._oLogger.setLevel(this._oLogger.Level.FATAL);
            break;
          case "WARNING":
            this._oLogger.setLevel(this._oLogger.Level.WARNING);
            break;
          case "ERROR":
            this._oLogger.setLevel(this._oLogger.Level.ERROR);
            break;
        }
      },

      getLogLevel: function () {
        return this._sLogLevel;
      },

      addLog: function (sMsg, sType, oComponent) {
        if (
          this._oListener.Component.getModel("shared").getProperty(
            "/sapSettings/sapUser"
          ) === "" ||
          this._oListener.Component.getModel("shared").getProperty(
            "/sapSettings/sapUser"
          ) === undefined ||
          this._oListener.Component.getModel("shared").getProperty(
            "/sapSettings/sapUser"
          ) === null
        ) {
          console.error(
            "No user is currently logged in ==> don't make calls to the BE for logging"
          );
          return;
        }

        var _sType = sType ? sType.toUpperCase() : "INFO";

        var oLogs = {};

        if (this._sLogLevel && _sType) {
          switch (_sType) {
            case "INFO":
              if (
                this._oLogger.isLoggable(this._oLogger.Level.INFO) ||
                this._oLogger.isLoggable(this._oLogger.Level.ALL)
              ) {
                this._oLogger.info(sMsg, oComponent);
              }
              break;
            case "FATAL":
              if (
                this._oLogger.isLoggable(this._oLogger.Level.FATAL) ||
                this._oLogger.isLoggable(this._oLogger.Level.ALL)
              ) {
                this._oLogger.fatal(sMsg, oComponent);
              }
              break;
            case "WARNING":
              if (
                this._oLogger.isLoggable(this._oLogger.Level.WARNING) ||
                this._oLogger.isLoggable(this._oLogger.Level.ALL)
              ) {
                this._oLogger.warning(sMsg, oComponent);
              }
              break;
            case "ERROR":
              if (
                this._oLogger.isLoggable(this._oLogger.Level.ERROR) ||
                this._oLogger.isLoggable(this._oLogger.Level.ALL)
              ) {
                this._oLogger.error(sMsg, oComponent);
              }
              break;
          }
          oLogs.logs = this._oLogger.getLogEntries();
          if (oLogs.logs && oLogs.logs.length) {
            this._addLogsToFile(oLogs);
            $.when(this.postLogs(oLogs)).done(
              jQuery.proxy(function () {
                this.clearLogs(oLogs);
              }, this)
            );
            this.readLogs();
          }
        }
      },

      clearLogs: function () {
        this._oLogger.setLogEntriesLimit(0);
        this._oLogger.setLogEntriesLimit(3000);
      },

      addLogFromListener: function () {
        //add to file
        var oLogs = {};
        if (this._oLogger) {
          oLogs.logs = this._oLogger.getLogEntries();
          this._addLogsToFile(oLogs);
        }
      },

      postLogs: function (oLogs) {
        var oDataLog = this._oDataModel;
        var d = jQuery.Deferred();

        if (this._oHelper.isOnline()) {
          var oLogEntity = {
            lognumber: "",
            object: "/ARMP/MW",
            subobject: "/ARMP/MWG",
            extnumber: "test",
            navLogHeader_Detail: {},
          };

          var _aLogs = this.mapLogs(oLogs);
          oLogEntity.navLogHeader_Detail = _aLogs;

          console.debug(oLogEntity);
          oDataLog.create("/LogHeaderSet", oLogEntity, {
            // urlParameters: {
            // 	"$expand": "navLogHeader_Detail"
            // },
            success: function (oResult) {
              //success
              d.resolve();
            },
            error: function (oError) {
              d.reject();
              //error
            },
          });
        }

        return d.promise();
      },

      //-------------------------------------
      // PRIVATE METHODS
      //-------------------------------------

      _getFile: function () {
        var d = $.Deferred();
        if (!this._oHelper.isDevModeActive()) {
          // && Device.os.name !== "win"
          console.debug("GET File executed");
          window.resolveLocalFileSystemURL(
            this._sPath,
            jQuery.proxy(function (oDir) {
              oDir.getFile(
                this._sFileName,
                {
                  create: true,
                },
                jQuery.proxy(function (oFileEntry) {
                  d.resolve(oFileEntry);
                }, this)
              );
            }, this)
          );
        } else {
          console.debug("GET File skipped");
          d.resolve();
        }
        return d.promise();
      },

      _addLogsToFile: function (oDataObj) {
        $.when(this._getFile()).done(
          jQuery.proxy(function (oFile) {
            this._oFile = oFile;

            if (this._oFile) {
              this._oFile.createWriter(function (oFileWriter) {
                oFileWriter.onwriteend = function (oData) {
                  console.debug(oData);
                  console.debug("Successful file write...");
                };

                oFileWriter.onerror = function (e) {
                  console.error("Failed file write: " + e.toString());
                };

                // If data object is not passed in,
                // create a new Blob instead.
                // 						if (!oDataObj) {

                oDataObj = new Blob([JSON.stringify(oDataObj, 1, "\r")], {
                  type: "application/json",
                });

                // 						}

                console.debug("Writing to file started");
                oFileWriter.write(oDataObj);
              });
            }
          }, this)
        );
      },

      mapLogs: function (aLogs) {
        var me = this;
        var results = [];
        aLogs.logs.forEach(function (oItem) {
          var aItem = {};

          aItem.lognumber = "";
          aItem.probclass = "";
          if (oItem.message) {
            aItem.message = oItem.message.toString();
          } else {
            aItem.message = "";
          }
          if (oItem.timestamp) {
            aItem.timestamp = oItem.timestamp.toString();
          } else {
            aItem.timestamp = "";
          }
          aItem.message_type = me.getMessageType(oItem.level).toString();

          results.push(aItem);
        });

        return results;
      },

      getMessageType: function (level) {
        switch (level) {
          case 0:
            return "F";
          case 1:
            return "E";
          case 2:
            return "W";
          case 3:
            return "I";
          default:
            return "";
        }
      },

      createLogModelWithUser: function (sUri, oData) {
        var sUser = oData.sapUser,
          sPass = oData.sapPass;

        var d = $.Deferred();
        var sUrlToBeUsed = "";

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = sUri;
        } else {
          sUrlToBeUsed = oData.host + sUri;
        }

        if (oData.sapClient) {
          if (sUrlToBeUsed.indexOf("?sap-client=") !== -1) {
            sUrlToBeUsed = sUrlToBeUsed;
          } else {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + oData.sapClient;
          }
        }

        sUrlToBeUsed =
          sUrlToBeUsed + "&authorization=" + this.make_base_auth(sUser, sPass);
        sap.ui.model.odata.v2.ODataModel.mServiceData = {};
        var deviceType = "windows";
        if (!this._oHelper.isDevModeActive()) {
          deviceType = device.platform;
        }
        this._oDataModel = new sap.ui.model.odata.v2.ODataModel(
          sUrlToBeUsed + "&saml2=disabled",
          {
            user:
              deviceType.indexOf("win") !== -1 ||
              deviceType.indexOf("Win") !== -1
                ? sUser
                : "",
            password:
              deviceType.indexOf("win") !== -1 ||
              deviceType.indexOf("Win") !== -1
                ? sPass
                : "",
            withCredentials: true,
            defaultBindingMode: "TwoWay",
            defaultCountMode: "Inline",
            metadataUrlParams: {},
            loadMetadataAsync: true,
            useBatch: false,
            headers: {
              "sap-client": oData.sapClient.toString(),
              Authorization: "Basic " + this.make_base_auth(sUser, sPass),
              "Cache-Control": "max-age=0",
            },
          }
        );

        this._oDataModel.attachMetadataLoaded(
          jQuery.proxy(function () {
            d.resolve();
          }, this)
        );

        this._oDataModel.attachMetadataFailed(
          jQuery.proxy(function (oError) {
            d.reject(oError);
          }, this)
        );
        return d.promise();
      },

      make_base_auth: function (user, password) {
        var tok = user + ":" + password;
        var hash = btoa(tok);
        return hash;
      },
    });
  }
);
