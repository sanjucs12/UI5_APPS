sap.ui.define([], function () {
  "use strict";

  var entityType = {};
  entityType.name = "zoneData";
  entityType.property = [];
  entityType.property.push({
    name: "zoneTagCode",
    type: "type.String",
  });
  entityType.property.push({
    name: "zoneTagId",
    type: "type.String",
  });
  entityType.property.push({
    name: "zoneName",
    type: "type.String",
  });
  entityType.property.push({
    name: "zoneCode",
    type: "type.String",
  });
  entityType.key = { propertyRef: [] };
  entityType.key.propertyRef.push({
    name: "zoneCode",
  });
  return entityType;
});
