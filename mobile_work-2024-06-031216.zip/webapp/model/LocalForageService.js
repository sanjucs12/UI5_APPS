sap.ui.define(
  [
    "sap/ui/base/Object",
    "sap/m/MessageToast",
    //   "com/arcelormittal/mobilesafety/libs/underscore",
    //   "com/arcelormittal/mobilesafety/model/DatabaseStatementsHelper",
    "mobilework/model/DatabaseService",
    "mobilework/util/Helper",
  ],
  function (
    Object,
    MessageToast,
    // underscore, dbhelper,
    db,
    Help
  ) {
    "use strict";

    let bWebSQLEnabled = true;

    return Object.extend("mobilework/model/LocalForageService", {
      constructor: function (oComponent) {
        // this.logger = jQuery.sap.log.getLogger();
        // this.backupDB = backupDB;
        //   this.oContext = oContext;
        this.oContext = new db(oComponent);
        this.oComponent = oComponent;
        this.helper = new Help();
        // this.PlanItemEntity;
      },

      initializeDB: function (bOpenOnly, bGetMeta) {
        // No actions needed ==> just loads the sql DB

        let d = jQuery.Deferred();
        if (bWebSQLEnabled) {
          let oResult = this.oContext.initializeDB(bOpenOnly, bGetMeta);
          oResult.then(function (oRes) {
            // Assumption: WebSQL returns undefined when the DB is opened
            if (oRes !== undefined) {
              console.error("DB issue 1: " + oRes);
            }
            d.resolve(oRes);
          });
        } else {
          d.resolve();
        }
        return d.promise();
      },
      _getMetaObjectFromDB: function () {
        // metaObject is stored to later create SQL database tables ==> for now we will ignore this

        let d = jQuery.Deferred();

        (async () => {
          let oSetting = await localforage.getItem("Setting");
          let oMetadata = oSetting["metadata"];
         if(oMetadata){
           this.metaObject = JSON.parse(oMetadata);
         }


          if (bWebSQLEnabled) {
            let oResult = this.oContext._getMetaObjectFromDB();
            oResult.then(async function (oRes) {
              // Assumption: WebSQL returns undefined after metadata table is created in WebSQL
              if (oRes !== undefined) {
                console.error("DB issue 2: " + oRes);
              }
              d.resolve(oMetadata);
            });
          } else {
            d.resolve(oMetadata);
          }
        })();
        return d.promise();
      },
      _getPlanItemSetFromDB: function () {
        // Ignore this, getPlanItemEntity will be used to get the data

        // this.PlanItemEntity

        let d = jQuery.Deferred();

        (async () => {
          let oSetting = await localforage.getItem("Setting");

          let oPlanItemSet = oSetting["PlanItemSet"];

          this.PlanItemEntity = oPlanItemSet;

          if (bWebSQLEnabled) {
            let oResult = this.oContext._getPlanItemSetFromDB();
            oResult.then(async function (oRes) {
              console.debug(oRes);

              // Assumption: WebSQL loads the PlanItemSet from the DB
              if (oRes !== undefined) {
                console.error("DB issue 3: " + oRes);
              }
              d.resolve(oRes);
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      getAllVHAndCatalogs: function () {
        // NO SQL LOGIC

        var oPromCatalog = this.getEntitySet("Catalog"),
          oPromQmart = this.getEntitySet("PMNotificationQmartVH"),
          oPromShift = this.getEntitySet("PMNotificationShiftVH"),
          oPromLangu = this.getEntitySet("PMNotificationLanguVH"),
          oPromUnWork = this.getEntitySet("ConfirmationsUnWorkVH"),
          oPromCraft = this.getEntitySet("PMNotificationCraftVH"),
          oPromSettings = this.getSAPSettings(),
          oPromActType = this.getEntitySet("ConfirmationsPMActTypeVH"),
          oPromPmenvr = this.getEntitySet("PMNotificationPmenvrVH"),
          oPromPmqual = this.getEntitySet("PMNotificationPmqualVH"),
          oPromPmsafe = this.getEntitySet("PMNotificationPmsafeVH"),
          oPromQuotCoR = this.getEntitySet("PMNotificationQuotCoRVH"),
          oPromQuotDeR = this.getEntitySet("PMNotificationQuotDeRVH"),
          oPromQuotPrR = this.getEntitySet("PMNotificationQuotPrRVH"),
          oPromQuotWcR = this.getEntitySet("PMNotificationQuotWcRVH"),
          oPromImpactOblCustomizing = this.getEntitySet("ImpactOblCustomizing"),
          d = $.Deferred(),
          oPromNotifcationType = this.helper.getNotificationTypes();

        $.when(
          oPromQmart,
          oPromCatalog,
          oPromShift,
          oPromLangu,
          oPromUnWork,
          oPromCraft,
          oPromSettings,
          oPromActType,
          oPromPmenvr,
          oPromPmqual,
          oPromPmsafe,
          oPromQuotCoR,
          oPromQuotDeR,
          oPromQuotPrR,
          oPromQuotWcR,
          oPromImpactOblCustomizing,
          oPromNotifcationType
        ).done(
          jQuery.proxy(function (
            _oQmartData,
            _oCatalogData,
            _oShiftData,
            _oLanguData,
            _oUnWorkData,
            _oCraftData,
            _oSettingData,
            _oActyTpeData,
            _oPmenvrData,
            _oPmqualData,
            _oPmsafeData,
            _oQuotCoRData,
            _oQuotDeRData,
            _oQuotPrRData,
            _oQuotWcRData,
            _oImpactOblData,
            oNotifcationType
          ) {
            var oSharedModel = this.oComponent.getModel("shared"),
              aQmart = [],
              aCatalog = [],
              aShift = [],
              aLangu = [],
              aCraft = [],
              aUnWork = [],
              aActType = [],
              aPmqual = [],
              aPmsafe = [],
              aQuotCoR = [],
              aQuotDeR = [],
              aQuotPrR = [],
              aQuotWcR = [],
              aPmenvr = [],
              aImpactObl = [];

            // for (var i = 0; i < _oQmartData.rows.length; i++) {
            // 	aQmart.push(_oQmartData.rows.item(i));
            // }

            for (var j = 0; j < _oCatalogData.rows.length; j++) {
              aCatalog.push(_oCatalogData.rows.item(j));
            }

            for (var k = 0; k < _oShiftData.rows.length; k++) {
              aShift.push(_oShiftData.rows.item(k));
            }

            for (var l = 0; l < _oLanguData.rows.length; l++) {
              aLangu.push(_oLanguData.rows.item(l));
            }

            for (var m = 0; m < _oUnWorkData.rows.length; m++) {
              aUnWork.push(_oUnWorkData.rows.item(m));
            }

            for (var n = 0; n < _oCraftData.rows.length; n++) {
              aCraft.push(_oCraftData.rows.item(n));
            }

            for (var o = 0; o < _oActyTpeData.rows.length; o++) {
              aActType.push(_oActyTpeData.rows.item(o));
            }
            for (var o = 0; o < _oPmenvrData.rows.length; o++) {
              aPmenvr.push(_oPmenvrData.rows.item(o));
            }
            for (var o = 0; o < _oPmqualData.rows.length; o++) {
              aPmqual.push(_oPmqualData.rows.item(o));
            }
            for (var o = 0; o < _oPmsafeData.rows.length; o++) {
              aPmsafe.push(_oPmsafeData.rows.item(o));
            }
            for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
              aQuotCoR.push(_oQuotCoRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
              aQuotDeR.push(_oQuotDeRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
              aQuotPrR.push(_oQuotPrRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
              aQuotWcR.push(_oQuotWcRData.rows.item(o));
            }
            for (var o = 0; o < _oImpactOblData.rows.length; o++) {
              aImpactObl.push(_oImpactOblData.rows.item(o));
            }

            // Issue no. 110 in V13.0
            aPmenvr.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aPmqual.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aPmsafe.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotCoR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotDeR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotPrR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotWcR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aImpactObl.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });

            oSharedModel.setProperty("/vh", {});
            oSharedModel.setProperty("/vh/Qmart", oNotifcationType.Types);
            oSharedModel.setProperty("/vh/Catalog", aCatalog);
            oSharedModel.setProperty("/vh/Shift", aShift);
            oSharedModel.setProperty("/vh/Langu", aLangu);
            oSharedModel.setProperty("/vh/UnWork", aUnWork);
            oSharedModel.setProperty("/vh/Craft", aCraft);
            oSharedModel.setProperty("/vh/ActType", aActType);
            oSharedModel.setProperty("/vh/Pmenvr", aPmenvr);
            oSharedModel.setProperty("/vh/Pmqual", aPmqual);
            oSharedModel.setProperty("/vh/Pmsafe", aPmsafe);
            oSharedModel.setProperty("/vh/QuotCoR", aQuotCoR);
            oSharedModel.setProperty("/vh/QuotDeR", aQuotDeR);
            oSharedModel.setProperty("/vh/QuotPrR", aQuotPrR);
            oSharedModel.setProperty("/vh/QuotWcR", aQuotWcR);
            oSharedModel.setProperty("/vh/ImpactObl", aImpactObl);
            oSharedModel.setProperty(
              "/vh/headerLines",
              aCatalog.filter((aCat) => {
                return aCat.Code === "";
              })
            );

            if (
              _oSettingData.sapUser === undefined &&
              _oSettingData.sapPass === undefined
            ) {
              _oSettingData.sapUser = oSharedModel.getProperty(
                "/sapSettings/sapUser"
              );
              _oSettingData.sapPass = oSharedModel.getProperty(
                "/sapSettings/sapPass"
              );
            }
            oSharedModel.setProperty("/sapSettings", _oSettingData);

            d.resolve();
          },
          this)
        );

        return d.promise();
      },
      _sqlDataBaseUpdate: function () {
        // SQL DB only ==> It will create database tables
        // Will only execute this logic when WebSQL is active

        let d = jQuery.Deferred();

        let oResult;

        oResult = this._convertToSQLResultSet([]);

        if (bWebSQLEnabled) {
          let oResult = this.oContext._sqlDataBaseUpdate();

          oResult.then(function (oRes) {
            // Assumption: WebSQL returns info about the WebSQL tables
            // No need to compare this with the indexedDB entries
            d.resolve(oRes);
          });
        } else {
          d.resolve(oResult);
        }

        return d.promise();
      },

      _getSQLForCreateTable: function (sEntity, oMetaDataObject, newKeys) {
        // Returns SQL DB query string
        // We will not compare outcome of WebSQL & IndexedDB

        if (bWebSQLEnabled) {
          let sResult = this.oContext._getSQLForCreateTable(
            sEntity,
            oMetaDataObject,
            newKeys
          );
          return sResult;
        } else {
          return "";
        }
      },

      _getSQLForCreateTableNoKeys: function (sEntity, oMetaDataObject) {
        // Returns SQL DB query string
        // We will not compare outcome of WebSQL & IndexedDB

        if (bWebSQLEnabled) {
          let sResult = this.oContext._getSQLForCreateTableNoKeys(
            sEntity,
            oMetaDataObject
          );
          return sResult;
        } else {
          return "";
        }
      },

      setMetaObject: function (newMetaObject) {
        // Set metaObject, no SQL logic

        this.metaObject = newMetaObject;
        if (bWebSQLEnabled) {
          this.oContext.setMetaObject(newMetaObject);
        }
      },
      getMetaObject: function () {
        // Get metaObject, no SQL logic

        let oResult;
        if (this.metaObject) {
          oResult = this.metaObject;
        } else {
          oResult = this.service.getModel().getServiceMetadata();
        }

        if (bWebSQLEnabled) {
          let oResultWebSQL = this.oContext.metaObject;
          if (oResultWebSQL && oResult === undefined) {
            console.error("MetaObject differs between WebSQL & IndexedDB");
          }
        }
        return oResult;
      },
      getEntitySet: async function (sEntity, custom) {
        if(!this.metaObject &&this.service &&  this.service._oModel && this.service._oModel.oMetadata && this.service._oModel.oMetadata.oMetadata){
          this.metaObject = this.service._oModel.oMetadata.oMetadata;
        }
        var d = jQuery.Deferred();

        let aItems;
        let sqlCustom1 ='SELECT a.* FROM TimeRegistration a INNER JOIN ( SELECT Pernr, MAX(Timestamp) AS last_time  FROM TimeRegistration GROUP BY Pernr ) b ON a.Pernr = b.Pernr AND a.Timestamp = b.last_time'
        if (sEntity === "TimeRegistration" && custom === sqlCustom1) {
          console.warn("Check the outcome of the timeregistration query");
          // Get TimeRegistration entries
          let aTimeRegs = (await localforage.getItem("TimeRegistration")) || [];
          // Get the latest entry for each employee
          let aTimeRegsLatest = [];
          // Get unique employee numbers
          let aPernrs = aTimeRegs.map((oItem) => {
            return oItem.Pernr;
          });
          // remove duplicates
          aPernrs = [...new Set(aPernrs)];
          // Get the latest entry for each employee
          aPernrs.forEach((sPernr) => {
            let aFilteredTimeRegs = aTimeRegs.filter((oItem) => {
              return oItem.Pernr === sPernr;
            });
            aFilteredTimeRegs = aFilteredTimeRegs.sort(
              (a, b) => b.Timestamp - a.Timestamp
            );
            aTimeRegsLatest.push(aFilteredTimeRegs[0]);
          });
          // Loop at aTimeRegsLatest and add property last_time which contains the Timestamp value
          // aTimeRegsLatest.forEach((oItem) => {
          //   oItem.last_time = oItem.Timestamp;
          // });
          aItems = aTimeRegsLatest;
        } else if (
          sEntity === "FuncLocOrg" &&
          custom === "SELECT * from FuncLocOrg where TrZone is not ''"
        ) {
          let aFuncLocOrg = (await localforage.getItem("FuncLocOrg")) || [];
          aItems = aFuncLocOrg.filter((oItem) => {
            return oItem.TrZone !== "";
          });

          console.warn("Check outcome of FuncLocOrg query");
        } else if (sEntity === "WCAOpeRisks" && custom !== undefined) {
          console.warn("TODO - implement query - WCAOpeRisks");
          aItems = (await localforage.getItem("WCAOpeRisks")) || [];
          let aValues = custom[1];
          aItems = aItems.filter((oItem) => {
            return oItem.Vornr === aValues[0] && oItem.Objid === aValues[1];
          });
        } else if (sEntity === "WCAData" && custom !== undefined) {
          console.warn("TODO - implement query - WCAData");
          aItems = (await localforage.getItem("WCAData")) || [];
          let aValues = custom[1];
          aItems = aItems.filter((oItem) => {
            return oItem.Objid === aValues[0];
          });
        } else if (sEntity === "WCARisks" && custom !== undefined) {
          console.warn("TODO - implement query - WCARisks");
          aItems = (await localforage.getItem("WCARisks")) || [];
          let aValues = custom[1];
          aItems = aItems.filter((oItem) => {
            return oItem.Objid === aValues[0];
          });
        } else if (sEntity === "WCAOpeData" && custom !== undefined) {
          console.warn("TODO - implement query - WCAOpeData");
          aItems = (await localforage.getItem("WCAOpeData")) || [];
          let aValues = custom[1];
          aItems = aItems.filter((oItem) => {
            return oItem.Vornr === aValues[0] && oItem.Objid === aValues[1];
          });
        } else if (
          sEntity === "TechnicalObject" &&
          custom !== undefined &&
          custom[1] !== undefined &&
          custom[1].length > 0
        ) {
          // [
          // "SELECT * FROM TechnicalObject WHERE TechObject  IN (" +
          // sParams +
          // ")",
          // techObjects,
          // ]
          let aTechObjects =
            (await localforage.getItem("TechnicalObject")) || [];
          aItems = aTechObjects.filter((oItem) => {
            return custom[1].includes(oItem.TechObject);
          });
        } else {
          aItems = (await localforage.getItem(sEntity)) || [];
        }

        // Format IndexedDB output
        if (sEntity === "PMOrder") {
          aItems.forEach((oItem) => {
            for (let sKey in oItem) {
              if (sKey === "Plant") {
                oItem[sKey] = parseFloat(oItem[sKey]);
              } else if (oItem[sKey] !== String && oItem[sKey] !== null) {
                oItem[sKey] = String(oItem[sKey]);
              }
            }
          });
        } else if (sEntity === "Operation") {
          aItems.forEach((oItem) => {
            for (let sKey in oItem) {
              if (
                sKey === "DurationNormal" ||
                sKey === "NumberOfCapacities" ||
                sKey === "Plant" ||
                sKey === "Quantity"
              ) {
                oItem[sKey] = parseFloat(oItem[sKey]);
              } else if (oItem[sKey] !== String && oItem[sKey] !== null) {
                oItem[sKey] = String(oItem[sKey]);
              }
            }
          });
        }

        if (sEntity === "PMNotification") {
          aItems = aItems.map((oItem) => {
            return this.formatPMNotification(oItem);
          });
        }

        if (sEntity === "FuncLocOrg") {
          aItems = aItems.map((oItem) => {
            return this.formatFuncLocOrg(oItem);
          });
        }

        if (bWebSQLEnabled) {
          let oResult = this.oContext.getEntitySet(sEntity, custom);
          oResult.then(async (oRes) => {
            console.debug(oRes);

            let x = [];
            for (let y = 0; y < oRes.rows.length; y++) {
              x.push(oRes.rows.item(y));
            }

            // Exceptions when comparing WebSQL & IndexedDB
            let xCopy = _.cloneDeep(x);
            let aItemsCopy = _.cloneDeep(aItems);

            if (sEntity === "Confirmation") {
              xCopy.forEach((oItem) => {
                oItem.ActWork = parseFloat(oItem.ActWork);
              });
              xCopy = xCopy.sort((a, b) => a.Handle.localeCompare(b.Handle));
              aItemsCopy.forEach((oItem) => {
                oItem.ActWork = parseFloat(oItem.ActWork);
              });
              aItemsCopy = aItemsCopy.sort((a, b) =>
                a.Handle.localeCompare(b.Handle)
              );
            }

            if (sEntity === "Picture") {
              xCopy = xCopy.sort((a, b) => {
                oItem.PicIndex = parseFloat(oItem.PicIndex);
              });
              aItemsCopy = aItemsCopy.sort((a, b) => {
                oItem.PicIndex = parseFloat(oItem.PicIndex);
              });
            }

            if (sEntity === "Participant") {
              xCopy = xCopy.sort((a, b) => a.Pernr.localeCompare(b.Pernr));
              aItemsCopy = aItemsCopy.sort((a, b) =>
                a.Pernr.localeCompare(b.Pernr)
              );
            }

            if (sEntity === "TechnicalObject") {
              xCopy = xCopy.sort((a, b) => a.Strno.localeCompare(b.Strno));
              aItemsCopy = aItemsCopy.sort((a, b) =>
                a.Strno.localeCompare(b.Strno)
              );
            }

            if (sEntity === "KnownScanId") {
              xCopy = xCopy.sort((a, b) => a.ScanId.localeCompare(b.ScanId));
              aItemsCopy = aItemsCopy.sort((a, b) =>
                a.ScanId.localeCompare(b.ScanId)
              );
            }

            if (sEntity === "FuncLocOrg") {
              xCopy = xCopy.sort((a, b) => a.Tplnr.localeCompare(b.Tplnr));
              aItemsCopy = aItemsCopy.sort((a, b) =>
                a.Tplnr.localeCompare(b.Tplnr)
              );
            }

            if (
              _.isEqual(xCopy, aItemsCopy) ||
              (_.isEmpty(xCopy) && aItemsCopy === null)
            ) {
              console.debug(JSON.stringify(xCopy));
              console.debug("Data is same: " + sEntity);
            } else {
              console.error("WebSQL:");
              console.error(x);
              console.error("IndexedDB:");
              console.error(aItems);
              console.error("SQL differs from localforage " + sEntity);
            }

            // Only resolve the answer when both the websql & indexeddb logic has finished
            // d.resolve(oRes);
            let oResult = this._convertToSQLResultSet(aItems);
            d.resolve(oResult);
          }).catch((error)=>{
            d.reject(aItems);
          }
          );
        } else {
          // WebSQL is disabled
          let oResult = this._convertToSQLResultSet(aItems);
          d.resolve(oResult);
        }

        return d.promise();
      },

      getPlanItemEntity: function () {
        // Get property PlanItemEntity, no SQL logic
        // SELECT SValue FROM Setting WHERE SKey=? :: PlanItemSet

        let oPlanItemEntity = this.PlanItemEntity? JSON.parse(this.PlanItemEntity):'';
       

        if (bWebSQLEnabled) {
          let oRes = this.oContext.getPlanItemEntity();
          if (!_.isEqual(oRes, oPlanItemEntity)) {
            console.error("SQL differs from localforage : PlanItemEntity");
          }
        }
        return oPlanItemEntity;
      },

      createTableAndFill: function (entityType, odata) {
        // WebSQL tables dropped, created & filled
        // Results will not be compared with IndexedDB

        // Comparison of whole database content can be done via
        // dbMigrator.check()

        let d = jQuery.Deferred();

        (async () => {
          await localforage.setItem(entityType.name, odata);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.createTableAndFill(entityType, odata);
            oResult.then(async (oRes) => {
              d.resolve(oRes);
            });
          } else {
            d.resolve("IndexedDB entity created: " + entityType);
          }
        })();

        return d.promise();
      },

      maintainInOutTable: function (data) {
        let d = jQuery.Deferred();

        (async () => {
          let aTimes = (await localforage.getItem("TimeInOut")) || [];

          data.forEach((oRow) => {
            let aFilteredTimes = aTimes.filter((oItem) => {
              return (
                oItem.Pernr === oRow.Pernr &&
                oItem.TimeIn !== "" &&
                oItem.TimeOut === ""
              );
            });

            aFilteredTimes = aFilteredTimes.sort(
              (a, b) => b.TimeStamp - a.TimeStamp
            );

            const oHighestTimeStamp = aFilteredTimes[0];

            if (oHighestTimeStamp !== undefined) {
              oHighestTimeStamp.TimeOut = oRow.TimeOut;
            } else {
              aTimes.push(oRow);
            }
          });

          await localforage.setItem("TimeInOut", aTimes);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.maintainInOutTable(data);

            oResult.then(async () => {
              console.debug("maintainInOutTable transaction finished");
              console.warn(
                "maintainInOutTable finished - Compare indexedDB & WebSQL content"
              );
              d.resolve();
            });
          } else {
            console.debug("maintainInOutTable transaction finished");
            d.resolve();
          }
        })();

        return d.promise();
      },
      multipleDataDb: function (entity, aData, metadataObject, type) {
        let d = jQuery.Deferred();
        let that = this;
        (async () => {
          if (type !== "Replace") {
            let aTimes = (await localforage.getItem(entity)) || [];
           
            aTimes = aTimes.concat(aData);
            await localforage.setItem(entity, aTimes);
          } else {
            let aTimes = (await localforage.getItem(entity)) || [];
            aTimes = that.replaceUtilFn(aTimes,aData,metadataObject.key.propertyRef)
            await localforage.setItem(entity, aTimes).then(function(oSu){
              debugger
              console.debug(oSu)
            }).catch(function(oSu){
              debugger
              console.error(oSu)
            });
          }

          if (bWebSQLEnabled) {
            let oResult = this.oContext.multipleDataDb(
              entity,
              aData,
              metadataObject,
              type
            );

            oResult.then(async (oRes) => {
              d.resolve(oRes); // Is also returning aData, no need to verify
              // Only useful verification is to compare the whole database content
              // dbMigrator.check();
            });
          } else {
            d.resolve(aData);
          }
        })();

        return d.promise();
      },
      _getMetaObject: function () {
        return this.getMetaObject();
      },
      deleteAllObjects: function (sEntity) {
        let d = jQuery.Deferred();

        (async () => {
          await localforage.removeItem(sEntity);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteAllObjects(sEntity);

            // Clear database entry
            oResult.then(async (oRes) => {
              // Confirm same content for websql & localforage
              // oRes --> assumption, not needed to return this value
              d.resolve();
            });
          } else {
            d.resolve();
            // If needed, compare the whole DB content after this deletion action
            // dbMigration.check();
          }
        })();

        return d.promise();
      },
      getSAPSettings: function () {
        var d = jQuery.Deferred();

        (async () => {
          let oLFResult = (await localforage.getItem("Setting")) || {};
          //   if (JSON.stringify(oRes) === JSON.stringify(oLFResult)) {

          /**
           * notifFields -> JSON
           * plant
           * sapClient
           * sapUser
           */

          // Get array of property names (keys) of the JSON object
          const keys = _.keys(oLFResult);

          // Iterate over the keys and access corresponding values
          _.forEach(keys, (key) => {
            const value = oLFResult[key];
            // console.debug(`${key}: ${value}`);
            try {
              oLFResult[key] = JSON.parse(value);
            } catch (e) {
              // Just continue
            }
          });

          // Similar behavior in DatabaseService.js for the getSAPSettings method
          delete oLFResult.metadata;

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getSAPSettings();
            oResult.then(async function (oRes) {
              console.debug(oRes);

              let oResCopy = _.cloneDeep(oRes);
              // delete oResCopy.metadata;

              if (
                _.isEqual(oResCopy, oLFResult) ||
                (_.isEmpty(oResCopy) && _.isEmpty(oLFResult))
              ) {
                console.debug("Data is same");
              } else {
                console.error(oResCopy);
                console.error(oLFResult);
                let aProperties = dbMigrator.findDifferentProperties(
                  oResCopy,
                  oLFResult
                );
                console.error(aProperties);
                console.error("SQL differes from localforage data");
              }

              // Only resolve when both websql & localforage have finished
              d.resolve(oLFResult);
            });
          } else {
            d.resolve(oLFResult);
          }
        })();

        return d.promise();
      },
      dropAllTables: function () {
        var d = jQuery.Deferred();

        (async () => {
          // Clear all tables in localforage
          let aKeys = await localforage.keys();

          aKeys = aKeys.filter((sKey) => {
            return sKey !== "trace" && sKey !== "pincode";
          });

          aKeys.forEach(async (sKey) => {
            await localforage.removeItem(sKey);
          });

          if (bWebSQLEnabled) {
            let oResult = this.oContext.dropAllTables();
            oResult.then(async (oRes) => {
              // Only resolve the answer when both the websql & indexeddb logic have finished
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      saveSAPSettings: function (oDataInput) {
        let d = jQuery.Deferred();

        (async () => {
          // oDataInput contains new values for the Setting table
          let oData = JSON.parse(JSON.stringify(oDataInput));
          if (
            this.oComponent.getModel("shared").getProperty("/publicRelease")
          ) {
            delete oData.sapUser;
            delete oData.sapPass;
          }

          let oSettingData = (await localforage.getItem("Setting")) || {};

          for (let sProp in oData) {
            let vValue = oData[sProp];
            if (typeof vValue === "object") {
              vValue = JSON.stringify(vValue);
            }
            //when lang set on onboarding with different lang other than device lang then its taking device lang not set lang
            if (
              oSettingData.langu &&
              oSettingData.langu !== vValue &&
              sProp === "langu"
            ) {
              console.debug(vValue);
            } else {
              oSettingData[sProp] = vValue;
            }
          }

          await localforage.setItem("Setting", oSettingData);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.saveSAPSettings(oDataInput);
            oResult.then(async (oRes) => {
              // to verify same content for websql & localforage use
              // dbMigrator.check();
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      updateSAPSettings: function (aSettings) {
        let d = jQuery.Deferred();

        (async () => {
          if (
            this.oComponent.getModel("shared").getProperty("/publicRelease")
          ) {
            aSettings = aSettings.filter(
              (x) => x.SKey !== "sapUser" && x.SKey !== "sapPass"
            );
          }

          let oSAPSettings = (await localforage.getItem("Setting")) || {};
          aSettings.forEach((oItem) => {
            let vValue = oItem.SValue;
            if (typeof vValue === "object") {
              vValue = JSON.stringify(vValue);
            }
            oSAPSettings[oItem.SKey] = vValue;
          });

          await localforage.setItem("Setting", oSAPSettings);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.updateSAPSettings(aSettings);

            oResult.then(async (oRes) => {
              // To check same content in websql & indexeddb use
              // dbMigrator.check();
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      _savePlanItemSetSettings: function (entity) {
        let d = jQuery.Deferred();

        (async () => {
          let aSetting = (await localforage.getItem("Setting")) || {};

          aSetting["PlanItemSet"] = JSON.stringify(entity);

          await localforage.setItem("Setting", aSetting);

          if (bWebSQLEnabled) {
            let oResult = this.oContext._savePlanItemSetSettings(entity);
            oResult.then(async (oRes) => {
              // Only resolve the answer when both the websql & indexeddb logic have finished
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      _createTable: function (tables) {
        let d = jQuery.Deferred();

        // Only WebSQL --> will not create tables upfront for IndexedDB
        if (bWebSQLEnabled) {
          let oResult = this.oContext._createTable(tables);
          oResult.then(async (oRes) => {
            d.resolve();
          });
        } else {
          d.resolve();
        }

        return d.promise();
      },

      initValueHelp: function (
        oValueHelpData,
        oCatalogData,
        oSettingData,
        oAIC,
        oImpactObl,
        bForceUpdate,
        bUpdateSettings
      ) {
        let d = jQuery.Deferred();
        let _bUpdateSettings = bUpdateSettings;
        let oValueHelpDataCopy = _.cloneDeep(oValueHelpData);
        let oCatalogDataCopy = _.cloneDeep(oCatalogData);
        let oSettingDataCopy = _.cloneDeep(oSettingData);
        let oAICCopy = _.cloneDeep(oAIC);
        let oImpactOblCopy = _.cloneDeep(oImpactObl),
        _bForceUpdate = bForceUpdate;

        (async () => {
          // =================  INDEXEDDB ======== START =========
          if (_bForceUpdate){
            oValueHelpData.results.forEach(async (oVH) => {
              let sDBKey = oVH.Entity + oVH.Property + "VH";
              oVH.NavValueHelpData.results.forEach((oItem) => {
                delete oItem.__metadata;
                delete oItem.Property;
                delete oItem.Entity;
              });
              await localforage.setItem(sDBKey, oVH.NavValueHelpData.results);
            });

            oCatalogData.results.forEach((oCatalogDataItem) => {
              delete oCatalogDataItem.__metadata;
            });

            await localforage.setItem("Catalog", oCatalogData.results);

            oAIC.results.forEach((oItem) => {
              delete oItem.__metadata;
            });

            await localforage.setItem("AICCustomizing", oAIC.results);

            let oSettingDataLF = await localforage.getItem("Setting");

            oSettingData.results.forEach(async (oSetting) => {
              var bUpdate = true;
              if (
                oSetting.SKey === "IWERK" ||
                oSetting.SKey === "INGRP" ||
                oSetting.SKey === "ARBPL" ||
                oSetting.SKey === "SWERK" ||
                oSetting.SKey === "GEWRK" ||
                oSetting.SKey === "REP_BY_WC" ||
                oSetting.SKey === "ISTWERK"
              ) {
                if (
                  this.oComponent.getModel("shared").getProperty("/sapSettings")[
                    oSetting.SKey
                  ] !== ""
                ) {
                  bUpdate = false;
                } else {
                  bUpdate = true;
                }
              }
              if (
                oSetting.SKey === "ARBPL" ||
                oSetting.SKey === "SWERK" ||
                oSetting.SKey === "GEWRK" ||
                oSetting.SKey === "IWERK" ||
                oSetting.SKey === "INGRP" ||
                oSetting.SKey === "REP_BY_WC" ||
                oSetting.SKey === "ISTWERK"
              ) {
                var _updateDoneFromDownload = true;
              }
              if (oSetting.SKey === "DEACT_TIME") {
                oSetting.SValue = oSetting.SValue.replace(",", ".") * 3600000;
              }
              if (oSetting.SKey === "EXIT_TIME") {
                oSetting.SValue =
                  this.helper.convertEURtoUS(oSetting.SValue) * 3600000;
              }

              if (oSetting.SValue == "") {
                switch (oSetting.SKey) {
                  case "MAND_CAUSE":
                    oSetting.SValue = false;
                    break;
                  case "MAND_ACTIV":
                    oSetting.SValue = false;
                    break;
                  case "MAND_DAMAG":
                    oSetting.SValue = false;
                    break;
                  case "CONF_M_BRD":
                    oSetting.SValue = false;
                    break;
                  case "CONF_M_DMG":
                    oSetting.SValue = false;
                    break;
                  case "CONF_M_CSE":
                    oSetting.SValue = false;
                    break;
                  case "FILL_CONFT":
                    oSetting.SValue = false;
                    break;
                  case "EXIT_MASS":
                    oSetting.SValue = false;
                    break;
                  case "EXIT_AUTO":
                    oSetting.SValue = false;
                    break;
                  case "EXIT_BADGE":
                    oSetting.SValue = false;
                    break;
                  default:
                    break;
                }
              }

              if (
                (oSetting.SValue !== "" ||
                  oSetting.SKey === "SHIFTINDIC" ||
                  _updateDoneFromDownload) &&
                (bUpdate === true || _bUpdateSettings === true)
              ) {
                oSettingDataLF[oSetting.SKey] = oSetting.SValue;
              }
            });

            await localforage.setItem("Setting", oSettingDataLF);

            oImpactObl.results.forEach((oImpactOblCustomizing) => {
              delete oImpactOblCustomizing.__metadata;
            });
            await localforage.setItem("ImpactOblCustomizing", oImpactObl.results);

            // =================  INDEXEDDB ====== END ===========

            if (bWebSQLEnabled) {
              let oResult = this.oContext.initValueHelp(
                oValueHelpDataCopy,
                oCatalogDataCopy,
                oSettingDataCopy,
                oAICCopy,
                oImpactOblCopy,
                bForceUpdate,
                bUpdateSettings
              );

              oResult.then(async (oRes) => {
                // You can compare outcome of both indexedDB & websql using
                // dbMigrator.check();
                d.resolve();
              });
            } else {
              d.resolve();
            }
          }else{
            d.resolve();
          }
        })();

        return d.promise();
      },

      getPermanentDataPart1: function (bUpdateSettings, user) {
        // PART 1. delete the existing data from DB

        let d = jQuery.Deferred();

        let fPermanentDataLogic = async () => {
          // Reset data of below tables
          await localforage.removeItem("Catalog");
          await localforage.removeItem("PMNotificationLanguVH");
          await localforage.removeItem("ConfirmationsUnWorkVH");
          await localforage.removeItem("PMNotificationQmartVH");
          await localforage.removeItem("PMNotificationShiftVH");
          await localforage.removeItem("PMNotificationCraftVH");
          await localforage.removeItem("ConfirmationsPMActTypeVH");
          await localforage.removeItem("TechnicalObjectGroupnameVH");
          await localforage.removeItem("PMNotificationPmenvrVH");
          await localforage.removeItem("PMNotificationPmqualVH");
          await localforage.removeItem("PMNotificationPmsafeVH");
          await localforage.removeItem("PMNotificationQuotCoRVH");
          await localforage.removeItem("PMNotificationQuotDeRVH");
          await localforage.removeItem("PMNotificationQuotPrRVH");
          await localforage.removeItem("PMNotificationQuotWcRVH");
          await localforage.removeItem("AICCustomizing");
          await localforage.removeItem("ImpactOblCustomizing");

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getPermanentDataPart1(
              bUpdateSettings,
              user
            );

            // The function calls the initValueHelp function which contains an indexedDB variant before completion

            oResult.then(async (oRes) => {
              // You can compare outcome of both indexedDB & websql using
              // dbMigrator.check();
              d.resolve();
            });
          } else {
            d.resolve();
          }
        };

        fPermanentDataLogic();

        return d.promise();
      },

      getPermanentDataPart2: function (bUpdateSettings, user) {
        // PART 2. retrieve value help data from BE and store it into DB

        // initValueHelp will check if both IndexedDB and WebSQL logic need to be executed

        let d = jQuery.Deferred();

        $.when(this.getSAPSettings()).done(
          jQuery.proxy(function (oSapSetting) {
            let oPromVH = this.service.getValueHelpData(oSapSetting.langu),
              oPromCatalog = this.service.getCatalogSet(oSapSetting.langu),
              oPromSettings = this.service.getSettingSet(
                oSapSetting.langu,
                user
              );

            $.when(oPromCatalog, oPromSettings, oPromVH)
              .done(
                jQuery.proxy(function (oCatalogData, oSettingData, oVHData) {
                  let sPlant = _.find(
                    oSettingData.results,
                    function (oSetting) {
                      return oSetting.SKey === "IWERK";
                    }
                  );
                  let oPromAIC = this.service.getAICCustomizingSet(
                      sPlant.SValue,
                      oSapSetting.langu
                    ),
                    oPromImpactObl = this.service.getImpactOblCustomizingSet(
                      sPlant.SValue,
                      oSapSetting.langu
                    );
                  $.when(oPromAIC, oPromImpactObl).done(
                    jQuery.proxy(function (oAIC, oImpactObl) {
                      console.debug(oAIC);

                      $.when(
                        this.initValueHelp(
                          oVHData,
                          oCatalogData,
                          oSettingData,
                          oAIC,
                          oImpactObl,
                          true,
                          bUpdateSettings
                        )
                      )
                        .done(
                          jQuery.proxy(function () {
                            // oBusyDialog.close();
                            d.resolve();
                          }, this)
                        )
                        .fail(
                          function () {
                            console.error("Updating database failed");
                            // oBusyDialog.close();
                            d.reject();
                          }.bind(this)
                        );
                    }, this)
                  );
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  d.reject(oError);
                }, this)
              );
          }, this)
        );

        return d.promise();
      },

      getPermanentData: function (bUpdateSettings, user) {
        let d = jQuery.Deferred();

        // Function exists out of 2 parts
        // PART 1. delete the existing data from DB
        // PART 2. retrieve value help data from BE and store it into DB

        this.getPermanentDataPart1()
          .then(jQuery.proxy(this.getPermanentDataPart2, this))
          .then((oRes) => {
            d.resolve();
          });

        return d.promise();
      },
      _createTablesFromMetadata: function () {
        // SQL specific table creations
        let d = jQuery.Deferred();

        this.metaObject = this.service.getModel().getServiceMetadata();

        if (bWebSQLEnabled) {
          let oResult = this.oContext._createTablesFromMetadata();
          oResult.then(async (oRes) => {
            d.resolve();
          });
        } else {
          d.resolve();
        }

        return d.promise();
      },
      initValueHelpSet: function (oValueHelp) {
        let d = jQuery.Deferred();

        (async () => {
          oValueHelp.results.forEach((oItem) => {
            delete oItem.__metadata;
          });

          await localforage.setItem("ValueHelpSet", oValueHelp.results);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.initValueHelpSet(oValueHelp);
            oResult.then(async (oRes) => {
              // compare content of valuehelp in websql vs valuehelp in localforage
              // dbMigrator.check();
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },

      _getEntityKeysCustom: function (sEntity, metadataObject) {
        // No DB statements
        return metadataObject;
      },

      _getEntityKeys: function (sEntity) {
        // No DB statements
        let oMetaObject = this._getMetaObject(),
          oEntityMeta = _.find(oMetaObject.dataServices.schema[0].entityType, {
            name: sEntity,
          });

        return _.sortBy(oEntityMeta.key.propertyRef, "name");
      },

      _getRelevantKeys: function (sEntity, oMetaDataObject) {
        // No DB statements
        let aKeys;
        if (!oMetaDataObject) {
          aKeys = this._getEntityKeys(sEntity);
        } else {
          if (!oMetaDataObject.key) {
            debugger;
          }
          aKeys = this._getEntityKeysCustom(
            sEntity,
            oMetaDataObject.key
              ? oMetaDataObject.key.propertyRef
              : oMetaDataObject
          );
        }
        return aKeys;
      },

      deleteObject: function (sEntity, oData, oMetaDataObject) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(sEntity)) || [];

          // delete object based on the key
          // get the keys to consider
          let aKeys = this._getRelevantKeys(sEntity, oMetaDataObject);

          // Filter out the object to delete
          aItems = aItems.filter((oItem) => {
            let bDelete = true;
            // Delete if all keys match
            aKeys.forEach((oKey) => {
              if (oItem[oKey.name] !== oData[oKey.name]) {
                bDelete = false;
              }
            });
            // bDelete is true if all keys match
            return !bDelete;
          });

          await localforage.setItem(sEntity, aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteObject(
              sEntity,
              oData,
              oMetaDataObject
            );

            oResult.then(async (oRes) => {
              // Assumption : return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();
        return d.promise();
      },
      insertObject: function (sEntity, oData, oMetadataObject) {
        if(!this.metaObject &&this.service &&  this.service._oModel && this.service._oModel.oMetadata && this.service._oModel.oMetadata.oMetadata){
          this.metaObject = this.service._oModel.oMetadata.oMetadata;
        }
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(sEntity)) || [];

          if (
            !_.some(aItems, (oItem) => {
              let bAlreadyExists = false;
              // Check if object already exists in localforage
              if (_.isEqual(oItem, oData)) {
                bAlreadyExists = true;
              } else if (
                sEntity === "PMNotification" &&
                oItem.Handle === (oData.Handle || "") &&
                oItem.Qmnum === (oData.Qmnum || "") &&
                oItem.Workhandle === (oData.Workhandle || "")
              ) {
                bAlreadyExists = true;
              } else if (
                sEntity === "Confirmation" &&
                oItem.Aufnr === (oData.Aufnr || "") &&
                oItem.ConfNo === (oData.ConfNo || "") &&
                oItem.Handle === (oData.Handle || "") &&
                oItem.SubActivity === (oData.SubActivity || "") &&
                oItem.Vornr === (oData.Vornr || "") &&
                oItem.Workhandle === (oData.Workhandle || "")
              ) {
                bAlreadyExists = true;
              }

              return bAlreadyExists;
            })
          ) {
            let oNewItem;
            if (sEntity === "Confirmation") {
              oNewItem = this.formatConfirmation(oData);
            } else if (sEntity === "PMNotification") {
              oNewItem = this.formatPMNotification(oData);
            } else if (sEntity === "Picture") {
              oNewItem = this.formatPicture(oData);
            } else if (sEntity === "WCARisks") {
              oNewItem = this.formatWCARisks(oData);
            } else if (sEntity === "WCAOpeRisks") {
              oNewItem = this.formatWCAOpeRisks(oData);
            } else if (sEntity === "Participant") {
              oNewItem = this.formatParticipant(oData);
            } else {
              oNewItem= this.modifyWithMetadata(sEntity, oData, oMetadataObject)
            }
            aItems.push(oNewItem);
          }
          await localforage.setItem(sEntity, aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.insertObject(
              sEntity,
              oData,
              oMetadataObject
            );

            oResult.always(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },

      formatParticipant(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "Participant")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "Arbpl",
        //   "ArbplDescription",
        //   "Area",
        //   "AreaText",
        //   "Ename",
        //   "Ingrp",
        //   "Iwerk",
        //   "Lifnr",
        //   "LifnrText",
        //   "Nachn",
        //   "Pernr",
        //   "Sname",
        //   "Swerk",
        //   "Vorna",
        //   "Workhandle",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          // if (prop === "Iwerk" || prop === "Swerk") {
          //   oNewItem[prop] = parseInt(oNewItem[prop]);
          // } else
          if (typeof oNewItem[prop] !== String && oNewItem[prop] !== null) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatWCARisks(oData) {
        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "WCAOpeRisks")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "ActionText",
        //   "Code",
        //   "Codegrp",
        //   "Codegrpx",
        //   "Codex",
        //   "Objid",
        //   "Qcode2",
        //   "QtxtCode2",
        //   "Vornr",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          // if (prop === "Iwerk" || prop === "Swerk") {
          //   oNewItem[prop] = parseInt(oNewItem[prop]);
          // } else
          if (typeof oNewItem[prop] !== String && oNewItem[prop] !== null) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatWCAOpeRisks(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "WCAOpeRisks")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "ActionText",
        //   "Code",
        //   "Codegrp",
        //   "Codegrpx",
        //   "Codex",
        //   "Objid",
        //   "Qcode2",
        //   "QtxtCode2",
        //   "Vornr",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          // if (prop === "Iwerk" || prop === "Swerk") {
          //   oNewItem[prop] = parseInt(oNewItem[prop]);
          // } else
          if (typeof oNewItem[prop] !== String && oNewItem[prop] !== null) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatFuncLocOrg(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "FuncLocOrg")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "Arbpl",
        //   "ArbplText",
        //   "Ingrp",
        //   "IngrpText",
        //   "Iwerk",
        //   "Swerk",
        //   "Tplnr",
        //   "TrZone",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          if (prop === "Iwerk" || prop === "Swerk") {
            oNewItem[prop] = parseInt(oNewItem[prop]);
          } else if (
            typeof oNewItem[prop] !== String &&
            oNewItem[prop] !== null
          ) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatPicture(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "Picture")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "Description",
        //   "Handle",
        //   "Parent",
        //   "PicContent",
        //   "PicIndex",
        //   "PicName",
        //   "PicType",
        //   "Tag",
        //   "Workhandle",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          // if (prop === "Iwerk" || prop === "Swerk") {
          //   oNewItem[prop] = parseInt(oNewItem[prop]);
          // } else
          if (typeof oNewItem[prop] !== String && oNewItem[prop] !== null) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatPMNotification(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        let aAllowedProps = [];
       
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "PMNotification")
          .property.forEach((x) => {
            aAllowedProps.push(x.name);
          });

        // let aAllowedProps = [
        //   "Arbpl",
        //   "Pmsafe",
        //   "Craft",
        //   "Pmenvr",
        //   "Otkat",
        //   "Pmqual",
        //   "QuotPrR",
        //   "RepByWc",
        //   "QuotCoR",
        //   "Urtxt",
        //   "NotifHandle",
        //   "QuotDeR",
        //   "Otgrp",
        //   "QuotWcR",
        //   "Iwerk",
        //   "Oteil",
        //   "Langu",
        //   "Qmnum",
        //   "Scanid",
        //   "Workhandle",
        //   "Handle",
        //   "Msaus",
        //   "Qmart",
        //   "Swerk",
        //   "Auszt",
        //   "Tplnr",
        //   "AusvnDatetime",
        //   "Equnr",
        //   "AusbsDatetime",
        //   "Qmdat",
        //   "Qmtxt",
        //   "Ingpr",
        //   "StrmnDatetime",
        //   "LtrmnDatetime",
        //   "Qmnam",
        //   "Qmgrp",
        //   "Qmcod",
        //   "Shift",
        //   "Fekat",
        //   "Fegrp",
        //   "Fecod",
        //   "Fetxt",
        //   "Urkat",
        //   "Urgrp",
        //   "Urcod",
        //   "Mnkat",
        //   "Mngrp",
        //   "Mncod",
        //   "Matxt",
        //   "Mfkat",
        //   "Mfgrp",
        //   "Mfcod",
        //   "Mftxt",
        //   "Text",
        //   "SendToGk",
        //   "Hidden",
        //   "OrderHandle",
        //   "Complete",
        // ];

        for (let sProp in oNewItem) {
          if (!aAllowedProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aAllowedProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          if (prop === "Iwerk" || prop === "Swerk") {
            oNewItem[prop] = parseInt(oNewItem[prop]);
          } else if (
            typeof oNewItem[prop] !== String &&
            oNewItem[prop] !== null
          ) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      formatConfirmation(oData) {
        // No DB statements
        // Can be further optimized by using metadata instead of hardcoded list of properties

        let oNewItem = _.cloneDeep(oData);

        // Below properties can be retrieved dynamically from the metadataobject
        // Check DatabaseService.js for the implementation

        let aProps = [];
        this.metaObject.dataServices.schema[0].entityType
          .find((x) => x.name === "Confirmation")
          .property.forEach((x) => {
            aProps.push(x.name);
          });

        // let aProps = [
        //   "ActWork",
        //   "Aufnr",
        //   "Complete",
        //   "ConfNo",
        //   "ConfText",
        //   "ExecFin",
        //   "ExecStart",
        //   "ExecutantCnt",
        //   "FinConf",
        //   "Handle",
        //   "Hidden",
        //   "IsFinished",
        //   "NotifHandle",
        //   "ParentHndl",
        //   "PersNo",
        //   "Plant",
        //   "Pmacttype",
        //   "Split",
        //   "SubActivity",
        //   "Text",
        //   "UnWork",
        //   "UnWorkIso",
        //   "Vornr",
        //   "WorkCntr",
        //   "Workhandle",
        // ];

        for (let sProp in oNewItem) {
          if (!aProps.includes(sProp)) {
            delete oNewItem[sProp];
          }
        }

        for (let prop of aProps) {
          if (oNewItem[prop] === undefined) {
            oNewItem[prop] = "";
          }
        }

        for (let prop in oNewItem) {
          if (prop === "ExecutantCnt" || prop === "Plant") {
            oNewItem[prop] = parseInt(oNewItem[prop]);
          } else if (
            typeof oNewItem[prop] !== String &&
            oNewItem[prop] !== null
          ) {
            oNewItem[prop] = String(oNewItem[prop]);
          }
        }

        return oNewItem;
      },

      updateObject: function (sEntity, oData, oMetadataObject, where) {
        if(!this.metaObject &&this.service &&  this.service._oModel && this.service._oModel.oMetadata && this.service._oModel.oMetadata.oMetadata){
          this.metaObject = this.service._oModel.oMetadata.oMetadata;
        }
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(sEntity)) || [];

          // Select the correct entity ...
          // ?improvement?  model/tables/CustomKeys.js

          console.debug(oData);
          console.debug(oMetadataObject);
          console.debug(where);

          if (sEntity === "Confirmation") {
            // PRIMARY KEY (Aufnr, ConfNo, Handle, SubActivity, Vornr, Workhandle )
            let oUpdatedItem = this.formatConfirmation(oData);
            aItems = aItems.map((oItem) =>
              oItem.Aufnr === (oUpdatedItem.Aufnr || "") &&
              oItem.ConfNo === (oUpdatedItem.ConfNo || "") &&
              oItem.Handle === (oUpdatedItem.Handle || "") &&
              oItem.SubActivity === (oUpdatedItem.SubActivity || "") &&
              oItem.Vornr === (oUpdatedItem.Vornr || "") &&
              oItem.Workhandle === (oUpdatedItem.Workhandle || "")
                ? oUpdatedItem
                : oItem
            );
          } else if (sEntity === "PMNotification") {
            // PRIMARY KEY (Handle, Qmnum, Workhandle
            let oUpdatedItem = this.formatPMNotification(oData);
            aItems = aItems.map((oItem) =>
              oItem.Handle === (oUpdatedItem.Handle || "") &&
              oItem.Qmnum === (oUpdatedItem.Qmnum || "") &&
              oItem.Workhandle === (oUpdatedItem.Workhandle || "")
                ? oUpdatedItem
                : oItem
            );
          }

          await localforage.setItem(sEntity, aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.updateObject(
              sEntity,
              oData,
              oMetadataObject,
              where
            );

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },

      getOrder: function (sOrderId) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMOrder")) || [];

          // Select the correct entity ...
          let oOrder = aItems.filter((oItem) => {
            return oItem.Orderid === sOrderId;
          });

          oOrder = this._convertToSQLResultSet(oOrder);

          for (let i = 0; i < oOrder.rows.length; i++) {
            for (let sRow in oOrder.rows.item(i)) {
              if (sRow === "Plant") {
                oOrder.rows.item(i)[sRow] = parseInt(oOrder.rows.item(i)[sRow]);
              } else if (
                typeof oOrder.rows.item(i)[sRow] !== String &&
                oOrder.rows.item(i)[sRow] !== null
              ) {
                oOrder.rows.item(i)[sRow] = String(oOrder.rows.item(i)[sRow]);
              }
            }
          }

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getOrder(sOrderId);
            oResult.then(async (oRes) => {
              // It might be needed to sort the order of the rows

              if (oOrder.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong order selected for Orderid"
                );
              }

              for (let i = 0; i < oOrder.rows.length; i++) {
                if (!_.isEqual(oOrder.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong order selected for Orderid"
                  );
                }
              }

              d.resolve(oOrder);
            });
          } else {
            d.resolve(oOrder);
          }
        })();

        return d.promise();
      },
      getNotificationWithQmnum: function (sNotifNo) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotification")) || [];

          // Select the correct entity ...
          let oNotification = aItems.filter((oItem) => {
            return oItem.Qmnum === sNotifNo;
          });

          oNotification = this._convertToSQLResultSet(oNotification);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getNotificationWithQmnum(sNotifNo);
            oResult.then(async (oRes) => {
              if (oNotification.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong PMNotification selected for Qmnum"
                );
              }

              for (let i = 0; i < oNotification.rows.length; i++) {
                if (!_.isEqual(oNotification.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong PMNotification selected for Qmnum"
                  );
                }
              }

              d.resolve(oNotification);
            });
          } else {
            d.resolve(oNotification);
          }
        })();

        return d.promise();
      },
      getNotificationWithHandle: function (sHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotification")) || [];

          // Select the correct entity ...
          let oNotification = aItems.filter((oItem) => {
            return oItem.Handle === sHandle;
          });

          oNotification = this._convertToSQLResultSet(oNotification);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getNotificationWithHandle(sHandle);

            oResult.then(async (oRes) => {
              if (oNotification.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong PMNotification selected for Handle"
                );
              }

              for (let i = 0; i < oNotification.rows.length; i++) {
                if (!_.isEqual(oNotification.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong PMNotification selected for Handle"
                  );
                }
              }

              d.resolve(oNotification);
            });
          } else {
            d.resolve(oNotification);
          }
        })();

        return d.promise();
      },
      getOperation: function (sOrderid, sVornr) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Operation")) || [];

          // Select the correct entity ...
          let oOperation = aItems.filter((oItem) => {
            return oItem.Orderid === sOrderid && oItem.Activity === sVornr;
          });

          oOperation = this._convertToSQLResultSet(oOperation);

          // Only 1 operation is selected
          // Next the operation properties are formatted
          for (let sProp in oOperation.rows.item(0)) {
            if (
              sProp === "DurationNormal" ||
              sProp === "NumberOfCapacities" ||
              sProp === "Plant" ||
              sProp === "Quantity"
            ) {
              oOperation.rows.item(0)[sProp] = parseInt(
                oOperation.rows.item(0)[sProp]
              );
            } else if (
              typeof oOperation.rows.item(0)[sProp] !== "string" &&
              oOperation.rows.item(0)[sProp] !== null
            ) {
              oOperation.rows.item(0)[sProp] = String(
                oOperation.rows.item(0)[sProp]
              );
            }
          }

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getOperation(sOrderid, sVornr);

            oResult.then(async (oRes) => {
              if (oRes.rows.length === 0 && oOperation.length === 0) {
                d.resolve(oRes);
                return;
              }

              if (!(oOperation.rows.length === 1 && oRes.rows.length === 1)) {
                console.error(
                  "IndexedDB issue 1: wrong Operation selected for Orderid and Activity"
                );
              }

              if (
                dbMigrator.findDifferentProperties(
                  oRes.rows.item(0),
                  oOperation.rows.item(0)
                ).length > 0
              ) {
                console.error(
                  "IndexedDB issue 2: wrong Operation selected for Orderid and Activity"
                );
              }

              d.resolve(oOperation);
            });
          } else {
            d.resolve(oOperation);
          }
        })();

        return d.promise();
      },
      getPhotoNamesById: function (sParentHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Picture")) || [];

          // Select the correct entity ...
          let aPictures = aItems.filter((oItem) => {
            return oItem.Parent === sParentHandle;
          });

          // aPictures should have the format of an SQL query result
          aPictures = this._convertToSQLResultSet(aPictures);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getPhotoNamesById(sParentHandle);

            oResult.then(async (oRes) => {
              if (aPictures.rows.length !== oRes.rows.length) {
                debugger;
                console.error(
                  "IndexedDB issue 1: wrong Pictures selected for Parent"
                );
              }

              let aIDB = _.cloneDeep(aPictures.rows).map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
              });
              let aSQL = [...oRes.rows].map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
              });

              for (let i = 0; i < aIDB.length; i++) {
                if (!_.isEqual(aIDB[i], aSQL[i])) {
                  console.error(
                    "IndexedDB issue 2: wrong Pictures selected for Parent"
                  );
                }
              }

              d.resolve(aPictures);
            });
          } else {
            d.resolve(aPictures);
          }
        })();

        return d.promise();
      },
      getConfirmationsWithParams: function (sOrderId, sVornr) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Confirmation")) || [];

          // Select the correct entity ...
          let aConfirmations = aItems.filter((oItem) => {
            return oItem.Aufnr === sOrderId && oItem.Vornr === sVornr;
          });

          // aConfirmations should have the format of an SQL query result
          aConfirmations = this._convertToSQLResultSet(aConfirmations);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getConfirmationsWithParams(
              sOrderId,
              sVornr
            );

            oResult.then(async (oRes) => {
              if (aConfirmations.rows.length !== oRes.rows.length) {
                debugger;
                console.error(
                  "IndexedDB issue 1: wrong Confirmation selected for Aufnr and Vornr"
                );
              }

              let oResCopy = [...oRes.rows];
              let aConfirmationsCopy = _.cloneDeep(aConfirmations.rows);

              oResCopy.forEach((oItem) => {
                oItem.ActWork = parseFloat(oItem.ActWork);
              });

              aConfirmationsCopy.forEach((oItem) => {
                oItem.ActWork = parseFloat(oItem.ActWork);
              });

              for (let i = 0; i < aConfirmationsCopy.length; i++) {
                if (
                  !_.some(oResCopy, (oItem) =>
                    _.isEqual(oItem, aConfirmationsCopy[i])
                  )
                ) {
                  console.error(
                    "IndexedDB issue 2: wrong Confirmation selected for Aufnr and Vornr"
                  );
                }
              }

              d.resolve(aConfirmations);
            });
          } else {
            d.resolve(aConfirmations);
          }
        })();

        return d.promise();
      },
      replaceObject: function (sEntity, oData, oMetadataObject) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(sEntity)) || [];

          // debugger;
          let oFormattedItem = this.formatConfirmation(oData);
          let bUpdated = false;

          if (sEntity === "Confirmation") {
            // PRIMARY KEY (Aufnr, ConfNo, Handle, SubActivity, Vornr, Workhandle )
            aItems = aItems.map((oItem) => {
              if (
                oItem.Aufnr === oFormattedItem.Aufnr &&
                oItem.ConfNo === oFormattedItem.ConfNo &&
                oItem.Handle === oFormattedItem.Handle &&
                oItem.SubActivity === oFormattedItem.SubActivity &&
                oItem.Vornr === oFormattedItem.Vornr &&
                oItem.Workhandle === oFormattedItem.Workhandle
              ) {
                bUpdated = true;
                return oFormattedItem;
              } else {
                return oItem;
              }
            });
            if (!bUpdated) {
              aItems.push(oFormattedItem);
            }
          } else if (sEntity === "PMNotification") {
            // PRIMARY KEY (Handle, Qmnum, Workhandle
            aItems = aItems.map((oItem) => {
              if (
                oItem.Handle === oFormattedItem.Handle &&
                oItem.Qmnum === oFormattedItem.Qmnum &&
                oItem.Workhandle === oFormattedItem.Workhandle
              ) {
                bUpdated = true;
                return oFormattedItem;
              } else {
                return oItem;
              }
            });
            if (!bUpdated) {
              aItems.push(oFormattedItem);
            }
          }else{
            let line =[this.modifyWithMetadata(sEntity, oData, oMetadataObject)];
            aItems= this.replaceUtilFn(aItems,line,oMetadataObject.key.propertyRef)
          }

          await localforage.setItem(sEntity, aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.replaceObject(
              sEntity,
              oData,
              oMetadataObject
            );

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      getOperationWithSubActivity: function (sOrderid, sVornr, sSubActivity) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Operation")) || [];

          // Select the correct entity ...
          let aOperation = aItems.filter((oItem) => {
            return (
              oItem.Orderid === sOrderid &&
              oItem.Activity === sVornr &&
              oItem.SubActivity === sSubActivity
            );
          });

          // aOperation should have the format of an SQL query result
          aOperation = this._convertToSQLResultSet(aOperation);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getOperationWithSubActivity(
              sOrderid,
              sVornr,
              sSubActivity
            );

            oResult.then(async (oRes) => {
              if (aOperation.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong Operation selected for Orderid, Activity and SubActivity"
                );
              }
              for (let i = 0; i < aOperation.rows.length; i++) {
                if (!_.isEqual(aOperation.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong Operation selected for Orderid, Activity and SubActivity"
                  );
                }
              }
              d.resolve(aOperation);
            });
          } else {
            d.resolve(aOperation);
          }
        })();

        return d.promise();
      },
      deleteNotification: function (sHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotification")) || [];

          // Select the correct entity ...
          let aNotification = aItems.filter((oItem) => {
            return oItem.Handle !== sHandle;
          });

          await localforage.setItem("PMNotification", aNotification);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteNotification(sHandle);

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deletePicturesFromParent: function (sParent) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Picture")) || [];

          // Select the correct entity ...
          let aPictures = aItems.filter((oItem) => {
            return oItem.Parent !== sParent;
          });

          await localforage.setItem("Picture", aPictures);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deletePicturesFromParent(sParent);

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      getConfirmationsBoundToNotification: function (sNotifHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Confirmation")) || [];

          // Select the correct entity ...
          let aConfirmations = aItems.filter((oItem) => {
            return oItem.NotifHandle === sNotifHandle;
          });

          // aConfirmations should have the format of an SQL query result
          aConfirmations = this._convertToSQLResultSet(aConfirmations);

          if (bWebSQLEnabled) {
            let oResult =
              this.oContext.getConfirmationsBoundToNotification(sNotifHandle);

            oResult.then(async (oRes) => {
              if (aConfirmations.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong Confirmations selected for NotifHandle"
                );
              }

              for (let i = 0; i < aConfirmations.rows.length; i++) {
                // if (!_.isEqual(aConfirmations.rows.item(i), oRes.rows.item(i))) {
                //   console.error(
                //     "IndexedDB issue 2: wrong Confirmations selected for NotifHandle"
                //   );
                // }
                if (
                  !_.some(oRes.rows, (oItem) =>
                    _.isEqual(oItem, aConfirmations.rows.item(i))
                  )
                ) {
                  console.error(
                    "IndexedDB issue 2: wrong Confirmations selected for NotifHandle"
                  );
                }
              }

              d.resolve(aConfirmations);
            });
          } else {
            d.resolve(aConfirmations);
          }
        })();

        return d.promise();
      },
      getPicturesBoundToNotification: function (sParentHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Picture")) || [];

          // Select the correct entity ...
          let aPictures = aItems.filter((oItem) => {
            return oItem.Parent === sParentHandle;
          });

          // aConfirmations should have the format of an SQL query result
          aPictures = this._convertToSQLResultSet(aPictures);

          if (bWebSQLEnabled) {
            let oResult =
              this.oContext.getPicturesBoundToNotification(sParentHandle);

            oResult.then(async (oRes) => {
              if (aPictures.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue: wrong Pictures selected for Parent"
                );
              }

              let aIDB = _.cloneDeep(aPictures.rows).map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
              });
              let aSQL = [...oRes.rows].map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
              });

              for (let i = 0; i < aIDB.length; i++) {
                if (!_.isEqual(aIDB[i], aSQL[i])) {
                  console.error(
                    "IndexedDB issue 2: wrong Pictures selected for Parent"
                  );
                }
              }
              d.resolve(aPictures);
            });
          } else {
            d.resolve(aPictures);
          }
        })();

        return d.promise();
      },
      deletePicturesBoundToNotification: function (sHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Picture")) || [];

          // Select the correct entity ...
          let aPictures = aItems.filter((oItem) => {
            return oItem.Parent !== sHandle;
          });

          await localforage.setItem("Picture", aPictures);

          if (bWebSQLEnabled) {
            let oResult =
              this.oContext.deletePicturesBoundToNotification(sHandle);

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      getInstallationTreeByScanId: function (sScanId) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("TechnicalObject")) || [];

          // Select the correct entity ...
          let aITs = aItems.filter((oItem) => {
            return oItem.Scanid === sScanId;
          });

          // aConfirmations should have the format of an SQL query result
          aITs = this._convertToSQLResultSet(aITs);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getInstallationTreeByScanId(sScanId);

            oResult.then(async (oRes) => {
              if (aITs.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong TechnicalObject selected for Scanid"
                );
              }

              let aITsCopy = _.cloneDeep(aITs.rows);
              aITsCopy = aITsCopy.sort((a, b) =>
                a.Strno.localeCompare(b.Strno)
              );
              let aSQLOutput = [...oRes.rows].sort((a, b) =>
                a.Strno.localeCompare(b.Strno)
              );

              for (let i = 0; i < aITsCopy.length; i++) {
                if (!_.isEqual(aITsCopy[i], aSQLOutput[i])) {
                  console.error(
                    "IndexedDB issue 2: wrong TechnicalObject selected for Scanid"
                  );
                }
              }
              d.resolve(aITs);
            });
          } else {
            d.resolve(aITs);
          }
        })();

        return d.promise();
      },
      getAICByCraft: function (sCraft) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("AICCustomizing")) || [];

          // Select the correct entity ...
          let aAIC = aItems.filter((oItem) => {
            return oItem.Craftcod === sCraft;
          });

          // aAIC should have the format of an SQL query result
          aAIC = this._convertToSQLResultSet(aAIC);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getAICByCraft(sCraft);

            oResult.then(async (oRes) => {
              if (aAIC.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong AICCustomizing selected for Craftcod"
                );
              }

              for (let i = 0; i < aAIC.rows.length; i++) {
                if (!_.isEqual(aAIC.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong AICCustomizing selected for Craftcod"
                  );
                }
              }

              d.resolve(aAIC);
            });
          } else {
            d.resolve(aAIC);
          }
        })();

        return d.promise();
      },

      getScanId: function (sScanId) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("KnownScanId")) || [];

          // Select the correct entity ...
          let aAIC = aItems.filter((oItem) => {
            return oItem.ScanId === sScanId;
          });

          // aAIC should have the format of an SQL query result
          aAIC = this._convertToSQLResultSet(aAIC);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getScanId(sScanId);

            oResult.then(async (oRes) => {
              if (aAIC.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong KnownScanId selected for ScanId"
                );
              }

              for (let i = 0; i < aAIC.rows.length; i++) {
                if (!_.isEqual(aAIC.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong KnownScanId selected for ScanId"
                  );
                }
              }

              d.resolve(aAIC);
            });
          } else {
            d.resolve(aAIC);
          }
        })();

        return d.promise();
      },
      getSqlEntity: function (entityName, keys) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(entityName)) || [];

          let aInputKeys = Object.keys(keys);
          let aInputValues = Object.values(keys);

          // Select the correct entity ...
          let aMatch = aItems.filter((oItem) => {
            let iMatch = 0;
            // Loop over properties of oItem
            for (let sKey in oItem) {
              if (aInputKeys.includes(sKey) && keys[sKey] === oItem[sKey]) {
                // Only return entities that have the correct value for all the keys
                iMatch = iMatch + 1;
              }
            }
            if (iMatch === aInputKeys.length) {
              return true;
            } else {
              return false;
            }
            // return oItem.ScanId === sScanId;
          });

          // aMatch should have the format of an SQL query result
          aMatch = this._convertToSQLResultSet(aMatch);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getSqlEntity(entityName, keys);

            oResult.then(async (oRes) => {
              if (aMatch.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong KnownScanId selected for ScanId"
                );
              }

              for (let i = 0; i < aMatch.rows.length; i++) {
                if (!_.isEqual(aMatch.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong KnownScanId selected for ScanId"
                  );
                }
              }

              d.resolve(aMatch);
            });
          } else {
            d.resolve(aMatch);
          }
        })();

        return d.promise();
      },

      deleteIncluding: function (table, sField, aExcluded) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(table)) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return !aExcluded.includes(oItem[sField]);
          });

          await localforage.setItem(table, aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteIncluding(
              table,
              sField,
              aExcluded
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      updateParticipants: function (sEntity, aParticipants, aOldParticipants) {
        let d = jQuery.Deferred();

        (async () => {
          let aContent = (await localforage.getItem("Participant")) || [];

          // Filter out the existing ones
          aParticipants = aParticipants.map((oItem) => {
            oItem = this.formatParticipant(oItem);
            aContent = aContent.filter((oContent) => {
              return parseInt(oContent.Pernr) !== parseInt(oItem.Pernr);
            });
            return oItem;
          });
          aContent = aContent.concat(aParticipants);

          await localforage.setItem("Participant", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.updateParticipants(
              sEntity,
              aParticipants,
              aOldParticipants
            );

            oResult.then(async (oRes) => {
              // Check if database content is still the same
              // dbMigrator.check()
              // Compare content of oRes & aContent
              d.resolve(aContent);
            });
          } else {
            d.resolve(aContent);
          }
        })();

        return d.promise();
      },

      _saveMetadataToSettings: function () {
        let d = jQuery.Deferred();

        (async () => {
          let oSAPSettings = (await localforage.getItem("Setting")) || {};
          oSAPSettings["metadata"] = JSON.stringify(this.oContext.metaObject);
          await localforage.setItem("Setting", oSAPSettings);

          if (bWebSQLEnabled) {
            let oResult = this.oContext._saveMetadataToSettings();

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },

      saveWorkSetPart1: async function (oData) {
        let d = jQuery.Deferred();

        // Get list of handles for each operation
        // let aHandles = await dbMigrator.getHandles();
        let that = this;

        //---------//
        // Create SQL array
        let aPMOrders = oData.NavOrder.results,
          aExistedOrders = [],
          aPMNotifications = oData.NavPMNotification.results;

        let oPromOrders = (await localforage.getItem("PMOrder")) || []; // this.getEntitySet("PMOrder"), // Reads entity from IndexedDB
        let oPromOperations = (await localforage.getItem("Operation")) || []; // this.getEntitySet("Operation"), // Reads entity from IndexedDB
        let oPromNotifications =
          (await localforage.getItem("PMNotification")) || []; // this.getEntitySet("PMNotification"); // Reads entity from IndexedDB

        $.when(oPromOrders, oPromOperations, oPromNotifications).done(
          jQuery.proxy(async function (
            oDataOrder,
            oDataOperations,
            oDataNotifications
          ) {
            let aOrderSet = oDataOrder || []; // PMOrder  LF-PMOrder    // this.helper.rowsToArray(oDataOrder);
            let aOperationSet = oDataOperations || []; // Operation  LF-Operation   // this.helper.rowsToArray(oDataOperations);
            let aNotificationSet = oDataNotifications || []; // PMNotification    LF-PMNotification   // this.helper.rowsToArray(oDataNotifications);

            let aWCARisks = []; // WCARisks
            let aWCAData = []; // WCAData
            let aWCAOpeRisks = []; // WCAOpeRisks
            let aWCAOpeData = []; // WCAOpeData
            let aPRT = []; // PRT
            let aComponent = []; // Component

            aPMOrders.forEach(
              function (oPMOrder) {
                //check if order is already on device
                if (!this._checkIfOrderExists(aOrderSet, oPMOrder)) {
                  let oPMOrderCopy = _.cloneDeep(oPMOrder);
                  delete oPMOrderCopy.__metadata;
                  delete oPMOrderCopy.NavOperation;
                  aOrderSet.push(oPMOrderCopy);

                  oData.NavWCARisks.results
                    .filter((wcaRisk) => {
                      return wcaRisk.Objid === oPMOrder.Orderid;
                    })
                    .forEach((wcaRisk) => {
                      delete wcaRisk.__metadata;
                      aWCARisks.push(wcaRisk);
                    });
                  oData.NavWCAData.results
                    .filter((WCAData) => {
                      return WCAData.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAData) => {
                      delete WCAData.__metadata;
                      aWCAData.push(WCAData);
                    });
                  oData.NavWCAOpeRisks.results
                    .filter((WCAOpeRisks) => {
                      return WCAOpeRisks.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAOpeRisks) => {
                      delete WCAOpeRisks.__metadata;
                      aWCAOpeRisks.push(WCAOpeRisks);
                    });
                  oData.NavWCAOpeData.results
                    .filter((WCAOpeData) => {
                      return WCAOpeData.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAOpeData) => {
                      delete WCAOpeData.__metadata;
                      aWCAOpeData.push(WCAOpeData);
                    });

                  oPMOrder.NavOperation.results.forEach(
                    function (oOperation) {
                      // Generate handle for each operation, used for selective delete later

                      oOperation.Handle = this.helper.getUUID();
                      // let oHandle = aHandles.find((x) => {
                      //   return (
                      //     x.Activity === String(oOperation.Activity) &&
                      //     x.Orderid === String(oOperation.Orderid)
                      //   );
                      // });
                      // if (oHandle) {
                      //   oOperation.Handle = oHandle.Handle;
                      // } else {
                      //   console.error(
                      //     "Handle not found for activity: " +
                      //       oOperation.Activity +
                      //       " and orderid: " +
                      //       oOperation.Orderid
                      //   );
                      // }

                      let oOperationCopy = _.cloneDeep(oOperation);
                      delete oOperationCopy.__metadata;
                      delete oOperationCopy.NavPRT;
                      delete oOperationCopy.NavComponent;
                      aOperationSet.push(oOperationCopy);

                      if (!oOperation.SubActivity) {
                        oOperation.NavPRT.results.forEach(function (oPRT) {
                          delete oPRT.__metadata;
                          aPRT.push(oPRT);
                        });

                        oOperation.NavComponent.results.forEach(function (
                          oComponent
                        ) {
                          delete oComponent.__metadata;
                          aComponent.push(oComponent);
                        });
                      }
                    }.bind(this)
                  );
                } else {
                  // check if operation is already on device.
                  var aNonExistingOperations = this._checkIfOperationExists(
                    aOperationSet,
                    oPMOrder
                  );
                  if (aNonExistingOperations.length > 0) {
                    oData.NavWCAOpeRisks.results
                      .filter((WCAOpeRisks) => {
                        return (
                          WCAOpeRisks.Objid ===
                            aNonExistingOperations.Orderid &&
                          WCAOpeRisks.Vornr === aNonExistingOperations.Activity
                        );
                      })
                      .forEach((WCAOpeRisks) => {
                        delete WCAOpeRisks.__metadata;
                        aWCAOpeRisks.push(WCAOpeRisks);
                      });
                    oData.NavWCAOpeData.results
                      .filter((WCAOpeData) => {
                        return (
                          WCAOpeData.Objid === aNonExistingOperations.Orderid &&
                          WCAOpeData.Vornr === aNonExistingOperations.Activity
                        );
                      })
                      .forEach((WCAOpeData) => {
                        delete WCAOpeData.__metadata;
                        aWCAOpeData.push(WCAOpeData);
                      });
                    aNonExistingOperations.forEach(
                      function (oOperation) {
                        // Generate handle for each operation, used for selective delete later

                        oOperation.Handle = this.helper.getUUID();

                        // let oHandle = aHandles.find((x) => {
                        //   return (
                        //     x.Activity === String(oOperation.Activity) &&
                        //     x.Orderid === String(oOperation.Orderid)
                        //   );
                        // });

                        // if (oHandle) {
                        //   oOperation.Handle = oHandle.Handle;
                        // } else {
                        //   console.error(
                        //     "Handle not found for activity: " +
                        //       oOperation.Activity +
                        //       " and orderid: " +
                        //       oOperation.Orderid
                        //   );
                        // }

                        let oOperationCopy = _.cloneDeep(oOperation);
                        delete oOperationCopy.__metadata;
                        delete oOperationCopy.NavPRT;
                        delete oOperationCopy.NavComponent;
                        aOperationSet.push(oOperationCopy);

                        if (!oOperation.SubActivity) {
                          oOperation.NavPRT.results.forEach(function (oPRT) {
                            delete oPRT.__metadata;
                            aPRT.push(oPRT);
                          });

                          oOperation.NavComponent.results.forEach(function (
                            oComponent
                          ) {
                            delete oComponent.__metadata;
                            aComponent.push(oComponent);
                          });
                        }
                      }.bind(this)
                    );
                  } else {
                    aExistedOrders.push(oPMOrder.Orderid);
                  }
                }
              }.bind(this)
            );

            aPMNotifications.forEach(
              jQuery.proxy(function (oPMNotification) {
                if (
                  !this._checkIfNotificationExists(
                    aNotificationSet,
                    oPMNotification
                  )
                ) {
                  delete oPMNotification.__metadata;
                  aNotificationSet.push(oPMNotification);
                }
              }, this)
            );

            await localforage.setItem("PMOrder", aOrderSet);
            await localforage.setItem("Operation", aOperationSet);
            await localforage.setItem("PMNotification", aNotificationSet);

            let aCurrentWCARisks =
              (await localforage.getItem("WCARisks")) || [];

            await localforage.setItem(
              "WCARisks",
              aCurrentWCARisks.concat(aWCARisks)
            );

            let aCurrentWCAData = (await localforage.getItem("WCAData")) || [];
            await localforage.setItem(
              "WCAData",
              aCurrentWCAData.concat(aWCAData)
            );

            let aCurrentOpeRisks =
              (await localforage.getItem("WCAOpeRisks")) || [];
            await localforage.setItem(
              "WCAOpeRisks",
              aCurrentOpeRisks.concat(aWCAOpeRisks)
            );

            let aCurrentOpeData =
              (await localforage.getItem("WCAOpeData")) || [];
            await localforage.setItem(
              "WCAOpeData",
              aCurrentOpeData.concat(aWCAOpeData)
            );

            let aCurrentPRT = (await localforage.getItem("PRT")) || [];
            await localforage.setItem("PRT", aCurrentPRT.concat(aPRT));

            let aCurrentComponent =
              (await localforage.getItem("Component")) || [];
            await localforage.setItem(
              "Component",
              aCurrentComponent.concat(aComponent)
            );

            d.resolve(aExistedOrders);
          },
          this)
        );

        return d.promise();
      },

      saveWorkSet: function (oData) {
        let d = jQuery.Deferred();

        this.saveWorkSetPart1(oData).then((aExistedOrders) => {
          if (bWebSQLEnabled) {
            let oResult = this.oContext.saveWorkSet(oData);

            oResult.then(async (oRes) => {
              // oRes should equal aExistedOrders
              if (!_.isEqual(oRes, aExistedOrders)) {
                console.error("save work set output not the same");
              }
              d.resolve(aExistedOrders);
            });
          } else {
            d.resolve(aExistedOrders);
          }
        });

        return d.promise();
      },
      deleteBoundNotifications: function () {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotifications")) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return oItem.Qmnum === "";
          });

          // debugger;
          await localforage.setItem("PMNotifications", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteBoundNotifications();

            oResult.then(async (oRes) => {
              // Assumption: return value is not used
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      setService: function (oService) {
        // Setting service property, no SQL logic
        this.service = oService;
        if (bWebSQLEnabled) {
          this.oContext.setService(oService);
        }
      },
      updateInstallationTree: function (sScanId, aTreeData) {
        let d = jQuery.Deferred();

        let aTreeDataInput = _.cloneDeep(aTreeData);

        (async () => {
          // Insert KnownScanId values
          let techObjects;
          if (aTreeData) {
            techObjects = aTreeData.map((row) => row.TechObject);
          }

          // Retrieve TechnicalObject info
          let aTechnicalObjects =
            (await localforage.getItem("TechnicalObject")) || [];

          // Select the relevant ones
          let instTree = aTechnicalObjects.filter((oItem) => {
            return techObjects.includes(oItem.TechObject);
          });

          let aScanIds = [sScanId];

          aTreeData.forEach(function (oTree) {
            if (oTree.Scanid && aScanIds.indexOf(oTree.Scanid) === -1) {
              aScanIds.push(oTree.Scanid);
            }
          });

          let aAllScanIds = (await localforage.getItem("KnownScanId")) || [];

          aScanIds.forEach((sScanID) => {
            if (
              aAllScanIds.findIndex((oItem) => {
                return sScanID === oItem.ScanId;
              }) === -1
            ) {
              aAllScanIds.push({ ScanId: sScanID });
            }
          });

          // Store the scan ids in the DB
          await localforage.setItem("KnownScanId", aAllScanIds);

          // Store the TechnicalObjects in the DB
          let aDBTreeData = [];
          for (let i = 0; i < aTreeData.length; i++) {
            //Some Function Locations went missing while synching multiple trees Issue 73 in ARMP 11.2
            let treePresent = null;
            treePresent = _.find(instTree, {
              TechObject: aTreeData[i].TechObject,
            });
            if (treePresent && aTreeData[i].TechObjectType !== "PA") {
              if (
                treePresent.Parent &&
                !treePresent.Parent.includes(aTreeData[i].Parent)
              ) {
                //Multiple Parent FL Groups added to FLs.
                aTreeData[i].Parent =
                  aTreeData[i].Parent + "+#+#" + treePresent.Parent;

                // Store aTreeData[i]
                aDBTreeData.push(aTreeData[i]);
              } else {
                if (aTreeData[i].TechObjectType == "IF") {
                  // Store aTreeData[i]
                  aDBTreeData.push(aTreeData[i]);
                }
                // Store treePresent
                else aDBTreeData.push(treePresent);
              }
            } else {
              // Store aTreeData[i]
              aDBTreeData.push(aTreeData[i]);
            }
          }

          // aTechnicalObjects --> existing entries
          // aDBTreeData --> new entries

          aDBTreeData.forEach((newItem) => {
            const existingItem = aTechnicalObjects.find((item) => {
              return (
                item.TechObject === newItem.TechObject &&
                item.TechObjectType === newItem.TechObjectType &&
                item.Workhandle === newItem.Workhandle
              );
            });
            if (existingItem) {
              // Update existing item in aItems
              aTechnicalObjects[aTechnicalObjects.indexOf(existingItem)] =
                newItem;
            } else {
              // Add new item to aItems
              aTechnicalObjects.push(newItem);
            }
          });

          aTechnicalObjects = aTechnicalObjects.map((item) => {
            delete item.__metadata;
            delete item.BomDataSet;
            delete item.NAVTechFloc;
            delete item.NavCraft;
            delete item.NavImpact;

            return item;
          });
          await localforage.setItem("TechnicalObject", aTechnicalObjects);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.updateInstallationTree(
              sScanId,
              aTreeDataInput
            );
            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      saveMultipleReplace: function (entity, aData) {
        // Replace database content ...

        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(entity)) || [];

          // aItems --> existing items
          // aData --> new items
          aData.forEach((newItem) => {
            const existingItem = aItems.find((item) => {
              if (entity === "FuncLocCraft") {
                return (
                  item.Craft === newItem.Craft &&
                  item.Ingrp === newItem.Ingrp &&
                  item.Iwerk === newItem.Iwerk &&
                  item.Swerk === newItem.Swerk &&
                  item.TechObject === newItem.TechObject &&
                  item.Tplnr === newItem.Tplnr &&
                  item.Workhandle === newItem.Workhandle
                );
              } else if (entity === "FuncLocOrg") {
                return item.Tplnr === newItem.Tplnr;
              } else if (entity === "BomData") {
                return (
                  item.Matnr === newItem.Matnr && item.Parent === newItem.Parent
                );
              } else if (entity === "FuncLocImpact") {
                return (
                  item.TechObject === newItem.TechObject &&
                  item.Workhandle === newItem.Workhandle
                );
              }
            });
            if (existingItem) {
              // Update existing item in aItems
              // Object.assign(existingItem, newItem);
              aItems[aItems.indexOf(existingItem)] = newItem;
            } else {
              // Add new item to aItems
              aItems.push(newItem);
            }
          });

          aItems = aItems.map((item) => {
            delete item.__metadata;
            return item;
          });
          await localforage.setItem(entity, aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.saveMultipleReplace(entity, aData);

            oResult.then(async (oRes) => {
              d.resolve(aData);
            });
          } else {
            d.resolve(aData);
          }
        })();

        return d.promise();
      },
      onSelectMultiple: function (entity, sHandle) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(entity)) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return sHandle.includes(oItem.Parent);
          });

          if (bWebSQLEnabled) {
            let oResult = this.oContext.onSelectMultiple(entity, sHandle);

            oResult.then(async (aPictures) => {
              let aContentCopy = _.cloneDeep(aContent).map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
                return oItem;
              });
              let aPicturesCopy = _.cloneDeep(aPictures).map((oItem) => {
                oItem.PicIndex = parseInt(oItem.PicIndex);
                return oItem;
              });

              if (aContentCopy.length !== aPicturesCopy.length) {
                console.error(
                  "IndexedDB issue 1: wrong " +
                    entity +
                    " selected for Parent: " +
                    sHandle
                );
              }

              for (let i = 0; i < aContentCopy.length; i++) {
                if (!_.isEqual(aContentCopy[i], aPicturesCopy[i])) {
                  console.error(
                    "IndexedDB issue 2: wrong " +
                      entity +
                      " selected for Parent: " +
                      sHandle
                  );
                }
              }
              d.resolve(aContent);
            });
          } else {
            d.resolve(aContent);
          }
        })();

        return d.promise();
      },
      deleteNotificationsWithQmnumAndHandle: function (aValues, sColumn) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotification")) || [];
          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return !aValues.includes(oItem[sColumn]);
          });

          // debugger;
          await localforage.setItem("PMNotification", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteNotificationsWithQmnumAndHandle(
              aValues,
              sColumn
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deleteConfirmationsExcluding: function (sField, aExcludedHandles) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Confirmation")) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            // Only keep items from the excluded list
            return aExcludedHandles.includes(oItem[sField]);
          });

          await localforage.setItem("Confirmation", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteConfirmationsExcluding(
              sField,
              aExcludedHandles
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deleteExcluding: function (aExcluded, entity, field) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem(entity)) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            // Only keep the items from the excluding list
            return aExcluded.includes(oItem[field]);
          });

          await localforage.setItem(entity, aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteExcluding(
              aExcluded,
              entity,
              field
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deleteOperationsExcluding: function (sField, aExcludedOperations) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Operation")) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            // DELETE WHERE NOT IN excluded operations
            // Only keep the operations that are in the excluded operations
            return aExcludedOperations.includes(oItem[sField]);
          });

          await localforage.setItem("Operation", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteOperationsExcluding(
              sField,
              aExcludedOperations
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deleteNotificationsExcluding: function (sField, aExcludedHandles) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("PMNotification")) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return !aExcludedHandles.includes(oItem[sField]);
          });

          await localforage.setItem("PMNotification", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteNotificationsExcluding(
              sField,
              aExcludedHandles
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      deletePicturesExcludingParent: function (sField, aExcludedParents) {
        let d = jQuery.Deferred();

        (async () => {
          let aItems = (await localforage.getItem("Picture")) || [];

          // Select the correct entity ...
          let aContent = aItems.filter((oItem) => {
            return !aExcludedParents.includes(oItem[sField]);
          });

          await localforage.setItem("Picture", aContent);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deletePicturesExcludingParent(
              sField,
              aExcludedParents
            );

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },
      getInstallationTreeGroups: function () {
        let d = jQuery.Deferred();

        (async () => {
          let aItems =
            (await localforage.getItem("TechnicalObjectGroupnameVH")) || [];

          aItems = this._convertToSQLResultSet(aItems);

          if (bWebSQLEnabled) {
            let oResult = this.oContext.getInstallationTreeGroups();

            oResult.then(async (oRes) => {
              if (aItems.rows.length !== oRes.rows.length) {
                console.error(
                  "IndexedDB issue 1: wrong TechnicalObjectGroupnameVH content"
                );
              }

              for (let i = 0; i < aItems.rows.length; i++) {
                if (!_.isEqual(aItems.rows.item(i), oRes.rows.item(i))) {
                  console.error(
                    "IndexedDB issue 2: wrong TechnicalObjectGroupnameVH content"
                  );
                }
              }

              d.resolve(aItems);
            });
          } else {
            d.resolve(aItems);
          }
        })();

        return d.promise();
      },
      deleteAllInstallationTree: function () {
        let d = jQuery.Deferred();

        (async () => {
          await localforage.removeItem("TechnicalObject");

          if (bWebSQLEnabled) {
            let oResult = this.oContext.deleteAllInstallationTree();

            oResult.then(async (oRes) => {
              d.resolve();
            });
          } else {
            d.resolve();
          }
        })();

        return d.promise();
      },

      // Helper functions copied from DatabaseService.js
      _checkIfOrderExists: function (aOrderSet, oPMOrder) {
        // Helper function
        let oOrderFound = _.find(aOrderSet, function (oOrder) {
          return oPMOrder.Orderid === oOrder.Orderid;
        });

        return oOrderFound ? true : false;
      },

      _checkIfNotificationExists: function (aNotificationSet, oPMNotification) {
        // Helper function
        var oNotificationFound = _.find(aNotificationSet, function (oNotif) {
          return oNotif.Qmnum === oPMNotification.Qmnum;
        });

        return oNotificationFound ? true : false;
      },

      _checkIfOperationExists: function (aOperationSet, oOrder) {
        // Helper function
        let aNotExistingOperations = [];
        oOrder.NavOperation.results.forEach(function (oPMOperation) {
          var oOperationFound = _.find(aOperationSet, function (oOperation) {
            return oPMOperation.Activity === oOperation.Activity;
          });

          if (!oOperationFound) {
            aNotExistingOperations.push(oPMOperation);
          }
        });

        return aNotExistingOperations;
      },

      _convertToSQLResultSet: function (aRows) {
        // Helper function
        // Simulated SQLResultSet object
        class SimulatedSQLResultSet {
          constructor(rows) {
            this.rows = rows || [];
            this.insertId = null; // Only applicable for INSERT statements
            this.rowsAffected = 0; // Number of rows affected by the SQL statement
            this.rows.item = (index) => {
              if (index >= 0 && index < this.rows.length) {
                return this.rows[index];
              } else {
                return null;
              }
            };
          }

          // Method to get the number of rows in the result set
          get length() {
            return this.rows.length;
          }
        }

        const resultSet = new SimulatedSQLResultSet(aRows);

        return resultSet;
      },

      replaceUtilFn: function(arr1, arr2, keys){
        const updatedArray1 = [];
         keys  = keys.map(({ name }) => name);
        arr1.forEach((obj1) => {
          const match = arr2.find((obj2) => {
            let isEqual = true; // Flag to track equality
      
            keys.forEach((key) => {
              if (obj1[key] !== obj2[key]) { // Check equality for each key
                isEqual = false;
                return false; // Early exit from inner loop if difference found
              }
            });
      
            return isEqual;
          });
      
          if (match) {
            updatedArray1.push({ ...obj1, ...match }); // Update existing object
          } else {
            updatedArray1.push(obj1); // Add object if no match found
          }
        });
      
        return updatedArray1.concat( // Add any remaining objects from array2
          arr2.filter((obj) => !arr1.some((existing) => keys.every((key) => existing[key] === obj[key])))
        );
      },

      modifyWithMetadata:function(type,aEntityData,oMetadataObject) {
         let oEntityData = {}
        var oEntityType ;
        if(!this.metadata){
          return  aEntityData;
        }else{
          oEntityType = this.metadata.find((o)=>{ return o.name===type})
        }
        if(oMetadataObject){
          oEntityType=oMetadataObject;
        }
        for (var i = 0; i < oEntityType.property.length; i++) {
          var oProperty = oEntityType.property[i];
          var sPropertyName = oProperty.name;
          if (aEntityData.hasOwnProperty(sPropertyName)) {
            //   aEntityData[sPropertyName]
          // }else{
            // aEntityData[sPropertyName] =aEntityData[sPropertyName] || '';
            if(oProperty.type ===  "Edm.String"){
              oEntityData[sPropertyName] = aEntityData[sPropertyName]?.toString() || '';
            }else if(oProperty.type ===  "Edm.DateTime"){
              oEntityData[sPropertyName] = aEntityData[sPropertyName]?new Date(aEntityData[sPropertyName]):null;
            }else if(oProperty.type ===  "Edm.Boolean"){
              oEntityData[sPropertyName] = aEntityData[sPropertyName] === 'true' ? true:false;
            }else{
              oEntityData[sPropertyName] = aEntityData[sPropertyName];
            }
          }
          
          
        }
        return oEntityData
      },
    });
  }
);
