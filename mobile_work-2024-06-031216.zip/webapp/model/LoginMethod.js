/*global Connection:true*/
/*global device:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "mobilework/util/Helper",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "mobilework/model/TokenService",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
  ],
  function (Object, Help, Filter, Operator, TokenService, MBox, MToast) {
    "use strict";

    return Object.extend("mobilework.model.LoginMethod", {
      constructor: function (oContext) {
        this.oContext = oContext;
        this._oHelper = new Help();
        this.onBoarding = false;
      },

      checkDeviceRegistration: async function (sPincodeServerDomain) {
        // Check if private key is available in database

        if (
          sPincodeServerDomain === undefined ||
          sPincodeServerDomain === null
        ) {
          console.log("Unknown pincode server domain");
          return false;
        }

        let aRegistrations;
        try {
          aRegistrations = await localforage.getItem("pincode");

          if (Array.isArray(aRegistrations) && aRegistrations.length) {
            const oRegistration = aRegistrations.find(function (oEntry) {
              return oEntry.PincodeServerDomain === sPincodeServerDomain;
            });

            if (oRegistration !== null && oRegistration !== undefined) {
              return true;
            }
          } else {
            return false;
          }
        } catch (oError) {
          console.log("ERROR");
          console.log(oError);
        }
        return false;
      },

      getUrl: async function (sEndpoint) {
        let sUrl;
        // if (!Capacitor.isNative) {
        if (this._oHelper.isDevModeActive()) {
          if (window.location.href.indexOf("cfapps.eu20") !== -1) {
            sUrl = sEndpoint;
          } else {
            const sPort = this.oContext.port;
            sUrl = "http://localhost:" + sPort + "/" + sEndpoint;
            // 3000 -> LOCAL
            // 8080 -> CLOUD
          }
        } else {
          let oMapping = await this._oHelper.getPincodeServerMapping();

          let sKey;
          if (
            this.oContext
              .getModel("shared")
              .getProperty("/sapSettings/sapSysId") === undefined
          ) {
            // During onboarding
            sKey = this.oContext
              .getModel("onboarding")
              .getProperty("/sapSysId");
          } else {
            // Regular login
            sKey = this.oContext
              .getModel("shared")
              .getProperty("/sapSettings/sapSysId");
          }
          let sPincodeServerDomain = oMapping.Mapping[sKey];

          // wa-fipm-pincode-sbx-001
          sUrl =
            "https://" +
            sPincodeServerDomain +
            ".azurewebsites.net/" +
            sEndpoint;
        }

        return sUrl;
      },

      pincodeServerPing: async function (oController, bShowErrors, oFragment) {
        let sUrl;

        sUrl = await this.getUrl("ping");

        let oTarget = {
          type: "GET",
          url: sUrl,
        };

        let oResponse;
        let bStop = false;
        try {
          oResponse = await $.ajax(oTarget);
        } catch (oError) {
          oResponse = oError;
          bStop = true;
          console.log(oError);
        }

        if (oResponse !== undefined && oResponse === "PINCODE SERVER REACHED") {
          // Hardcoded response from Azure Pincode ping service
          // OK
        } else {
          bStop = true;
          console.log("Pincode server response not as expected");
        }

        console.log(oResponse);

        if (bStop || oResponse === undefined) {
          console.log("PING ERROR");
          console.log(oResponse);

          // Show info message about the registration failure
          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          //     await this.abortPincodeSetup(oController);
          // }

          if (
            oResponse.statusText === "Internal Server Error" ||
            oResponse.statusText === "error"
          ) {
            MToast.show(this.oContext.getText("NoSAPSystemConnection"));
          } else if (oResponse.statusText === "Ip Forbidden") {
            MToast.show(this.oContext.getText("NoSAPSystemConnection"));
          } else {
            MBox.error(this.oContext.getText("PincodeServerDown"));
          }

          if (oResponse !== undefined) console.log(oResponse);

          throw new Error("PincodeServerDown");
        }
      },
      onRegisterDevicePress: async function (oController, oFragment) {
        console.log("Perform register device steps");

        // Generate UID
        // var deviceType;
        // if(!this._oHelper.isDevModeActive()){
        //     deviceType = device.platform;

        //  if(deviceType !== 'Android'){
        //     var sUUID = device.uuid;

        //     // Generate private key
        //     var keyPair = await window.crypto.subtle.generateKey(
        //         {
        //             name: "RSA-PSS",
        //             modulusLength: 4096,
        //             publicExponent: new Uint8Array([1, 0, 1]),
        //             hash: "SHA-256"
        //         },
        //         true,
        //         ["sign", "verify"]
        //     );

        //     // Call Middleware with UID & private key
        //     var publicKey = await window.crypto.subtle.exportKey("jwk", keyPair.publicKey);
        //     var privateKey = await window.crypto.subtle.exportKey("jwk", keyPair.privateKey);
        //  }else if(deviceType === 'Android'){
        //     var sUUID = crypto.randomUUID();

        //     // Generate private key
        //     var keyPair = await crypto.subtle.generateKey(
        //         {
        //             name: "RSA-PSS",
        //             modulusLength: 4096,
        //             publicExponent: new Uint8Array([1, 0, 1]),
        //             hash: "SHA-256"
        //         },
        //         true,
        //         ["sign", "verify"]
        //     );

        //     // Call Middleware with UID & private key
        //     var publicKey = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
        //     var privateKey = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
        //  }
        // }

        var sUUID = crypto.randomUUID();

        // Generate private key
        var keyPair = await crypto.subtle.generateKey(
          {
            name: "RSA-PSS",
            modulusLength: 4096,
            publicExponent: new Uint8Array([1, 0, 1]),
            hash: "SHA-256",
          },
          true,
          ["sign", "verify"]
        );

        // Call Middleware with UID & private key
        var publicKey = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
        var privateKey = await crypto.subtle.exportKey(
          "jwk",
          keyPair.privateKey
        );
        // Register key on Authentication server

        const sUser = oController
          .getModel("onboarding")
          .getProperty("/sapUser");
        const sPass = oController
          .getModel("onboarding")
          .getProperty("/sapPass");
        var sSystemID;

        if (
          oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId") !== undefined
        ) {
          sSystemID = oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");
        } else if (
          oController.getModel("onboarding").getProperty("/sapSysId") !==
          undefined
        ) {
          sSystemID = oController
            .getModel("onboarding")
            .getProperty("/sapSysId");
        }

        let oPincode = {
          User: sUser,
          Pass: sPass,
          DeviceID: sUUID,
          PublicKey: JSON.stringify(publicKey),
          SystemID: sSystemID,
        };

        // Check if pincode server is running
        try {
          await this.pincodeServerPing(oController, true, oFragment);
        } catch (oError) {
          console.log("ERROR PING SAP");
          console.log(oError);
          oController
            .getModel("login")
            .setProperty("/show-connection-nok", true);

          throw new Error("NoPing");
        }

        // Based on the SystemID the correct URL will be called
        let sUrl;

        sUrl = await this.getUrl("RegisterDevice");
        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {
        //     const sPort = this.oContext.port;
        //     sUrl = 'http://localhost:' + sPort + '/RegisterDevice';
        //     // 3000 -> Local
        //     // 8080 -> Cloud
        // } else if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //     sUrl = '/RegisterDevice';
        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/RegisterDevice';
        // }

        let oResponse;

        let oOptions = {
          url: sUrl,
          // headers: { 'Content-Type': 'application/json' },
          // data: JSON.stringify(oPincode),
          data: oPincode,
          dataType: "json",
          type: "POST",
        };
        let bStop = false;
        try {
          oResponse = await $.ajax(oOptions);
        } catch (oError) {
          bStop = true;
          oResponse = oError;
          console.log(oError);
        }

        if (bStop) {
          let sError;

          console.log("LOGIN ERROR");
          console.log(oResponse);

          // Show info message about the registration failure
          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          //     await this.abortPincodeSetup();
          // }

          if (oResponse !== undefined) console.log(oResponse);

          if (oResponse.responseJSON.Error !== undefined) {
            sError = oResponse.responseJSON.Error;
          }

          if (sError === "SAP_LOGIN_TEST_FAILED") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED"));
            throw new Error("SAP_LOGIN_TEST_FAILED");
          } else if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED_401"));
            throw new Error("SAP_LOGIN_TEST_FAILED_401");
          } else {
            MBox.error(this.oContext.getText("RegisterDeviceError"));
            throw new Error("REGISTER_DEVICE_ERROR");
          }
        }

        if (bStop) {
          console.log("LOGIN ERROR");
          console.log(oResponse);
          // Show info message about the registration failure
          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          //     await this.abortPincodeSetup(oController);
          //     MBox.error(this.oContext.getText("RegisterDeviceError"));
          // }
        } else {
          console.log(oResponse);

          delete oPincode.User;
          delete oPincode.Pass;
          delete oPincode.SystemID;

          oPincode.PublicKey = keyPair.publicKey;
          oPincode.PrivateKey = keyPair.privateKey;
          oPincode.PincodeServerDomain = oController
            .getModel("login")
            .getProperty("/pincodeServerDomain");

          // Add entry in database
          let aPincode = await localforage.getItem("pincode");
          if (Array.isArray(aPincode) && aPincode.length) {
            aPincode.push(oPincode);
          } else {
            aPincode = [];
            aPincode.push(oPincode);
          }

          await localforage.setItem("pincode", aPincode);

          oController.getModel("onboarding").setProperty("/sapPass", "");

          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          // }
        }
      },
      onRegisterLoginDevicePress: async function (oController, oFragment) {
        console.log("Perform register device steps");

        var sUUID = crypto.randomUUID();

        // Generate private key
        var keyPair = await crypto.subtle.generateKey(
          {
            name: "RSA-PSS",
            modulusLength: 4096,
            publicExponent: new Uint8Array([1, 0, 1]),
            hash: "SHA-256",
          },
          true,
          ["sign", "verify"]
        );

        // Call Middleware with UID & private key
        var publicKey = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
        var privateKey = await crypto.subtle.exportKey(
          "jwk",
          keyPair.privateKey
        );
        // Register key on Authentication server

        const sUser = oController
          .getModel("login")
          .getProperty("/sapUserDeviceRegister");
        const sPass = oController
          .getModel("login")
          .getProperty("/sapPasswordDeviceRegister");
        var sSystemID;

        if (
          oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId") !== undefined
        ) {
          sSystemID = oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");
        } else if (
          oController.getModel("onboarding").getProperty("/sapSysId") !==
          undefined
        ) {
          sSystemID = oController
            .getModel("onboarding")
            .getProperty("/sapSysId");
        }

        let oPincode = {
          User: sUser,
          Pass: sPass,
          DeviceID: sUUID,
          PublicKey: JSON.stringify(publicKey),
          SystemID: sSystemID,
        };

        // Check if pincode server is running
        try {
          await this.pincodeServerPing(oController, true, oFragment);
        } catch (oError) {
          console.log("ERROR PING SAP");
          console.log(oError);
          oController
            .getModel("login")
            .setProperty("/show-connection-nok", true);

          throw new Error("NoPing");
        }

        // Based on the SystemID the correct URL will be called
        let sUrl;

        sUrl = await this.getUrl("RegisterDevice");
        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {
        //     const sPort = this.oContext.port;
        //     sUrl = 'http://localhost:' + sPort + '/RegisterDevice';
        //     // 3000 -> Local
        //     // 8080 -> Cloud
        // } else if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //     sUrl = '/RegisterDevice';
        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/RegisterDevice';
        // }

        let oResponse;

        let oOptions = {
          url: sUrl,
          // headers: { 'Content-Type': 'application/json' },
          // data: JSON.stringify(oPincode),
          data: oPincode,
          dataType: "json",
          type: "POST",
        };
        let bStop = false;
        try {
          oResponse = await $.ajax(oOptions);
        } catch (oError) {
          bStop = true;
          oResponse = oError;
          console.log(oError);
        }

        if (bStop) {
          let sError;

          console.log("LOGIN ERROR");
          console.log(oResponse);

          // Show info message about the registration failure
          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          //     await this.abortPincodeSetup();
          // }

          if (oResponse !== undefined) console.log(oResponse);

          if (oResponse.responseJSON.Error !== undefined) {
            sError = oResponse.responseJSON.Error;
          }

          if (sError === "SAP_LOGIN_TEST_FAILED") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED"));
            throw new Error("SAP_LOGIN_TEST_FAILED");
          } else if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED_401"));
            throw new Error("SAP_LOGIN_TEST_FAILED_401");
          } else {
            MBox.error(this.oContext.getText("RegisterDeviceError"));
            throw new Error("REGISTER_DEVICE_ERROR");
          }
        }

        if (bStop) {
          console.log("LOGIN ERROR");
          console.log(oResponse.responseJSON.Error);
          // Show info message about the registration failure
          // if (oFragment !== undefined) {
          //     this.onCloseLogin(oFragment);
          //     await this.abortPincodeSetup(oController);
          //     MBox.error(this.oContext.getText("RegisterDeviceError"));
          // }
        } else {
          console.log(oResponse);

          delete oPincode.User;
          delete oPincode.Pass;
          delete oPincode.SystemID;

          oPincode.PublicKey = keyPair.publicKey;
          oPincode.PrivateKey = keyPair.privateKey;
          oPincode.PincodeServerDomain = oController
            .getModel("login")
            .getProperty("/pincodeServerDomain");

          // Add entry in database
          let aPincode = await localforage.getItem("pincode");
          if (Array.isArray(aPincode) && aPincode.length) {
            aPincode.push(oPincode);
          } else {
            aPincode = [];
            aPincode.push(oPincode);
          }

          await localforage.setItem("pincode", aPincode);

          oController.getModel("login").setProperty("/sapPass", "");
        }
      },

      resetPincode: async function () {
        // console.log(this.oContext);
        await localforage.removeItem("pincode");
        this.oContext
          .getModel("onboarding")
          .setProperty("/pincodeAvailable", false);

        await this.abortPincodeSetup();
      },

      abortPincodeSetup: async function () {
        this.oContext
          .getModel("onboarding")
          .setProperty("/pincodeState", false);
        this.oContext
          .getModel("onboarding")
          .setProperty("/sapOnboardingPass", true);

        MBox.success(this.oContext.getText("DeviceCertificateResetDone"));

        // this.oContext.getModel('login').setProperty('/pincodeState', false)
        // this.oContext.getModel("login").setProperty("/sapPasswordVisible", true);
        // this.oContext.getModel("login").setProperty("/sapPincodeVisible", false);
      },

      onPincodeLoginPress: async function (oController, oEvent, yesCallback) {
        // Triggered via pressing login button
        let oModel = this.oContext.getModel("onboarding");
        let oDialog = oEvent.getSource().getParent();
        this.onBoarding = true;

        // Below piece of code is needed on the android device for below scenario
        // Opening the login fragment again, after a failed login
        // The wrong login data should be visible to adjust accordingly,
        // Problem is that the model binding doesn't work anymore, even when rebinding the properties
        // >> Therefore we use the ID to write the changes to the model ( not best practice but it covers the requirement here )

        // if (capacitorExports.Capacitor.getPlatform() === "android") {
        //     if(!this._oHelper.isDevModeActive()){
        //     let oLoginUser = sap.ui.getCore().getElementById('LoginUser');
        //     let oLoginPass = sap.ui.getCore().getElementById('LoginPass');
        //     if (oLoginPass !== undefined && oLoginUser !== undefined) {
        //         oModel.setProperty("/sapUser", oLoginUser.getValue());
        //         oModel.setProperty("/sapPass", oLoginPass.getValue());
        //     }
        // }

        console.log("Pincode login");

        // Check if pincode server is running
        await this.pincodeServerPing(oController, true);

        let oChallenge;
        try {
          // Retrieve Challenge
          oChallenge = await this.retrieveChallenge(oController);
        } catch (oError) {
          if (
            oError === "GET_CHALLENGE_FAILED_1" ||
            oError === "GET_CHALLENGE_FAILED_2"
          ) {
            MBox.error(this.oContext.getText("ChallengeRetrievalFailed"));
          }
          throw oError;
        }

        // challenge signature
        const aPincode = await localforage.getItem("pincode");
        const sPincodeServerDomain = oController
          .getModel("login")
          .getProperty("/pincodeServerDomain");
        const oPincode = aPincode.find(function (oEntry) {
          return oEntry.PincodeServerDomain === sPincodeServerDomain;
        });
        const sChallengeSignature = await this.signChallenge(
          oChallenge["challenge"],
          oPincode
        );

        // Read user input
        const sSAPUser = oController
          .getModel("onboarding")
          .getProperty("/sapUser");
        const sSAPPincode = oController
          .getModel("onboarding")
          .getProperty("/sapPinCode");
        const sDeviceID = oPincode.DeviceID;
        var sSystemID;
        if (
          oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId") !== undefined
        ) {
          sSystemID = oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");
        } else if (
          oController.getModel("onboarding").getProperty("/sapSysId") !==
          undefined
        ) {
          sSystemID = oController
            .getModel("onboarding")
            .getProperty("/sapSysId");
        }

        const oUserInfo = {
          User: sSAPUser,
          Pincode: sSAPPincode,
          DeviceID: sDeviceID,
          ChallengeSignature: sChallengeSignature,
          SystemID: sSystemID,
        };

        let oResponse;
        let sUrl;

        sUrl = await this.getUrl("PincodeLogin");

        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {
        //     const sPort = this.oContext.port;
        //     sUrl = 'http://localhost:' + sPort + '/PincodeLogin';
        //     // 3000 -> LOCAL
        //     // 8080 -> CLOUD
        // } else if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //     sUrl = '/PincodeLogin';
        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/PincodeLogin';
        // }

        let oHeaders = {
          "Content-Type": "application/json",
        };
        if (oChallenge["cookie"] !== undefined) {
          oHeaders["Cookie"] = oChallenge["cookie"];
        }

        let oOptions = {
          url: sUrl,
          // headers: oHeaders,
          dataType: "json",
          type: "POST",
          data: oUserInfo,
          webFetchExtra: {
            credentials: "include",
          },
          success: function (data) {
            oResponse = data;
          },
          error: function (oError) {
            oResponse = oError;
            bStop = true;
            console.log(oError);
          },
        };

        let bStop = false;
        let sError;
        let iAttempts;
        // try {
        //     oResponse = await Capacitor.Plugins.CapacitorHttp.post(oOptions);
        // } catch (oError) {
        //     console.log("LOGIN ERROR");
        //     console.log(oError);
        //     // Show info message about the registration failure

        //     // if (oError !== undefined && oError.responseJSON !== undefined) {
        //     //     sError = oError.responseJSON.Error
        //     // }
        //     // if (sError === "WRONG_PINCODE") {
        //     //     iAttempts = oError.responseJSON.AttemptsLeft;
        //     // }
        //     bStop = true;
        // };
        try {
          oResponse = await $.ajax(oOptions);
          oController
            .getModel("login")
            .setProperty("/show-connection-ok", true);
          oController
            .getModel("login")
            .setProperty("/show-authorization-text", true);
        } catch (oError) {
          bStop = true;
          console.log(oError);
        }
        if (bStop) {
          // if (!bStop) {

          if (oResponse !== undefined) {
            sError = oResponse.responseJSON.Error;
          }
          if (sError === "WRONG_PINCODE") {
            iAttempts = oResponse.responseJSON.AttemptsLeft;
          }

          if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            // Prevent wrong password to be used to reach the logging service
            oController.getModel("login").setProperty("/sapPass", "");
          }

          console.log(oResponse);
          // }

          this.showPincodeError(sError, iAttempts, oModel);

          throw new Error("PINCODE_LOGIN_FAILED");
        }

        oModel.setProperty("/sapPass", oResponse.Password);
        oController
          .getSharedModel()
          .setProperty("/sapSettings/sapPass", oResponse.Password);

        // await this.processLoginWrapper(oDialog, oModel, yesCallback);
      },
      onLoginPincodeLoginPress: async function (
        oController,
        oEvent,
        yesCallback
      ) {
        // Triggered via pressing login button
        let oModel = oController.getModel("login");
        let oDialog = oEvent.getSource().getParent();

        // Below piece of code is needed on the android device for below scenario
        // Opening the login fragment again, after a failed login
        // The wrong login data should be visible to adjust accordingly,
        // Problem is that the model binding doesn't work anymore, even when rebinding the properties
        // >> Therefore we use the ID to write the changes to the model ( not best practice but it covers the requirement here )

        // if (capacitorExports.Capacitor.getPlatform() === "android") {
        if (!this._oHelper.isDevModeActive()) {
          let oLoginUser = sap.ui.getCore().getElementById("LoginUser");
          let oLoginPass = sap.ui.getCore().getElementById("LoginPass");
          if (oLoginPass !== undefined && oLoginUser !== undefined) {
            oModel.setProperty("/sapUser", oLoginUser.getValue());
            oModel.setProperty("/sapPass", oLoginPass.getValue());
          }
        }

        console.log("Pincode login");

        // Check if pincode server is running
        try {
          await this.pincodeServerPing(oController, true);
        } catch (oError) {
          console.log("ERROR PING SAP");
          console.log(oError);
          oModel.setProperty("/show-connection-nok", true);

          throw new Error("NoPing");
        }

        let oChallenge;
        try {
          // Retrieve Challenge
          oChallenge = await this.retrieveChallenge(oController);
        } catch (oError) {
          if (
            oError === "GET_CHALLENGE_FAILED_1" ||
            oError === "GET_CHALLENGE_FAILED_2"
          ) {
            MBox.error(this.oContext.getText("ChallengeRetrievalFailed"));
          }
          throw oError;
        }

        // challenge signature
        const aPincode = await localforage.getItem("pincode");
        const sPincodeServerDomain = oController
          .getModel("login")
          .getProperty("/pincodeServerDomain");
        const oPincode = aPincode.find(function (oEntry) {
          return oEntry.PincodeServerDomain === sPincodeServerDomain;
        });
        const sChallengeSignature = await this.signChallenge(
          oChallenge["challenge"],
          oPincode
        );

        // Read user input
        const sSAPUser = oController.getModel("login").getProperty("/sapUser");
        const sSAPPincode = oController
          .getModel("login")
          .getProperty("/sapPinCode");
        const sDeviceID = oPincode.DeviceID;
        var sSystemID;
        if (
          oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId") !== undefined
        ) {
          sSystemID = oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");
        } else if (
          oController.getModel("onboarding").getProperty("/sapSysId") !==
          undefined
        ) {
          sSystemID = oController
            .getModel("onboarding")
            .getProperty("/sapSysId");
        }

        const oUserInfo = {
          User: sSAPUser,
          Pincode: sSAPPincode,
          DeviceID: sDeviceID,
          ChallengeSignature: sChallengeSignature,
          SystemID: sSystemID,
        };

        let oResponse;
        let sUrl;

        sUrl = await this.getUrl("PincodeLogin");
        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {
        //     const sPort = this.oContext.port;
        //     sUrl = 'http://localhost:' + sPort + '/PincodeLogin';
        //     // 3000 -> LOCAL
        //     // 8080 -> CLOUD
        // } else if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //     sUrl = '/PincodeLogin';
        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/PincodeLogin';
        // }

        let oHeaders = {
          "Content-Type": "application/json",
        };
        if (oChallenge["cookie"] !== undefined) {
          oHeaders["Cookie"] = oChallenge["cookie"];
        }

        let oOptions = {
          url: sUrl,
          // headers: oHeaders,
          dataType: "json",
          type: "POST",
          data: oUserInfo,
          webFetchExtra: {
            credentials: "include",
          },
          success: function (data) {
            oResponse = data;
          },
          error: function (oError) {
            oResponse = oError;
            bStop = true;
            console.log(oError);
          },
        };

        let bStop = false;
        let sError;
        let iAttempts;
        // try {
        //     oResponse = await Capacitor.Plugins.CapacitorHttp.post(oOptions);
        // } catch (oError) {
        //     console.log("LOGIN ERROR");
        //     console.log(oError);
        //     // Show info message about the registration failure

        //     // if (oError !== undefined && oError.responseJSON !== undefined) {
        //     //     sError = oError.responseJSON.Error
        //     // }
        //     // if (sError === "WRONG_PINCODE") {
        //     //     iAttempts = oError.responseJSON.AttemptsLeft;
        //     // }
        //     bStop = true;
        // };
        try {
          oResponse = await $.ajax(oOptions);
          oController
            .getModel("login")
            .setProperty("/show-connection-ok", true);
          oController
            .getModel("login")
            .setProperty("/show-authorization-text", true);
        } catch (oError) {
          bStop = true;
          console.log(oError);
        }
        if (bStop) {
          // if (!bStop) {

          if (oResponse !== undefined) {
            sError = oResponse.responseJSON.Error;
          }
          if (sError === "WRONG_PINCODE") {
            iAttempts = oResponse.responseJSON.AttemptsLeft;
          }

          if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            // Prevent wrong password to be used to reach the logging service
            oController.getModel("login").setProperty("/sapPass", "");
          }

          console.log(oResponse);
          // }

          this.showPincodeError(sError, iAttempts, oModel);

          throw new Error("PINCODE_LOGIN_FAILED");
        }

        oModel.setProperty("/sapPass", oResponse.Password);
        oController
          .getSharedModel()
          .setProperty("/sapSettings/sapPass", oResponse.Password);

        // await this.processLoginWrapper(oDialog, oModel, yesCallback);
      },
      showPincodeError: async function (sError, iAttempts, oModel) {
        if (sError === "TOO_MANY_WRONG_ATTEMPTS") {
          MBox.error(this.oContext.getText("TOO_MANY_WRONG_ATTEMPTS"));
        } else if (sError === "FAILED_TO_SET_PINCODE") {
          MBox.error(this.oContext.getText("FAILED_TO_SET_PINCODE"));
        } else if (sError === "WRONG_PINCODE") {
          MBox.error(this.oContext.getText("WRONG_PINCODE", [iAttempts]));
        } else if (sError === "SIGNATURE_VERIFICATION_FAILED") {
          MBox.error(this.oContext.getText("SIGNATURE_VERIFICATION_FAILED"));
        } else if (sError === "PASSWORD_NO_LONGER_VALID") {
          MBox.error(this.oContext.getText("PASSWORD_NO_LONGER_VALID"));
        } else if (sError === "SAP_USER_CURRENTLY_LOCKED") {
          MBox.error(this.oContext.getText("SAP_USER_CURRENTLY_LOCKED"));
        } else if (sError === "SAP_USER_EXPIRED") {
          MBox.error(this.oContext.getText("SAP_USER_EXPIRED"));
        } else if (sError === "SAP_LOGIN_TEST_FAILED") {
          MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED"));
        } else if (sError === "SAP_LOGIN_TEST_FAILED_401") {
          MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED_401"));
        } else if (sError === "SET_PINCODE_FAILED") {
          MBox.error(this.oContext.getText("SET_PINCODE_FAILED"));
        } else if (sError === "DEVICE_REGISTRATION_SECRET_NOT_FOUND") {
          // this.showDeviceRegistrationResetDialog();
          MBox.error(this.oContext.getText("DeviceRegistrationInvalid"));
          await localforage.removeItem("pincode");
          if (!this.onBoarding) {
            oModel.setProperty("/sapPincodeVisible", false);
            oModel.setProperty("/pinCodeState", false);
            oModel.setProperty("/sapPasswordVisible", true);
          }
          if (this.onBoarding) {
            oModel.setProperty("/pincodeAvailable", false);
            oModel.setProperty("/sapOnboardingPass", true);
            oModel.setProperty("/showPinCodeInput", false);
          }
        } else if (sError === "USER_REGISTRATION_SECRET_NOT_FOUND") {
          MBox.error(
            this.oContext.getText("USER_REGISTRATION_SECRET_NOT_FOUND")
          );
          oModel.setProperty("/sapPass", "");
        } else if (sError === "SESSION_CHECK_FAILED") {
          MBox.error(this.oContext.getText("SESSION_CHECK_FAILED"));
        } else {
          MBox.error(this.oContext.getText("UnknownPincodeError"));
        }
      },

      signChallenge: async function (sChallenge, oPincode) {
        let enc = new TextEncoder();
        let sEncodedChallenge = enc.encode(sChallenge);
        console.log("PRIVATEKEY");
        console.log(oPincode.PrivateKey);
        const sEncryptedString = await window.crypto.subtle.sign(
          {
            name: "RSA-PSS",
            saltLength: 32,
          },
          oPincode.PrivateKey,
          sEncodedChallenge
        );

        function arrayBufferToBase64(arrayBuffer) {
          const uint8Array = new Uint8Array(arrayBuffer);
          const base64String = btoa(String.fromCharCode(...uint8Array));
          return base64String;
        }

        console.log(sEncryptedString);
        const base64String = arrayBufferToBase64(sEncryptedString);
        console.log(base64String);
        return base64String;
      },
      retrieveChallenge: async function (oController) {
        let oResponse;
        let oStatus;
        let oXhr;

        let sCookieHeader;

        let sUrl;

        sUrl = await this.getUrl("Challenge");

        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {
        //     const sPort = this.oContext.port;
        //     sUrl = 'http://localhost:' + sPort + '/Challenge';
        //     // 3000 -> LOCAL
        //     // 8080 -> CLOUD
        // } else if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //     sUrl = '/Challenge';
        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/Challenge';
        // }

        function getChallenge(oOptions) {
          return new Promise((resolve, reject) => {
            $.ajax({
              url: oOptions.url,
              type: oOptions.type,
              webFetchExtra: oOptions.webFetchExtra,
              success: function (oData, oStatus, oXhr) {
                resolve({ oData, oStatus, oXhr });
              },
              error: function (oXhr, oStatus, oError) {
                resolve({ oXhr, oStatus, oError });
              },
            });
          });
        }

        let oOptions = {
          url: sUrl,
          type: "GET",
          webFetchExtra: {
            credentials: "include",
          },
        };

        let bStop = false;
        try {
          const oAnswer = await getChallenge(oOptions); // { oResponse , oStatus, oXhr }
          oResponse = oAnswer.oData;
          oStatus = oAnswer.oStatus;
          oXhr = oAnswer.oXhr;
        } catch (oError) {
          // Log error details
          oResponse = oError;
          console.log(oError);
          bStop = true;
        }

        if (bStop) {
          // Log error details
          if (oResponse !== undefined) console.log(oResponse);
          throw new Error("GET_CHALLENGE_FAILED_1");
        }

        // if (oResponse.headers['Set-Cookie'] !== undefined) {
        //     sCookieHeader = oResponse.headers['Set-Cookie'].split(';')[0];
        // }

        let sChallenge;
        if (oResponse !== undefined) {
          sChallenge = oResponse.Challenge;
          console.log(sChallenge);
          return {
            challenge: sChallenge,
            // cookie: sCookieHeader
          };
        }
        throw new Error("GET_CHALLENGE_FAILED_2");
      },
      onRegisterUserPress: async function (oController, oEvent, oFragment) {
        console.log("Perform User registeration");

        // Triggered via pressing login button
        let oModel = oController.getModel("login");

        // Below piece of code is needed on the android device for below scenario
        // Opening the login fragment again, after a failed login
        // The wrong login data should be visible to adjust accordingly,
        // Problem is that the model binding doesn't work anymore, even when rebinding the properties
        // >> Therefore we use the ID to write the changes to the model ( not best practice but it covers the requirement here )

        // if (capacitorExports.Capacitor.getPlatform() === "android") {
        if (!this._oHelper.isDevModeActive()) {
          let oLoginUser = sap.ui.getCore().getElementById("ruUser");
          let oLoginPass = sap.ui.getCore().getElementById("ruPass");
          let oLoginPincode = sap.ui.getCore().getElementById("ruPincode");

          if (oLoginPass !== undefined && oLoginUser !== undefined) {
            oModel.setProperty("/sapUser", oLoginUser.getValue());
            oModel.setProperty("/sapPass", oLoginPass.getValue());
            oModel.setProperty("/sapPinCodeRegister", oLoginPincode.getValue());
          }
        }

        // Make sure user & password are provided by user
        if (
          oModel.getProperty("/sapUserRegister") === "" ||
          oModel.getProperty("/sapPasswordRegister") === "" ||
          sap.ui.getCore().byId("ruPincode").getValue() === ""
        ) {
          console.log("INPUT");
          // console.log(sap.ui.getCore().byId('ruPincode').getValue())
          MToast.show(this.oContext.getText("CredentialMissing"));
          return;
        }

        // Verify pincode complexity
        if (sap.ui.getCore().byId("ruPincode").getValueState() === "Error") {
          MToast.show(this.oContext.getText("PincodeRequirementWarning")); // this.oContext.getText(oError)
          return;
        }

        // Check if pincode server is running
        await this.pincodeServerPing(oController, true, oFragment);

        // Retrieve Challenge
        let oResponse;
        let oChallenge;
        try {
          // Retrieve Challenge
          oChallenge = await this.retrieveChallenge(oController);
        } catch (oError) {
          if (
            oError === "GET_CHALLENGE_FAILED_1" ||
            oError === "GET_CHALLENGE_FAILED_2"
          ) {
            MBox.error(this.oContext.getText("ChallengeRetrievalFailed"));
          }
          throw oError;
        }

        // Read user input
        // localforage
        const sSAPUser = oModel.getProperty("/sapUserRegister");
        const sSAPPass = oModel.getProperty("/sapPasswordRegister");
        const sSAPPincode = oModel.getProperty("/sapPinCodeRegister");
        var sSystemID;
        if (
          oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId") !== undefined
        ) {
          sSystemID = oController
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");
        } else if (
          oController.getModel("onboarding").getProperty("/sapSysId") !==
          undefined
        ) {
          sSystemID = oController
            .getModel("onboarding")
            .getProperty("/sapSysId");
        }

        // challenge signature
        const aPincode = await localforage.getItem("pincode");
        const sPincodeServerDomain = oController
          .getModel("login")
          .getProperty("/pincodeServerDomain");
        const oPincode = aPincode.find(function (oEntry) {
          return oEntry.PincodeServerDomain === sPincodeServerDomain;
        });
        const sChallengeSignature = await this.signChallenge(
          oChallenge["challenge"],
          oPincode
        );

        const sDeviceID = oPincode.DeviceID;

        const oUserInfo = {
          User: sSAPUser,
          Pass: sSAPPass,
          DeviceID: sDeviceID,
          ChallengeSignature: sChallengeSignature,
          Pincode: sSAPPincode,
          SystemID: sSystemID,
        };

        let sUrl;
        sUrl = await this.getUrl("RegisterUser");

        // // if (!Capacitor.isNative) {
        // if (this._oHelper.isDevModeActive()) {

        //     if ( window.location.href.indexOf("cfapps.eu20") !== -1 ) {
        //         sUrl = '/RegisterUser';

        //     }else{
        //         const sPort = this.oContext.port;
        //         sUrl = 'http://localhost:' + sPort + '/RegisterUser';
        //         // 3000 -> LOCAL
        //         // 8080 -> CLOUD
        //     }

        // } else {
        //     sUrl = 'https://' + oController.getModel('login').getProperty('/pincodeServerDomain') + '.azurewebsites.net/RegisterUser';
        // }

        // let oHeaders = {
        //     'Content-Type': 'application/json'
        // };
        if (oChallenge["cookie"] !== undefined) {
          oHeaders["Cookie"] = oChallenge["cookie"];
        }

        let oOptions = {
          url: sUrl,
          // headers: oHeaders,
          data: oUserInfo,
          dataType: "json",
          type: "POST",
          webFetchExtra: {
            credentials: "include",
          },
        };

        let bStop = false;
        try {
          oResponse = await $.ajax(oOptions);
        } catch (oError) {
          oResponse = oError;
          console.log("LOGIN ERROR");
          console.log(oError);
          bStop = true;
        }

        console.log(oResponse);

        if (bStop) {
          let sError;

          if (oResponse !== undefined) {
            sError = oResponse.responseJSON.Error;
          }

          if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            // Clear password to disable trying to send to the log service with invalid credentials !
            oController.getModel("onboarding").setProperty("/sapPass", "");
            oController.getModel("login").setProperty("/sapPass", "");
          }

          if (sError === "DEVICE_REGISTRATION_SECRET_NOT_FOUND") {
            // let closeUserRegistrationDialog = function () {

            //     this.loginMethods.onRegisterUserClose(oFragment);

            // }

            //    this.showDeviceRegistrationResetDialog(closeUserRegistrationDialog);
            MBox.error(this.oContext.getText("DeviceRegistrationInvalid"));
            await localforage.removeItem("pincode");
            oController
              .getModel("login")
              .setProperty("/sapPincodeVisible", false);
            oController.getModel("login").setProperty("/pinCodeState", false);
            oController.onCloseRegisterPinCode();
            throw new Error("DEVICE_REGISTRATION_SECRET_NOT_FOUND");
          } else if (sError === "SAP_LOGIN_TEST_FAILED") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED"));
            throw new Error("SAP_LOGIN_TEST_FAILED");
          } else if (sError === "SAP_LOGIN_TEST_FAILED_401") {
            MBox.error(this.oContext.getText("SAP_LOGIN_TEST_FAILED_401"));

            throw new Error("SAP_LOGIN_TEST_FAILED_401");
          } else {
            MBox.error(this.oContext.getText("UserRegistrationFailure"));

            throw new Error("REGISTER_USER_FAILED");
          }
        }

        // this.onRegisterUserClose(oFragment);

        MBox.success(this.oContext.getText("UserRegistrationSuccess"));

        oController.getModel("onboarding").setProperty("/sapPass", "");
        oController.getModel("login").setProperty("/sapPass", "");
      },
    });
  }
);
