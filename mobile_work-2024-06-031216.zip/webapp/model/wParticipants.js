sap.ui.define([], function () {
  "use strict";

  var entityType = {};
  entityType.name = "wParticipants";
  entityType.property = [];
  entityType.property.push({
    name: "hash",
    type: "type.String",
  });
  entityType.property.push({
    name: "uid",
    type: "type.String",
  });
  entityType.property.push({
    name: "amei",
    type: "type.String",
  });
  entityType.property.push({
    name: "scannedOn",
    type: "type.String",
  });
  entityType.key = { propertyRef: [] };
  entityType.key.propertyRef.push({
    name: "amei",
  });
  return entityType;
});
