/* global _:true */
sap.ui.define(
  [
    "sap/ui/base/Object",
    "mobilework/util/Helper",
    "mobilework/libs/lodash",
    "sap/m/MessageBox",
    "mobilework/model/tables/CustomKeys",
  ],
  function (baseObject, Help, Lo, MBox, CustomKeys) {
    "use strict";
    /**
     * Modifying database tables
     * @namespace mobilework.model.DatabaseService
     * @param {sap.ui.base.Object} baseObject - Sap Core Controller
     * @param {mobilework.util.Helper} Help - Helper Class in MW Application
     * @param {mobilework.libs.lodash} Lo - Loadash external Library
     * @param {sap.m.MessageBox} MBox - Message Box control of SAP
     * @param {mobilework.model.tables.CustomKeys} CustomKeys -Keys for custom tables created in the app
     * @returns {mobilework.model.DatabaseService} The instance of the SQLITE Database service  class.
     */
    return baseObject.extend("mobilework.model.DatabaseService", {
      constructor: function (component) {
        this.helper = new Help();
        this.busyDialog = new sap.m.BusyDialog();
        this.component = component;
      },

      //------------------//
      // PROPERTIES
      //------------------//

      //------------------//
      // PUBLICS
      //------------------//

      initializeDB: function (bOpenOnly, bGetMeta) {
        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog;

        oBusyDialog.open();

        console.debug("initialize db");

        $.when(this._openDatabase(bOpenOnly, bGetMeta))
          .done(function () {
            console.debug("openDatabase done");
            oBusyDialog.close();
            d.resolve();
          })
          .fail(function () {
            console.error("openDatabase failed");
            oBusyDialog.close();
            d.reject();
          });

        return d.promise();
      },

      setService: function (oService) {
        this.service = oService;
      },
      /**
       * Get Catalog, Settings, Valuehelp and store it in DB
       * 24/04/2023: Busy Screen shown in case the database update fails
       * Implemented a fail function to remove the busy screen
       * @memberOf mobilework.model.DatabaseService
       * @public
       * @param  oValueHelpData -Value help Data from SAP
       * @param  oCatalogData - catalog Data used in select controls in SAP
       * @param  oSettingData - User Default etting sfrom Backend
       * @param  oAIC - AIC Customizing Based on Plant
       * @param  oImpactObl -  Impact  Customizing Based on Plant
       * @returns Returns a promise at the end. Resolves only if all data is succefully updated in database
       */
      initValueHelp: function (
        oValueHelpData,
        oCatalogData,
        oSettingData,
        oAIC,
        oImpactObl,
        bForceUpdate,
        bUpdateSettings
      ) {
        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          _bForceUpdate = bForceUpdate,
          _bUpdateSettings = bUpdateSettings;

        if (!this.metaObject) {
          this.metaObject = this.service.getModel().getServiceMetadata();
        }

        this._isSQLAvailable();
        oBusyDialog.open();

        $.when(this._isDBIntialized()).done(
          jQuery.proxy(function (bIsInit) {
            // if (!bIsInit) {
            // 	this._createTablesFromMetadata();
            // }

            if (!bIsInit || _bForceUpdate) {
              this.db.transaction(
                jQuery.proxy(function (tx) {
                  oValueHelpData.results.forEach(
                    jQuery.proxy(function (oVH) {
                      var sSQLCreate = this._getSQLForVhCreateTable(
                          oVH.Entity,
                          oVH.Property
                        ),
                        aSQLInsert = this._getSQLForVhDataInsert(
                          oVH.Entity,
                          oVH.Property,
                          oVH.NavValueHelpData.results
                        );

                      tx.executeSql(
                        sSQLCreate,
                        null,
                        jQuery.proxy(function (tx2, res) {
                          aSQLInsert.forEach(function (oSQLInsert) {
                            tx2.executeSql(oSQLInsert.sql, oSQLInsert.valArray);
                          });
                        }, this),
                        jQuery.proxy(function (tx2, error) {
                          // nothing yet
                        }, this)
                      );
                    }, this)
                  );

                  oCatalogData.results.forEach(
                    jQuery.proxy(function (oCatalog) {
                      var sCreateSQL = this._getSQLForCreateTable("Catalog");

                      var sSQL = this._getSQLForInsertObject(
                          "Catalog",
                          oCatalog
                        ),
                        aValues = this._getValueArrayForInsert(
                          "Catalog",
                          oCatalog
                        );

                      tx.executeSql(
                        sCreateSQL,
                        null,
                        jQuery.proxy(function (tx2, res) {
                          tx2.executeSql(sSQL, aValues);
                        }, this)
                      );

                      //tx.executeSql(sSQL, aValues);
                    }, this)
                  );

                  oAIC.results.forEach(
                    jQuery.proxy(function (oAICCustomizing) {
                      var sCreateSQL =
                        this._getSQLForCreateTable("AICCustomizing");

                      var sSQL = this._getSQLForInsertObject(
                          "AICCustomizing",
                          oAICCustomizing
                        ),
                        aValues = this._getValueArrayForInsert(
                          "AICCustomizing",
                          oAICCustomizing
                        );

                      tx.executeSql(
                        sCreateSQL,
                        null,
                        jQuery.proxy(function (tx2, res) {
                          tx2.executeSql(sSQL, aValues);
                        }, this)
                      );

                      //tx.executeSql(sSQL, aValues);
                    }, this)
                  );

                  oSettingData.results.forEach(
                    jQuery.proxy(function (oSetting) {
                      var bUpdate = true;
                      if (
                        oSetting.SKey === "IWERK" ||
                        oSetting.SKey === "INGRP" ||
                        oSetting.SKey === "ARBPL" ||
                        oSetting.SKey === "SWERK" ||
                        oSetting.SKey === "GEWRK" ||
                        oSetting.SKey === "REP_BY_WC" ||
                        oSetting.SKey === "ISTWERK"
                      ) {
                        if (
                          this.component
                            .getModel("shared")
                            .getProperty("/sapSettings")[oSetting.SKey] !== ""
                        ) {
                          bUpdate = false;
                        } else {
                          bUpdate = true;
                        }
                      }
                      if (
                        oSetting.SKey === "ARBPL" ||
                        oSetting.SKey === "SWERK" ||
                        oSetting.SKey === "GEWRK" ||
                        oSetting.SKey === "IWERK" ||
                        oSetting.SKey === "INGRP" ||
                        oSetting.SKey === "REP_BY_WC" ||
                        oSetting.SKey === "ISTWERK"
                      ) {
                        var _updateDoneFromDownload = true;
                      }
                      if (oSetting.SKey === "DEACT_TIME") {
                        oSetting.SValue =
                          oSetting.SValue.replace(",", ".") * 3600000;
                      }
                      if (oSetting.SKey === "EXIT_TIME") {
                        oSetting.SValue =
                          this.helper.convertEURtoUS(oSetting.SValue) * 3600000;
                        //oSetting.SValue.replace(',','.')*3600000;
                      }

                      if (oSetting.SValue == "") {
                        switch (oSetting.SKey) {
                          case "MAND_CAUSE":
                            oSetting.SValue = false;
                            break;
                          case "MAND_ACTIV":
                            oSetting.SValue = false;
                            break;
                          case "MAND_DAMAG":
                            oSetting.SValue = false;
                            break;
                          case "CONF_M_BRD":
                            oSetting.SValue = false;
                            break;
                          case "CONF_M_DMG":
                            oSetting.SValue = false;
                            break;
                          case "CONF_M_CSE":
                            oSetting.SValue = false;
                            break;
                          case "FILL_CONFT":
                            oSetting.SValue = false;
                            break;
                          case "EXIT_MASS":
                            oSetting.SValue = false;
                            break;
                          case "EXIT_AUTO":
                            oSetting.SValue = false;
                            break;
                          case "EXIT_BADGE":
                            oSetting.SValue = false;
                            break;
                          default:
                            break;
                        }
                      }
                      if (
                        (oSetting.SValue !== "" ||
                          oSetting.SKey === "SHIFTINDIC" ||
                          _updateDoneFromDownload) &&
                        (bUpdate === true || _bUpdateSettings === true)
                      ) {
                        var sSQL =
                            "REPLACE INTO Setting (SValue, SKey) VALUES (?,?)",
                          aValues = [oSetting.SValue, oSetting.SKey];

                        tx.executeSql(sSQL, aValues);
                      }
                    }, this)
                  );

                  oImpactObl.results.forEach(
                    jQuery.proxy(function (oImpactOblCustomizing) {
                      var sCreateSQL = this._getSQLForCreateTable(
                        "ImpactOblCustomizing"
                      );

                      var sSQL = this._getSQLForInsertObject(
                          "ImpactOblCustomizing",
                          oImpactOblCustomizing
                        ),
                        aValues = this._getValueArrayForInsert(
                          "ImpactOblCustomizing",
                          oImpactOblCustomizing
                        );

                      tx.executeSql(
                        sCreateSQL,
                        null,
                        jQuery.proxy(function (tx2, res) {
                          tx2.executeSql(sSQL, aValues);
                        }, this)
                      );
                    }, this)
                  );
                }, this),
                function (error) {
                  oBusyDialog.close();
                  d.reject(error);
                },
                jQuery.proxy(async function () {
                  // Old Localforage logic location

                  oBusyDialog.close();

                  d.resolve();
                }, this)
              );
            } else {
              oBusyDialog.close();
              d.resolve();
            }
          }, this)
        );

        return d.promise();
      },

      insertObject: function (sEntity, oData, oMetadataObject) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred();
        var sSQL = this._getSQLForInsertObject(sEntity, oData, oMetadataObject);
        var aValues = this._getValueArrayForInsert(
          sEntity,
          oData,
          oMetadataObject
        );
        var oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              aValues,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
          }
        );

        return d.promise();
      },

      updateObject: function (sEntity, oData, oMetadataObject, where) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = this._getSQLForUpdateObject(
            sEntity,
            oData,
            oMetadataObject,
            where
          ),
          aValues = this._getValueArrayForUpdate(
            sEntity,
            oData,
            oMetadataObject,
            where
          ),
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              aValues,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
          }
        );

        return d.promise();
      },

      replaceObject: function (sEntity, oData, oMetadataObject) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = this._getSQLForReplaceObject(sEntity, oData, oMetadataObject),
          aValues = this._getValueArrayForInsert(
            sEntity,
            oData,
            oMetadataObject
          ),
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              aValues,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
          }
        );

        return d.promise();
      },

      deleteObject: function (sEntity, oData, oMetaDataObject) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = this._getSQLForDeleteObject(sEntity, oData, oMetaDataObject),
          aValues = this._getValueArrayForDelete(
            sEntity,
            oData,
            oMetaDataObject
          ),
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              aValues,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
          }
        );

        return d.promise();
      },

      dropAllTables: function () {
        var d = jQuery.Deferred(),
          sSQL =
            "SELECT 'DROP TABLE IF EXISTS ' || name FROM sqlite_master WHERE TYPE = 'table';",
          aDropStatments = [];

        if (this._isSQLAvailable()) {
          this.db.transaction(
            function (tx) {
              tx.executeSql(sSQL, null, function (tx2, res) {
                for (var i = 1; i < res.rows.length; i++) {
                  for (var sProp in res.rows.item(i)) {
                    aDropStatments.push(res.rows.item(i)[sProp]);
                  }
                }
                aDropStatments.forEach(function (sDropStatement) {
                  tx2.executeSql(sDropStatement);
                });
              });
            },
            function (error) {
              d.reject();
            },
            function () {
              d.resolve();
            }
          );
        }

        return d.promise();
      },

      deleteAllObjects: function (sEntity) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "DELETE FROM " + sEntity,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              null,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.resolve(error);
              }
            );
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.reject();
          }
        );

        return d.promise();
      },

      deleteOperationsExcluding: function (sField, aExcludedOperations) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          _aExcludedOperations = aExcludedOperations.filter(function (
            item,
            pos
          ) {
            return aExcludedOperations.indexOf(item) === pos;
          }),
          sSQL =
            "DELETE FROM Operation " +
            this._getExcludeWhereClause(sField, _aExcludedOperations.length),
          aValues = _aExcludedOperations,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deleteExcluding: function (aExcluded, entity, field) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          _aExcluded = aExcluded.filter(function (item, pos) {
            return aExcluded.indexOf(item) === pos;
          }),
          sSQL =
            "DELETE FROM " +
            entity +
            " " +
            this._getExcludeWhereClause(field, _aExcluded.length),
          aValues = _aExcluded,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deleteNotificationsExcluding: function (sField, aExcludedHandles) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL =
            "DELETE FROM PMNotification " +
            this._getExcludeWhereClause(sField, aExcludedHandles.length),
          aValues = aExcludedHandles,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deleteNotificationsWithQmnumAndHandle: function (aValues, sColumn) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "",
          oBusyDialog = this.busyDialog,
          sParams = "?",
          iLength = aValues.length,
          bNoValues = false;

        //set up number of ? for parameters
        for (var i = 0; i < iLength - 1; i++) {
          sParams = sParams + ",?";
        }

        if (aValues.length !== 0 && sColumn !== "") {
          sSQL =
            "DELETE FROM PMNotification WHERE " +
            sColumn +
            " IN (" +
            sParams +
            ")";
        } else if (aValues.length === 0) {
          bNoValues = true;
        }

        if (!bNoValues) {
          this.db.transaction(
            function (tx) {
              tx.executeSql(sSQL, aValues);
              console.debug(sSQL);
              console.debug(aValues);
            },
            function (error) {
              oBusyDialog.close();
              d.reject(error);
            },
            function () {
              oBusyDialog.close();
              d.resolve();
            }
          );
        } else {
          oBusyDialog.close();
          d.resolve();
        }

        return d.promise();
      },

      deleteNotification: function (sHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "DELETE FROM PMNotification WHERE Handle=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, [sHandle]);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deletePicturesBoundToNotification: function (sHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "DELETE FROM Picture WHERE Parent=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, [sHandle]);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deleteBoundNotifications: function () {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "DELETE FROM PMNotification WHERE Qmnum != ''",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deleteConfirmationsExcluding: function (sField, aExcludedHandles) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL =
            "DELETE FROM Confirmation " +
            this._getExcludeWhereClause(sField, aExcludedHandles.length),
          aValues = aExcludedHandles,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deletePicturesFromParent: function (sParent) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "DELETE FROM Picture WHERE Parent=?",
          aValues = [sParent],
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      deletePicturesExcludingParent: function (sField, aExcludedParents) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL =
            "DELETE FROM Picture " +
            this._getExcludeWhereClause(sField, aExcludedParents.length),
          aValues = aExcludedParents,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sSQL, aValues);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      getSAPSettings: function () {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Setting",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              null,
              function (tx2, res) {
                var oSAPInfo = {};

                for (var i = 0; i < res.rows.length; i++) {
                  try {
                    oSAPInfo[res.rows.item(i).SKey] = JSON.parse(
                      res.rows.item(i).SValue
                    );
                  } catch (_e) {
                    oSAPInfo[res.rows.item(i).SKey] = res.rows.item(i).SValue;
                  }
                }

                delete oSAPInfo.metadata;

                oBusyDialog.close();
                d.resolve(oSAPInfo);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.resolve({});
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      saveSAPSettings: function (oDataInput) {
        // SAVE STTINGS TABLE

        let oData = JSON.parse(JSON.stringify(oDataInput));

        if (this.component.getModel("shared").getProperty("/publicRelease")) {
          delete oData.sapUser;
          delete oData.sapPass;
        }

        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL =
            "CREATE TABLE IF NOT EXISTS Setting (SKey PRIMARY KEY, SValue)",
          oBusyDialog = this.busyDialog,
          _oData = oData;
        $.when(this.getSAPSettings()).done(
          jQuery.proxy(function (oSettingData) {
            this.db.transaction(
              function (tx) {
                tx.executeSql(
                  sSQL,
                  null,
                  function (tx2, res) {
                    // var sSQL2 = "INSERT INTO Setting VALUES (?, ?)";
                    var sSQL2 =
                      "REPLACE INTO Setting (SKey, SValue) VALUES (?,?)";

                    for (var sProp in _oData) {
                      var vValue = _oData[sProp];
                      // if (vValue !== "") {
                      if (typeof vValue === "object") {
                        vValue = JSON.stringify(vValue);
                      }
                      //when lang set on onboarding with different lang other than device lang then its taking device lang not set lang
                      if (
                        oSettingData.langu &&
                        oSettingData.langu !== vValue &&
                        sProp === "langu"
                      ) {
                        console.debug(vValue);
                      } else {
                        tx2.executeSql(sSQL2, [sProp, vValue]);
                      }
                    }

                    oBusyDialog.close();
                    d.resolve();
                  },
                  function (tx2, error) {
                    oBusyDialog.close();
                    d.reject(error);
                  }
                );
              },
              function (error) {
                console.error("Transaction ERROR: " + error.message);
              },
              function () {
                console.debug("Populated database OK");
              }
            );
          }, this)
        );

        return d.promise();
      },

      updateSAPSettings: function (aSettings) {
        this._isSQLAvailable();
        this.busyDialog.open();

        // Do not perform this action in case of a functional user policy
        if (this.component.getModel("shared").getProperty("/publicRelease")) {
          aSettings = aSettings.filter(
            (x) => x.SKey !== "sapUser" && x.SKey !== "sapPass"
          );
        }

        var d = jQuery.Deferred(),
          sSQL = "REPLACE INTO Setting (SValue, SKey) VALUES (?,?)",
          oBusyDialog = this.busyDialog,
          _aSettings = aSettings;

        this.db.transaction(
          function (tx) {
            for (var i = 0; i < _aSettings.length; i++) {
              if (
                _aSettings[i].SValue === undefined ||
                _aSettings[i].SValue === "undefined"
              ) {
                var vValue = "";
              } else {
                vValue = _aSettings[i].SValue;
              }
              if (typeof vValue === "object") {
                vValue = JSON.stringify(vValue);
              }

              tx.executeSql(sSQL, [vValue, _aSettings[i].SKey]);
            }
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      getEntitySet: function (sEntity, custom) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL,
          sValue = null,
          oBusyDialog = this.busyDialog;
        console.debug("get entity set: ", sEntity);
        console.debug(sSQL);
        if (custom) {
          if (typeof custom === "string") {
            sSQL = custom;
          } else {
            sValue = custom[1];
            sSQL = custom[0];
          }
        } else {
          sSQL = this._getSQLForFullReadTable(sEntity);
        }
        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              sValue,
              function (tx2, res) {
                console.debug("get entity set: ", res);
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                console.error("get entity set: ", error);
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.debug("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getScanId: function (sScanId) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM KnownScanId WHERE ScanId=?",
          oBusyDialog = this.busyDialog,
          _sScanId = sScanId;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sScanId],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getOrder: function (sOrderId) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM PMOrder WHERE Orderid=?",
          oBusyDialog = this.busyDialog,
          _sOrderid = sOrderId;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sOrderid],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getOperation: function (sOrderid, sVornr) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Operation WHERE Orderid=? AND Activity=?",
          oBusyDialog = this.busyDialog,
          _sOrderid = sOrderid,
          _sVornr = sVornr;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sOrderid, _sVornr],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getOperationWithSubActivity: function (sOrderid, sVornr, sSubActivity) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL =
            "SELECT * FROM Operation WHERE Orderid=? AND Activity=? AND SubActivity=?",
          oBusyDialog = this.busyDialog,
          _sOrderid = sOrderid,
          _sVornr = sVornr,
          _sSubActivity = sSubActivity;

        if (!_sSubActivity) {
          sSubActivity = "";
        }

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sOrderid, _sVornr, _sSubActivity],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getNotBoundNotifications: function () {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM PMNotification WHERE Qmnum = ''",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              null,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getNotificationWithHandle: function (sHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM PMNotification WHERE Handle=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sHandle],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getNotificationWithQmnum: function (sNotifNo) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM PMNotification WHERE Qmnum=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sNotifNo],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getConfirmationsWithParams: function (sOrderId, sVornr) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Confirmation WHERE Aufnr=? AND Vornr=?",
          oBusyDialog = this.busyDialog,
          _sOrderid = sOrderId,
          _sVornr = sVornr;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sOrderid, _sVornr],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getConfirmationsBoundToNotification: function (sNotifHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Confirmation WHERE NotifHandle=?",
          oBusyDialog = this.busyDialog,
          _sNotifHandle = sNotifHandle;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [_sNotifHandle],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getValueHelp: function (sEntity, sProp) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = this._getSQLForVhDataGet(sEntity, sProp),
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              null,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getAllVHAndCatalogs: function () {
        var oPromCatalog = this.getEntitySet("Catalog"),
          oPromQmart = this.getEntitySet("PMNotificationQmartVH"),
          oPromShift = this.getEntitySet("PMNotificationShiftVH"),
          oPromLangu = this.getEntitySet("PMNotificationLanguVH"),
          oPromUnWork = this.getEntitySet("ConfirmationsUnWorkVH"),
          oPromCraft = this.getEntitySet("PMNotificationCraftVH"),
          oPromSettings = this.getSAPSettings(),
          oPromActType = this.getEntitySet("ConfirmationsPMActTypeVH"),
          oPromPmenvr = this.getEntitySet("PMNotificationPmenvrVH"),
          oPromPmqual = this.getEntitySet("PMNotificationPmqualVH"),
          oPromPmsafe = this.getEntitySet("PMNotificationPmsafeVH"),
          oPromQuotCoR = this.getEntitySet("PMNotificationQuotCoRVH"),
          oPromQuotDeR = this.getEntitySet("PMNotificationQuotDeRVH"),
          oPromQuotPrR = this.getEntitySet("PMNotificationQuotPrRVH"),
          oPromQuotWcR = this.getEntitySet("PMNotificationQuotWcRVH"),
          oPromImpactOblCustomizing = this.getEntitySet("ImpactOblCustomizing"),
          d = $.Deferred(),
          oPromNotifcationType = this.helper.getNotificationTypes();

        $.when(
          oPromQmart,
          oPromCatalog,
          oPromShift,
          oPromLangu,
          oPromUnWork,
          oPromCraft,
          oPromSettings,
          oPromActType,
          oPromPmenvr,
          oPromPmqual,
          oPromPmsafe,
          oPromQuotCoR,
          oPromQuotDeR,
          oPromQuotPrR,
          oPromQuotWcR,
          oPromImpactOblCustomizing,
          oPromNotifcationType
        ).done(
          jQuery.proxy(function (
            _oQmartData,
            _oCatalogData,
            _oShiftData,
            _oLanguData,
            _oUnWorkData,
            _oCraftData,
            _oSettingData,
            _oActyTpeData,
            _oPmenvrData,
            _oPmqualData,
            _oPmsafeData,
            _oQuotCoRData,
            _oQuotDeRData,
            _oQuotPrRData,
            _oQuotWcRData,
            _oImpactOblData,
            oNotifcationType
          ) {
            var oSharedModel = this.component.getModel("shared"),
              aQmart = [],
              aCatalog = [],
              aShift = [],
              aLangu = [],
              aCraft = [],
              aUnWork = [],
              aActType = [],
              aPmqual = [],
              aPmsafe = [],
              aQuotCoR = [],
              aQuotDeR = [],
              aQuotPrR = [],
              aQuotWcR = [],
              aPmenvr = [],
              aImpactObl = [];

            // for (var i = 0; i < _oQmartData.rows.length; i++) {
            // 	aQmart.push(_oQmartData.rows.item(i));
            // }

            for (var j = 0; j < _oCatalogData.rows.length; j++) {
              aCatalog.push(_oCatalogData.rows.item(j));
            }

            for (var k = 0; k < _oShiftData.rows.length; k++) {
              aShift.push(_oShiftData.rows.item(k));
            }

            for (var l = 0; l < _oLanguData.rows.length; l++) {
              aLangu.push(_oLanguData.rows.item(l));
            }

            for (var m = 0; m < _oUnWorkData.rows.length; m++) {
              aUnWork.push(_oUnWorkData.rows.item(m));
            }

            for (var n = 0; n < _oCraftData.rows.length; n++) {
              aCraft.push(_oCraftData.rows.item(n));
            }

            for (var o = 0; o < _oActyTpeData.rows.length; o++) {
              aActType.push(_oActyTpeData.rows.item(o));
            }
            for (var o = 0; o < _oPmenvrData.rows.length; o++) {
              aPmenvr.push(_oPmenvrData.rows.item(o));
            }
            for (var o = 0; o < _oPmqualData.rows.length; o++) {
              aPmqual.push(_oPmqualData.rows.item(o));
            }
            for (var o = 0; o < _oPmsafeData.rows.length; o++) {
              aPmsafe.push(_oPmsafeData.rows.item(o));
            }
            for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
              aQuotCoR.push(_oQuotCoRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
              aQuotDeR.push(_oQuotDeRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
              aQuotPrR.push(_oQuotPrRData.rows.item(o));
            }
            for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
              aQuotWcR.push(_oQuotWcRData.rows.item(o));
            }
            for (var o = 0; o < _oImpactOblData.rows.length; o++) {
              aImpactObl.push(_oImpactOblData.rows.item(o));
            }

            // Issue no. 110 in V13.0
            aPmenvr.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aPmqual.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aPmsafe.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotCoR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotDeR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotPrR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aQuotWcR.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });
            aImpactObl.sort((a, b) => {
              return a.VhKey - b.VhKey;
            });

            oSharedModel.setProperty("/vh", {});
            oSharedModel.setProperty("/vh/Qmart", oNotifcationType.Types);
            oSharedModel.setProperty("/vh/Catalog", aCatalog);
            oSharedModel.setProperty("/vh/Shift", aShift);
            oSharedModel.setProperty("/vh/Langu", aLangu);
            oSharedModel.setProperty("/vh/UnWork", aUnWork);
            oSharedModel.setProperty("/vh/Craft", aCraft);
            oSharedModel.setProperty("/vh/ActType", aActType);
            oSharedModel.setProperty("/vh/Pmenvr", aPmenvr);
            oSharedModel.setProperty("/vh/Pmqual", aPmqual);
            oSharedModel.setProperty("/vh/Pmsafe", aPmsafe);
            oSharedModel.setProperty("/vh/QuotCoR", aQuotCoR);
            oSharedModel.setProperty("/vh/QuotDeR", aQuotDeR);
            oSharedModel.setProperty("/vh/QuotPrR", aQuotPrR);
            oSharedModel.setProperty("/vh/QuotWcR", aQuotWcR);
            oSharedModel.setProperty("/vh/ImpactObl", aImpactObl);
            oSharedModel.setProperty(
              "/vh/headerLines",
              aCatalog.filter((aCat) => {
                return aCat.Code === "";
              })
            );

            if (
              _oSettingData.sapUser === undefined &&
              _oSettingData.sapPass === undefined
            ) {
              _oSettingData.sapUser = oSharedModel.getProperty(
                "/sapSettings/sapUser"
              );
              _oSettingData.sapPass = oSharedModel.getProperty(
                "/sapSettings/sapPass"
              );
            }
            oSharedModel.setProperty("/sapSettings", _oSettingData);

            d.resolve();
          },
          this)
        );

        return d.promise();
      },

      getPhotoNamesById: function (sParentHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Picture WHERE Parent=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sParentHandle],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getPicturesBoundToNotification: function (sParentHandle) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM Picture WHERE Parent=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sParentHandle],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getInstallationTreeGroups: function () {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM TechnicalObjectGroupnameVH",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              null,
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getInstallationTreeByScanId: function (sScanId) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM TechnicalObject WHERE Scanid=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sScanId],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getAICByCraft: function (sCraft) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL = "SELECT * FROM AICCustomizing WHERE Craftcod=?",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(
              sSQL,
              [sCraft],
              function (tx2, res) {
                oBusyDialog.close();
                d.resolve(res);
              },
              function (tx2, error) {
                oBusyDialog.close();
                d.reject(error);
              }
            );
          },
          function (error) {
            console.error("Transaction ERROR: " + error.message);
          },
          function () {
            console.debug("Populated database OK");
          }
        );

        return d.promise();
      },

      getPermanentDataPart1: function (bUpdateSettings, user) {
        this._isSQLAvailable();
        // this.busyDialog.open();

        let d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          oPromDeleteCatalog = this.deleteAllObjects("Catalog"),
          oPromDeleteLangu = this.deleteAllObjects("PMNotificationLanguVH"),
          oPromDeleteUnWork = this.deleteAllObjects("ConfirmationsUnWorkVH"),
          oPromDeleteQmart = this.deleteAllObjects("PMNotificationQmartVH"),
          oPromDeleteShift = this.deleteAllObjects("PMNotificationShiftVH"),
          oPromDeleteCraft = this.deleteAllObjects("PMNotificationCraftVH"),
          oPromDeleteActType = this.deleteAllObjects(
            "ConfirmationsPMActTypeVH"
          ),
          oPromDeleteTechObjGroups = this.deleteAllObjects(
            "TechnicalObjectGroupnameVH"
          ),
          oPromDeletePmenvr = this.deleteAllObjects("PMNotificationPmenvrVH"),
          oPromDeletePmqual = this.deleteAllObjects("PMNotificationPmqualVH"),
          oPromDeletePmsafe = this.deleteAllObjects("PMNotificationPmsafeVH"),
          oPromDeleteQuotCoR = this.deleteAllObjects("PMNotificationQuotCoRVH"),
          oPromDeleteQuotDeR = this.deleteAllObjects("PMNotificationQuotDeRVH"),
          oPromDeleteQuotPrR = this.deleteAllObjects("PMNotificationQuotPrRVH"),
          oPromDeleteQuotWcR = this.deleteAllObjects("PMNotificationQuotWcRVH"),
          oPromDeleteAICCustomizing = this.deleteAllObjects("AICCustomizing"),
          oPromDeleteImpactOblCustomizingSet = this.deleteAllObjects(
            "ImpactOblCustomizing"
          );

        $.when(
          oPromDeleteCatalog,
          oPromDeleteLangu,
          oPromDeleteQmart,
          oPromDeleteShift,
          oPromDeleteUnWork,
          oPromDeleteCraft,
          oPromDeleteActType,
          oPromDeleteTechObjGroups,
          oPromDeleteAICCustomizing,
          oPromDeletePmenvr,
          oPromDeletePmqual,
          oPromDeletePmsafe,
          oPromDeleteQuotCoR,
          oPromDeleteQuotDeR,
          oPromDeleteQuotPrR,
          oPromDeleteQuotWcR,
          oPromDeleteImpactOblCustomizingSet
        ).done(
          jQuery.proxy(function () {
            d.resolve();
          })
        );

        return d.promise();
      },

      /**
       * Get Catalog, Settings, Valuehelp from SAP
       * 24/04/2023: Busy Screen shown in case the database update fails
       * Implemented a fail function to remove the busy screen
       * @memberOf mobilework.model.DatabaseService
       * @public
       * @param  bUpdateSettings - Field to check whether user settings dta need to be updated or not
       * @param  user -  User to besend to fetch USer Default Settings
       * @returns Returns a promise at the end. Resolves only if all data is succefully fetched and updated in database
       */
      getPermanentData: function (bUpdateSettings, user) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          oPromDeleteCatalog = this.deleteAllObjects("Catalog"),
          oPromDeleteLangu = this.deleteAllObjects("PMNotificationLanguVH"),
          oPromDeleteUnWork = this.deleteAllObjects("ConfirmationsUnWorkVH"),
          oPromDeleteQmart = this.deleteAllObjects("PMNotificationQmartVH"),
          oPromDeleteShift = this.deleteAllObjects("PMNotificationShiftVH"),
          oPromDeleteCraft = this.deleteAllObjects("PMNotificationCraftVH"),
          oPromDeleteActType = this.deleteAllObjects(
            "ConfirmationsPMActTypeVH"
          ),
          oPromDeleteTechObjGroups = this.deleteAllObjects(
            "TechnicalObjectGroupnameVH"
          ),
          oPromDeletePmenvr = this.deleteAllObjects("PMNotificationPmenvrVH"),
          oPromDeletePmqual = this.deleteAllObjects("PMNotificationPmqualVH"),
          oPromDeletePmsafe = this.deleteAllObjects("PMNotificationPmsafeVH"),
          oPromDeleteQuotCoR = this.deleteAllObjects("PMNotificationQuotCoRVH"),
          oPromDeleteQuotDeR = this.deleteAllObjects("PMNotificationQuotDeRVH"),
          oPromDeleteQuotPrR = this.deleteAllObjects("PMNotificationQuotPrRVH"),
          oPromDeleteQuotWcR = this.deleteAllObjects("PMNotificationQuotWcRVH"),
          oPromDeleteAICCustomizing = this.deleteAllObjects("AICCustomizing"),
          oPromDeleteImpactOblCustomizingSet = this.deleteAllObjects(
            "ImpactOblCustomizing"
          );

        $.when(
          oPromDeleteCatalog,
          oPromDeleteLangu,
          oPromDeleteQmart,
          oPromDeleteShift,
          oPromDeleteUnWork,
          oPromDeleteCraft,
          oPromDeleteActType,
          oPromDeleteTechObjGroups,
          oPromDeleteAICCustomizing,
          oPromDeletePmenvr,
          oPromDeletePmqual,
          oPromDeletePmsafe,
          oPromDeleteQuotCoR,
          oPromDeleteQuotDeR,
          oPromDeleteQuotPrR,
          oPromDeleteQuotWcR,
          oPromDeleteImpactOblCustomizingSet
        )
          .done(
            jQuery.proxy(function () {
              $.when(this.getSAPSettings()).done(
                jQuery.proxy(function (oSapSetting) {
                  var oPromVH = this.service.getValueHelpData(
                      oSapSetting.langu
                    ),
                    oPromCatalog = this.service.getCatalogSet(
                      oSapSetting.langu
                    ),
                    oPromSettings = this.service.getSettingSet(
                      oSapSetting.langu,
                      user
                    );

                  $.when(oPromCatalog, oPromSettings, oPromVH)
                    .done(
                      jQuery.proxy(function (
                        oCatalogData,
                        oSettingData,
                        oVHData
                      ) {
                        var sPlant = _.find(
                          oSettingData.results,
                          function (oSetting) {
                            return oSetting.SKey === "IWERK";
                          }
                        );
                        let oPromAIC = this.service.getAICCustomizingSet(
                            sPlant.SValue,
                            oSapSetting.langu
                          ),
                          oPromImpactObl =
                            this.service.getImpactOblCustomizingSet(
                              sPlant.SValue,
                              oSapSetting.langu
                            );
                        $.when(oPromAIC, oPromImpactObl).done(
                          jQuery.proxy(function (oAIC, oImpactObl) {
                            console.debug(oAIC);

                            $.when(
                              this.initValueHelp(
                                oVHData,
                                oCatalogData,
                                oSettingData,
                                oAIC,
                                oImpactObl,
                                true,
                                bUpdateSettings
                              )
                            )
                              .done(
                                jQuery.proxy(function () {
                                  oBusyDialog.close();
                                  d.resolve();
                                }, this)
                              )
                              .fail(
                                function () {
                                  console.error("Updating database failed");
                                  oBusyDialog.close();
                                  d.reject();
                                }.bind(this)
                              );
                          }, this)
                        );
                      },
                      this)
                    )
                    .fail(
                      jQuery.proxy(function (oError) {
                        d.reject(oError);
                      }, this)
                    );
                }, this)
              );
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              d.reject(oError);
            }, this)
          );

        return d.promise();
      },

      updateParticipants: function (sEntity, aParticipants, aOldParticipants) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          aUpdParticipants = aParticipants,
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          jQuery.proxy(function (tx) {
            for (var i in aUpdParticipants) {
              delete aUpdParticipants[i].__metadata;

              var oCorrespondingParticipant = _.find(
                aOldParticipants,
                function (oParticipant) {
                  return (
                    (oParticipant.Pernr &&
                      parseInt(oParticipant.Pernr) ===
                        parseInt(aUpdParticipants[i].Pernr)) ||
                    ((((!oParticipant.Pernr ||
                      oParticipant.Pernr === "00000000") &&
                      !aUpdParticipants[i].Pernr) ||
                      aUpdParticipants[i].Pernr === "00000000") &&
                      oParticipant.Arbpl &&
                      oParticipant.Arbpl === aUpdParticipants[i].Arbpl)
                  ); //|| oParticipant.Workhandle === aUpdParticipants[i].Workhandle;
                }
              );

              if (oCorrespondingParticipant) {
                if (
                  oCorrespondingParticipant.Arbpl &&
                  (oCorrespondingParticipant.Pernr === "00000000" ||
                    !oCorrespondingParticipant.Pernr)
                ) {
                  aUpdParticipants[i].Pernr = "";
                }
                var sSQL = this._getSQLForUpdateParticipants(
                    sEntity,
                    aUpdParticipants[i]
                  ),
                  aValues = this._getValueArrayForUpdateParticipants(
                    sEntity,
                    aUpdParticipants[i],
                    oCorrespondingParticipant
                  );
              } else {
                sSQL = this._getSQLForReplaceObject(
                  sEntity,
                  aUpdParticipants[i]
                );
                aValues = this._getValueArrayForInsert(
                  sEntity,
                  aUpdParticipants[i]
                );
              }
              tx.executeSql(
                sSQL,
                aValues,
                function (tx2, res) {
                  oBusyDialog.close();
                  d.resolve(res);
                },
                function (tx2, error) {
                  oBusyDialog.close();
                  d.reject(error);
                }
              );
            }
          }, this)
        );

        return d.promise();
      },
      updateInstallationTree: function (sScanId, aTreeData) {
        this._isSQLAvailable();
        //this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQLId = "REPLACE INTO KnownScanId VALUES (?)",
          sSQLTree = "",
          aValArray = [],
          oBusyDialog = this.busyDialog,
          aScanIds = [sScanId],
          that = this,
          techObjects = [],
          sqlCustom,
          sParams = "?";
        if (aTreeData) {
          techObjects = aTreeData.map((row) => row.TechObject);
          for (var i = 0; i < techObjects.length - 1; i++) {
            sParams = sParams + ",?";
          }

          if (techObjects.length !== 0) {
            sqlCustom = [
              "SELECT * FROM TechnicalObject WHERE TechObject  IN (" +
                sParams +
                ")",
              techObjects,
            ];
          } else if (techObjects.length === 0) {
            // d.resolve();
          }
        } else {
          // d.resolve();
        }
        $.when(this.getEntitySet("TechnicalObject", sqlCustom)).done(
          jQuery.proxy(function (odata) {
            var instTree = this.helper.rowsToArray(odata);
            aTreeData.map(function (oTree) {
              var _oTree = oTree;
              // var instTree = this.helper.rowsToArray(odata);
              // aTreeData.map(function (oTree) {
              // 	var _oTree = oTree;

              // if (!_oTree.Scanid) {
              // 	_oTree.Scanid = sScanId;
              // } else
              if (_oTree.Scanid && aScanIds.indexOf(_oTree.Scanid) === -1) {
                aScanIds.push(_oTree.Scanid);
              }

              return _oTree;
            });

            this.db.transaction(
              function (tx) {
                for (var h = 0; h < aScanIds.length; h++) {
                  tx.executeSql(sSQLId, [aScanIds[h]]);
                }

                // for (var i = 0; i < aTreeData.length; i++) {
                // 	//Some Function Locations went missing while synching multiple trees Issue 73 in ARMP 11.2
                // 	var treePresent = null;
                // 	treePresent = _.find(instTree, {
                // 		TechObject: aTreeData[i].TechObject
                // 	});
                // 	if (treePresent && aTreeData[i].TechObjectType !== "PA") {
                // 		if (treePresent.Parent && !treePresent.Parent.includes(aTreeData[i].Parent)) {
                // 			//Multiple Parent FL Groups added to FLs.
                // 			aTreeData[i].Parent = aTreeData[i].Parent + "+#+#" + treePresent.Parent;
                // 			aValArray = that._getValueArrayForInsert("TechnicalObject", aTreeData[i]);
                // 		} else {
                // 			if (aTreeData[i].TechObjectType == "IF") {
                // 				aValArray = that._getValueArrayForInsert("TechnicalObject", aTreeData[i]);
                // 			} else
                // 				aValArray = that._getValueArrayForInsert("TechnicalObject", treePresent);
                // 		}
                // 	} else {
                // 		aValArray = that._getValueArrayForInsert("TechnicalObject", aTreeData[i]);
                // 	}

                for (var i = 0; i < aTreeData.length; i++) {
                  //Some Function Locations went missing while synching multiple trees Issue 73 in ARMP 11.2
                  var treePresent = null;
                  treePresent = _.find(instTree, {
                    TechObject: aTreeData[i].TechObject,
                  });
                  if (treePresent && aTreeData[i].TechObjectType !== "PA") {
                    if (
                      treePresent.Parent &&
                      !treePresent.Parent.includes(aTreeData[i].Parent)
                    ) {
                      //Multiple Parent FL Groups added to FLs.
                      aTreeData[i].Parent =
                        aTreeData[i].Parent + "+#+#" + treePresent.Parent;
                      aValArray = that._getValueArrayForInsert(
                        "TechnicalObject",
                        aTreeData[i]
                      );
                    } else {
                      if (aTreeData[i].TechObjectType == "IF") {
                        aValArray = that._getValueArrayForInsert(
                          "TechnicalObject",
                          aTreeData[i]
                        );
                      } else
                        aValArray = that._getValueArrayForInsert(
                          "TechnicalObject",
                          treePresent
                        );
                    }
                  } else {
                    aValArray = that._getValueArrayForInsert(
                      "TechnicalObject",
                      aTreeData[i]
                    );
                  }

                  sSQLTree = that._getSQLForReplaceObject(
                    "TechnicalObject",
                    aTreeData[i]
                  );
                  tx.executeSql(sSQLTree, aValArray);
                }
              },
              function (error) {
                //oBusyDialog.close();
                d.reject(error);
              },
              function () {
                //oBusyDialog.close();
                d.resolve();
              }
            );
          }, this)
        );
        return d.promise();
      },

      updateTechObj: function (iIndex, aTechObjList) {
        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          sSQLTree = "",
          aValArray = [],
          that = this;

        this.db.transaction(
          function (tx) {
            // for (var h = 0; h < aScanIds.length; h++) {
            // 	tx.executeSql(sSQLId, [aScanIds[h]]);
            // }
            // sSQLTree = that._getSQLForInsertObject("TechnicalObject", aTreeData[0]);

            for (var i = iIndex; i < aTechObjList.length; i++) {
              sSQLTree = that._getSQLForReplaceObject(
                "TechnicalObject",
                aTechObjList[i]
              );
              aValArray = that._getValueArrayForInsert(
                "TechnicalObject",
                aTechObjList[i]
              );
              // aValArray.push(that._getValueArrayForInsert("TechnicalObject", aTreeData[i]));

              tx.executeSql(sSQLTree, aValArray);

              if (i % 50000 === 0 && i !== iIndex) {
                iIndex = i;
                break;
              } else {
                iIndex = i;
              }
            }

            // tx.executeSql(sSQLTree, aValArray);
          },
          function (error) {
            // oBusyDialog.close();
            d.reject(error);
          },
          function () {
            if (iIndex === aTechObjList.length - 1) {
              // oBusyDialog.close();
              d.resolve();
            } else {
              iIndex = iIndex + 1;
              that.updateTechObj(iIndex, aTechObjList);
              d.resolve();
            }
          }
        );

        return d.promise();
      },

      deleteAllInstallationTree: function () {
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sDeleteSQL = "DELETE FROM TechnicalObject",
          oBusyDialog = this.busyDialog;

        this.db.transaction(
          function (tx) {
            tx.executeSql(sDeleteSQL);
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve();
          }
        );

        return d.promise();
      },

      insertInstallationTree: function (sScanId, aTreeData) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQLId = "REPLACE INTO KnownScanId VALUES (?)",
          sSQLTree = "",
          aValArray = [],
          oBusyDialog = this.busyDialog,
          aScanIds = [sScanId];

        aTreeData.map(function (oTree) {
          var _oTree = oTree;

          if (!_oTree.Scanid) {
            _oTree.Scanid = sScanId;
          } else if (aScanIds.indexOf(_oTree.Scanid) === -1) {
            aScanIds.push(_oTree.Scanid);
          }

          return _oTree;
        });

        this.db.transaction(
          jQuery.proxy(function (tx) {
            for (var h = 0; h < aScanIds.length; h++) {
              tx.executeSql(sSQLId, [aScanIds[h]]);
            }

            for (var i = 0; i < aTreeData.length; i++) {
              sSQLTree = this._getSQLForInsertObject(
                "TechnicalObject",
                aTreeData[i]
              );
              aValArray += this._getValueArrayForInsert(
                "TechnicalObject",
                aTreeData[i]
              );

              tx.executeSql(sSQLTree, aValArray);
            }
          }, this),
          jQuery.proxy(function (error) {
            oBusyDialog.close();
            d.reject(error);
          }, this),
          jQuery.proxy(function () {
            oBusyDialog.close();
            d.resolve();
          }, this)
        );

        return d.promise();
      },

      saveMultipleReplace: function (entity, aData) {
        this._isSQLAvailable();
        //this.busyDialog.open();

        var oDatas = aData,
          d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          aSQL = [];

        oDatas.forEach(
          jQuery.proxy(function (oData) {
            aSQL.push({
              sql: this._getSQLForReplaceObject(entity, oData),
              values: this._getValueArrayForInsert(entity, oData),
            });
          }, this)
        );

        // Execute sql
        this.db.transaction(
          function (tx) {
            for (var i = 0; i < aSQL.length; i++) {
              tx.executeSql(aSQL[i].sql, aSQL[i].values);
            }
          },
          function (error) {
            //oBusyDialog.close();
            d.reject(error);
          },
          function () {
            //oBusyDialog.close();
            d.resolve(aData);
          }
        );

        return d.promise();
      },

      saveWorkSet: function (oData) {
        this._isSQLAvailable();
        this.busyDialog.open();

        //---------//

        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          aSQL = [],
          that = this;

        //---------//
        // Create SQL array
        var aPMOrders = oData.NavOrder.results,
          aExistedOrders = [],
          aPMNotifications = oData.NavPMNotification.results;

        var oPromOrders = this.getEntitySet("PMOrder"),
          oPromOperations = this.getEntitySet("Operation"),
          oPromNotifications = this.getEntitySet("PMNotification");

        $.when(oPromOrders, oPromOperations, oPromNotifications).done(
          jQuery.proxy(async function (
            oDataOrder,
            oDataOperations,
            oDataNotifications
          ) {
            // WR - At this point the handle should be available in the IndexedDB
            // Get list of handles for each operation
            let aHandles = await dbMigrator.getHandles();

            var aOrderSet = this.helper.rowsToArray(oDataOrder);
            var aOperationSet = this.helper.rowsToArray(oDataOperations);
            var aNotificationSet = this.helper.rowsToArray(oDataNotifications);
            // oData.NavWCAOpeData.results.forEach((opData)=>{
            // 	aSQL.push({
            // 		sql: that._getSQLForInsertObject("WCAOpeData", opData),
            // 		values: that._getValueArrayForInsert("WCAOpeData", opData)
            // 	});
            // });

            aPMOrders.forEach(
              function (oPMOrder) {
                //check if order is already on device
                if (!this._checkIfOrderExists(aOrderSet, oPMOrder)) {
                  aSQL.push({
                    sql: that._getSQLForInsertObject("PMOrder", oPMOrder),
                    values: that._getValueArrayForInsert("PMOrder", oPMOrder),
                  });
                  oData.NavWCARisks.results
                    .filter((wcaRisk) => {
                      return wcaRisk.Objid === oPMOrder.Orderid;
                    })
                    .forEach((wcaRisk) => {
                      aSQL.push({
                        sql: that._getSQLForReplaceObject(
                          "WCARisks",
                          wcaRisk,
                          null,
                          CustomKeys[2].key.propertyRef
                        ),
                        values: that._getValueArrayForInsert(
                          "WCARisks",
                          wcaRisk,
                          null,
                          CustomKeys[2].key.propertyRef
                        ),
                      });
                    });
                  oData.NavWCAData.results
                    .filter((WCAData) => {
                      return WCAData.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAData) => {
                      aSQL.push({
                        sql: that._getSQLForReplaceObject(
                          "WCAData",
                          WCAData,
                          null,
                          CustomKeys[0].key.propertyRef
                        ),
                        values: that._getValueArrayForInsert(
                          "WCAData",
                          WCAData,
                          null,
                          CustomKeys[0].key.propertyRef
                        ),
                      });
                    });
                  oData.NavWCAOpeRisks.results
                    .filter((WCAOpeRisks) => {
                      return WCAOpeRisks.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAOpeRisks) => {
                      aSQL.push({
                        sql: that._getSQLForReplaceObject(
                          "WCAOpeRisks",
                          WCAOpeRisks,
                          null,
                          CustomKeys[3].key.propertyRef
                        ),
                        values: that._getValueArrayForInsert(
                          "WCAOpeRisks",
                          WCAOpeRisks,
                          null,
                          CustomKeys[3].key.propertyRef
                        ),
                      });
                    });
                  oData.NavWCAOpeData.results
                    .filter((WCAOpeData) => {
                      return WCAOpeData.Objid === oPMOrder.Orderid;
                    })
                    .forEach((WCAOpeData) => {
                      aSQL.push({
                        sql: that._getSQLForReplaceObject(
                          "WCAOpeData",
                          WCAOpeData,
                          null,
                          CustomKeys[1].key.propertyRef
                        ),
                        values: that._getValueArrayForInsert(
                          "WCAOpeData",
                          WCAOpeData,
                          null,
                          CustomKeys[1].key.propertyRef
                        ),
                      });
                    });

                  oPMOrder.NavOperation.results.forEach(
                    function (oOperation) {
                      // Generate handle for each operation, used for selective delete later
                      // oOperation.Handle = this.helper.getUUID();
                      let oHandle = aHandles.find((x) => {
                        return (
                          x.Activity === String(oOperation.Activity) &&
                          x.Orderid === String(oOperation.Orderid)
                        );
                      });
                      if (oHandle) {
                        oOperation.Handle = oHandle.Handle;
                      } else {
                        console.error(
                          "Handle not found for activity: " +
                            oOperation.Activity +
                            " and orderid: " +
                            oOperation.Orderid
                        );
                      }

                      aSQL.push({
                        sql: that._getSQLForInsertObject(
                          "Operation",
                          oOperation
                        ),
                        values: that._getValueArrayForInsert(
                          "Operation",
                          oOperation
                        ),
                      });

                      if (!oOperation.SubActivity) {
                        oOperation.NavPRT.results.forEach(function (oPRT) {
                          aSQL.push({
                            sql: that._getSQLForInsertObject("PRT", oPRT),
                            values: that._getValueArrayForInsert("PRT", oPRT),
                          });
                        });

                        oOperation.NavComponent.results.forEach(function (
                          oComponent
                        ) {
                          aSQL.push({
                            sql: that._getSQLForInsertObject(
                              "Component",
                              oComponent
                            ),
                            values: that._getValueArrayForInsert(
                              "Component",
                              oComponent
                            ),
                          });
                        });
                      }
                    }.bind(this)
                  );
                } else {
                  // check if operation is already on device.
                  var aNonExistingOperations = this._checkIfOperationExists(
                    aOperationSet,
                    oPMOrder
                  );
                  if (aNonExistingOperations.length > 0) {
                    oData.NavWCAOpeRisks.results
                      .filter((WCAOpeRisks) => {
                        return (
                          WCAOpeRisks.Objid ===
                            aNonExistingOperations.Orderid &&
                          WCAOpeRisks.Vornr === aNonExistingOperations.Activity
                        );
                      })
                      .forEach((WCAOpeRisks) => {
                        aSQL.push({
                          sql: that._getSQLForInsertObject(
                            "WCAOpeRisks",
                            WCAOpeRisks
                          ),
                          values: that._getValueArrayForInsert(
                            "WCAOpeRisks",
                            WCAOpeRisks
                          ),
                        });
                      });
                    oData.NavWCAOpeData.results
                      .filter((WCAOpeData) => {
                        return (
                          WCAOpeData.Objid === aNonExistingOperations.Orderid &&
                          WCAOpeData.Vornr === aNonExistingOperations.Activity
                        );
                      })
                      .forEach((WCAOpeData) => {
                        aSQL.push({
                          sql: that._getSQLForInsertObject(
                            "WCAOpeData",
                            WCAOpeData
                          ),
                          values: that._getValueArrayForInsert(
                            "WCAOpeData",
                            WCAOpeData
                          ),
                        });
                      });
                    aNonExistingOperations.forEach(
                      function (oOperation) {
                        // Generate handle for each operation, used for selective delete later
                        // oOperation.Handle = this.helper.getUUID();

                        let oHandle = aHandles.find((x) => {
                          return (
                            x.Activity === String(oOperation.Activity) &&
                            x.Orderid === String(oOperation.Orderid)
                          );
                        });

                        if (oHandle) {
                          oOperation.Handle = oHandle.Handle;
                        } else {
                          console.error(
                            "Handle not found for activity: " +
                              oOperation.Activity +
                              " and orderid: " +
                              oOperation.Orderid
                          );
                        }

                        aSQL.push({
                          sql: that._getSQLForInsertObject(
                            "Operation",
                            oOperation
                          ),
                          values: that._getValueArrayForInsert(
                            "Operation",
                            oOperation
                          ),
                        });

                        if (!oOperation.SubActivity) {
                          oOperation.NavPRT.results.forEach(function (oPRT) {
                            aSQL.push({
                              sql: that._getSQLForInsertObject("PRT", oPRT),
                              values: that._getValueArrayForInsert("PRT", oPRT),
                            });
                          });

                          oOperation.NavComponent.results.forEach(function (
                            oComponent
                          ) {
                            aSQL.push({
                              sql: that._getSQLForInsertObject(
                                "Component",
                                oComponent
                              ),
                              values: that._getValueArrayForInsert(
                                "Component",
                                oComponent
                              ),
                            });
                          });
                        }
                      }.bind(this)
                    );
                  } else {
                    aExistedOrders.push(oPMOrder.Orderid);
                  }
                }
              }.bind(this)
            );

            aPMNotifications.forEach(
              jQuery.proxy(function (oPMNotification) {
                if (
                  !this._checkIfNotificationExists(
                    aNotificationSet,
                    oPMNotification
                  )
                ) {
                  aSQL.push({
                    sql: that._getSQLForInsertObject(
                      "PMNotification",
                      oPMNotification
                    ),
                    values: that._getValueArrayForInsert(
                      "PMNotification",
                      oPMNotification
                    ),
                  });
                }
              }, this)
            );
          },
          this)
        );

        // Execute sql
        this.db.transaction(
          function (tx) {
            for (var i = 0; i < aSQL.length; i++) {
              tx.executeSql(aSQL[i].sql, aSQL[i].values);
            }
          },
          function (error) {
            oBusyDialog.close();
            d.reject(error);
          },
          function () {
            oBusyDialog.close();
            d.resolve(aExistedOrders);
          }
        );

        return d.promise();
      },

      //------------------//
      // PRIVATES
      //------------------//

      _isSQLAvailable: function () {
        if (!this.helper.isDevModeActive()) {
          if (window.sqlitePlugin) {
            return true;
          }
        } else {
          if (window.openDatabase) {
            return true;
          }
        }

        throw new Error("SQL Plugin is dead.");
      },

      _isDBIntialized: function () {
        var d = jQuery.Deferred(),
          sSQL = "SELECT name FROM sqlite_master WHERE type='table'";

        if (!this.db) {
          return false;
        }

        this.db.transaction(function (tx) {
          tx.executeSql(sSQL, null, function (tx2, res) {
            var bIsInit = true,
              aTableArray = [];

            for (var i = 0; i < res.rows.length; i++) {
              aTableArray.push(res.rows.item(i).name);
            }

            if (aTableArray.indexOf("Setting") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("Confirmation") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("Participant") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotification") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("Catalog") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("Picture") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("InstallationTree") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationLanguVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationQmartVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationShiftVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationCraftVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("ConfirmationsUnWorkVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMOrder") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("ConfirmationsPMActTypeVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationPmenvrVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationPmqualVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationPmsafeVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationQuotCoRVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationQuotDeRVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationQuotPrRVH") === -1) {
              bIsInit = false;
            }
            if (aTableArray.indexOf("PMNotificationQuotWcRVH") === -1) {
              bIsInit = false;
            }

            d.resolve(bIsInit);
          });
        });

        return d.promise();
      },

      _checkIfOrderExists: function (aOrderSet, oPMOrder) {
        var oOrderFound = _.find(aOrderSet, function (oOrder) {
          return oPMOrder.Orderid === oOrder.Orderid;
        });

        return oOrderFound ? true : false;
      },

      _checkIfNotificationExists: function (aNotificationSet, oPMNotification) {
        var oNotificationFound = _.find(aNotificationSet, function (oNotif) {
          return oNotif.Qmnum === oPMNotification.Qmnum;
        });

        return oNotificationFound ? true : false;
      },

      _checkIfOperationExists: function (aOperationSet, oOrder) {
        var aNotExistingOperations = [];
        oOrder.NavOperation.results.forEach(function (oPMOperation) {
          var oOperationFound = _.find(aOperationSet, function (oOperation) {
            return oPMOperation.Activity === oOperation.Activity;
          });

          if (!oOperationFound) {
            aNotExistingOperations.push(oPMOperation);
          }
        });

        return aNotExistingOperations;
      },

      _getDBKey: function (bPublicRelease) {
        if (!bPublicRelease) {
          return true;
        }

        var d = jQuery.Deferred();

        var ss = new cordova.plugins.SecureStorage(
          jQuery.proxy(function () {
            console.debug("Success");
            ss.get(
              jQuery.proxy(function (value) {
                console.debug("Success, got " + value);
                console.debug("Retrieved KEY");
                console.debug(value);
                d.resolve(value);
              }, this),
              jQuery.proxy(function (error) {
                console.error("Error " + error);
                var uuid = self.crypto.randomUUID();
                console.debug("GENERATED KEY");
                console.debug(uuid);
                ss.set(
                  jQuery.proxy(function (key) {
                    console.debug("Set " + key);
                    d.resolve(uuid);
                  }, this),
                  jQuery.proxy(function (error) {
                    console.error("Error " + error);
                    d.reject(error);
                  }, this),
                  "mydbkey",
                  uuid
                );
              }, this),
              "mydbkey"
            );
          }, this),
          jQuery.proxy(function (error) {
            console.error("Error " + error);

            MBox.error(
              this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("EnableScreenLock"),
              {
                actions: [MBox.Action.CLOSE],
                onClose: function (sAction) {
                  navigator.app.exitApp();
                },
              }
            );
            d.reject(error);
          }, this),
          "MobileWork"
        );

        return d.promise();
      },

      _openDatabase: function (bOpenOnly, bGetMeta) {
        var d = jQuery.Deferred(),
          db = null;

        try {
          this._isSQLAvailable();
        } catch (e) {
          MBox.error(
            this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("DoesNotSupportSqlite")
          );
          d.reject();
        }

        console.debug("openDatabase");
        console.debug(this.db);

        let oSharedModel = this.component.getModel("shared");

        if (!this.db) {
          if (!this.helper.isDevModeActive()) {
            let oDBConfig = {};
            let bPublicRelease = oSharedModel.getProperty("/publicRelease");

            // Retrieve password
            $.when(this._getDBKey(bPublicRelease))
              .done(
                jQuery.proxy(function (sKey) {
                  // Continue logic
                  if (bPublicRelease) {
                    console.debug("KEY USED");
                    console.debug(sKey);

                    oDBConfig = {
                      name: "mobilework",
                      key: sKey, // "dfsqmkljsdf54654vljsmdjv@@#fdkjkfdjs",
                      location: "default",
                    };
                  } else {
                    oDBConfig = {
                      name: "mobilework",
                      location: "default",
                    };
                  }

                  db = window.sqlitePlugin.openDatabase(
                    oDBConfig,
                    jQuery.proxy(function (db2) {
                      console.debug("database opened");
                      $.when(
                        this._onDatabaseCreateSuccess(db2, bOpenOnly, bGetMeta)
                      )
                        .done(function () {
                          d.resolve();
                        })
                        .fail(function () {});
                    }, this),
                    jQuery.proxy(function (error) {
                      this._onDatabaseCreateFailed(error);
                    }, this)
                  );
                }, this)
              )
              .fail(function (oError) {
                console.error(oError);
              });
          } else {
            db = window.openDatabase("mobilework", "0.1", "mobilework", 200000);
            if (db) {
              $.when(
                this._onDatabaseCreateSuccess(db, bOpenOnly, bGetMeta)
              ).done(function () {
                d.resolve();
              });
            }
          }
        } else {
          $.when(
            this._onDatabaseCreateSuccess(this.db, bOpenOnly, bGetMeta)
          ).done(function () {
            d.resolve();
          });
        }

        return d.promise();
      },

      _onDatabaseCreateSuccess: function (db, bOpenOnly, bGetMeta) {
        var d = jQuery.Deferred();

        this.db = db;

        console.debug("onDatabaseCreateSuccess");
        console.debug(bOpenOnly);
        console.debug(bGetMeta);

        if (bOpenOnly) {
          if (bGetMeta) {
            $.when(this._getMetaObjectFromDB()).done(function () {
              console.debug("getMetaOBjectFromDB done");
              d.resolve();
            });
          } else {
            d.resolve();
          }
        } else {
          $.when(this._createTablesFromMetadata())
            .done(function () {
              console.debug("createTablesFromMetadata done");
              d.resolve();
            })
            .fail(function () {
              console.error("createTablesFromMetadata failed");
              d.reject();
            });
        }

        return d.promise();
      },

      _onDatabaseCreateFailed: function (error) {
        // TODO
      },

      _saveMetadataToSettings: function () {
        let d = jQuery.Deferred();
        let sSQL =
          "CREATE TABLE IF NOT EXISTS Setting (SKey PRIMARY KEY, SValue)";
        this.db.transaction(
          jQuery.proxy(function (tx) {
            tx.executeSql(sSQL, null);
            tx.executeSql("INSERT INTO Setting VALUES (?, ?)", [
              "metadata",
              JSON.stringify(this.metaObject),
            ]);
          }, this),
          function (error) {
            d.reject(error);
          },
          function () {
            d.resolve();
          }
        );
        return d.promise();
      },

      _createTablesFromMetadata: function () {
        console.debug("CREATE TABLES FROM METADATA");
        var oModel = this.service.getModel(),
          d = jQuery.Deferred(),
          oMetaObject = oModel.getServiceMetadata(),
          aSQL = [],
          fnSuccess = null,
          fnSuccessSetting = function (tx2) {
            tx2.executeSql(
              "DELETE FROM Setting WHERE SKey=?",
              ["metadata"],
              async function (tx3, res2) {
                tx3.executeSql("INSERT INTO Setting VALUES (?, ?)", [
                  "metadata",
                  JSON.stringify(oMetaObject),
                ]);

                // // Might not be needed once the DB migration is over
                // let oSettingDataLF = await localforage.getItem("Setting");
                // oSettingDataLF["metadata"] = JSON.stringify(oMetaObject);
                // await localforage.setItem("Setting", oSettingDataLF);
              }
            );
          };

        this.metaObject = oMetaObject;
        if (this.metaObject) {
          this.metaObject.dataServices.schema[0].entityType.forEach(
            jQuery.proxy(function (oEntity) {
              if (
                oEntity.name === "Operation" ||
                oEntity.name === "Component" ||
                oEntity.name === "PRT" ||
                oEntity.name === "AICCustomizing" ||
                oEntity.name === "TimeRegistration"
              ) {
                aSQL.push(this._getSQLForCreateTableNoKeys(oEntity.name));
              } else if (
                oEntity.name === "WCAData" ||
                oEntity.name === "WCAOpeData" ||
                oEntity.name === "WCARisks" ||
                oEntity.name === "WCAOpeRisks"
              ) {
                aSQL.push(
                  this._getSQLForCreateTable(
                    oEntity.name,
                    null,
                    CustomKeys.find((item) => item.name === oEntity.name)
                  )
                );
              } else {
                aSQL.push(this._getSQLForCreateTable(oEntity.name));
              }
            }, this)
          );

          if (this._isSQLAvailable()) {
            this.db.transaction(
              function (tx) {
                for (var i = 0; i < aSQL.length; i++) {
                  if (aSQL[i].indexOf("Setting") !== -1) {
                    fnSuccess = fnSuccessSetting;
                  } else {
                    fnSuccess = null;
                  }

                  tx.executeSql(aSQL[i], null, fnSuccess);
                }

                //additional table for known scan ids for functional locations
                tx.executeSql(
                  "CREATE TABLE IF NOT EXISTS KnownScanId (ScanId PRIMARY KEY)"
                );
              },
              function (error) {
                d.reject();
              },
              function () {
                d.resolve();
              }
            );
          }
        } else {
          d.resolve();
        }

        return d.promise();
      },

      _getMetaObject: function () {
        return this.metaObject;
      },

      _getMetaObjectFromDB: function () {
        var d = jQuery.Deferred(),
          sSQL = "SELECT SValue FROM Setting WHERE SKey=?";

        console.debug("getMetadataFromDB");

        this.db.transaction(
          jQuery.proxy(function (tx) {
            tx.executeSql(
              sSQL,
              ["metadata"],
              jQuery.proxy(function (tx2, res) {
                console.debug("metadata object retrieved from DB");
                console.debug(res.rows.length);
                console.debug(res.rows);
                if (res.rows.length > 0) {
                  this.metaObject = JSON.parse(res.rows.item(0).SValue);
                  d.resolve();
                } else {
                  $.when(this._createTablesFromMetadata())
                    .done(function () {
                      console.debug("createTablesFromMetadata done");
                      d.resolve();
                    })
                    .fail(function () {
                      console.error("createTablesFromMetadata failed");
                      d.reject();
                    });
                }
              }, this),
              jQuery.proxy(function (oError) {
                console.debug("TEST: ", oError);
              }, this)
            );
          }, this)
        );

        return d.promise();
      },

      _getPropertiesForEntity: function (oMetaObject, sEntity) {
        var aProps = [],
          oEntity = {};

        if (!oMetaObject) {
          this.metaObject = this.service._oModel.oMetadata.oMetadata;
          oMetaObject = this.metaObject;
        }

        oEntity = _.find(oMetaObject.dataServices.schema[0].entityType, {
          name: sEntity,
        });

        oEntity.property.forEach(function (oProp) {
          aProps.push(oProp.name);
        });

        return _.sortBy(aProps);
      },

      _getFullPropertyForEntity: function (oMetaObject, sEntity) {
        var aProps = [],
          oEntity = _.find(oMetaObject.dataServices.schema[0].entityType, {
            name: sEntity,
          });

        oEntity.property.forEach(function (oProp) {
          aProps.push(oProp);
        });

        return _.sortBy(aProps);
      },

      _getSQLForCreateTable: function (sEntity, oMetaDataObject, newKeys) {
        var sSQL = "CREATE TABLE IF NOT EXISTS " + sEntity + " (",
          aProps,
          aKeys,
          sKeySQL = "PRIMARY KEY (";

        if (!oMetaDataObject) {
          aProps = this._getFullPropertyForEntity(
            this._getMetaObject(),
            sEntity
          );
        } else {
          aProps = this._getFullPropertyForEntityCustom(oMetaDataObject);
        }
        if (!oMetaDataObject) {
          if (newKeys) {
            aKeys = newKeys.key.propertyRef;
          } else {
            aKeys = this._getEntityKeys(sEntity);
          }
        } else {
          if (!oMetaDataObject.key) {
            debugger;
          }
          aKeys = this._getEntityKeysCustom(
            sEntity,
            oMetaDataObject.key.propertyRef
          );
        }

        for (var sProp in aProps) {
          if (
            (aProps[sProp].type.indexOf("String") !== -1 ||
              aProps[sProp].type.indexOf("DateTime") !== -1) &&
            aProps[sProp].name !== "Swerk" &&
            aProps[sProp].name !== "Iwerk" &&
            aProps[sProp].name !== "Plant" &&
            aProps[sProp].name !== "ExecutantCnt"
          ) {
            sSQL += aProps[sProp].name + " TEXT, ";
          } else {
            sSQL +=
              aProps[sProp].name +
              " " +
              aProps[sProp].type.substring(4).toUpperCase() +
              ", ";
          }
        }

        for (var sKey in aKeys) {
          if (parseInt(sKey) === aKeys.length - 1) {
            sKeySQL += aKeys[sKey].name + " ) ";
          } else {
            sKeySQL += aKeys[sKey].name + ", ";
          }
        }

        sSQL += sKeySQL;

        return sSQL + ")";
      },

      _getSQLForCreateTableNoKeys: function (sEntity, oMetaDataObject) {
        var sSQL = "CREATE TABLE IF NOT EXISTS " + sEntity + " (",
          aProps;
        if (!oMetaDataObject) {
          aProps = this._getFullPropertyForEntity(
            this._getMetaObject(),
            sEntity
          );
        } else {
          aProps = this._getFullPropertyForEntityCustom(oMetaDataObject);
        }
        //sKeySQL = "PRIMARY KEY (";

        for (var sProp in aProps) {
          if (
            (aProps[sProp].type.indexOf("String") !== -1 ||
              aProps[sProp].type.indexOf("DateTime") !== -1) &&
            aProps[sProp].name !== "Swerk" &&
            aProps[sProp].name !== "Iwerk" &&
            aProps[sProp].name !== "Plant" &&
            aProps[sProp].name !== "ExecutantCnt"
          ) {
            sSQL += aProps[sProp].name + " TEXT, ";
          } else {
            sSQL +=
              aProps[sProp].name +
              " " +
              aProps[sProp].type.substring(4).toUpperCase() +
              ", ";
          }
        }

        sSQL = sSQL.slice(0, -2);

        return sSQL + ")";
      },

      _getSQLForInsertObject: function (sEntity, oData, oMetadatObject) {
        //"INSERT INTO customerAccounts (firstname, lastname, acctNo) VALUES (?,?,?)";
        var sSQL = "INSERT INTO " + sEntity + "(",
          aProps;
        if (!oMetadatObject) {
          aProps = this._getPropertiesForEntity(this._getMetaObject(), sEntity);
        } else {
          aProps = this.getPropertiesFromEntityCustom(oMetadatObject);
        }

        for (var sProp in aProps) {
          sSQL += aProps[sProp] + ", ";
        }

        sSQL = sSQL.slice(0, -2);
        sSQL += ") VALUES (";

        for (var sProp in aProps) {
          sSQL += "?,";
        }

        sSQL = sSQL.slice(0, -1);

        return sSQL + ")";
      },

      _getSQLForFullReadTable: function (sEntity) {
        // SELECT firstname, lastname, acctNo FROM customerAccounts
        return "SELECT * FROM " + sEntity;
      },

      _getSQLForReplaceObject: function (sEntity, oData, oMetadatObject) {
        if (sEntity === "Setting") {
          debugger;
        }
        //"REPLACE INTO Setting (SValue, SKey) VALUES (?,?)";
        var sSQL = "REPLACE INTO " + sEntity + "(",
          aProps,
          sWhere = "";
        if (!oMetadatObject) {
          aProps = this._getPropertiesForEntity(this._getMetaObject(), sEntity);
        } else {
          aProps = this.getPropertiesFromEntityCustom(oMetadatObject);
        }
        for (var sProp in aProps) {
          sSQL += aProps[sProp] + ", ";
        }
        sSQL = sSQL.slice(0, -2);
        sSQL += ") VALUES (";

        for (var sProperty in aProps) {
          if (parseInt(sProperty) === aProps.length - 1) {
            sSQL += "? )";
          } else {
            sSQL += "?,";
          }
        }

        return sSQL;
      },

      _getSQLForUpdateObject: function (
        sEntity,
        oData,
        oMetadataObject,
        where
      ) {
        if (sEntity === "Setting") {
          debugger;
        }
        //UPDATE product SET qoh=? WHERE productid=?
        //"REPLACE INTO Setting (SValue, SKey) VALUES (?,?)";
        var sSQL = "UPDATE " + sEntity + " SET ",
          aProps,
          sWhere = "";
        if (!oMetadataObject) {
          aProps = this._getPropertiesForEntity(this._getMetaObject(), sEntity);
        } else {
          aProps = this.getPropertiesFromEntityCustom(oMetadataObject);
        }
        for (var sProp in aProps) {
          sSQL += aProps[sProp] + "=?, ";
        }

        sSQL = sSQL.slice(0, -2);

        sWhere = this._getWhereClauseForEntity(sEntity, where);

        sSQL += " " + sWhere;

        return sSQL;
      },

      _getSQLForUpdateParticipants: function (sEntity, oData) {
        var sSQL = "UPDATE " + sEntity + " SET ",
          aProps = this._getPropertiesForEntity(this._getMetaObject(), sEntity),
          sWhere = "";

        for (var sProp in aProps) {
          sSQL += aProps[sProp] + "=?, ";
        }

        sSQL = sSQL.slice(0, -2);

        sWhere = this._getWhereClauseForEntity(sEntity);

        sSQL += " " + sWhere;

        return sSQL;
      },

      _getSQLForDeleteObject: function (sEntity, oData, oMetadatObject) {
        //DELETE FROM counterCombos WHERE comboid = ?
        var sSQL = "DELETE FROM " + sEntity,
          sWhere = "";

        sWhere = this._getWhereClauseForEntity(sEntity, oMetadatObject);

        sSQL += " " + sWhere;

        return sSQL;
      },

      _getSQLForVhCreateTable: function (sEntity, sProp) {
        return (
          "CREATE TABLE IF NOT EXISTS " + sEntity + sProp + "VH (VhKey, VhVal)"
        );
      },

      _getSQLForVhDataInsert: function (sEntity, sProp, aValues) {
        var aSQLArray = [];

        aValues.forEach(function (oValue) {
          var oSQLObject = {};

          oSQLObject.sql =
            "INSERT INTO " +
            sEntity +
            sProp +
            "VH" +
            " (VhKey, VhVal) VALUES (?, ?)";
          oSQLObject.valArray = [];
          oSQLObject.valArray.push(oValue.VhKey);
          oSQLObject.valArray.push(oValue.VhVal);

          aSQLArray.push(oSQLObject);
        });

        return aSQLArray;
      },

      _getSQLForVhDataGet: function (sEntity, sProp) {
        return "SELECT * FROM " + sEntity + sProp + "VH";
      },

      _getValueArrayForInsert: function (sEntity, oData, oMetadatObject) {
        var aValues = [],
          aProps,
          oDummyObj = {};
        if (!oMetadatObject) {
          aProps = this._getPropertiesForEntity(this._getMetaObject(), sEntity);
        } else {
          aProps = this.getPropertiesFromEntityCustom(oMetadatObject);
        }

        for (var iIndex in aProps) {
          var sProp = aProps[iIndex];

          if (oData.hasOwnProperty(sProp)) {
            oDummyObj[sProp] = oData[sProp];
          } else {
            oDummyObj[sProp] = "";
          }
        }

        for (var sProp in oDummyObj) {
          aValues.push(oDummyObj[sProp]);
        }

        return aValues;
      },

      _getValueArrayForUpdate: function (
        sEntity,
        oData,
        oMetadataObject,
        where
      ) {
        var aValueArray = this._getValueArrayForInsert(
            sEntity,
            oData,
            oMetadataObject
          ),
          aKeyArray = [],
          aKeys;
        if (!where) {
          aKeys = this._getEntityKeys(sEntity);
        } else {
          if (!oMetadataObject.key) {
            debugger;
          }
          aKeys = this._getEntityKeysCustom(
            sEntity,
            oMetadataObject.key
              ? oMetadataObject.key.propertyRef
              : oMetadataObject
          );
        }

        aKeys.forEach(function (oKey) {
          if (oData[oKey.name] !== undefined) {
            aKeyArray.push(oData[oKey.name]);
          } else {
            aKeyArray.push("");
          }
        });

        return aValueArray.concat(aKeyArray);
      },

      _getValueArrayForUpdateParticipants: function (
        sEntity,
        oData,
        oOldParticipant
      ) {
        var aValueArray = this._getValueArrayForInsert(sEntity, oData),
          aKeyArray = [],
          aKeys = this._getEntityKeys(sEntity);

        aKeys.forEach(function (oKey) {
          if (oOldParticipant[oKey.name] !== undefined) {
            aKeyArray.push(oOldParticipant[oKey.name]);
          } else {
            aKeyArray.push("");
          }
        });

        return aValueArray.concat(aKeyArray);
      },

      _getValueArrayForDelete: function (sEntity, oData, oMetadataObject) {
        var aKeyArray = [],
          aKeys;
        if (!oMetadataObject) {
          aKeys = this._getEntityKeys(sEntity);
        } else {
          if (!oMetadataObject.key) {
            debugger;
          }
          //aKeys = this._getEntityKeysCustom(sEntity, oMetadataObject);
          aKeys = this._getEntityKeysCustom(
            sEntity,
            oMetadataObject.key
              ? oMetadataObject.key.propertyRef
              : oMetadataObject
          );
        }
        aKeys.forEach(function (oKey) {
          if (oData[oKey.name] !== undefined) {
            aKeyArray.push(oData[oKey.name]);
          } else {
            aKeyArray.push("");
          }
        });

        return aKeyArray;
      },

      _getExcludeWhereClause: function (sKeyField, iNumberOfExcludes) {
        var sWhereClause = "WHERE " + sKeyField + " NOT IN (";

        for (var i = 0; i < iNumberOfExcludes; i++) {
          sWhereClause += "?,";
        }

        sWhereClause = sWhereClause.slice(0, -1) + ")";

        return sWhereClause;
      },

      _getWhereClauseForEntity: function (sEntity, oMetaDataObject) {
        var sWhereClause = "WHERE ",
          aKeys;
        if (!oMetaDataObject) {
          aKeys = this._getEntityKeys(sEntity);
        } else {
          //aKeys = this._getEntityKeysCustom(sEntity, oMetaDataObject);
          if (!oMetaDataObject.key) {
            debugger;
          }
          aKeys = this._getEntityKeysCustom(
            sEntity,
            oMetaDataObject.key
              ? oMetaDataObject.key.propertyRef
              : oMetaDataObject
          );
        }
        aKeys.forEach(function (oKey) {
          sWhereClause += oKey.name + "=? AND ";
        });

        sWhereClause = sWhereClause.slice(0, -5);

        return sWhereClause;
      },

      _getEntityKeys: function (sEntity) {
        var oMetaObject = this._getMetaObject(),
          oEntityMeta = _.find(oMetaObject.dataServices.schema[0].entityType, {
            name: sEntity,
          });

        return _.sortBy(oEntityMeta.key.propertyRef, "name");
      },

      initValueHelpSet: function (oValueHelp) {
        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog;
        this._isSQLAvailable();
        oBusyDialog.open();
        $.when(this._isDBIntialized()).done(
          jQuery.proxy(function (bIsInit) {
            //if (!bIsInit) {
            var sSQLCreate = this._getSQLForVHSCreateTable("ValueHelp");
            this.db.transaction(
              jQuery.proxy(function (tx) {
                tx.executeSql(
                  sSQLCreate,
                  null,
                  jQuery.proxy(function (tx2, res) {
                    //console.debug(res);
                  }, this),
                  jQuery.proxy(function (tx2, error) {
                    // nothing yet
                  }, this)
                );
                oValueHelp.results.forEach(
                  jQuery.proxy(function (oVH) {
                    var sSQL = this._getSQLForVHSInsertObject("ValueHelp", oVH),
                      aSQLInsert = this._getValueArrayForVHSInsert(
                        "ValueHelp",
                        oVH
                      );
                    this.db.transaction(
                      function (tx) {
                        tx.executeSql(
                          sSQL,
                          aSQLInsert,
                          function (tx2, res) {
                            //console.debug(res);
                          },
                          function (tx2, error) {
                            console.debug(error);
                          }
                        );
                      },
                      function (error) {
                        oBusyDialog.close();
                        d.reject(error);
                      },
                      function () {
                        oBusyDialog.close();
                      }
                    );
                  }, this)
                );
              }, this),
              function (error) {
                oBusyDialog.close();
                d.reject(error);
              },
              function () {
                oBusyDialog.close();
                d.resolve();
              }
            );
            /*} else {
					oBusyDialog.close();
					d.resolve();
				}*/
          }, this)
        );

        return d.promise();
      },

      _getSQLForVHSCreateTable: function (sEntity) {
        var sSQL = "CREATE TABLE IF NOT EXISTS " + sEntity + "Set (",
          aProps = this._getFullPropertyForEntity(
            this.service._oConfigModel.oMetadata.oMetadata,
            sEntity
          ),
          aKeys = this._getVHSEntityKeys(sEntity),
          sKeySQL = "PRIMARY KEY (";
        for (var sProp in aProps) {
          if (
            (aProps[sProp].type.indexOf("String") !== -1 ||
              aProps[sProp].type.indexOf("DateTime") !== -1) &&
            aProps[sProp].name !== "Swerk" &&
            aProps[sProp].name !== "Iwerk" &&
            aProps[sProp].name !== "Plant" &&
            aProps[sProp].name !== "ExecutantCnt"
          ) {
            sSQL += aProps[sProp].name + " TEXT, ";
          } else {
            sSQL +=
              aProps[sProp].name +
              " " +
              aProps[sProp].type.substring(4).toUpperCase() +
              ", ";
          }
        }
        for (var sKey in aKeys) {
          if (parseInt(sKey) === aKeys.length - 1) {
            sKeySQL += aKeys[sKey].name + " ) ";
          } else {
            sKeySQL += aKeys[sKey].name + ", ";
          }
        }
        sSQL += sKeySQL;
        return sSQL + ")";
      },

      _getVHSEntityKeys: function (sEntity) {
        var oMetaObject = this.service._oConfigModel.oMetadata.oMetadata,
          oEntityMeta = _.find(oMetaObject.dataServices.schema[0].entityType, {
            name: sEntity,
          });
        return _.sortBy(oEntityMeta.key.propertyRef, "name");
      },

      _getValueArrayForVHSInsert: function (sEntity, oData) {
        var aValues = [],
          aProps = this._getPropertiesForEntity(
            this.service._oConfigModel.oMetadata.oMetadata,
            sEntity
          ),
          oDummyObj = {};
        for (var iIndex in aProps) {
          var sProp = aProps[iIndex];
          if (oData.hasOwnProperty(sProp)) {
            oDummyObj[sProp] = oData[sProp];
          } else {
            oDummyObj[sProp] = "";
          }
        }
        for (var sProp in oDummyObj) {
          aValues.push(oDummyObj[sProp]);
        }
        return aValues;
      },

      _getSQLForVHSInsertObject: function (sEntity, oData) {
        //"INSERT INTO customerAccounts (firstname, lastname, acctNo) VALUES (?,?,?)";
        var sSQL = "INSERT INTO " + sEntity + "Set(";
        var aProps = this._getPropertiesForEntity(
          this.service._oConfigModel.oMetadata.oMetadata,
          sEntity
        );
        for (var sProp in aProps) {
          sSQL += aProps[sProp] + ", ";
        }
        sSQL = sSQL.slice(0, -2);
        sSQL += ") VALUES (";
        for (var sProp in aProps) {
          sSQL += "?,";
        }
        sSQL = sSQL.slice(0, -1);
        return sSQL + ")";
      },

      createTableAndFill: function (entityType, odata) {
        this._isSQLAvailable();

        var d = $.Deferred(),
          aStatements = this.generateInsertStatementsForBatch(
            entityType,
            odata
          );

        if (aStatements && this.db) {
          this.db.transaction(
            jQuery.proxy(function (tx) {
              _.each(
                aStatements,
                jQuery.proxy(function (uStatement) {
                  switch (typeof uStatement) {
                    case "string":
                      /* DROP or CREATE statements */
                      tx.executeSql(uStatement);
                      break;
                    case "object":
                      // 	/* INSERT INTO statements */
                      if (Array.isArray(uStatement)) {
                        tx.executeSql(uStatement[0], uStatement[1]);
                      }
                      break;
                  }
                  // tx.executeSql(aStatement);
                }, this)
              );
            }, this),
            jQuery.proxy(function (error) {
              d.reject(error);
            }, this),
            jQuery.proxy(function () {
              d.resolve(entityType.name + "Table dropped, created and filled");
            }, this)
          );
        }
        return d.promise();
      },

      getPropertiesFromEntityCustom: function (oEntity) {
        var aProps = [];
        oEntity.property.forEach(function (oProp) {
          aProps.push(oProp.name);
        });

        return _.sortBy(aProps);
      },

      _getFullPropertyForEntityCustom: function (sEntity) {
        var aProps = [];

        sEntity.property.forEach(function (oProp) {
          aProps.push(oProp);
        });

        return _.sortBy(aProps);
      },

      generateInsertStatementsForBatch: function (entityType, odata) {
        if (
          entityType.name === "Operation" ||
          entityType.name === "Component" ||
          entityType.name === "PRT" ||
          entityType.name === "AICCustomizing"
        ) {
          var batch = [
            this.generateDropTableStatement(entityType.name),
            this._getSQLForCreateTableNoKeys(entityType.name),
          ];
        } else if (
          entityType.name === "WCARisks" ||
          entityType.name === "WCAOpeRisks" ||
          entityType.name === "WCAData" ||
          entityType.name === "WCAOpeData"
        ) {
          batch = [
            this.generateDropTableStatement(entityType.name),
            this._getSQLForCreateTable(
              entityType.name,
              null,
              CustomKeys.find((item) => item.name === entityType.name)
            ),
          ];
        } else if (entityType.name === "FollowUpNotif") {
          batch = [
            this.generateDropTableStatement(entityType.name),
            this._getSQLForCreateTableNoKeys(entityType.name, entityType),
          ];
        } else {
          batch = [
            this.generateDropTableStatement(entityType.name),
            this._getSQLForCreateTable(entityType.name, entityType),
          ];
        }

        var insertStatement = this.getSQLInsertStatement(odata, entityType);
        return _.union(batch, insertStatement);
      },

      generateDropTableStatement: function (sTableName) {
        return "DROP TABLE IF EXISTS " + sTableName;
      },

      getSQLInsertStatement: function (odata, entityType) {
        var statement = [];
        odata.forEach(
          jQuery.proxy(function (data) {
            var sSQL = this._getSQLForInsertObject(
                entityType.name,
                data,
                entityType
              ),
              aValues = this._getValueArrayForInsert(
                entityType.name,
                data,
                entityType
              );
            statement.push([sSQL, aValues]);
          }, this)
        );
        return statement;
      },

      _getEntityKeysCustom: function (sEntity, metadataObject) {
        return metadataObject;
        //return _.sortBy(metadataObject, "name");
      },

      _sqlDataBaseUpdate: function () {
        var d = jQuery.Deferred();
        this.db.transaction(
          function (tx) {
            var sql = "SELECT * from sqlite_master WHERE type = 'table'";
            tx.executeSql(
              sql,
              [],
              function (tx2, res) {
                d.resolve(res);
              },
              function (tx2, error) {
                d.reject(error);
              }
            );
          },
          function (error) {
            d.reject(error);
          },
          function () {}
        );

        return d.promise();
      },

      deleteIncluding: function (table, sField, aExcluded) {
        this._isSQLAvailable();
        this.busyDialog.open();

        var d = jQuery.Deferred(),
          sSQL,
          aValues = aExcluded,
          oBusyDialog = this.busyDialog,
          sParams = "?";
        for (var i = 0; i < aExcluded.length - 1; i++) {
          sParams = sParams + ",?";
        }

        if (aValues.length !== 0 && sField !== "") {
          sSQL =
            "DELETE FROM " +
            table +
            " WHERE " +
            sField +
            " IN (" +
            sParams +
            ")";
        }

        if (aValues.length === 0) {
          oBusyDialog.close();
          d.resolve();
        } else {
          this.db.transaction(
            function (tx) {
              tx.executeSql(sSQL, aValues);
            },
            function (error) {
              oBusyDialog.close();
              d.reject(error);
            },
            function () {
              oBusyDialog.close();
              d.resolve();
            }
          );
        }

        return d.promise();
      },
      //after this release remove savemultiplereplace//
      multipleDataDb: function (entity, aData, metadataObject, type) {
        this._isSQLAvailable();
        var oDatas = aData,
          d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          aSQL = [];

        oDatas.forEach(
          jQuery.proxy(function (oData) {
            if (type === "Replace") {
              aSQL.push({
                sql: this._getSQLForReplaceObject(
                  entity,
                  oData,
                  metadataObject
                ),
                values: this._getValueArrayForInsert(
                  entity,
                  oData,
                  metadataObject
                ),
              });
            } else {
              aSQL.push({
                sql: this._getSQLForInsertObject(entity, oData, metadataObject),
                values: this._getValueArrayForInsert(
                  entity,
                  oData,
                  metadataObject
                ),
              });
            }
          }, this)
        );

        // Execute sql
        this.db.transaction(
          function (tx) {
            for (var i = 0; i < aSQL.length; i++) {
              tx.executeSql(aSQL[i].sql, aSQL[i].values);
            }
          },
          function (error) {
            debugger;
            d.reject(error);
          },
          function () {
            d.resolve(aData);
          }
        );

        return d.promise();
      },

      _createTable: function (tables) {
        var d = jQuery.Deferred(),
          aSQL = [];

        if (tables) {
          tables.forEach(
            jQuery.proxy(function (oEntity) {
              aSQL.push(this._getSQLForCreateTable(oEntity.name, oEntity));
            }, this)
          );

          if (this._isSQLAvailable()) {
            this.db.transaction(
              function (tx) {
                for (var i = 0; i < aSQL.length; i++) {
                  tx.executeSql(aSQL[i], null);
                }
              },
              function (error) {
                d.reject();
              },
              function () {
                d.resolve();
              }
            );
          }
        } else {
          d.resolve();
        }

        return d.promise();
      },

      maintainInOutTable: function (data) {
        var d = jQuery.Deferred();
        this.db.transaction(
          function (tx) {
            data.forEach(function (row) {
              //if(row.TimeOut){
              tx.executeSql(
                'SELECT * FROM TimeInOut WHERE Pernr = ? AND TimeIn IS NOT NULL AND TimeOut IS "" ORDER BY TimeStamp DESC',
                [row.Pernr],
                function (tx, results) {
                  if (results.rows.length > 0 && row.TimeOut) {
                    let timestamp = results.rows.item(0).TimeStamp;
                    tx.executeSql(
                      "UPDATE TimeInOut SET TimeOut = ? WHERE Pernr = ? AND TimeStamp = ?",
                      [row.TimeOut, row.Pernr, timestamp]
                    );
                  } else if (!row.TimeOut) {
                    tx.executeSql(
                      "INSERT INTO TimeInOut (TimeStamp, Pernr, TimeIn, TimeOut, TrZone) VALUES (?, ?, ?, ?, ?)",
                      [
                        row.TimeStamp,
                        row.Pernr,
                        row.TimeIn,
                        row.TimeOut,
                        row.TrZone,
                      ]
                    );
                  }
                }
              );
              // }else {
              // 	tx.executeSql('INSERT INTO TimeInOut (TimeStamp, Pernr, TimeIn, TimeOut, TrZone) VALUES (?, ?, ?, ?, ?)', [row.TimeStamp, row.Pernr, row.TimeIn, row.TimeOut, row.TrZone]);
              // }
            });
          },
          function (error) {
            d.reject(error);
          },
          function () {
            d.resolve();
          }
        );
        return d.promise();
      },
      //keys format : {order: "400128"}
      getSqlEntity: function (entityName, keys) {
        var select = "Select * from " + entityName + " where ",
          where = "";
        Object.keys(keys).forEach((item) => {
          where = where ? where + item + "= ? AND " : item + " = ? AND ";
        });
        where = where.slice(0, -4);
        return [select + where, Object.values(keys)];
      },

      _savePlanItemSetSettings: function (entity) {
        var sSQL =
          "CREATE TABLE IF NOT EXISTS Setting (SKey PRIMARY KEY, SValue)";

        this.db.transaction(
          jQuery.proxy(function (tx) {
            tx.executeSql(sSQL, null);
            tx.executeSql("INSERT INTO Setting VALUES (?, ?)", [
              "PlanItemSet",
              JSON.stringify(entity),
            ]);
          }, this)
        );
        this.PlanItemEnitity = entity;
        return Promise.resolve();
      },

      setMetaObject: function (newMetaObject) {
        this.metaObject = newMetaObject;
      },

      getMetaObject: function () {
        return this.metaObject;
      },

      getPlanItemEntity: function () {
        return this.PlanItemEnitity;
      },

      _getPlanItemSetFromDB: function () {
        var d = jQuery.Deferred(),
          sSQL = "SELECT SValue FROM Setting WHERE SKey=?";

        console.debug("getMetadataFromDB");

        this.db.transaction(
          jQuery.proxy(function (tx) {
            tx.executeSql(
              sSQL,
              ["PlanItemSet"],
              jQuery.proxy(function (tx2, res) {
                console.debug("metadata object retrieved from DB");
                console.debug(res.rows.length);
                console.debug(res.rows);
                if (res.rows.length > 0) {
                  this.PlanItemEnitity = JSON.parse(res.rows.item(0).SValue);
                  d.resolve();
                }
              }, this),
              jQuery.proxy(function (oError) {
                console.debug("TEST: ", oError);
              }, this)
            );
          }, this)
        );

        return d.promise();
      },

      onSelectMultiple: function (entity, sHandle) {
        this.busyDialog.open();
        this._isSQLAvailable();
        var d = jQuery.Deferred(),
          oBusyDialog = this.busyDialog,
          sql = [],
          count = 0,
          pictures = [];
        this.busyDialog.open();
        sHandle.forEach((handle) => {
          sql.push(
            "SELECT * FROM " + entity + " WHERE Parent ='" + handle + "'"
          );
        });
        for (let i = 0; i < sql.length; i++) {
          $.when(this.getEntitySet(entity, sql[i]))
            .done(
              jQuery.proxy(function (oData) {
                count++;
                pictures = pictures.concat(this.helper.rowsToArray(oData));
                if (sHandle.length === count) {
                  d.resolve(pictures);
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oData) {
                count++;
                if (sHandle.length === count) {
                  d.resolve(pictures);
                }
              }, this)
            );
        }
        return d.promise();
      },
    });
  }
);
