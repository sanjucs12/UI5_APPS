/*global Connection:true*/
/*global device:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "mobilework/util/Helper",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "mobilework/model/TokenService",
  ],
  function (Object, Help, Filter, Operator, TokenService) {
    "use strict";

    let oService = Object.extend("mobilework.model.service", {
      // publicRelease: true,

      constructor: function (
        oModel,
        sHost,
        sServiceUrl,
        sDeviceName,
        sSAPClient,
        sUser,
        sPassword,
        sServicePath,
        sLangu,
        sConfigUri,
        sConfigUrl,
        sConfigModel,
        component
      ) {
        if (component === undefined) {
          console.debug("Component should be provided !");
          // debugger;
        }

        this.component = component;
        this._oModel = oModel;

        this.publicRelease = this.component
          .getModel("shared")
          .getProperty("/publicRelease");

        // GET BELOW INFO FROM THIS.COMPONENT TO PREVENT INCONSISTENCIES

        // this._sHost = sHost;
        // this._sServiceUrl = sServiceUrl;
        // this._sDeviceName = sDeviceName ? sDeviceName.toString() : "";
        // this._sSAPClient = sSAPClient;
        // this._sUser = sUser;
        // this._sPassword = sPassword;
        // this._sBearer = sPassword;
        // this._sServicePath = sServicePath;

        // this._sLangu = sLangu;
        this._oHelper = new Help();

        this._iIndex = 0;

        // this._sConfigUri = sConfigUri;
        // this._sConfigUrl = sConfigUrl;

        this._sAppID = "MOB_WORK";

        this._oConfigModel = sConfigModel;

        // // Check if Metadata check is already running for the service model
        // if (!this._oModel.bCheckRunning) {
        // 	// start interval
        // 	this._oModel.bCheckRunning = true;

        // 	this._oModel.attachMetadataFailed(function (oData) {
        // 		console.debug("Metadata WR failed");
        // 		console.debug(this._oModel.oMetadata.bLoaded);
        // 		console.debug(this._oModel.oMetadata.bFailed);
        // 		//
        // 		// console.debug(oData);
        // 	}.bind(this));

        // 	this._oModel.attachMetadataLoaded(function (oData) {
        // 		console.debug("Metadata WR succeed");
        // 		console.debug(this._oModel.oMetadata.bLoaded);
        // 		console.debug(this._oModel.oMetadata.bFailed);
        // 		//
        // 		// console.debug(oData);
        // 	}.bind(this));
        //
        // 	// this._oModel.refreshMetadata();

        // 	let oInterval = setInterval(this._metaDataCheck.bind(this), 3000);
        // 	this._oModel.oInterval = oInterval;
        // 	//

        // 	// console.debug(x);
        // 	//setInterval()
        // }
      },

      onDestroy: function () {
        clearInterval(this._oModel.oInterval);
      },

      _getLangu: function () {
        let oSharedModel = this.component.getModel("shared");
        let sLangu = oSharedModel.getProperty("/sapSettings/langu");

        if (!sLangu) {
          sLangu = "EN";
        }

        return sLangu;
      },

      _metaDataCheck: function () {
        let x = this._oModel.refreshMetadata().catch(function (oError) {
          console.error("Error WR catch");
        }); // Issue the whole app is reloading ...
      },

      getModel: function () {
        return this._oModel;
      },

      getUser: function () {
        return this._sUser;
      },

      // updateLanguage: function (sLangu) {
      // 	this._sLangu = sLangu;
      // },

      updateIndex: function () {
        this._iIndex++;
      },

      // updateHost: function (sHost) {
      // 	this._sHost = sHost;
      // },

      // setProperties: function (sHost, sServiceUrl, sDeviceName, sSAPClient, sUser, sPassword, sUri, sLangu) {
      // 	this._sHost = sHost;
      // 	this._sServiceUrl = sServiceUrl;
      // 	this._sDeviceName = sDeviceName.toString();
      // 	this._sSAPClient = sSAPClient;
      // 	this._sUser = sUser;
      // 	this._sPassword = sPassword;
      // 	// this._sBearer = sBearer;
      // 	this._sLangu = sLangu;
      // 	if (!this._sLangu) {
      // 		this._sLangu = "EN";
      // 	}
      // },

      checkTokenExpiration: function () {
        return this._checkTokenExpiration(this._oModel);
      },

      getCatalogSet: function (sLang) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); //this._sLangu;

        if (sLang) {
          sLangu = sLang;
          oSharedModel.setProperty("/sapSettings/langu", sLang);
          // this._sLangu = sLang;
        }
        console.debug(this._oModel.oMetadata);

        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/CatalogSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getValueHelpData: function (sLang) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); //this._sLangu;
        if (sLang) {
          sLangu = sLang;
          // this._sLangu = sLang;
          oSharedModel.setProperty("/sapSettings/langu", sLang);
        }
        console.debug(this._oModel.oMetadata);

        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/ValueHelpSet", {
                  urlParameters: {
                    $expand: "NavValueHelpData",
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getValueHelpSet: function () {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(), // this._sLangu,
          aFilters = [];

        aFilters.push(
          new sap.ui.model.Filter({
            path: "AppId",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: this._sAppID,
          })
        );
        if (
          this._oConfigModel !== null &&
          !this._oConfigModel.oMetadata.bFailed
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.read("/ValueHelpSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  filters: aFilters,
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      // getSettingSet: function (sLang,user) {
      // 	var d = jQuery.Deferred(),
      // 		sSAPClient = this._sSAPClient,
      // 		sLangu = this._sLangu;
      // 	if(sLang) {
      getSettingSet: function (sLang, user) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); // this._sLangu;

        if (sLang) {
          sLangu = sLang;
          // this._sLangu = sLang;
          oSharedModel.setProperty("/sapSettings/langu", sLang);
        }
        let aFilters = [];

        aFilters.push(
          new sap.ui.model.Filter({
            path: "SValue",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: user || oSharedModel.getProperty("/sapSettings/sapUser"), // this._sUser
          })
        );

        console.debug(this._oModel.oMetadata);

        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/SettingSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                  filters: aFilters,
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getInstallationTreeSet: function (
        sField,
        sValue,
        bEnableDownloadBoms,
        iLevels,
        iCall
      ) {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(), // this._sLangu, this._sLangu,
          _sValue = sValue;

        if (!_sValue) {
          _sValue = "";
        }

        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/TechnicalObjectSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                    $expand: "NavCraft,NAVTechFloc,BomDataSet,NavImpact",
                    downloadbom: bEnableDownloadBoms,
                    levels: iLevels,
                    call: iCall,
                    //"$select": "Rbnr,Scanid,Strno,Workhandle,TechObject,Parent,Ktx01,TechObjectType,Equnr,Tplnr,Matnr,NavCraft"
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                  filters: [
                    new Filter({
                      path: sField,
                      operator: Operator.EQ,
                      value1: _sValue,
                    }),
                  ],
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getParticipantData: function (aFilters) {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient, this._sSAPClient,
          sLangu = this._getLangu(), //this._sLangu, this._sLangu,
          sNetworkState = navigator.connection.type;

        if (this._oHelper.isDevModeActive() || Connection) {
          if (
            this._oHelper.isDevModeActive() ||
            (sNetworkState !== Connection.UNKNOWN &&
              sNetworkState !== Connection.NONE)
          ) {
            this._checkTokenExpiration(this._oModel)
              .then(
                function () {
                  this._oModel.read("/ParticipantSet", {
                    urlParameters: {
                      "sap-client": sSAPClient,
                      "sap-language": sLangu,
                    },
                    success: function (oData) {
                      d.resolve(oData);
                    },
                    error: function (oError) {
                      d.reject(oError);
                    },
                    filters: aFilters,
                  });
                }.bind(this)
              )
              .catch(function (oError) {
                d.reject(oError);
              });
          } else {
            d.reject({
              offline: true,
            });
          }
        } else {
          d.reject({
            connection: false,
          });
        }

        return d.promise();
      },

      // getInstallationTreeSet: function (sField, sValue, bEnableDownloadBoms, iLevels, iCall) {

      // 	let oSharedModel = this.component.getModel('shared');
      // 	let d = jQuery.Deferred(),
      // 		sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
      // 		sLangu = this._getLangu(), // this._sLangu,
      // 		_sValue = sValue;

      // 	if (!_sValue) {
      // 		_sValue = "";
      // 	}

      // 	if (!this._oModel.oMetadata.bFailed) {

      // 		this._checkTokenExpiration(this._oModel).then(function () {
      // 			this._oModel.read("/TechnicalObjectSet", {
      // 				urlParameters: {
      // 					"sap-client": sSAPClient,
      // 					"sap-language": sLangu,
      // 					"$expand": "NavCraft",
      // 					"downloadbom": bEnableDownloadBoms,
      // 					"levels": iLevels,
      // 					"call": iCall
      // 					//"$select": "Rbnr,Scanid,Strno,Workhandle,TechObject,Parent,Ktx01,TechObjectType,Equnr,Tplnr,Matnr,NavCraft"
      // 				},
      // 				success: function (oData) {
      // 					d.resolve(oData);
      // 				},
      // 				error: function (oError) {
      // 					d.reject(oError);
      // 				},
      // 				filters: [new Filter({
      // 					path: sField,
      // 					operator: Operator.EQ,
      // 					value1: _sValue
      // 				})]
      // 			});
      // 		}.bind(this)).catch(function (oError) { d.reject(oError) });

      // 	} else {
      // 		d.reject();
      // 	}

      // 	return d.promise();
      // },

      // getParticipantData: function (aFilters) {
      // 	let oSharedModel = this.component.getModel('shared');
      // 	let d = jQuery.Deferred(),
      // 		sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
      // 		sLangu = this._getLangu(), //this._sLangu,
      // 		sNetworkState = navigator.connection.type;

      // 	if (this._oHelper.isDevModeActive() || Connection) {
      // 		if (this._oHelper.isDevModeActive() || (sNetworkState !== Connection.UNKNOWN && sNetworkState !== Connection.NONE)) {

      // 			this._checkTokenExpiration(this._oModel).then(function () {
      // 				this._oModel.read("/ParticipantSet", {
      // 					urlParameters: {
      // 						"sap-client": sSAPClient,
      // 						"sap-language": sLangu
      // 					},
      // 					success: function (oData) {
      // 						d.resolve(oData);
      // 					},
      // 					error: function (oError) {
      // 						d.reject(oError);
      // 					},
      // 					filters: aFilters
      // 				});
      // 			}.bind(this)).catch(function (oError) { d.reject(oError) });

      // 		} else {
      // 			d.reject({
      // 				offline: true
      // 			});
      // 		}
      // 	} else {
      // 		d.reject({
      // 			connection: false
      // 		});
      // 	}

      // 	return d.promise();
      // },

      checkTokenExpirationForModels: async function () {
        if (this._oModel !== null)
          await this._checkTokenExpiration(this._oModel);
        if (this._oConfigModel !== null)
          await this._checkTokenExpiration(this._oConfigModel);
      },

      _checkTokenExpiration: async function (oModel) {
        if (this.publicRelease) {
          try {
            let sHost = "";
            if (!this.component.helper.isDevModeActive())
              sHost = this.component
                .getModel("shared")
                .getProperty("/sapSettings/host");
            return this.component.tokenService.checkTokenExpiration(
              oModel,
              sHost
            );
          } catch (oError) {
            console.error(oError);
          }
        } else return true;
      },

      getWorkSet: function () {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(), //this._sLangu,
          sDeviceId = oSharedModel.getProperty("/sapSettings/deviceName"); // this._sDeviceName;

        if (this._oModel.oMetadata.bFailed === false) {
          //

          // publicRelease > check token validity
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                //
                this._oModel.read("/WorkSet('" + sDeviceId + "')", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                    //	"$expand": "NavOrder/NavOperation/NavPRT,NavOrder/NavOperation/NavComponent,NavInstallationTree,NavPMNotification"
                    $expand:
                      "NavOrder/NavOperation/NavPRT,NavOrder/NavOperation/NavComponent,NavInstallationTree,NavPMNotification,NavWCARisks,NavWCAOpeData,NavWCAOpeRisks,NavWCAData",
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: jQuery.proxy(function (oError) {
                    d.reject(this._oHelper.parseGateWayError(oError));
                  }, this),
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getAICCustomizingSet: function (plant, sLang) {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); //this._sLangu;

        if (sLang) {
          sLangu = sLang;
          // this._sLangu = sLang;
          oSharedModel.setProperty("/sapSettings/langu", sLang);
        }
        if (this._oModel.oMetadata.bFailed === false) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/AICCustomizingSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                  filters: [
                    new Filter({
                      path: "Site",
                      operator: Operator.EQ,
                      value1: plant,
                    }),
                  ],
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      // setDeviceName: function (sDeviceName) {
      // 	this._sDeviceName = sDeviceName.toString();
      // },

      logoff: function () {
        // var d = jQuery.Deferred(),
        let sLogoffUrl,
          d = jQuery.Deferred();
        let oSharedModel = this.component.getModel("shared");
        let sPass = oSharedModel.getProperty("/sapSettings/sapPass");
        let sHost = this.component
          .getModel("shared")
          .getProperty("/sapSettings/host");
        let sSysId = this.component
          .getModel("shared")
          .getProperty("/sapSettings/sapSysId");

        if (this._oHelper.isDevModeActive()) {
          this.clearModels();
          return true;
        }

        if (sHost === undefined || this._oHelper.isDevModeActive())
          sLogoffUrl = "/sap/public/bc/icf/logoff";
        else sLogoffUrl = sHost + "/sap/public/bc/icf/logoff";

        let oTarget;
        if (this.publicRelease) {
          if (sPass === "" || sPass === undefined) {
            return "No bearer token loaded";
            // At this point we don't throw an error >
            // later in the flow the next service call will be checked again for a valid token
          }

          oTarget = {
            type: "GET",
            url: sLogoffUrl,
            beforeSend: function (request) {
              request.setRequestHeader("Authorization", "Bearer " + sPass);
              request.setRequestHeader("TargetSAPSystem", sSysId);
              request.setRequestHeader("Cache-Control", "max-age=0");
            }.bind(this),
          };
        } else {
          oTarget = {
            type: "GET",
            url: sLogoffUrl,
          };
        }
        //

        $.ajax(oTarget)
          .done(
            jQuery.proxy(function (oData) {
              d.resolve(oData);
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              d.reject(oError);
            }, this)
          );

        this.clearModels();

        return d.promise();

        // let oData = await $.ajax(oTarget).catch(jQuery.proxy(function (oError) {
        // 	//
        // 	// console.debug(oError);
        // 	return oError;

        // }, this));

        // return oData;
      },

      clearModel: function (oModel) {
        if (
          oModel !== undefined &&
          oModel !== null &&
          oModel.mCustomHeaders !== undefined &&
          oModel.mCustomHeaders !== null &&
          oModel.mCustomHeaders.Authorization !== undefined &&
          oModel.mCustomHeaders.Authorization !== null
        ) {
          delete oModel.mCustomHeaders.Authorization;
        }
        if (
          oModel !== undefined &&
          oModel !== null &&
          oModel.oSharedMetaData !== undefined &&
          oModel.oSharedMetaData !== null &&
          oModel.oSharedMetaData.oMetadata !== undefined &&
          oModel.oSharedMetaData.oMetadata !== null &&
          oModel.oSharedMetaData.oMetadata.sPassword !== undefined &&
          oModel.oSharedMetaData.oMetadata.sPassword !== null
        ) {
          delete oModel.oSharedMetaData.oMetadata.sPassword;
        }
        if (
          oModel !== undefined &&
          oModel !== null &&
          oModel.oSharedMetaData !== undefined &&
          oModel.oSharedMetaData !== null &&
          oModel.oSharedMetaData.oMetadata !== undefined &&
          oModel.oSharedMetaData.oMetadata !== null &&
          oModel.oSharedMetaData.oMetadata.sUser !== undefined &&
          oModel.oSharedMetaData.oMetadata.sUser !== null
        ) {
          delete oModel.oSharedMetaData.oMetadata.sUser;
        }
        if (
          oModel !== undefined &&
          oModel !== null &&
          oModel.sUser !== undefined &&
          oModel.sUser !== null
        ) {
          delete oModel.sUser;
        }
        if (
          oModel !== undefined &&
          oModel !== null &&
          oModel.sPassword !== undefined &&
          oModel.sPassword !== null
        ) {
          delete oModel.sPassword;
        }

        // if (oModel.aUrlParams) {
        //   delete oModel.aUrlParams;
        // }

        // if (oModel.sMetadataUrl) {
        //   delete oModel.sMetadataUrl;
        // }

        // if (this.component.logs._oDataModel.mCustomHeaders.Authorization) {
        //   delete this.component.logs._oDataModel.mCustomHeaders.Authorization;
        // }
        // if (
        //   this.component.logs._oDataModel.oSharedMetaData.oMetadata
        //     .sPassword
        // ) {
        //   delete this.component.logs._oDataModel.oSharedMetaData.oMetadata
        //     .sPassword;
        // }
        // if (
        //   this.component.logs._oDataModel.oSharedMetaData.oMetadata.sUser
        // ) {
        //   delete this.component.logs._oDataModel.oSharedMetaData.oMetadata
        //     .sUser;
        // }
        // if (this.component.logs._oDataModel.sUser) {
        //   delete this.component.logs._oDataModel.sUser;
        // }
        // if (this.component.logs._oDataModel.sPassword) {
        //   delete this.component.logs._oDataModel.sPassword;
        // }

        // if (this.component.logs._oDataModel.aUrlParams) {
        // 	delete this.component.logs._oDataModel.aUrlParams
        // }

        // if (this.component.logs._oDataModel.sMetadataUrl) {
        // 	delete this.component.logs._oDataModel.sMetadataUrl
        // }

        // if (this.component.logs._oDataModel.mCodeListModelParams.serviceUrl) {
        // 	delete this.component.logs._oDataModel.mCodeListModelParams.serviceUrl
        // }

        // if (this.component.logs._oDataModel.mCodeListModelParams.headers.Authorization) {
        // 	delete this.component.logs._oDataModel.mCodeListModelParams.headers.Authorization
        // }

        // delete this.component.logs._oDataModel.oAnnotations._mCustomHeaders.Authorization;

        // delete this.component.logs._oDataModel.oAnnotations._oMetadata.sUrl;

        // delete this.component.logs._oDataModel.oSharedServiceData.securityToken;

        // delete this.component.logs._oDataModel.oSharedServerData.securityToken;
      },

      clearModels: function () {
        if (
          this !== undefined &&
          this !== null &&
          this._oModel !== undefined &&
          this._oModel !== null
        ) {
          this.clearModel(this._oModel);
        }
        if (
          this !== undefined &&
          this !== null &&
          this._oConfigModel !== undefined &&
          this._oConfigModel !== null
        ) {
          this.clearModel(this._oConfigModel);
        }

        let deleteCookies = function () {
          var cookies = document.cookie.split(";");

          for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i];
            var eqPos = cookie.indexOf("=");
            var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
            document.cookie =
              name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          }
        };
        deleteCookies();
      },

      make_base_auth: function (user, password) {
        var tok = user + ":" + password;
        var hash = btoa(tok);
        return hash;
      },

      _getConfigUrl: function () {
        let sHost = this.component
          .getModel("shared")
          .getProperty("/sapSettings/host");
        let sConfigUri = this._getConfigUri();
        let sConfigUrl = sHost + sConfigUri;
        return sConfigUrl;
      },

      _getConfigUri: function () {
        return this.component.getManifestEntry(
          "/sap.app/dataSources/configserver"
        ).uri;
      },

      _getServiceUrl: function () {
        // debugger
        let sUri = this._getServiceUri();
        let sUrl =
          this.component.getModel("shared").getProperty("/sapSettings/host") +
          sUri;
        return sUrl;
      },

      _getServiceUri: function () {
        return this.component.getManifestEntry("/sap.app/dataSources/odata")
          .uri;
      },

      getDataModel: function (d) {
        // this._oModel.destroy();
        // var d = $.Deferred();

        //if (!this._oHelper.isDevModeActive()) {

        //$.when(this.logoff()).done(jQuery.proxy(function () {

        let oSharedModel = this.component.getModel("shared");
        let sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient");
        let sUrlToBeUsed = "";
        let sUser = oSharedModel.getProperty("/sapSettings/sapUser");
        let sPass = oSharedModel.getProperty("/sapSettings/sapPass");
        let sSysId = oSharedModel.getProperty("/sapSettings/sapSysId");

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = this._getServiceUri(); // this._sServicePath;
        } else {
          sUrlToBeUsed = this._getServiceUrl(); //this._sServiceUrl;
        }

        if (sSAPClient && sSAPClient !== "undefined") {
          // (this._sSAPClient && this._sSAPClient !== "undefined") {
          sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + sSAPClient;
        }
        sUrlToBeUsed =
          sUrlToBeUsed + "&authorization=" + this.make_base_auth(sUser, sPass);
        sap.ui.model.odata.v2.ODataModel.mServiceData = {};
        var deviceType = "getInstallationTreeSet";
        if (!this._oHelper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (this.publicRelease) {
          this.oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              // user: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? this._sUser : "",
              // password: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? this._sPassword : "",
              // withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient ? sSAPClient.toString() : "",
                Authorization: "Bearer " + sPass, //this.make_base_auth(this._sUser, this._sPassword),
                TargetSAPSystem: sSysId,
                "Cache-Control": "max-age=0",
                "Access-Control-Allow-Origin": "*",
              },
            }
          );

          this.oModel.attachRequestFailed(function (oEvent) {
            console.error("REQUEST FAILED");
            console.error(oEvent);
          });
        } else {
          this.oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              user:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sUser
                  : "",
              password:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sPass
                  : "",
              withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient ? sSAPClient.toString() : "",
                Authorization: "Basic " + this.make_base_auth(sUser, sPass),
                "Cache-Control": "max-age=0",
                "Access-Control-Allow-Origin": "*",
              },
            }
          );
        }

        this.oModel.attachMetadataLoaded(
          jQuery.proxy(function () {
            // debugger
            console.debug("metadata loaded in service");
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", false);
            // d.resolve();
          }, this)
        );

        this.oModel.attachMetadataFailed(
          jQuery.proxy(function () {
            // debugger
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", true);
            console.debug("metadata failed in service");
            // d.reject();
          }, this)
        );
        //}, this));
        //}

        return this.oModel;
      },

      createModelWithUser: function (sUser, sPass, oController, loginProgress) {
        //this._oModel.destroy();
        /*this._oModel.oSharedMetaData = {};
			this._oModel.oSharedServerData = {};
			this._oModel.oSharedServiceData = {};
			this._oModel.mPathCache = {};*/

        let bIndexChanged = false;
        let oSharedModel = this.component.getModel("shared");
        let d = $.Deferred();
        let sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient");

        let sSysId = oSharedModel.getProperty("/sapSettings/sapSysId");
        // let sUser = oSharedModel.getProperty("/sapSettings/sapUser");

        if (sUser === oSharedModel.getProperty("/sapSettings/sapUser")) {
          bIndexChanged = true;
        }

        // this._sUser = sUser;
        // this._sPassword = sPass;
        oSharedModel.setProperty("/sapSettings/sapPass", sPass);

        // this._sBearer = sPass;
        var sUrlToBeUsed = "";

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = this._getServiceUri(); // this._sServicePath;
        } else {
          sUrlToBeUsed = this._getServiceUrl(); // this._sServiceUrl;
        }

        if (sSAPClient && sSAPClient !== "undefined") {
          if (sUrlToBeUsed.indexOf("?sap-client=") !== -1) {
            sUrlToBeUsed = sUrlToBeUsed;
          } else {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + sSAPClient;
          }
        }

        sap.ui.model.odata.v2.ODataModel.mServiceData = {};
        var deviceType = "windows";
        if (!this._oHelper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (this.publicRelease) {
          // sUrlToBeUsed = sUrlToBeUsed + "&authorization=" + this.make_base_auth(sUser, sPass);
          sUrlToBeUsed =
            bIndexChanged === true ? sUrlToBeUsed + this._iIndex : sUrlToBeUsed;

          this._oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              // user: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? sUser : "",
              // password: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? sPass : "",
              // withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient.toString(),
                Authorization: "Bearer " + sPass,
                TargetSAPSystem: sSysId,
                "Cache-Control": "max-age=0",
              },
            }
          );

          this._oModel.attachRequestFailed(function (oEvent) {
            console.error(oEvent);
            console.error("REQUEST FAILED");
          });
        } else {
          sUrlToBeUsed =
            sUrlToBeUsed +
            "&authorization=" +
            this.make_base_auth(sUser, sPass);
          sUrlToBeUsed =
            bIndexChanged === true ? sUrlToBeUsed + this._iIndex : sUrlToBeUsed;

          this._oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              user:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sUser
                  : "",
              password:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sPass
                  : "",
              withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient.toString(),
                Authorization: "Basic " + this.make_base_auth(sUser, sPass),
                "Cache-Control": "max-age=0",
              },
            }
          );
        }

        // this._oModel.setHeaders({
        // 	"sap-client": this._sSAPClient.toString(),
        // 	"Cache-Control": "max-age=0"
        // });

        this._oModel.attachMetadataLoaded(
          jQuery.proxy(function () {
            // debugger
            console.debug("metadata loaded in service");
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", false);
            if (loginProgress) {
              if (
                oController
                  .getModel("login")
                  .getProperty("/show-connection-ok") === false
              ) {
                oController
                  .getModel("login")
                  .setProperty("/show-connection-ok", true);
                oController
                  .getModel("login")
                  .setProperty("/show-authorization-text", true);
              }
            } else {
              console.debug("Metadata loaded -> color green");
              this.component
                .getAggregation("rootControl")
                .getController()
                .genericSetDeviceIdColor("Green");
              this.component
                .getAggregation("rootControl")
                .getController()
                .genericReplaceStyleClass(
                  this.component.getRootControl(),
                  "Green"
                );
            }

            d.resolve();
          }, this)
        );

        this._oModel.attachMetadataFailed(
          jQuery.proxy(function (oError) {
            // debugger
            console.error("metadata failed in service");
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", true);
            if (loginProgress) {
              oController
                .getModel("login")
                .setProperty("/show-connection-nok", true);
              oController
                .getModel("login")
                .setProperty("/show-connection-ok", false);
              oController
                .getModel("login")
                .setProperty("/show-authorization-text", false);
              oController
                .getModel("login")
                .setProperty("/show-cancel-LoginProgress", true);
              oController
                .getModel("login")
                .setProperty("/show-retry-LoginProgress", false);
            } else {
              console.debug("Metadata failed -> color red");
              this.component
                .getAggregation("rootControl")
                .getController()
                .genericSetDeviceIdColor("Red");
              this.component
                .getAggregation("rootControl")
                .getController()
                .genericReplaceStyleClass(
                  this.component.getRootControl(),
                  "Red"
                );
            }
            d.reject(oError);
          }, this)
        );

        /*this._oModel.metadataLoaded(true).then(jQuery.proxy(function () {
				console.debug("metadata loaded in service");
				d.resolve();
			}, this), jQuery.proxy(function (fail) {
				console.debug("metadata failed in service");
				d.reject();
			}, this));*/

        //}, this));

        return d.promise();
      },

      createModelWithHostAndClient: function (sHost, sClient) {
        let oSharedModel = this.component.getModel("shared");

        let sUser = oSharedModel.getProperty("/sapSettings/sapUser"),
          sPass = oSharedModel.getProperty("/sapSettings/sapPass"),
          sSysId = oSharedModel.getProperty("/sapSettings/sapSysId");
        // sBearer = this._sBearer;

        let d = $.Deferred();

        let bIndexChanged = false;

        if (
          sHost ===
          this.component.getModel("shared").getProperty("/sapSettings/host")
        ) {
          bIndexChanged = true;
        }

        //this._oModel.destroy();

        //$.when(this.logoff()).done(jQuery.proxy(function () {

        // this._sHost = sHost;
        // this._sSAPClient = sClient;
        oSharedModel.setProperty("/sapSettings/sapClient", sClient);

        // this._sServiceUrl = sHost + this._sServicePath;
        var sUrlToBeUsed = "";

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = this._getServiceUri(); // this._sServicePath;
        } else {
          sUrlToBeUsed = this._getServiceUrl(); // this._sServiceUrl;
        }

        if (sClient && sClient !== "undefined") {
          if (sUrlToBeUsed.indexOf("?sap-client=") !== -1) {
            sUrlToBeUsed = sUrlToBeUsed;
          } else {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + sClient;
          }
        }

        sUrlToBeUsed =
          sUrlToBeUsed + "&authorization=" + this.make_base_auth(sUser, sPass);
        sUrlToBeUsed =
          bIndexChanged === true ? sUrlToBeUsed + this._iIndex : sUrlToBeUsed;
        sap.ui.model.odata.v2.ODataModel.mServiceData = {};
        var deviceType = "windows";
        if (!this._oHelper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (this.publicRelease) {
          this._oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              // user: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? sUser : "",
              // password: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? sPass : "",
              // withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sClient.toString(),
                Authorization: "Bearer " + sPass, // "Basic " + this.make_base_auth(sUser, sPass),
                TargetSAPSystem: sSysId,
                "Cache-Control": "max-age=0",
              },
            }
          );
        } else {
          //  // publicRelease version needed ??
          this._oModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              user:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sUser
                  : "",
              password:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sPass
                  : "",
              withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sClient.toString(),
                Authorization: "Basic " + this.make_base_auth(sUser, sPass),
                "Cache-Control": "max-age=0",
              },
            }
          );
        }

        this._oModel.attachRequestFailed(
          function (oEvent) {
            console.error("REQUEST FAILED");
            console.error(oEvent);
            this.component.getModel("shared").setProperty("/metaFailed", true);
          }.bind(this)
        );

        this._oModel.attachMetadataLoaded(
          jQuery.proxy(function () {
            // debugger
            console.debug("metadata loaded in service");
            this.component.getModel("shared").setProperty("/metaFailed", false);

            // this.getDBService()._createTablesFromMetadata(); // TODO necessary ??
            this.component.dbService._createTablesFromMetadata();
            d.resolve();
          }, this)
        );

        this._oModel.attachMetadataFailed(
          jQuery.proxy(function () {
            // debugger
            console.error("metadata failed in service");
            this.component.getModel("shared").setProperty("/metaFailed", true);
            d.reject();
          }, this)
        );

        return d.promise();
      },

      connectionCheck: function (sUser, sPassword, bDevMode) {
        let oSharedModel = this.component.getModel("shared");

        let _sUser = sUser,
          _sPassword = sPassword,
          d = jQuery.Deferred(),
          sNetworkState = navigator.connection.type;

        if (!_sUser) {
          _sUser = oSharedModel.getProperty("/sapSettings/sapUser");
        }
        if (_sUser === "" || _sPassword === "") {
          // d.resolve();
          let sPart1 = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("NoCredentialsFound");
          let sPart2 = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("LoginFirst");
          return sPart1 + ",\n" + sPart2;
          // "USER_CREDENTIALS_MISSING";
        }

        if (bDevMode || Connection) {
          if (
            bDevMode &&
            navigator.connection.rtt === 0 &&
            navigator.connection.downlink === 0
          ) {
            return d.resolve(
              this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("Offline")
            );
          }

          if (
            bDevMode ||
            (sNetworkState !== Connection.UNKNOWN &&
              sNetworkState !== Connection.NONE)
          ) {
            if (this._oModel.oMetadata.bLoaded === true) {
              this._checkTokenExpiration(this._oModel)
                .then(
                  function () {
                    if (oSharedModel.getProperty("/publicRelease")) {
                      let oData = {
                        ConnectionCheck: {
                          Type: "S",
                          Message: "Connection ok",
                        },
                      };
                      d.resolve(oData);
                      return;
                    }

                    if (!this._oModel.getHeaders().Authorization) {
                      let oHeaders = this._oModel.getHeaders();
                      let sAuth =
                        "Basic " + this.make_base_auth(_sUser, _sPassword);
                      oHeaders.Authorization = sAuth;
                      this._oModel.setHeaders(oHeaders);
                    }

                    this._oModel.callFunction("/ConnectionCheck", {
                      urlParameters: {
                        UNAME: _sUser,
                        UCODE: _sPassword,
                      },
                      success: function (oData) {
                        // oController.getModel('login').setProperty("/show-authorization-ok", true);
                        //connection check fails in other controllers
                        //oController.getModel('login').setProperty("/show-authorization-ok", true);
                        d.resolve(oData);
                      },
                      error: function (oError) {
                        //oController.getModel('login').setProperty("/show-authorization-nok", true);
                        d.reject(oError);
                      },
                    });
                  }.bind(this)
                )
                .catch(function (oError) {
                  debugger;
                  d.reject(oError);
                });
            } else {
              // WR 29.11.2023 - Odata model not loaded > try to reload ...
              console.debug("RELOAD METADATA");
              this._oModel.refreshMetadata().catch(function (oError) {
                console.error("Reloading metadata failed");
              });
              d.resolve("METADATA_REFRESH_TRIGGERED");
            }
          } else {
            d.resolve(
              this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("Offline")
            );
          }
        } else {
          d.resolve();
        }

        return d.promise();
      },

      sync: function (
        aNotifications,
        aConfirmations,
        aParticipants,
        aPictures
      ) {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sWorkHandle = this._oHelper.getUUID(),
          sDeviceId = oSharedModel.getProperty("/sapSettings/deviceName"), // this._sDeviceName,
          oWorkEntity = {
            Workhandle: sWorkHandle,
            Deviceid: sDeviceId,
            NavPMNotification: [],
            NavConfirmation: [],
            NavParticipant: [],
            NavPicture: [],
          },
          // sWorkHandle1=this._oHelper.getUUID(),
          // oWorkEntity1 = {
          //   Workhandle: sWorkHandle,
          //   Deviceid: sDeviceId,
          //   NavPMNotification: [],
          //   NavConfirmation: [],
          //   NavParticipant: [],
          //   NavPicture: [],
          // },
          _aNotif = this._oHelper.mapNotifications(
            aNotifications,
            sWorkHandle,
            aConfirmations
          ),
          _aConf = this._oHelper.mapConfirmations(aConfirmations, sWorkHandle),
          _aPartic = this._oHelper.mapParticipants(aParticipants, sWorkHandle),
          _aPic = this._oHelper.mapPictures(aPictures, sWorkHandle);

        oWorkEntity.NavConfirmation = _aConf;
        oWorkEntity.NavParticipant = _aPartic;
        oWorkEntity.NavPicture = _aPic;
        oWorkEntity.NavPMNotification = _aNotif;
        // System Log
        console.info('=====================WHEN=====================');
        console.info('WHEN: Server is reachable');
        typeof WifiWizard2 !=='undefined' && WifiWizard2.getConnectedSSID().then((oRes)=>{console.info("WHEN: Name of the wifi connected " + oRes)});
        typeof WifiWizard2 !=='undefined' && WifiWizard2.getWifiIPInfo().then((oRes)=>{console.info("WHEN: IP address of connected wifi is "+ oRes.ip)});
        console.info("WHEN:Notifications sent " , _aNotif);
        console.info("WHEN:Confirmations sent " , _aConf);
        console.info("WHEN:Particpants sent " , _aPartic);
        console.info("WHEN:Pictures sent " , _aPic);
        console.info("HTTP request made - /sap/opu/odata/ARMP/MW_SRV/WorkSet" )
        console.info('=====================END=====================');

          let that=this;

        this._checkTokenExpiration(this._oModel)
          .then(
            function () {
              // WR - 23.11.2022 Custom header test
              // this._oModel.setHeaders({
              // 	"PublicRelease" : "X"
              // });
              this._oModel.create("/WorkSet", oWorkEntity, {
                success: function (oResult) {
                  // System Log
                  console.info('=====================AFTER-->Detailed Content=====================');
                  console.info("AFTER: -->Detailed Content Send to SAP successful ", oResult);
                  console.info('=====================AFTER END-->Detailed Content=====================');

                  d.resolve();
                },
                error: jQuery.proxy(function (oError) {
                  // System Log
                  console.info('=====================AFTER-->Detailed Content=====================');
                  console.error("AFTER:-->Detailed Content Send to SAP unsuccessful ", oError);
                  console.info('=====================AFTER END-->Detailed Content=====================');

                  d.reject(this._oHelper.parseGateWayError(oError));
                }, this),
              });
            }.bind(this)
          )
          .catch(function (oError) {
            d.reject(oError);
          });

        return d.promise();
      },

      deassignAllData: function (sDeviceID, bDevMode, OrderID) {
        let _sDeviceID = sDeviceID,
          sNetworkState = navigator.connection.type,
          d = $.Deferred(),
          urlParameters = {
            DEVICEID: _sDeviceID,
          };
        urlParameters.ORDERID = OrderID ? OrderID : "";

        if (bDevMode || Connection) {
          if (
            bDevMode ||
            (sNetworkState !== Connection.UNKNOWN &&
              sNetworkState !== Connection.NONE)
          ) {
            if (this._oModel.oMetadata.bLoaded === true) {
              this._checkTokenExpiration(this._oModel)
                .then(
                  function () {
                    this._oModel.callFunction("/Deassign", {
                      urlParameters: urlParameters,
                      success: function (oData) {
                        d.resolve(oData);
                      },
                      error: function (oError) {
                        d.resolve(oError);
                      },
                    });
                  }.bind(this)
                )
                .catch(function (oError) {
                  d.reject(oError);
                });
            } else {
              d.resolve();
            }
          } else {
            d.resolve({
              offline: true,
            });
          }
        } else {
          d.resolve();
        }

        return d.promise();
      },

      // ----------------------------------- //
      //        Configuration server         //
      // ----------------------------------- //

      createConfigurationModel: function (
        uri,
        oSettings,
        oController,
        onBoarding
      ) {
        //this._oModel.destroy();
        /*this._oModel.oSharedMetaData = {};
			this._oModel.oSharedServerData = {};
			this._oModel.oSharedServiceData = {};
			this._oModel.mPathCache = {};*/
        let bIndexChanged = false;
        let sConfigUri = uri,
          sConfigUrl = oSettings.host + sConfigUri,
          sUrlToBeUsed = "";
        let d = $.Deferred();
        // let sUrlToBeUsed = "";

        let oSharedModel = this.component.getModel("shared");
        let sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient");
        let sUser = oSharedModel.getProperty("/sapSettings/sapUser");
        let sPass = oSharedModel.getProperty("/sapSettings/sapPass");
        let sSysId = oSharedModel.getProperty("/sapSettings/sapSysId");

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = sConfigUri;
        } else {
          sUrlToBeUsed = sConfigUrl;
        }
        if (sSAPClient && sSAPClient !== "undefined") {
          if (sUrlToBeUsed.indexOf("?sap-client=") !== -1) {
            sUrlToBeUsed = sUrlToBeUsed;
          } else {
            sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + sSAPClient;
          }
        }

        // sUrlToBeUsed = bIndexChanged === true ? sUrlToBeUsed + this._iIndex : sUrlToBeUsed;
        sap.ui.model.odata.v2.ODataModel.mServiceData = {};
        var deviceType = "windows";
        if (!this._oHelper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (this.publicRelease) {
          this._oConfigModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              // user: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? this._sUser : "",
              // password: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? this._sPassword : "",
              // withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient.toString(),
                Authorization: "Bearer " + sPass, // + this.make_base_auth(this._sUser, this._sPassword),
                TargetSAPSystem: sSysId,
                "Cache-Control": "max-age=0",
              },
            }
          );

          this._oConfigModel.attachRequestFailed(function (oEvent) {
            console.error("REQUEST FAILED");
            console.error(oEvent);
          });
        } else {
          sUrlToBeUsed =
            sUrlToBeUsed +
            "&authorization=" +
            this.make_base_auth(sUser, sPass);

          this._oConfigModel = new sap.ui.model.odata.v2.ODataModel(
            sUrlToBeUsed + "&saml2=disabled",
            {
              user:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sUser
                  : "",
              password:
                deviceType.indexOf("win") !== -1 ||
                deviceType.indexOf("Win") !== -1
                  ? sPass
                  : "",
              withCredentials: true,
              defaultBindingMode: "TwoWay",
              defaultCountMode: "Inline",
              metadataUrlParams: {},
              loadMetadataAsync: true,
              useBatch: false,
              headers: {
                "sap-client": sSAPClient.toString(),
                Authorization: "Basic " + this.make_base_auth(sUser, sPass),
                "Cache-Control": "max-age=0",
              },
            }
          );
        }

        // this._oModel.setHeaders({
        // 	"sap-client": this._sSAPClient.toString(),
        // 	"Cache-Control": "max-age=0"
        // });

        this._oConfigModel.attachMetadataLoaded(
          jQuery.proxy(function () {
            // debugger
            console.debug("metadata loaded in service");
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", false);
            if (onBoarding) {
              oController.getModel("login").setProperty("/show-data-ok", true);
            }
            d.resolve();
          }, this)
        );

        this._oConfigModel.attachMetadataFailed(
          jQuery.proxy(function (oError) {
            // debugger
            console.error("metadata failed in service");
            let oSharedModel = this.component.getModel("shared");
            oSharedModel.setProperty("/metaFailed", true);
            if (onBoarding) {
              oController.getModel("login").setProperty("/show-data-nok", true);
            }
            d.reject(oError);
          }, this)
        );

        /*this._oModel.metadataLoaded(true).then(jQuery.proxy(function () {
				console.debug("metadata loaded in service");
				d.resolve();
			}, this), jQuery.proxy(function (fail) {
				console.debug("metadata failed in service");
				d.reject();
			}, this));*/

        //}, this));

        return d.promise();
      },

      getDeviceSettings: function (sDeviceID, sPlant) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(), //this._sLangu,
          sDeviceId = sDeviceID,
          publicRelease = this.publicRelease;

        if (
          this._oConfigModel !== null &&
          this._oConfigModel.oMetadata.bFailed === false
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.read(
                  "/DeviceSet(AppId='" +
                    this._sAppID +
                    "',DeviceId='" +
                    sDeviceId +
                    "',Werks='" +
                    sPlant +
                    "')",
                  {
                    urlParameters: {
                      "sap-client": sSAPClient,
                      "sap-language": sLangu,
                      $expand: "navDeviceSettings",
                    },
                    success: function (oData) {
                      // Security > do not allow FUNC_USER
                      // debugger;

                      if (
                        publicRelease &&
                        oData.navDeviceSettings &&
                        oData.navDeviceSettings.results.filter(function (x) {
                          return x.Fieldname === "policy";
                        })[0].ValueString === "FUNC_USER"
                      ) {
                        console.debug("Functional user detected");
                        oData.navDeviceSettings.results.filter(function (x) {
                          return x.Fieldname === "policy";
                        })[0].ValueString = "LOGON_STRT";
                      }

                      d.resolve(oData);
                    },
                    error: jQuery.proxy(function (oError) {
                      d.reject(this._oHelper.parseGateWayError(oError));
                    }, this),
                  }
                );
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getUnassignedDevices: function (sPlant) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); // this._sLangu;

        let aFilters = [];

        aFilters.push(
          new sap.ui.model.Filter({
            path: "Assigned",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: false,
          })
        );
        aFilters.push(
          new sap.ui.model.Filter({
            path: "AppId",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: this._sAppID,
          })
        );
        aFilters.push(
          new sap.ui.model.Filter({
            path: "Werks",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: sPlant,
          })
        );

        if (
          this._oConfigModel !== null &&
          this._oConfigModel.oMetadata.bFailed === false
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.read("/DeviceSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: jQuery.proxy(function (oError) {
                    d.reject(this._oHelper.parseGateWayError(oError));
                  }, this),
                  filters: aFilters,
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      assignDevice: function (sDeviceID, sPlant) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); // this._sLangu;

        if (
          this._oConfigModel !== null &&
          this._oConfigModel.oMetadata.bFailed === false
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.callFunction("/setAssign", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                    AppId: this._sAppID,
                    DeviceId: sDeviceID,
                    Werks: sPlant,
                    Assigned: true,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: jQuery.proxy(function (oError) {
                    d.reject(this._oHelper.parseGateWayError(oError));
                  }, this),
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }
        return d.promise();
      },

      unassignDevice: function (sDeviceID, sPlant) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); // this._sLangu;

        if (
          this._oConfigModel !== null &&
          this._oConfigModel.oMetadata.bFailed === false
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.callFunction("/setAssign", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                    AppId: this._sAppID,
                    DeviceId: sDeviceID,
                    Werks: sPlant,
                    Assigned: false,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: jQuery.proxy(function (oError) {
                    d.reject(this._oHelper.parseGateWayError(oError));
                  }, this),
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }
        return d.promise();
      },

      setVersion: function (sDeviceID, sPlant, sAppVersion) {
        let oSharedModel = this.component.getModel("shared");

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); // this._sLangu;

        if (
          this._oConfigModel !== null &&
          this._oConfigModel.oMetadata.bFailed === false
        ) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.callFunction("/setVersion", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                    AppId: this._sAppID,
                    Werks: sPlant,
                    DeviceId: sDeviceID,
                    Version: sAppVersion,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: jQuery.proxy(function (oError) {
                    d.reject(this._oHelper.parseGateWayError(oError));
                  }, this),
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }
        return d.promise();
      },

      testServiceBrowser: function () {
        var client = this.component
          .getModel("shared")
          .getProperty("/sapSettings/sapClient");
        var url = this._getServiceUrl() + "/$metadata?sap-client=" + client;
        window.open(url);
      },

      setZonebadging: function (oWorkEntity) {
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu();
        oWorkEntity = this._oHelper.mapZoneBadging(oWorkEntity);
        oWorkEntity = {
          Workhandle: this._oHelper.getUUID(),
          Deviceid: "VS5",
          NavPMNotification: [],
          NavConfirmation: [],
          NavParticipant: [],
          NavPicture: [],
          NavTimeRegistration: oWorkEntity,
        };
        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.create("/WorkSet", oWorkEntity, {
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(me._oHelper.parseGateWayError(oError));
                  },
                  urlParameters: { "sap-language": sLangu },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },
      imageUpload: function (oPictureEntity) {
        let oSharedModel = this.component.getModel("shared"),
          me = this;
        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); 
        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.create("/PictureSet", oPictureEntity, {
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(me._oHelper.parseGateWayError(oError));
                  },
                  urlParameters: { "sap-language": sLangu },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getImpactOblCustomizingSet: function (plant, sLang) {
        let oSharedModel = this.component.getModel("shared");

        var d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(); //this._sLangu;

        if (sLang) {
          sLangu = sLang;
          oSharedModel.setProperty("/sapSettings/langu", sLang);
        }

        if (this._oModel.oMetadata.bFailed === false) {
          this._checkTokenExpiration(this._oModel)
            .then(
              function () {
                this._oModel.read("/ImpactOblCustomizingSet", {
                  urlParameters: {
                    "sap-client": sSAPClient,
                    "sap-language": sLangu,
                  },
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(oError);
                  },
                  filters: [
                    new Filter({
                      path: "Werks",
                      operator: Operator.EQ,
                      value1: plant,
                    }),
                  ],
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      sendAgreement: function (user) {
        let oSharedModel = this.component.getModel("shared"),
          me = this;
        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu(),
          oEntity = {
            AppId: this._sAppID,
            Username: user,
            Agreement: "X",
          };
        if (!oEntity.Username) {
          d.reject();
        }
        if (!this._oConfigModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.create("/AgreementSet", oEntity, {
                  success: function (oData) {
                    d.resolve(oData);
                  },
                  error: function (oError) {
                    d.reject(me._oHelper.parseGateWayError(oError));
                  },
                });
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },
      getAgreement: function (username) {
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu();
        if (!this._oConfigModel.oMetadata.bFailed) {
          if (!username) {
            d.reject();
          }
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                this._oConfigModel.read(
                  "/AgreementSet(AppId='" +
                    this._sAppID +
                    "',Username='" +
                    username +
                    "')",
                  {
                    urlParameters: {
                      "sap-client": sSAPClient,
                      "sap-language": sLangu,
                    },
                    success: function (oData) {
                      d.resolve(oData);
                    },
                    error: function (oError) {
                      d.reject(me._oHelper.parseGateWayError(oError));
                    },
                  }
                );
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },

      getWCAData: function (order, operation) {
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let d = jQuery.Deferred(),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"), // this._sSAPClient,
          sLangu = this._getLangu();
        if (!this._oModel.oMetadata.bFailed) {
          this._checkTokenExpiration(this._oConfigModel)
            .then(
              function () {
                //WCMSyncSet(Objid='',Vornr='')
                this._oModel.read(
                  "/WCMSyncSet(Objid='" +
                    order +
                    "',Vornr='" +
                    operation +
                    "')",
                  {
                    urlParameters: {
                      "sap-client": sSAPClient,
                      "sap-language": sLangu,
                      $expand:
                        "NavWCMSyncData,NavWCMSyncRisk,NavWCMSyncOpeData,NavWCMSyncOpeRisk",
                    },
                    success: function (oData) {
                      d.resolve(oData);
                    },
                    error: function (oError) {
                      d.reject(me._oHelper.parseGateWayError(oError));
                    },
                  }
                );
              }.bind(this)
            )
            .catch(function (oError) {
              d.reject(oError);
            });
        } else {
          d.reject();
        }

        return d.promise();
      },
      
      getPurOrderItems: function(purchaseord){
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let sUrl = "/sap/opu/odata/ARMP/MW_PO_CDS/",
          sUser = oSharedModel.getProperty("/sapSettings/sapUser"),
          sPass = oSharedModel.getProperty("/sapSettings/sapPass"),
          sSysId = oSharedModel.getProperty("/sapSettings/sapSysId"),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"),
          d = jQuery.Deferred(),
          sUrlToBeUsed;

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = sUrl;
        } else {
          sUrlToBeUsed = oSharedModel.getProperty("/sapSettings/host") + sUrl;
        }
        var oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
          json: true,
          // loadMetadataAsync: true,
          // headers: {
          //   "Authorization": "Bearer " + sPass,//this.make_base_auth(sUser, sPass),
          //   'Content-Type': 'application/json'
          // }
          defaultBindingMode: "TwoWay",
          defaultCountMode: "Inline",
          metadataUrlParams: {},
          loadMetadataAsync: true,
          useBatch: false,
          headers: {
            "sap-client": sSAPClient.toString(),
            Authorization: "Bearer " + sPass, // + this.make_base_auth(this._sUser, this._sPassword),
            TargetSAPSystem: sSysId,
            "Content-Type": "application/json",
            "Cache-Control": "max-age=0",
          },
        });
        oModel.attachRequestFailed(function (oEvent) {
          d.reject();
        });
        let aFilters = [];
        if (!purchaseord) {
        aFilters.push(new sap.ui.model.Filter({
            path: "Plant",
            operator: sap.ui.model.FilterOperator.EQ,
            // value1: 'FRA0'//this.component.getModel('shared').getProperty("/sapSettings/plant")
            // value1:this.component.getModel('shared').getProperty("/sapSettings/plant")
            value1: '1000'
          }));
        aFilters.push(new sap.ui.model.Filter({
            path: "Vendor",
            operator: sap.ui.model.FilterOperator.EQ,
            // value1: this.component.getModel('shared').getProperty("/sapSettings/Vendor") 
            value1: 'SUBCO0002'
            // value1: 'AC054766'
            //this.component.getModel('shared').getProperty("/sapSettings/Vendor") 
          }));
        }else{
          aFilters.push(new sap.ui.model.Filter({
            path: "PoNumber",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: purchaseord //this.component.getModel('shared').getProperty("/sapSettings/Vendor") 
          }));
        }
          let vendor = this.component.getModel('shared').getProperty("/sapSettings/Vendor"),
          plant = this.component.getModel('shared').getProperty("/sapSettings/plant") ;
          // if(!vendor){
          //   d.reject({message:this.component
          //   .getModel("i18n")
          //   .getResourceBundle()
          //   .getText("NoVendorFound")});
          // }
        oModel.attachMetadataLoaded(function (oEvent) {
          let sPath = "/xARMPxMW_PO"
          oModel.read(sPath, {
            urlParameters: {
              $expand: "to_POServices",
             // $top:10,
              // $skip:10,
            },
            success: function(oData, response) {
              // let oEntity = _.find(oModel.getServiceMetadata().dataServices.schema[0].entityType, {
              //   name: "xARMPxMW_POType"
              // });
             // that.getDBService().createTableAndFill(oEntity,oData)
              d.resolve({entity:oModel.getServiceMetadata().dataServices.schema[0].entityType,data:oData.results});
              //console.debug(oData)
            },
            error: function(error) {
              d.reject();
            }
            ,
            filters: aFilters
          });
        }.bind(this));
  
        oModel.attachMetadataFailed(function (oEvent) {
          d.reject();
        }.bind(this));
        return d.promise();
      },
  
      getPlanItemService: function(){
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let sUrl = "/sap/opu/odata/ARMP/MW_PO_CDS/",
          sUser = oSharedModel.getProperty("/sapSettings/sapUser"),
          sPass = oSharedModel.getProperty("/sapSettings/sapPass"),
          sSysId = oSharedModel.getProperty("/sapSettings/sapSysId"),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"),
          sLangu = this._getLangu(),
          d = jQuery.Deferred(),
          sUrlToBeUsed;

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = sUrl;
        } else {
          sUrlToBeUsed = oSharedModel.getProperty("/sapSettings/host") + sUrl;
        }
        var oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
          json: true,
          // loadMetadataAsync: true,
          // headers: {
          //   "Authorization": "Bearer " + sPass,//this.make_base_auth(sUser, sPass),
          //   'Content-Type': 'application/json'
          // }
          defaultBindingMode: "TwoWay",
          defaultCountMode: "Inline",
          metadataUrlParams: {},
          loadMetadataAsync: true,
          useBatch: false,
          headers: {
            "sap-client": sSAPClient.toString(),
            Authorization: "Bearer " + sPass, // + this.make_base_auth(this._sUser, this._sPassword),
            TargetSAPSystem: sSysId,
            "Content-Type": "application/json",
            "Cache-Control": "max-age=0",
          },
        });
        oModel.attachRequestFailed(function (oEvent) {
          d.reject();
        });

        let that = this,
          vendor = this.component
            .getModel("shared")
            .getProperty("/sapSettings/Vendor"),
          plant = this.component
            .getModel("shared")
            .getProperty("/sapSettings/plant");
        if (!vendor) {
          d.reject({
            message: this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("NoVendorFound"),
          });
        }
        oModel.attachMetadataLoaded(
          function (oEvent) {
            let sPath = "/xARMPxMW_PO";
            oModel.read(sPath, {
              urlParameters: {
                $expand: "to_POServices",
                "sap-client": sSAPClient,
                "sap-language": sLangu,
              },

              success: function (oData, response) {
                // let oEntity = _.find(oModel.getServiceMetadata().dataServices.schema[0].entityType, {
                //   name: "xARMPxMW_POType"
                // });
                // that.getDBService().createTableAndFill(oEntity,oData)
                d.resolve({
                  entity:
                    oModel.getServiceMetadata().dataServices.schema[0]
                      .entityType,
                  data: oData.results,
                });
                //console.debug(oData)
              },
              error: function (error) {
                d.reject();
              },
            });
          }.bind(this)
        );

        oModel.attachMetadataFailed(
          function (oEvent) {
            d.reject();
          }.bind(this)
        );
        return d.promise();
      },
      /*END: Date: 01/03/2024 AMID: Sambit 13.1 Bug Number:27*/

      getPlanItemService: function () {
        let oSharedModel = this.component.getModel("shared"),
          me = this;

        let sUrl = "/sap/opu/odata/ARMP/GW_PM_PLAN_SRV/",
          sUser = oSharedModel.getProperty("/sapSettings/sapUser"),
          sPass = oSharedModel.getProperty("/sapSettings/sapPass"),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"),
          d = jQuery.Deferred(),
          sSysId = oSharedModel.getProperty("/sapSettings/sapSysId"),
          sUrlToBeUsed;

        if (this._oHelper.isDevModeActive()) {
          sUrlToBeUsed = sUrl;
        } else {
          sUrlToBeUsed = oSharedModel.getProperty("/sapSettings/host") + sUrl;
        }
        this._oPlanItemService = new sap.ui.model.odata.v2.ODataModel(
          sUrlToBeUsed,
          {
            defaultBindingMode: "TwoWay",
            defaultCountMode: "Inline",
            metadataUrlParams: {},
            loadMetadataAsync: true,
            useBatch: false,
            headers: {
              "sap-client": sSAPClient.toString(),
              Authorization: "Bearer " + sPass, // + this.make_base_auth(this._sUser, this._sPassword),
              TargetSAPSystem: sSysId,
              "Cache-Control": "max-age=0",
              "Content-Type": "application/json",
            },
          }
        );
        this._oPlanItemService.attachRequestFailed(function (oEvent) {
          d.reject();
        });

        let that = this;
        this._oPlanItemService.attachMetadataLoaded(
          function (oEvent) {
            let oEntity = _.find(
              this._oPlanItemService.getServiceMetadata().dataServices.schema[0]
                .entityType,
              {
                name: "PlanItem",
              }
            );
            d.resolve(oEntity);
          }.bind(this)
        );

        this._oPlanItemService.attachMetadataFailed(
          function (oEvent) {
            d.reject();
          }.bind(this)
        );
        return d.promise();
      },

      sendTimeSheets: async function (oTimeSheets, aPartic) {
        let oSharedModel = this.component.getModel("shared"),
          sSAPClient = oSharedModel.getProperty("/sapSettings/sapClient"),
          sLangu = this._getLangu();

        var d = jQuery.Deferred(),
          Source = "mobilework",
          sDeviceId = oSharedModel.getProperty("/sapSettings/deviceName"),
          oWorkEntity = {
            Source: Source,
            NavPlanItem: [],
          },
          _aTimeSheets = this._oHelper.mapTimeSheets(oTimeSheets, aPartic);
        oWorkEntity.NavPlanItem = _aTimeSheets;
        this._checkTokenExpiration(this._oPlanItemService)
          .then(
            function () {
              this._oPlanItemService.create("/MassUploadSet", oWorkEntity, {
                urlParameters: {
                  "sap-client": sSAPClient,
                  "sap-language": sLangu,
                },
                success: function (oResult) {
                  d.resolve(oResult);
                },
                error: jQuery.proxy(function (oError) {
                  d.reject(this._oHelper.parseGateWayError(oError));
                }, this),
              });
            }.bind(this)
          )
          .catch(function (oError) {
            d.reject(oError);
          });

        return d.promise();
      },
    });
  //We don't have getService() if check without logging in. In that case testping is defined outside.
  //But we can call Service.testPing() using this defining in this method
    oService.testPing = function (oSharedModel, oHelper) {
      // window.open(pingUrl);
      let d = jQuery.Deferred();
      // sHost = this._sHost;
      // let oSharedModel = this.component.getModel('shared');
      let sPass = oSharedModel.getProperty("/sapSettings/sapPass");
      let sHost = oSharedModel.getProperty("/sapSettings/host");
      let sSysId = oSharedModel.getProperty("/sapSettings/sapSysId");

      let sPingUrl;

      if (sHost === undefined || oHelper.isDevModeActive())
        sPingUrl = "/sap/public/ping";
      else sPingUrl = sHost + "/sap/public/ping";

      let oTarget;

      if (oSharedModel.getProperty("/publicRelease")) {
        if (sPass === "" || sPass === undefined) {
            d.reject('UNKNOWN_BEARER');
           return d.promise();
          // At this point we don't throw an error >
          // later in the flow the next service call will be checked again for a valid token
        }
        /*BEGIN: Date: 06/03/2024 AMID: A0866990 13.1 MWX Bug Number: 39*/
        oTarget = {
          type: "GET",
          url: sPingUrl,
          beforeSend: function (request) {
          	request.setRequestHeader("Authorization", "Bearer " + sPass);
          	request.setRequestHeader("TargetSAPSystem", sSysId);
          	request.setRequestHeader("Cache-Control", "max-age=0");
          }.bind(this)
        };
      } else {
        oTarget = {
          type: "GET",
          url: sPingUrl,
        };
      }

      // {
      // 	type: "GET",
      // 	url: pingUrl
      // }

      $.ajax(oTarget)
        .done(
          jQuery.proxy(function (oData) {
            d.resolve(oData);
          }, this)
        )
        .fail(
          jQuery.proxy(function (oError) {
            d.reject(oError);
          }, this)
        );

      return d.promise();
    };

    return oService;
  }
);
