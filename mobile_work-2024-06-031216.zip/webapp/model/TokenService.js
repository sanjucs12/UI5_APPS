/*global Connection:true*/
/*global device:true*/
sap.ui.define(
  [
    "sap/ui/base/Object",
    "mobilework/util/Helper",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/library",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/Input",
  ],
  function (
    Object,
    Help,
    Filter,
    Operator,
    MToast,
    Dialog,
    mobileLibrary,
    Button,
    Text,
    Input
  ) {
    "use strict";

    // shortcut for sap.m.ButtonType
    var ButtonType = mobileLibrary.ButtonType;

    // shortcut for sap.m.DialogType
    var DialogType = mobileLibrary.DialogType;

    return Object.extend("mobilework.model.TokenService", {
      // publicRelease: true,

      newValidToken: "",
      validUntill: null,
      valid: null,
      username: null,

      constructor: function (component) {
        this.component = component;

        this.publicRelease = this.component
          .getModel("shared")
          .getProperty("/publicRelease");
        this._oHelper = new Help();
      },

      clearToken: function () {
        this.newValidToken = "";
        this.validUntil = null;
        this.valid = null;
        this.username = null;
        console.log("Clear Token service");
      },

      updateToken: function (sToken, oToken) {
        this.newValidToken = sToken;
        this.validUntil = oToken.exp;
        this.username = oToken.user_name;
        this._checkValidity(oToken);
      },

      _checkValidity: function () {
        if (this.validUntil * 1000 - Date.now() > 5 * 60 * 1000) {
          // Token is still valid for more then 5 minutes
          // This ensure that the following transaction calls should be initiated within those 5 minutes
          this.valid = true;
        } else {
          this.valid = false;
        }
      },

      _newToken: async function (sHost) {
        // Call the other app >> will return a new bearer token

        // !!!!!!!!!!! Intent for result !!!!!!!!!!!!
        // Return FALSE if this fails
        let sNewToken = "123456",
          plant = this.component
            .getModel("shared")
            .getProperty("/sapSettings/plant");
        if (!plant) {
          plant = this.component.getModel("onboarding").getProperty("/plant");
        }

        let sDecision = {};
        if (this._oHelper.isDevModeActive()) {
          sDecision.token = await this.mockAuthenticatorApp();
        } else {
          try {
            // Call Gates plugin
            sDecision = await window.cordova.plugins.GatesPlugin.listen(plant);
          } catch (oError) {
            console.error("Gates plugin failed");
            console.error(oError);
            sDecision = "CANCEL";
          }
        }

        sNewToken = sDecision ? sDecision.token : sDecision;
        // OK OR CANCEL
        if (sDecision === "CANCEL") {
          // No valid token is available at the moment, cancel the operation
          // throw new Error('Action cancelled by user');
          MToast.show(
            this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("AppReturnedInvalidToken")
          );
          //MToast.show("Authenticator App returned invalid token");
          return false;
        } else {
          if (this._oHelper.isDevModeActive()) {
            sDecision.hash = "00010001";
            sDecision.uid = "0001";
            sDecision.scannedOn = "0001000100010001";
            sDecision.amei = "00000015";
          }
        }

        // Perform an online check on the token
        // debugger
        try {
          await this.checkTokenAtLogin(sNewToken, sHost).catch(function (
            oError
          ) {
            throw oError;
          });
          let sValidToken = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("ValidToken");
          delete sDecision.token;
          this.component
            .getModel("shared")
            .setProperty("/loginWAIData", sDecision);
          if (!this.valid) {
            MToast.show(
              this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("InvalidToken")
            );
            return false;
          }
          // MToast.show(sValidToken);

          return true;
        } catch (oError) {
          MToast.show(oError.message);

          return false;
        }
      },

      retrieveNewToken: async function (sHost) {
        // Repeat until correct token is retrieved
        return await this._newToken(sHost);
      },

      _popupDecision: async function (oEvent) {
        //
        return oEvent;
      },

      _onAuthenticationDecision: function (oEvent) {
        //
        // this.oApproveDialog.close();

        // this._popupDecision(oEvent);

        resolve("test");

        //
      },

      mockAuthenticatorApp: async function () {
        return new Promise((resolve) => {
          // Open dialog, asking for login && cancel option

          if (!this.oAuthenticatorMockup) {
            let oConfirmButton = new Button({
              type: ButtonType.Emphasized,
              text: "Use token",
              id: "useToken",
              press: async function (oEvent) {
                // Call Authenticator app for result
                // let bResult = await this._newToken(sHost);

                // if (bResult){
                // Retrieved token is checked online

                // debugger
                let sInput = oEvent
                  .getSource()
                  .getParent()
                  .getAggregation("content")[0]
                  .getProperty("value");
                this.oAuthenticatorMockup.destroy();
                delete this.oAuthenticatorMockup;
                resolve(sInput);
                // }
              }.bind(this),
            });

            let oCancelButton = new Button({
              text: "Cancel",
              id: "cancel",
              press: async function (oEvent) {
                this.oAuthenticatorMockup.destroy();
                delete this.oAuthenticatorMockup;
                resolve("CANCEL");
              }.bind(this),
            });

            let oDemoButton = new Button({
              text: "Load Token",
              id: "loadToken",
              press: async function (oEvent) {
                //HAR
                // let sInput = `eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vZXVyLWZsYXQtYXBpLWRldi0wODFrbmdpYy5hdXRoZW50aWNhdGlvbi5ldTIwLmhhbmEub25kZW1hbmQuY29tL3Rva2VuX2tleXMiLCJraWQiOiJkZWZhdWx0LWp3dC1rZXktMTEwMzA3Mzg2NCIsInR5cCI6IkpXVCIsImppZCI6ICJYVHZIWkxqak9PSGx1dDJDWlBVVysxc1hNUzBIN1pZNzdLWlhVWjRBazZJPSJ9.eyJqdGkiOiI0MTA3NzBkMjFiYTU0MzVmODdkNWRjODExNTUwODNkNyIsImV4dF9hdHRyIjp7ImVuaGFuY2VyIjoiWFNVQUEiLCJzdWJhY2NvdW50aWQiOiJkNDk3MWFjZC0wNDc3LTQ2ZDMtOTQ4Yy01YjBjYWQxYTA4ZDAiLCJ6ZG4iOiJldXItZmxhdC1hcGktZGV2LTA4MWtuZ2ljIn0sInhzLnN5c3RlbS5hdHRyaWJ1dGVzIjp7InhzLnJvbGVjb2xsZWN0aW9ucyI6WyJBUk1QIFVzZXIiXX0sImdpdmVuX25hbWUiOiI1MTg3IiwieHMudXNlci5hdHRyaWJ1dGVzIjp7fSwiZmFtaWx5X25hbWUiOiJ0aGlzLWRlZmF1bHQtd2FzLW5vdC1jb25maWd1cmVkLmludmFsaWQiLCJzdWIiOiI4MTkyNWRiMC0yZWZlLTQ1ZmQtYTM4Yy01NDI1MjkwMTVlNmUiLCJzY29wZSI6WyJhcm1wLWFwaS1kZXYhdDE0MjYwLlVzZXIiLCJvcGVuaWQiXSwiY2xpZW50X2lkIjoic2ItYXJtcC1hcGktZGV2IXQxNDI2MCIsImNpZCI6InNiLWFybXAtYXBpLWRldiF0MTQyNjAiLCJhenAiOiJzYi1hcm1wLWFwaS1kZXYhdDE0MjYwIiwiZ3JhbnRfdHlwZSI6InVybjppZXRmOnBhcmFtczpvYXV0aDpncmFudC10eXBlOnNhbWwyLWJlYXJlciIsInVzZXJfaWQiOiI4MTkyNWRiMC0yZWZlLTQ1ZmQtYTM4Yy01NDI1MjkwMTVlNmUiLCJvcmlnaW4iOiJ1cm5nYXRlc2lkcCIsInVzZXJfbmFtZSI6IjUxODciLCJlbWFpbCI6IjUxODdAdGhpcy1kZWZhdWx0LXdhcy1ub3QtY29uZmlndXJlZC5pbnZhbGlkIiwicmV2X3NpZyI6IjQ5N2IwYWYwIiwiaWF0IjoxNzA4NDIzNTkwLCJleHAiOjE3MDg0NjY3OTAsImlzcyI6Imh0dHBzOi8vZXVyLWZsYXQtYXBpLWRldi0wODFrbmdpYy5hdXRoZW50aWNhdGlvbi5ldTIwLmhhbmEub25kZW1hbmQuY29tL29hdXRoL3Rva2VuIiwiemlkIjoiZDQ5NzFhY2QtMDQ3Ny00NmQzLTk0OGMtNWIwY2FkMWEwOGQwIiwiYXVkIjpbImFybXAtYXBpLWRldiF0MTQyNjAiLCJvcGVuaWQiLCJzYi1hcm1wLWFwaS1kZXYhdDE0MjYwIl19.F0p2XzyI5T5nngSi8fqMDiKlkf5LefEyQDsgw6ngDJygC9M8fvBIs-FeXh8ZioA2DkhNkH1q-xUmF0LinKAB-5gLlbC7BgmeYpoWAeDvnmv_2dSGcGODxz8iksvwQbdAkbVW4MilNCot2qfExLDPtITnz1UWO9b0anMM2S3ZVV6lQMu8hVR23oHg9BY3437vxVdDmnPH_1DCtvbnW7Iv2jbh1YexmOLPf1wqzVRasXgFS0pur9GBHukN9haXtw6BAP1GEWlsbhLJUSZKR_jND-dsI7IrNWxlkzjk0fzfk0iFT43IRrCzFARAWJiXWtK2CLroNHAT4czvAqEYEgxfIA`;
                //ACE
                let sInput = `eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vZXVyLWZsYXQtYXBpLWRldi0wODFrbmdpYy5hdXRoZW50aWNhdGlvbi5ldTIwLmhhbmEub25kZW1hbmQuY29tL3Rva2VuX2tleXMiLCJraWQiOiJkZWZhdWx0LWp3dC1rZXktMTEwMzA3Mzg2NCIsInR5cCI6IkpXVCIsImppZCI6ICJGWUFKM2ZpSmxPdkRWSzFQL2w2MDJjWkdoL28wem4yR2NnbDV4ZXZMb3ZBPSJ9.eyJqdGkiOiIxNzU0OWU5ZjkzM2Y0Nzc0ODc0N2JmYmQ4NWIzMjUzMCIsImV4dF9hdHRyIjp7ImVuaGFuY2VyIjoiWFNVQUEiLCJzdWJhY2NvdW50aWQiOiJkNDk3MWFjZC0wNDc3LTQ2ZDMtOTQ4Yy01YjBjYWQxYTA4ZDAiLCJ6ZG4iOiJldXItZmxhdC1hcGktZGV2LTA4MWtuZ2ljIn0sInhzLnN5c3RlbS5hdHRyaWJ1dGVzIjp7InhzLnJvbGVjb2xsZWN0aW9ucyI6WyJBUk1QIFVzZXIiXX0sImdpdmVuX25hbWUiOiI1MTg3IiwieHMudXNlci5hdHRyaWJ1dGVzIjp7fSwiZmFtaWx5X25hbWUiOiJ0aGlzLWRlZmF1bHQtd2FzLW5vdC1jb25maWd1cmVkLmludmFsaWQiLCJzdWIiOiJiNTBhMTA0Yy0zNDgxLTQ3MDItOTMzZS0xYzIyNGRiZmZlZDMiLCJzY29wZSI6WyJhcm1wLWFwaS1kZXYhdDE0MjYwLlVzZXIiLCJvcGVuaWQiXSwiY2xpZW50X2lkIjoic2ItYXJtcC1hcGktZGV2IXQxNDI2MCIsImNpZCI6InNiLWFybXAtYXBpLWRldiF0MTQyNjAiLCJhenAiOiJzYi1hcm1wLWFwaS1kZXYhdDE0MjYwIiwiZ3JhbnRfdHlwZSI6InVybjppZXRmOnBhcmFtczpvYXV0aDpncmFudC10eXBlOnNhbWwyLWJlYXJlciIsInVzZXJfaWQiOiJiNTBhMTA0Yy0zNDgxLTQ3MDItOTMzZS0xYzIyNGRiZmZlZDMiLCJvcmlnaW4iOiJnYXRlcy1kZXYtaWRwLWFwaS0yMDI1IiwidXNlcl9uYW1lIjoiNTE4NyIsImVtYWlsIjoiNTE4N0B0aGlzLWRlZmF1bHQtd2FzLW5vdC1jb25maWd1cmVkLmludmFsaWQiLCJyZXZfc2lnIjoiMWVlMGY4OGMiLCJpYXQiOjE3MTU0MDg2OTEsImV4cCI6MTcxNTQ1MTg5MSwiaXNzIjoiaHR0cHM6Ly9ldXItZmxhdC1hcGktZGV2LTA4MWtuZ2ljLmF1dGhlbnRpY2F0aW9uLmV1MjAuaGFuYS5vbmRlbWFuZC5jb20vb2F1dGgvdG9rZW4iLCJ6aWQiOiJkNDk3MWFjZC0wNDc3LTQ2ZDMtOTQ4Yy01YjBjYWQxYTA4ZDAiLCJhdWQiOlsiYXJtcC1hcGktZGV2IXQxNDI2MCIsIm9wZW5pZCIsInNiLWFybXAtYXBpLWRldiF0MTQyNjAiXX0.Go3P22-4cRu3DYCOZ9pF7DQ9TVVGWlGefCbQoveo_iJ3kPBC5Hz0rhjjfKWbtcXIbd_mkeO-cTKOTMh06u5FAw-A81snLk_ATgcZ2EWwlxw113XJyyrUx0N8mLgn-DSeho8CNLDYmnl9EqAtW0bpauN1uDe1_plqQzYFYA_G-tX6yjf42E8QJHbLOPuvwWVDEkVbak4gPEfsrTADM0P9dlowbMSIoQmsrnHjEyf5AtTlztmqfVvqwQjSmczkwq90aVCMNw_odneBts1nrrh0btqnH89NvZEUBGyFGOIkaaQX_HOxsaJvnuLLRtFq5tzDaZsoWrz8WCpZvoVW4-cfEw`;
                this.oAuthenticatorMockup.destroy();
                delete this.oAuthenticatorMockup;
                resolve(sInput);
              }.bind(this),
            });

            this.oAuthenticatorMockup = new Dialog({
              type: DialogType.Message,
              title: "Authenticator App Mockup",
              content: new Input({ placeholder: "Please enter the token" }),
              buttons: [oConfirmButton, oDemoButton, oCancelButton],
              // beginButton: oConfirmButton,
              // endButton: oCancelButton
            });
          }

          this.oAuthenticatorMockup.open();
        });
      },

      renewTokenPopup: async function (sHost) {
        return new Promise((resolve) => {
          // Open dialog, asking for login && cancel option

          if (!this.oApproveDialog) {
            let oConfirmButton = new Button({
              type: ButtonType.Emphasized,
              text: this.getModel("i18n").getResourceBundle().getText("Authenticate"),
              id: "authenticateConfirm",
              press: async function (oEvent) {
                // Call Authenticator app for result
                //
                // debugger;
                this.oApproveDialog.setBusy(true);
                let bResult = await this._newToken(sHost);

                if (bResult) {
                  // Retrieved token is checked online
                  this.oApproveDialog.destroy();
                  delete this.oApproveDialog;
                  resolve("OK");
                } else {
                  this.oApproveDialog.setBusy(false);
                }
              }.bind(this),
            });

            let oCancelButton = new Button({
              text: "Cancel",
              id: "authenticateCancel",
              press: async function (oEvent) {
                this.oApproveDialog.destroy();
                delete this.oApproveDialog;
                resolve("CANCEL");
              }.bind(this),
            });

            this.oApproveDialog = new Dialog({
              type: DialogType.Message,
              title: this.getModel("i18n").getResourceBundle().getText("Confirm"),
              content: new Text({
                text: this.getModel("i18n").getResourceBundle().getText("tokenExpired"),
              }),
              beginButton: oConfirmButton,
              endButton: oCancelButton,
            });
          }

          this.oApproveDialog.open();
        });

        // return await _popupDecision;
        // throw new Error('User cancelled action');
      },

      // Called from a model >> always called from service.js to pass the sHost
      checkTokenExpiration: async function (oModel, sHost) {
        console.log("checkTokenValidity");
        //

        // Check if token in memory is still valid
        this._checkValidity();

        // If current token is not valid we will initiate the login procedure to retrieve a token
        if (!this.valid) {
          // Retrieve a new token
          // Give user possibility to either retrieve a new token or to cancel the action

          // debugger // TOKEN POPUP >> CHECK WHY !!!!!!!
          let sDecision = await this.renewTokenPopup(sHost);

          // OK OR CANCEL
          if (sDecision === "CANCEL") {
            // No valid token is available at the moment, cancel the operation
            throw new Error("Action cancelled by user");
          } else if (sDecision === "OK") {
            // Set logon data
            // debugger;
            this.component
              .getModel("shared")
              .setProperty("/sapSettings/sapUser", this.username);
            this.component
              .getModel("shared")
              .setProperty("/sapSettings/sapPass", this.newValidToken);
            let sText = this.component
              .getModel("i18n")
              .getResourceBundle()
              .getText("LoggedInAs", [this.username]);
            this.component
              .getModel("shared")
              .setProperty("/loggedInAsMsg", sText);
            this.component
              .getModel("shared")
              .setProperty("/bUserIconVisible", true);
          } else {
            console.error("unexpected case > error");
          }
          //

          // _handleToken()
        }

        // Get current Model token
        let sModelToken = null;
        if (
          oModel.getHeaders().Authorization !== undefined &&
          oModel.getHeaders().Authorization.split("Bearer ").length === 2
        ) {
          sModelToken = oModel.getHeaders().Authorization.split("Bearer ")[1];
        }
        //
        if (sModelToken === undefined) {
          console.error("Unexpected : Model has no token");
          this._updateModelToken(oModel);
        } else if (sModelToken === this.newValidToken) {
          console.debug("Valid bearer token");
        } else {
          console.debug("updating the model bearer token");
          this._updateModelToken(oModel);
        }
        return true;
      },

      _updateModelToken: function (oModel) {
        let oHeaders = oModel.getHeaders();
        oHeaders.Authorization = "Bearer " + this.newValidToken;
        oModel.setHeaders(oHeaders);
      },

      // Called from the main controller popup
      checkTokenAtLogin: async function (sToken, sHost) {
        let oToken = this._handleToken(sToken);
        let sUserName = oToken.user_name;
        let sSysId = this.component
          .getModel("shared")
          .getProperty("/sapSettings/sapSysId");

        let sTokenCheckURL = sHost + "/sap/opu/odata/ARMP/MW_SRV/$metadata";

        let oTarget = {
          type: "GET",
          url: sTokenCheckURL,
          beforeSend: function (request) {
            request.setRequestHeader("Authorization", "Bearer " + sToken);
            request.setRequestHeader("TargetSAPSystem", sSysId);
            request.setRequestHeader("Cache-Control", "max-age=0");
          }.bind(this),
        };

        let oResponse;

        oResponse = await $.ajax(oTarget).catch(
          function (oError) {
            console.error(oError);
            if (oError.status === 401) {
              //
              let sInvalidToken = this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("InvalidToken");
              return new Error(sInvalidToken);
            } else if (
              oError.responseText !== undefined &&
              oError.status === 404
            ) {
              let sMessage = "Not able to reach authentication server";
              return new Error(sMessage); // oError.responseText
            } else {
              //
              let sTokenValidationFailed = this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("TokenValidationFailed");
              return new Error(sTokenValidationFailed);
            }
          }.bind(this)
        );

        console.log(oResponse);

        //
        this.updateToken(sToken, oToken);
        console.log("SET new valid token");

        return sUserName;
      },

      _handleToken: function (sToken) {
        let base64Url = sToken.split(".")[1];
        if (base64Url === undefined) {
          let sInvalidToken = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("InvalidToken");
          throw new Error(sInvalidToken);
        }
        let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        if (base64 === undefined) {
          let sInvalidToken = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("InvalidToken");
          throw new Error(sInvalidToken);
        }

        let jsonPayload;
        try {
          jsonPayload = decodeURIComponent(
            window
              .atob(base64)
              .split("")
              .map(function (c) {
                return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
              })
              .join("")
          );
        } catch (oError) {
          console.error(oError);
          let sInvalidToken = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("InvalidToken");
          throw new Error(sInvalidToken);
        }

        let oToken = JSON.parse(jsonPayload);

        if (oToken.user_name !== undefined) {
          return oToken;
        } else {
          let sInvalidToken = this.component
            .getModel("i18n")
            .getResourceBundle()
            .getText("InvalidToken");
          throw new Error(sInvalidToken);
        }
      },

      addParticipants: async function (dev) {
        let devMode = this._oHelper.isDevModeActive() || dev;
        let participants,
          token = this.component
            .getModel("shared")
            .getProperty("/sapSettings/sapPass"),
          plant = this.component
            .getModel("shared")
            .getProperty("/sapSettings/plant");

        if (devMode) {
          try {
            participants = await this.onDynamicAdd([]);
          } catch (oError) {
            console.error("Gates plugin failed");
            console.error(oError);
            participants = "CANCEL";
          }
          participants = participants[1];
          //'[{\"badgeNumber\":\"6329\",\"hash\":\"wefefwwef0ewewf7cwefwewef2\",\"amei\":"00000005",\"scannedOn\":\"2023-02-21T14:21:27.815603\"},{\"badgeNumber\":\"9405\",\"hash\":\"a0wegwge9gwregeg9weg14wefwegwe\",\"amei\":"000015",\"scannedOn\":\"2023-02-21T14:21:33.298144\"}]';
        } else {
          try {
            participants =
              await window.cordova.plugins.GatesPlugin.addParticipants(
                token,
                plant
              );
          } catch (oError) {
            console.error("Gates plugin failed");
            console.error(oError);
            participants = "CANCEL";
          }
        }
        return participants;
      },

      onZoneBadge: async function (type, ZoneBadgingType, noNetwork, dev) {
        let devMode = this._oHelper.isDevModeActive() || dev;
        let zoneData,
          config = [],
          mode,
          token = this.component
            .getModel("shared")
            .getProperty("/sapSettings/sapPass");
        if (type) {
          config.push("ZoneBadgeIn");
        } else {
          config.push("ZoneBadgeOut");
        }
        if (!noNetwork) {
          mode = "Connected";
        } else {
          mode = "Disconnected";
        }
        config.push(
          this.component.getModel("shared").getProperty("/sapSettings/plant")
        );
        config.push(token);
        config.push(mode);
        config.push(ZoneBadgingType);
        config.push('STL');
        config.push('STLDESC');

        if (devMode) {
          // zoneData=this.createDataZone(config);
          try {
            zoneData = await this.onDynamicAdd(config);
          } catch (oError) {
            console.error("Gates plugin failed");
            console.error(oError);
            zoneData = "CANCEL";
          }
          return zoneData;
          //[ '{\"zoneTagCode\":\"Tag Krakow\",\"zoneTagId\":8,\"zoneName\":\"Walcownia zimna - wyroby plaskie\",\"zoneCode\":\"4ACC0Z01\"}', '[{\"badgeNumber\":\"6329\",\"hash\":\"dvfbwewee875222d946c5842\",\"amei\":"00000005",\"scannedOn\":\"2023-02-21T14:21:27.815603\"},{\"badgeNumber\":\"9405\",\"hash\":\"aweffwewef099145agwe5fcc7285\",\"amei\":"00015",\"scannedOn\":\"2023-02-21T14:21:33.298144\"}]'];
        } else {
          try {
            zoneData = await window.cordova.plugins.GatesPlugin.onZoneBadge(
              config
            );
          } catch (oError) {
            console.error("Gates plugin failed");
            console.error(oError);
            zoneData = "CANCEL";
          }
          return zoneData;
        }
      },

      onDynamicAdd: async function (config) {
        let that = this,
          zoneData;
        return new Promise(function (resolve, reject) {
          if (!that.oDefaultDialog) {
            that.oDefaultDialog = new sap.m.Dialog({
              title: "Add people",
              content: new Input({
                placeholder: "Please enter Person1,Person2;Zone",
              }),
              beginButton: new Button({
                type: ButtonType.Emphasized,
                text: "OK",
                press: async function (oEvent) {
                  let value = oEvent
                    .getSource()
                    .getParent()
                    .getContent()[0]
                    .getValue();
                  value = value.split(";");
                  let zone = value[1],
                    participants = value[0].split(",");
                  zoneData = that.createDataZone(config, participants, zone);
                  that.oDefaultDialog.close();
                  that.oDefaultDialog.destroy();
                  delete that.oDefaultDialog;
                  resolve(zoneData);
                }.bind(that),
              }),
              endButton: new Button({
                text: "Close",
                press: function () {
                  that.oDefaultDialog.close();
                  that.oDefaultDialog.destroy();
                  delete that.oDefaultDialog;
                  reject();
                }.bind(that),
              }),
            });

            // to get access to the controller's model
            // that.getView().addDependent(that.oDefaultDialog);
          }

          that.oDefaultDialog.open();
        });
      },

      createDataZone: function (config, participants, zone) {
        var data = [],
          //name=['CMT','COK','STL','4ACC0Z01'];
          name = ["ALL", "ALL", "ALL", "STL", "STL", "STL"];
        //name=['4ACC0Z01','STL','4ACC0Z01','STL','4ACC0Z01','STL'];
        if (config[4] === "ScanZoneTagAndParticipants") {
          let x = zone || Math.floor(Math.random() * 5);

          data[0] = JSON.stringify({
            zoneTagId: x,
            zoneName: "Zone" + x,
            zoneTagCode: "ZoneTag" + x,
            zoneCode: zone ? zone : name[x],
          });
          data[1] = JSON.stringify(this.createdatPart(participants));
        } else if (config[4] === "ScanZoneTag") {
          let x = zone || Math.floor(Math.random() * 5);

          data[0] = JSON.stringify({
            zoneTagId: x,
            zoneName: "Zone" + x,
            zoneTagCode: "ZoneTag" + x,
            zoneCode: zone ? zone : name[x],
          });
          data[1] = JSON.stringify(null);
        } else {
          data[0] = JSON.stringify(null);
          data[1] = JSON.stringify(this.createdatPart(participants));
        }
        return data;
      },

      createdatPart: function (participants) {
        let data = [],
          //amei=['000015','000009','000005','000014','000021','000013','000016'];
          amei = participants || ["000015", "000005"];
        for (var i = 0; i < amei.length; i++) {
          let now = new Date();
          now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
          let istISOString = now.toISOString();
          let part = {
            scannedOn: istISOString,
            uid: "Badge NO." + amei[i],
            hash: "Hash No." + amei[i],
            amei: amei[i],
          };
          data.push(part);
        }
        // let x=Math.floor(Math.random() * 5) + 1;
        // for(var i =0; i<amei.length;i++){
        // 	let now= new Date();
        //     now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
        //     let istISOString = now.toISOString();
        // 	let part={
        // 		"scannedOn": istISOString,
        // 		"uid": "Badge NO." + amei[x+i],
        // 		"hash": "Hash No." + amei[x+i],
        // 		"amei": amei[x+i]
        // 	}
        // 	data.push(part);
        // }
        return data;
      },

      // checkToken: async function (sToken, sHost) {

      //     let sTokenCheckURL = sHost + "/sap/opu/odata/ARMP/AUD_OD_AUDIT_SRV_SRV/$metadata";

      //     let oTarget = {
      //         type: "GET",
      //         url: sTokenCheckURL,
      //         beforeSend: function (request) {
      //             request.setRequestHeader("Authorization", "Bearer " + sToken);
      //             request.setRequestHeader("Cache-Control", "max-age=0");
      //         }.bind(this)
      //     }

      //     let oResponse;

      //     oResponse = await $.ajax(oTarget).catch(function (oError) {
      //         //
      //         console.log(oError);
      //         if (oError.status === 401) {
      //             let sInvalidToken = this.getModel('i18n').getResourceBundle().getText('InvalidToken');
      //             return new Error(sInvalidToken);
      //         }
      //         else {
      //             let sTokenValidationFailed = this.getModel('i18n').getResourceBundle().getText('TokenValidationFailed');
      //             return new Error(sTokenValidationFailed);
      //         }
      //     }.bind(this));

      //     console.log(oResponse);
      //     this.newValidToken = sToken;
      //     console.log('SET new valid token');
      //     //
      //     return oResponse;

      // },

      // test : function async(oModel) {

      //     let currentToken = oModel.getHeaders().Authorization;

      //     // publicRelease >> 401 >> Popup screen to authenticate again
      //     if (oEvent.getParameter('response') !== undefined && oEvent.getParameter('response').statusCode === 401) {
      //         // open login fragment ??
      //         //
      //         // let sURL = this.getRouter()._oMatchedRoute.getURL();
      //         // this._oRouter.navTo('login',{statusCode : 401 , source: sURL });

      //         let oHeaders = oEvent.getSource().getHeaders();

      //         // First check if a newer token is already available in the service
      //         if (this.newValidToken !== "" &&
      //             this.newValidToken !== oHeaders.Authorization.split('Bearer ')[1]) {
      //             // Set the new token
      //             oHeaders.Authorization = 'Bearer ' + this.newValidToken;
      //             oEvent.getSource().setHeaders(oHeaders);
      //             // Inform user to repeat the action
      //             MToast.show(this.getModel('i18n').getResourceBundle().getText('RepeatAction'));
      //             return;
      //         }

      //         // Solution >> call authenticator app >> retrieve the token
      //         let sNewToken = "123";

      //         try {
      //             // Check the token returned by the authenticator app
      //             await this.checkToken(sNewToken).catch(function (oError) {
      //                 throw oError;
      //             });

      //             MToast.show(this.getText("ValidToken"));

      //             // Set the token
      //             this.newValidToken = sNewToken;

      //             // Set the new token
      //             oHeaders.Authorization = 'Bearer ' + this.newValidToken;
      //             oEvent.getSource().setHeaders(oHeaders);
      //             // Inform user to repeat the action
      //             MToast.show(this.getModel('i18n').getResourceBundle().getText('RepeatAction'));
      //             //
      //         } catch (oError) {
      //             MToast.show(oError.message);
      //             // Call the authenticator app again
      //             return;
      //         }

      //     }

      // }
    });
  }
);
