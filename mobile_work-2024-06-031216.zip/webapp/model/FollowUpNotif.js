sap.ui.define([], function () {
  "use strict";

  var entityType = {};
  entityType.name = "FollowUpNotif";
  entityType.property = [];
  entityType.property.push({
    name: "Handle",
    type: "type.String",
  });
  entityType.property.push({
    name: "FollowUp",
    type: "type.String",
  });
  entityType.property.push({
    name: "DisabledForNotifFromOrder",
    type: "type.String",
  });
  entityType.property.push({
    name: "FinalArbplFrom",
    type: "type.String",
  });
  entityType.property.push({
    name: "FinalIngrpFrom",
    type: "type.String",
  });
  entityType.key = { propertyRef: [] };
  entityType.key.propertyRef.push({
    name: "Handle",
  });
  return entityType;
});
