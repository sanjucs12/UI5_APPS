sap.ui.define([], function () {
	"use strict";

	var entityType = {};
	entityType.name = "GdlLink";
	entityType.property = [];
	entityType.property.push({
		name: "sObjId",
		type: "type.String"
	});
	entityType.property.push({
		name: "sObjType",
		type: "type.String"
	});
	entityType.property.push({
		name: "HasLinksFlags",
		type: "type.String"
	});
	entityType.key={"propertyRef":[]};
	entityType.key.propertyRef.push({
		name: "sObjId"
	});
	return entityType;
});
