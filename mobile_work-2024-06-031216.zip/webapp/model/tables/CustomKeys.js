sap.ui.define([], function () {
	"use strict";

	var Keys = [];
	
    Keys.push({
            name : "WCAData",
	        key:{
                "propertyRef":[{ name: "Objid" } , { name: "Wcewapinr" } ]
            }
        });
    Keys.push( {
            name : "WCAOpeData",
	        key:{
                "propertyRef":[{ name: "Objid" } , { name: "Wcewapinr" },{ name: "Vornr" } ]
            }
        });
    Keys.push( {
            name : "WCARisks",
	        key:{
                "propertyRef":[{ name: "Objid" } , { name: "Codegrp" },{ name: "Code" },{ name: "ActionText" } ]
            }
        });
    Keys.push( {
            name : "WCAOpeRisks",
	        key:{
                "propertyRef":[{ name: "Objid" } , { name: "Codegrp" },{ name: "Code" },{ name: "ActionText" },{ name: "Vornr" }  ]
            }
        });
	
	return Keys;
});
