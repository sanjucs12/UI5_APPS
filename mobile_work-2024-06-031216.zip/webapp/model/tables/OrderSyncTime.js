sap.ui.define([], function () {
	"use strict";

	var entityType = {};
	entityType.name = "OrderSyncTime";
	entityType.property = [];
	entityType.property.push({
		name: "Orderid",
		type: "type.String"
	});
	entityType.property.push({
		name: "Operation",
		type: "type.String"
	});
	entityType.property.push({
		name: "Date",
		type: "type.String"
	});
	entityType.key={"propertyRef":[]};
	entityType.key.propertyRef.push({
		name: "Orderid"
	});
	entityType.key.propertyRef.push({
		name: "Operation"
	});
	return entityType;
});
