sap.ui.define([], function () {
	"use strict";

	var entityType = {};
	entityType.name = "TimeSheet";
	entityType.property = [];
	entityType.property.push({
		name: "Split",
		type: "type.String"
	});
	entityType.property.push({
		name: "PoNumber",
		type: "type.String"
	});
	entityType.property.push({
		name: "PoItem",
		type: "type.String"
	});
	entityType.property.push({
		name: "ServiceNum",
		type: "type.String"
	});
	
	entityType.property.push({
		name: "PlId",
		type: "type.String"
	});
	entityType.property.push({
		name: "Parent",
		type: "type.String"
	});
	entityType.key={"propertyRef":[]};
	entityType.key.propertyRef.push({
		name: "PlId"
	});
	
	
	return entityType;
});
