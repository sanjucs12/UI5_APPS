sap.ui.define([], function () {
	"use strict";

	var entityType = {};
	entityType.name = "TimeInOut";
	entityType.property = [];
	entityType.property.push({
		name: "TimeStamp",
		type: "type.String"
	});
	entityType.property.push({
		name: "Pernr",
		type: "type.String"
	});
	entityType.property.push({
		name: "TrZone",
		type: "type.String"
	});
	entityType.property.push({
		name: "TimeIn",
		type: "type.String"
	});
	entityType.property.push({
		name: "TimeOut",
		type: "type.String"
	});
	entityType.key={"propertyRef":[]};
	entityType.key.propertyRef.push({
		name: "Pernr"
	});
	entityType.key.propertyRef.push({
		name: "TimeStamp"
	});
	return entityType;
});
