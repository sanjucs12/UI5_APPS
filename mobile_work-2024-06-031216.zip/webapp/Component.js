/*global device:true*/

// import {compactDecrypt} from 'mobilework/resources/browser/index.js';

sap.ui.define(
  [
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "sap/m/MessageBox",
    "mobilework/model/models",
    "mobilework/util/ScannerHandler",
    "mobilework/util/Helper",
    // "mobilework/model/DatabaseService",
    "mobilework/model/LocalForageService",
    "mobilework/model/service",
    "mobilework/util/Validator",
    "mobilework/util/GdlDoc",
    "mobilework/util/dialogManager",
    "mobilework/util/KeyListener",
    "sap/base/Log",
    "mobilework/util/Logs",
    "sap/m/MessageToast",
    "mobilework/model/TokenService",
    "sap/m/Dialog",
    "sap/m/library",
    "sap/ui/core/library",
    "sap/m/Button",
    "sap/m/Text",
    "mobilework/model/tables/CustomKeys",
    "mobilework/model/LoginMethod",
    // "mobilework/resources/browser/index"
    // "mobilework/runConfiguration"
    "mobilework/controller/BaseController",
  ],
  function (
    UIComponent,
    Device,
    MBox,
    models,
    ScanHandler,
    Help,
    DBSerivce,
    Service,
    Valid,
    GdlApi,
    DialogManager,
    KeyListener,
    Baselog,
    Logger,
    MToast,
    TokenService,
    Dialog,
    mobileLibrary,
    coreLibrary,
    Button,
    Text,
    CustomKeys,
    LoginMethod,
    BaseController
  ) {
    "use strict";
    /**
     * Base controller for all other controllers.
     *
     * @namespace mobilework.Component
     * @param {sap.ui.core.UIComponent} UIComponent - Sap Core Component
     * @param {mobilework.util.ScannerHandler} ScannerHandler - ScannerHandler
     * @param {sap.m.MessageBox} MBox - Sap Message Box Control
     * @param {sap.m.MToast} MToast - Sap Message toast Control
     * @returns {mobilework.Component} The instance of the Component  class.
     */

    // shortcut for sap.m.ButtonType
    var ButtonType = mobileLibrary.ButtonType;

    // shortcut for sap.m.DialogType
    var DialogType = mobileLibrary.DialogType;

    // shortcut for sap.ui.core.ValueState
    var ValueState = coreLibrary.ValueState;

    return UIComponent.extend("mobilework.Component", {
      tokenService: null,

      dbService: null,

      scanHandler: null,

      helper: null,

      service: null,

      validator: null,

      gdlApi: null,

      dialogManager: null,

      keyListener: null,

      isOffline: false,

      logs: {},

      port: 8080,

      loginMethod: null,

      metadata: {
        manifest: "json",
        includes: ["css/style.css"],
      },

      // isNotBusyBoxRooted: function () {
      //   console.debug("Device is not Busy Box rooted");
      //   // alert("device is not busy box rooted");
      //   this.startProcedure();
      // },
      isNotBusyBoxRooted: function () {
        console.debug("Device is not Busy Box rooted");
        // alert("device is not busy box rooted");
        let Publicversion = this.getModel("runConfiguration").getProperty("/publicRelease")
        if(Publicversion){
        var that = this;
        let appId = BuildInfo.packageName;
        let packageName = ""
        switch (appId) {
          case 'com.arcelormittal.sap.mobilework.ACE.dev':
            packageName = 'com.arcelormittal.europe.flat.whoamidev';
            break;
          case 'com.arcelormittal.sap.mobilework.ACE.uat':
            packageName = 'com.arcelormittal.europe.flat.whoamiuat';
            break;
          case 'com.arcelormittal.sap.mobilework.ACE':
            packageName = 'com.arcelormittal.europe.flat.whoami';
            break;
        }
        appAvailability.check(packageName, function () {
          console.debug("installed")
          that.startProcedure();
        }, function () {
          console.error("uat not installed")
          if (appId === 'com.arcelormittal.sap.mobilework.ACE.dev') {
            //sap.m.MessageBox.error(that.getModel("i18n").getResourceBundle().getText("WAIdevversion"))
            sap.m.MessageBox.error("Please install WAI dev Version")
          } else if (appId === 'com.arcelormittal.sap.mobilework.ACE.uat') {
            //sap.m.MessageBox.error(that.getModel("i18n").getResourceBundle().getText("WAIuatversion"))
            sap.m.MessageBox.error("Please install WAI UAT Version")
          } else {

            let url = 'https://play.google.com/store/apps/details?id=' + packageName;
            let target = '_system';
            window.open(url, target);
            //document.addEventListener("resume", jQuery.proxy(this.onAppResume, this),  false);
            document.addEventListener("resume", function () {
              appAvailability.check(packageName, function () {
                console.info("installed")
                that.startProcedure();
              }, function () {
                console.error("wai prod not installed")
                //sap.m.MessageBox.error(that.getModel("i18n").getResourceBundle().getText("WAInotinstalled"))
                sap.m.MessageBox.error(" WAI app is not installed")
              });
            });

          }

        });
      }else{
        console.log("public version false")
         this.startProcedure();
      }
      },
      isBusyBoxRooted: function (oContext, bIsRooted) {
        console.error("Busy box rooted");
        console.error(oContext);
        console.error(this);
        console.error(bIsRooted);

        if (bIsRooted) {
          this.isBusyBoxRootedException(this, "Device is busy box rooted");
        } else {
          this.isNotBusyBoxRooted();
        }
      },
      /**
       * isBusyBoxRootedException
       * @public
       * @memberof mobilework.Component
       */
      isBusyBoxRootedException: function (oContext, sError) {
        console.error(sError);
        console.error(oContext);

        // alert("device is busy box rooted")
        console.error("Device is rooted with Busy Box");
        console.error("STOP APP");

        if (this.oDialogBBRootFail === undefined) {
          this.oDialogBBRootFail = new Dialog({
            type: DialogType.Message,
            title: "Error",
            state: ValueState.Error,
            content: new Text({
              text: this.getModel("i18n")
                .getResourceBundle()
                .getText("DeviceRootedBB"),
            }),
            beginButton: new Button({
              type: ButtonType.Emphasized,
              text: "OK",
              press: function () {
                this.oDialogBBRootFail.close();
                navigator.app.exitApp();
              }.bind(this),
            }),
          });
        }

        this.oDialogBBRootFail.open();
      },

      isRooted: function (oContext, bIsRooted) {
        console.error("isRooted");
        console.error(oContext);
        console.error(this);
        console.error(bIsRooted);
        if (bIsRooted) {
          this.isRootedException("Rooted device", this);
        } else {
          this.isNotRooted();
        }
      },

      isRootedException: function (sError, oContext) {
        console.error("isrootedexception");
        console.error(oContext);
        console.error(this);

        console.error(sError);
        // alert("device is rooted")
        console.error("Device is rooted");
        console.error("STOP APP");

        if (this.oDialogRootFail === undefined) {
          this.oDialogRootFail = new Dialog({
            type: DialogType.Message,
            title: "Error",
            state: ValueState.Error,
            content: new Text({
              text: this.getModel("i18n")
                .getResourceBundle()
                .getText("DeviceRooted"),
            }),
            beginButton: new Button({
              type: ButtonType.Emphasized,
              text: "OK",
              press: function () {
                this.oDialogRootFail.close();
                navigator.app.exitApp();
              }.bind(this),
            }),
          });
        }

        this.oDialogRootFail.open();
      },

      isNotRooted: function () {
        // alert("device is not rooted")
        console.debug("Device is not rooted");

        // available => Android
        var sPlatform = cordova.platformId.toLowerCase();
        if (sPlatform === "android") {
          IRoot.isRootedWithBusyBox(
            this.isBusyBoxRooted.bind(this, this),
            this.isBusyBoxRootedException.bind(this, this)
          );
        }
      },

      startProcedure: function () {
        //init service (odata)
        if (!this.dbService) {
          this.dbService = new DBSerivce(this);

          $.when(this.dbService.initializeDB(true, false)).done(
            jQuery.proxy(function () {
              $.when(this.dbService.getSAPSettings()).done(
                jQuery.proxy(function (oData) {
                  var _oSharedModel = this.getModel("shared");

                  if (!oData.host && !oData.sapClient && !oData.sapSysId) {
                    // Off boarded device routine

                    _oSharedModel.setProperty("/isBusy", false);
                    _oSharedModel.setProperty("/configFailed", true);
                    _oSharedModel.setProperty("/metaFailed", true); // OFFBOARDED > no model connection

                    this._initRouter();

                    // jQuery.getJSON(this.helper.getConfigLocation(), jQuery.proxy(this._onUserDataLoaded, this))

                    // jQuery.getJSON(this.helper.getConfigLocation(), jQuery.proxy(function () {
                    // 	_oSharedModel.setProperty("/isBusy", false);
                    // 	_oSharedModel.setProperty("/configFailed", true);
                    // 	this._initRouter();
                    // }, this))
                    // 	.fail(jQuery.proxy(function () {
                    // 		_oSharedModel.setProperty("/isBusy", false);
                    // 		_oSharedModel.setProperty("/configFailed", true);
                    // 		this._initRouter();
                    // 	}, this));

                    // jQuery.getJSON(this.helper.getConfigLocation(), jQuery.proxy(this._onUserDataLoaded, this)).
                    // fail(jQuery.proxy(function () {
                    // 	_oSharedModel.setProperty("/isBusy", false);
                    // 	_oSharedModel.setProperty("/configFailed", true);
                    // 	this._initRouter();
                    // }, this));
                  } else {
                    if (oData.policy === "FUNC_USER") {
                      // Functional user policy >> load data directly

                      // this._initRouter();
                      this._onUserDataLoaded(oData);
                      this._initRouter();
                      _oSharedModel.setProperty("/isBusy", false);
                    } else {
                      if (oData.sapUser !== "" || oData.sapPass !== "") {
                        // Clear the session credentials in database

                        oData.sapUser = "";
                        oData.sapPass = "";

                        let that = this;
                        let aSettingsArray = [];
                        let oSettings = oData;

                        for (let sProp in oSettings) {
                          if (oSettings.hasOwnProperty(sProp)) {
                            aSettingsArray.push({
                              SKey: sProp,
                              SValue: oSettings[sProp],
                            });
                          }
                        }

                        $.when(
                          this.dbService.updateSAPSettings(aSettingsArray)
                        ).done(() => {
                          // sap.m.MessageToast.show(this.getText("LogoffSuccess"));
                          // this.getSharedModel().setProperty("/loggedInAsMsg", "");

                          that.startRouter(oData, _oSharedModel);
                        });
                      } else {
                        this.startRouter(oData, _oSharedModel);
                      }
                    }
                  }
                }, this)
              );
            }, this)
          );
        }

        // Get defaults
        var _oSharedModel = this.getModel("shared"),
          oOnboardingModel = new sap.ui.model.json.JSONModel(),
          oDefaultsModel = new sap.ui.model.json.JSONModel();

        this.setModel(oOnboardingModel, "onboarding");
        this.setModel(oDefaultsModel, "defaults");

        /*jQuery.getJSON(this.helper.getDefaultSettings(), jQuery.proxy(function (oResult) {
				this.getModel("defaults").setProperty("/settings", oResult);
				console.debug(oResult);
			}, this));*/
        $.when(this.helper.getDefaultSettings())
          .done(
            jQuery.proxy(function (oResult) {
              this.getModel("defaults").setProperty("/settings", oResult);
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              console.error("Error: " + oError);
            }, this)
          );

        /*jQuery.getJSON(this.helper.getDefaultSystems(), jQuery.proxy(function (oResult) {
				this.getModel("defaults").setProperty("/systems", oResult.Systems);
				console.debug(oResult);
			}, this));*/
        $.when(this.helper.getDefaultSystems()).done(
          jQuery.proxy(function (oResult) {
            this.getModel("defaults").setProperty("/systems", oResult);
          }, this)
        );

        if (navigator) {
          var aLangu = navigator.language.split("-");
          this.getModel("onboarding").setProperty("/langu", aLangu[0]);
          this._selectDefaultCountryByLangu(aLangu[0]);
          sap.ui.getCore().getConfiguration().setLanguage(aLangu[0]);
        }

        // init ScannerHandler
        if (!this.scanHandler) {
          this.scanHandler = new ScanHandler(this);
        }
      },

      startRouter: function (oData, _oSharedModel) {
        // Onboarded device startup routine >> user still needs to login again
        this.getModel("shared").setProperty("/sapSettings", oData);
        _oSharedModel.setProperty("/isBusy", false);
        _oSharedModel.setProperty("/metaFailed", true); // User not yet logged in > no model loaded

        if (oData.langu) {
          sap.ui
            .getCore()
            .getConfiguration()
            .setLanguage(oData.langu.toLowerCase());
        }

        this._initRouter();
      },

      startLogModule: function () {
        return new Promise(async function (resolve, reject) {
          // if (
          //   !this.getModel("runConfiguration").getProperty("/publicRelease")
          // ) {
          let oSAPLogConfig = {
            object: "/ARMP/MW",
            subobject: {
              error: "/ARMP/ERROR",
              trace: "/ARMP/TRACES",
              log: "/ARMP/LOG",
            },
          };

          am.armp.log
            // Ideally we use a better database name like mobile-work-db,
            //  but unfortunately this ionic-test-db is already used in production.
            .initDB("mobilework-lf-db", false, oSAPLogConfig)
            .then((x) => {
              console.debug("am.armp.log - init db finished");
              resolve("LOG_MODULE_OK");
            });
          // } else {
          //   resole("OK");
          // }
        });
      },

      startBase: function () {
        // set the device model
        this.setModel(models.createDeviceModel(), "device");
        this.busyDialog = new sap.m.BusyDialog();
        this.loginMethod = new LoginMethod(this);
        // let sPath = jQuery.sap.getModulePath("mobilework", "model/runConfiguration.json");
        // let oRunConfigurationModel = new sap.ui.model.json.JSONModel(sPath);

        let oRunConfigurationModel = this.getModel("runConfiguration");
        // oRunConfigurationModel.dataLoaded().then(
        //   function () {
        console.debug("Data loaded");
        console.debug(
          this.getModel("runConfiguration").getProperty("/publicRelease")
        );

        //init helper
        if (!this.helper) {
          this.helper = new Help(this.getModel("runConfiguration"));
        }

        //init validator
        if (!this.validator) {
          this.validator = new Valid(this);
        }

        //init dialog manager
        if (!this.dialogManager) {
          this.dialogManager = new DialogManager();
        }

        //init logging
        //!this.helper.isDevModeActive() - CHANGE BACK
        //	if (!this.helper.isDevModeActive()) {
        this.logs = new Logger(
          "Logs.json",
          Baselog,
          "WARNING",
          this.getModel("ODataLog"),
          this
        );
        //	}

        //init key listener
        if (!this.keyListener) {
          this.keyListener = new KeyListener(null, true, null);
        }

        //init shared model
        if (!this.getModel("shared")) {
          var oSharedModel = new sap.ui.model.json.JSONModel({
            isBusy: true,
          });
          oSharedModel.setSizeLimit(2500);
          console.debug("RunConfiguration");

          let bPublicRelease =
            oRunConfigurationModel.getProperty("/publicRelease");
          console.debug(bPublicRelease);
          oSharedModel.setProperty("/publicRelease", bPublicRelease);
          this.setModel(oSharedModel, "shared");
          this.setModel(new sap.ui.model.json.JSONModel({}), "PurchaseOrders");
          this.setModel(
            new sap.ui.model.json.JSONModel({ PONum: "" }),
            "PurchaseOrd"
          );
          //this.getModel("PurchaseOrders").setSizeLimit(2500);
        }

        if (!this.TokenService) {
          this.tokenService = new TokenService(this);
        }

        // Only proceed if device is not rooted
        // https://github.com/scottyab/rootbeer
        // Can lead to false positives for certain devices like oneplus  >> we might need to leave out the BusyBox check

        if (
          this.helper.isDevModeActive() ||
          oSharedModel.getProperty("/publicRelease") === false
        ) {
          console.debug(" ==== DEV MODE ==== ");
          this.startProcedure();
        } else if (IRoot) {
          // available => iOS + Android
          IRoot.isRooted(
            this.isRooted.bind(this, this),
            this.isRootedException.bind(this, this)
          );
        } else {
          MBox.success("IRoot plugin not found", {
            onClose: function () {
              navigator.app.exitApp();
            }.bind(this),
          });

          // this.startProcedure();
        }
        // }.bind(this)
        // );

        // TODO add some logging and check the logcat output & android manifest

        // try {
        // 	// Call Gates plugin
        // 	window.cordova.plugins.GatesPlugin.listen(jQuery.proxy(function (result) {
        // 		console.debug(result);
        // 		console.debug("result");//
        // 	}, this), jQuery.proxy(function (oError) {
        // 		console.debug(oError)
        // 	}, this));
        // } catch (ex) {
        // 	this.logger.error("Gates plugin not activated");
        // }

        // try {
        // 	// Call Gates plugin
        // 	let result = await window.cordova.plugins.GatesPlugin.listen();
        // } catch (ex) {
        // 	this.logger.error("Gates plugin failed");
        // }

        // return; //
      },

      /**
       * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
       * @public
       * @override
       */
      init: function () {
        // call the base component's init function
        // UIComponent.prototype.init.apply(this, arguments);
        console.debug("startProcedure");
        UIComponent.prototype.init.apply(this, arguments);

        let that = this;

        // Start log module
        this.startDB()
          .then(async (bPublicRelease) => {
            return new Promise(async (resolve, reject) => {
              await this.startLogModule();

              // START database migration
              await dbMigrator.performMigration(bPublicRelease);

              resolve("MIGRATION_FINISHED");
            });
          })
          .then(async (x) => {
            console.debug("Promise result");
            console.debug(x);
          })
          .then((x) => {
            console.debug("Promise result");
            console.debug(x);
            this.startBase();
          });
      },

      startDB: function () {
        return new Promise(async (resolve, reject) => {
          let oRunConfigurationModel = this.getModel("runConfiguration");
          oRunConfigurationModel.dataLoaded().then(async () => {
            console.debug("Data loaded");
            console.debug(
              this.getModel("runConfiguration").getProperty("/publicRelease")
            );

            // START localforage
            let bPublicRelease =
              this.getModel("runConfiguration").getProperty("/publicRelease");
            console.debug("Public release check:");
            console.debug(bPublicRelease);

            if (!dbMigrator.isDevModeActive()) {
              if (bPublicRelease) {
                // Get database key from Android storage

                let sKey = await this.getDBKey();
                console.debug("=== DB KEY ===");
                console.debug(sKey);

                localforage
                  .defineDriver(window.cordovaSQLiteDriver)
                  .then(() => {
                    return localforage.config({
                      driver: [
                        window.cordovaSQLiteDriver._driver,
                        localforage.INDEXEDDB,
                        localforage.WEBSQL,
                        localforage.LOCALSTORAGE,
                      ],
                      name: "mobilework-lf-db",
                      dbKey: sKey,
                    });
                  })
                  .then(() => {
                    resolve(bPublicRelease);
                    return;
                  });
              } else {
                localforage
                  .defineDriver(window.cordovaSQLiteDriver)
                  .then(() => {
                    return localforage.config({
                      driver: [
                        window.cordovaSQLiteDriver._driver,
                        localforage.INDEXEDDB,
                        localforage.WEBSQL,
                        localforage.LOCALSTORAGE,
                      ],
                      name: "mobilework-lf-db",
                    });
                  })
                  .then(() => {
                    resolve(bPublicRelease);
                    return;
                  });
              }
            } else {
              localforage.config({
                driver: [
                  localforage.INDEXEDDB,
                  localforage.WEBSQL,
                  localforage.LOCALSTORAGE,
                ],
                name: "mobilework-lf-db",
              });
              resolve(bPublicRelease);
            }
          });
        });
      },

      getDBKey: function () {
        var d = jQuery.Deferred();

        var ss = new cordova.plugins.SecureStorage(
          jQuery.proxy(function () {
            console.debug("Success");
            ss.get(
              jQuery.proxy(function (value) {
                console.debug("Success, got " + value);
                console.debug("Retrieved KEY");
                console.debug(value);
                d.resolve(value);
              }, this),
              jQuery.proxy(function (error) {
                console.error("Error " + error);
                var uuid = self.crypto.randomUUID();
                console.debug("GENERATED KEY");
                console.debug(uuid);
                ss.set(
                  jQuery.proxy(function (key) {
                    console.debug("Set " + key);
                    d.resolve(uuid);
                  }, this),
                  jQuery.proxy(function (error) {
                    console.debug("Error " + error);
                    d.reject(error);
                  }, this),
                  "mydbkey",
                  uuid
                );
              }, this),
              "mydbkey"
            );
          }, this),
          jQuery.proxy(function (error) {
            console.debug("Error " + error);

            MBox.error(
              this.component
                .getModel("i18n")
                .getResourceBundle()
                .getText("EnableScreenLock"),
              {
                actions: [MBox.Action.CLOSE],
                onClose: function (sAction) {
                  navigator.app.exitApp();
                },
              }
            );
            d.reject(error);
          }, this),
          "MobileWork"
        );

        return d.promise();
      },

      _initRouter: function () {
        this.getRouter().initialize();
        this.getRouter().getTargetHandler().setCloseDialogs(false);

        // if (!this.getModel("runConfiguration").getProperty("/publicRelease")) {
        // Register router for usage by child components
        am.armp.log.registerParentRouter(this.getRouter(), "main");

        let that = this;

        let fParentAuthorization = function () {
          console.debug(that);
          if (that.getModel("shared") === undefined) {
            return false;
          }

          let sSapUser = that
            .getModel("shared")
            .getProperty("/sapSettings/sapUser");
          let sSapPass = that
            .getModel("shared")
            .getProperty("/sapSettings/sapPass");
          let sHost = that.getModel("shared").getProperty("/sapSettings/host");
          let sSystemID = that
            .getModel("shared")
            .getProperty("/sapSettings/sapSysId");

          if (
            sSapPass !== undefined &&
            sSapPass !== null &&
            sSapPass !== "" &&
            sSapUser !== undefined &&
            sSapUser !== null &&
            sSapUser !== "" &&
            sHost !== undefined &&
            sHost !== null &&
            sHost !== ""
          ) {
            let sBasic = sSapUser + ":" + sSapPass;
            sBasic = btoa(sBasic);

            return {
              Header: "Basic " + sBasic, // "Basic ODgwNDI0OlNpZG1hcjEyM0BhbQ==", //
              SapUser: sSapUser, // "880424", // sSapUser,
              SapPass: sSapPass, // "Sidmar123@am", // sSapPass,
              Host: sHost, // "https://amfshars.sap.europe.arcelormittal.com", // sHost,
              SystemID: sSystemID, // "HAR", // sSystemID
              PublicRelease: that
                .getModel("shared")
                .getProperty("/publicRelease"),
            };
          } else {
            return false;
          }
        };

        // Additional check used by log component before sending data to SAP
        am.armp.log.registerParentAuthorization(fParentAuthorization);

        am.armp.log.registerConnectivityIndicators(
          this.getModel("shared"),
          "/bUserIconVisible",
          this.getModel("shared"),
          "/bOnline"
        );

        // Action when status icon is pressed
        let oBaseController = new BaseController();

        let fStatusIconPressed = function (oEvent) {
          let oView = oEvent.getSource().getParent().getParent().getParent();
          this.getOwnerComponent = jQuery.proxy(function () {
            return that;
          }, that);
          oBaseController.getModel = jQuery.proxy(that.getModel, that);
          oBaseController.getView = function () {
            return oView;
          };
          this.onStatusIconPress(oEvent);
        };

        am.armp.log.registerStatusIconPressHandle(
          jQuery.proxy(fStatusIconPressed, oBaseController)
        );
        // }

        this.getRouter().navTo("main");
      },

      make_base_auth: function (user, password) {
        var tok = user + ":" + password;
        var hash = btoa(tok);
        return hash;
      },

      _onUserDataLoaded: function (oData) {
        console.debug("USER DATA LOADED");
        var oModel = null,
          oShared = this.getModel("shared"),
          sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
          sConfigUri = this.getManifestEntry(
            "/sap.app/dataSources/configserver"
          ).uri,
          sConfigUrl = oData.host + sConfigUri,
          sUrl = oData.host + sUri,
          sUrlToBeUsed = "",
          d = $.Deferred();

        if (typeof oData.sapUser === "string") {
          oData.sapUser = oData.sapUser.toUpperCase();
        }

        if (oData.langu) {
          sap.ui
            .getCore()
            .getConfiguration()
            .setLanguage(oData.langu.toLowerCase());
        }

        if (this.helper.isDevModeActive()) {
          sUrlToBeUsed = sUri;
        } else {
          sUrlToBeUsed = sUrl;
        }

        // oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed + "&saml2=disabled", {
        // 	user: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? oData.sapUser : "",
        // 	password: deviceType.indexOf("win") !== -1 || deviceType.indexOf("Win") !== -1 ? oData.sapPass : "",
        // 	withCredentials: true,
        // 	defaultBindingMode: "TwoWay",
        // 	defaultCountMode: "Inline",
        // 	metadataUrlParams: {},
        // 	loadMetadataAsync: true,
        // 	useBatch: false,
        // 	headers: {
        // 		"sap-client": oData.sapClient ? oData.sapClient.toString() : "",
        // 		"Authorization": "Basic " + this.make_base_auth(oData.sapUser, oData.sapPass),
        // 		"Cache-Control": "max-age=0"
        // 	}
        // });

        if (oData.sapUser && oData.sapPass) {
          oModel = this._initModel(oShared, oData, sUrlToBeUsed, d);
        } else {
          oModel = null;
        }

        this.service = new Service(
          oModel,
          oData.host,
          sUrlToBeUsed,
          oData.deviceName,
          oData.sapClient,
          oData.sapUser,
          oData.sapPass,
          sUri,
          oData.langu,
          sConfigUri,
          sConfigUrl,
          null,
          this
        );
        this.gdlApi = new GdlApi(
          oData.sapSysId,
          oData.sapClient,
          oData.GDL_API_URL,
          "BUS2007",
          oData.sapUser,
          this
        );
        this.setModel(this.service.getModel(), "odata");
        this.dbService.setService(this.service);

        if (oData.fromJSON) {
          delete oData.fromJSON;

          this.dbService.saveSAPSettings(oData);
        }

        // If oData does not contain user & password we select it from the shared model
        if (oData.sapUser === undefined && oData.sapPass === undefined) {
          oData.sapUser = oShared.getProperty("/sapSettings/sapUser");
          oData.sapPass = oShared.getProperty("/sapSettings/sapPass");
        }
        oShared.setProperty("/sapSettings", oData);

        // if (!this.helper.isOnline()) {
        // 	// this.isOffline = true;
        // 	this._copyValueHelpToSharedModel();
        // }
        if (!oModel) {
          d.reject("FAILED");
        } else {
          oModel.attachRequestFailed(function (oEvent) {
            console.debug("OMODEL REQUEST FAILED");
            console.debug(oEvent);
            d.reject(oEvent);
          });

          oModel.attachMetadataLoaded(
            function (oEvent) {
              console.debug("Metadata loaded");
              oShared.setProperty("/metaFailed", false); // Model metadata loaded
              d.resolve();
            }.bind(this)
          );

          oModel.attachMetadataFailed(
            function (oEvent) {
              console.debug("Metadata failed");
              oShared.setProperty("/metaFailed", true); // Model metadata failed
              d.reject(oEvent);
            }.bind(this)
          );
        }

        return d.promise();
      },

      _initModel: function (oShared, oData, sUrlToBeUsed, d) {
        let oModel = null;

        var deviceType = "windows";
        if (!this.helper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (oData.sapClient && oData.sapClient !== "undefined") {
          sUrlToBeUsed = sUrlToBeUsed + "?sap-client=" + oData.sapClient;
        }

        if (oShared.getProperty("/publicRelease")) {
          if (
            deviceType.indexOf("win") !== -1 ||
            deviceType.indexOf("Win") !== -1
          ) {
            oModel = new sap.ui.model.odata.v2.ODataModel(
              sUrlToBeUsed + "&saml2=disabled",
              {
                // user: oData.sapUser,
                // password: oData.sapPass,
                // withCredentials: true,
                defaultBindingMode: "TwoWay",
                defaultCountMode: "Inline",
                metadataUrlParams: {},
                loadMetadataAsync: true,
                useBatch: false,
                headers: {
                  "sap-client": oData.sapClient
                    ? oData.sapClient.toString()
                    : "",
                  "Cache-Control": "max-age=0",
                  Authorization: "Bearer " + oData.sapPass,
                  TargetSAPSystem: oData.sapSysId,
                },
              }
            );
          } else {
            oModel = new sap.ui.model.odata.v2.ODataModel(
              sUrlToBeUsed + "&saml2=disabled",
              {
                // user: "",
                // password: "",
                // withCredentials: true,
                defaultBindingMode: "TwoWay",
                defaultCountMode: "Inline",
                metadataUrlParams: {},
                loadMetadataAsync: true,
                useBatch: false,
                headers: {
                  "sap-client": oData.sapClient
                    ? oData.sapClient.toString()
                    : "",
                  Authorization: "Bearer " + oData.sapPass,
                  TargetSAPSystem: oData.sapSysId,
                  "Cache-Control": "max-age=0",
                },
              }
            );
          }
        } else {
          sUrlToBeUsed =
            sUrlToBeUsed +
            "&authorization=" +
            this.make_base_auth(oData.sapUser, oData.sapPass);

          if (
            deviceType.indexOf("win") !== -1 ||
            deviceType.indexOf("Win") !== -1
          ) {
            oModel = new sap.ui.model.odata.v2.ODataModel(
              sUrlToBeUsed + "&saml2=disabled",
              {
                user: oData.sapUser,
                password: oData.sapPass,
                withCredentials: true,
                defaultBindingMode: "TwoWay",
                defaultCountMode: "Inline",
                metadataUrlParams: {},
                loadMetadataAsync: true,
                useBatch: false,
                headers: {
                  "sap-client": oData.sapClient
                    ? oData.sapClient.toString()
                    : "",
                  "Cache-Control": "max-age=0",
                },
              }
            );
          } else {
            oModel = new sap.ui.model.odata.v2.ODataModel(
              sUrlToBeUsed + "&saml2=disabled",
              {
                user: "",
                password: "",
                withCredentials: true,
                defaultBindingMode: "TwoWay",
                defaultCountMode: "Inline",
                metadataUrlParams: {},
                loadMetadataAsync: true,
                useBatch: false,
                headers: {
                  "sap-client": oData.sapClient
                    ? oData.sapClient.toString()
                    : "",
                  Authorization:
                    "Basic " +
                    this.make_base_auth(oData.sapUser, oData.sapPass),
                  "Cache-Control": "max-age=0",
                },
              }
            );
          }
        }

        // oModel.setHeaders({
        // 	"sap-client": oData.sapClient ? oData.sapClient.toString() : "",
        // 	"Cache-Control": "max-age=0"
        // });

        // 	// if (!this.loadMetaObjectFromDB && !this.loadMetaObjectOnline) {
        // 	// 	this.loadMetaObjectOnline = true;

        // 	// Scenario 3 : online && app is starting && user is not logged in
        // 	// console.debug("SCENARIO 3:  Load metadata online procedure ...");

        // 	// In case of functional user profile below code can be executed

        // 	// In case of public && normal start profile we will start the offline logon procedure
        // 	// let bOffLineLogin = true;
        // 	// if (bOffLineLogin) {
        // 	// 	console.debug("Load content offline procedure");

        // 	// this._start_procedure_offline();

        // 	// 	oShared.setProperty("/metaFailed", false);

        // 	// }
        // 	// else {
        // 	// 	console.debug("Functional user logon procedure");

        // 	// 	this._start_procedure_functional_user();

        // 	// }
        //

        // 	oShared.setProperty("/metaFailed", false);

        // 	// }
        // 	d.resolve();
        // }, this));

        // oModel.attachMetadataFailed(jQuery.proxy(function (oEvent) {

        // 	this.getModel("shared").setProperty("/connectionErrorCode", oEvent.getParameters().statusCode);

        // 	console.debug("metadata has not been loaded");

        // 	// Triggerd in case the app is offline or the user is logged off
        // 	//
        // 	// if (!this.loadMetaObjectFromDB && !this.loadMetaObjectOnline && !this.OnboardingProcedure) {
        // 	// 	this.loadMetaObjectFromDB = true;

        // 	// 	// When device is onboarded > we want to load the data via this procedure
        // 	//

        // 	// 	console.debug("Scenario 4 : Logged off & offline > Start APP - load metadata offline procedure ...");

        // 	// 	this._start_procedure_offline();

        // 	// 	oShared.setProperty("/metaFailed", true);
        // 	// }
        // 	oShared.setProperty("/metaFailed", true);

        // 	d.reject(oEvent);
        // }, this));
        return oModel;
      },

      _start_procedure_offline: function () {
        // Execute for scenario's 5 & 6
        // Device has been onboarded before

        this.dbService._getMetaObjectFromDB();
        this.dbService._getPlanItemSetFromDB();

        // this.isOffline = false;
        this._copyValueHelpToSharedModel();

        // this._initRouter();
      },

      _start_procedure_functional_user: function (oView, sqlUpdate) {
        // WR -- Not sure when this logic should be executed ??
        // It seems to load the config server

        oView.setBusy(true);
        // this.isOffline = false;

        console.debug("metadata has been loaded");

        // this.getModel('shared').setProperty("/metaFailed", false);

        $.when(this.dbService.initializeDB(false, true)).done(
          jQuery.proxy(function () {
            var uri = this.getManifestEntry(
              "/sap.app/dataSources/configserver"
            ).uri;
            var oShared = this.getModel("shared"),
              oSettings = oShared.getProperty("/sapSettings");
            if (sqlUpdate) this.sqlDataBaseUpdate();
            $.when(this.service.createConfigurationModel(uri, oSettings)).done(
              jQuery.proxy(function () {
                $.when(
                  this.service.getDeviceSettings(
                    oShared.getProperty("/sapSettings/deviceName"),
                    oShared.getProperty("/sapSettings/plant")
                  ),
                  this.service.getValueHelpSet()
                ).done(
                  jQuery.proxy(function (oResult, oValueHelp) {
                    var notifFields = {};
                    this._aDeviceSettings = oResult.navDeviceSettings.results;

                    for (var x in this._aDeviceSettings) {
                      if (
                        this._aDeviceSettings[x].Fieldname.indexOf(
                          "notifFields"
                        ) !== -1
                      ) {
                        var aNotifField =
                          this._aDeviceSettings[x].Fieldname.split("_");
                        var sNotifField = aNotifField[1];
                        notifFields[sNotifField] =
                          this._aDeviceSettings[x].Type === "BOOL"
                            ? this._aDeviceSettings[x].ValueBool
                            : this._aDeviceSettings[x].ValueString;
                      } else {
                        this.getModel("onboarding").setProperty(
                          "/" + this._aDeviceSettings[x].Fieldname,
                          this._aDeviceSettings[x].Type === "BOOL"
                            ? this._aDeviceSettings[x].ValueBool
                            : this._aDeviceSettings[x].ValueString
                        );
                      }
                    }
                    var enableDownloadBoms = _.find(this._aDeviceSettings, {
                      Fieldname: "enableDownloadBoms",
                    });
                    var enableOrderConfCreation = _.find(
                      this._aDeviceSettings,
                      { Fieldname: "enableOrderConfCreation" }
                    );
                    var persNoNotRequired = _.find(this._aDeviceSettings, {
                      Fieldname: "persNoNotRequired",
                    });
                    var rfidMand = _.find(this._aDeviceSettings, {
                      Fieldname: "rfidMand",
                    });
                    var hideLogOffButton = _.find(this._aDeviceSettings, {
                      Fieldname: "hideLogOffButton",
                    });
                    var Notifstatus_tbp = _.find(this._aDeviceSettings, {
                      Fieldname: "Notifstatus_tbp",
                    });
                    var ZoneBadging = _.find(this._aDeviceSettings, {
                      Fieldname: "ZoneBadging",
                    });
                    var Connected = _.find(this._aDeviceSettings, {
                      Fieldname: "Connected",
                    });
                    var TrCheckError = _.find(this._aDeviceSettings, {
                      Fieldname: "TrCheckError",
                    });
                    var POActive = _.find(this._aDeviceSettings, {
                      Fieldname: "POActive",
                    });
                    if (!enableDownloadBoms) {
                      this.getModel("onboarding").setProperty(
                        "/enableDownloadBoms",
                        false
                      );
                    }
                    if (!enableOrderConfCreation) {
                      this.getModel("onboarding").setProperty(
                        "/enableOrderConfCreation",
                        false
                      );
                    }
                    if (!persNoNotRequired) {
                      this.getModel("onboarding").setProperty(
                        "/persNoNotRequired",
                        false
                      );
                    }
                    if (!rfidMand) {
                      this.getModel("onboarding").setProperty(
                        "/rfidMand",
                        false
                      );
                    }
                    if (!hideLogOffButton) {
                      this.getModel("onboarding").setProperty(
                        "/hideLogOffButton",
                        false
                      );
                    }
                    if (!Notifstatus_tbp) {
                      this.getModel("onboarding").setProperty(
                        "/Notifstatus_tbp",
                        false
                      );
                    }
                    if (!TrCheckError) {
                      this.getModel("onboarding").setProperty(
                        "/TrCheckError",
                        false
                      );
                    }
                    if (!POActive) {
                      this.getModel("onboarding").setProperty(
                        "/POActive",
                        false
                      );
                    }
                    if (!Connected) {
                      this.getModel("onboarding").setProperty(
                        "/Connected",
                        false
                      );
                    }
                    if (!ZoneBadging) {
                      this.getModel("onboarding").setProperty(
                        "/ZoneBadging",
                        false
                      );
                    }
                    notifFields = this.helper.onNotifFieldChange(notifFields);
                    this.getModel("shared").setProperty(
                      "/sapSettings/notifFields",
                      notifFields
                    );
                    this.getModel("onboarding").setProperty(
                      "/notifFields",
                      notifFields
                    );

                    this.getModel("onboarding").setProperty(
                      "/langu",
                      this.getModel("onboarding")
                        .getProperty("/langu")
                        .toUpperCase()
                    );

                    // if (!this.getModel("shared").getProperty("/configFailed") || this.getModel("shared").getProperty("/configFailed") === false) {
                    // 	this.dbService.saveSAPSettings(this.getModel("onboarding").getProperty("/"));
                    // }

                    if (
                      this.getModel("shared").getProperty(
                        "/sapSettings/sapUser"
                      ) !== undefined &&
                      this.getModel("shared").getProperty(
                        "/sapSettings/sapPass"
                      ) !== undefined &&
                      this.getModel("shared").getProperty(
                        "/sapSettings/sapClient"
                      ) !== undefined
                    ) {
                      this.dbService.saveSAPSettings(
                        this.getModel("onboarding").getProperty("/")
                      );
                    }

                    $.when(
                      this.dbService.deleteAllObjects("ValueHelpSet")
                    ).done(
                      jQuery.proxy(function () {
                        this.dbService.initValueHelpSet(oValueHelp);
                      }, this)
                    );

                    this.getAggregation("rootControl")
                      .getController()
                      .genericSetDeviceIdColor("Green");
                    this.getAggregation("rootControl")
                      .getController()
                      .genericReplaceStyleClass(this.getRootControl(), "Green");

                    var sAppVersion =
                      this.getManifestObject()._oManifest._version;
                    if (
                      this.service &&
                      this.getModel("shared").getProperty(
                        "/sapSettings/deviceName"
                      ) !== undefined
                    ) {
                      $.when(
                        this.service.setVersion(
                          this.getModel("shared").getProperty(
                            "/sapSettings/deviceName"
                          ),
                          this.getModel("shared").getProperty(
                            "/sapSettings/plant"
                          ),
                          sAppVersion
                        )
                      ).done(jQuery.proxy(function (oResult) {}, this));
                    }
                  }, this)
                );
              }, this)
            );

            //automatically get permanent data.

            //if (!this.getModel("shared").getProperty("/configFailed") || this.getModel("shared").getProperty("/configFailed") === false) {
            $.when(this.dbService.getPermanentData(false))
              .done(
                jQuery.proxy(function () {
                  console.debug("permanent data done");

                  //Save metadata if it exists in the dbservice
                  //this._saveMetadata();
                  //refresh all the value help (get from service)
                  // this.refreshValueHelp();

                  //await this.dbService.getAllVHAndCatalogs();
                  this.dbService.getAllVHAndCatalogs();

                  // Close Dialog window

                  this.getModel("shared").setProperty("/configFailed", false);

                  console.debug("ONBOARDING FINISHED - ONLINE");
                  oView.setBusy(false);
                  // this.getRouter().navTo("reload", {}, true);

                  // $.when(this.createParticipant(this.getModel("shared").getProperty("/sapSettings/sapUser"))).done(jQuery.proxy(function () {
                  // 	this.getParticipantsFromDb();
                  // }, this));

                  // this._initRouter();
                }, this)
              )
              .fail(
                jQuery.proxy(function (oError) {
                  var oPromVH = this.service.getValueHelpData(),
                    oPromCatalog = this.service.getCatalogSet(),
                    oPromSettings = this.service.getSettingSet();

                  console.debug("permanent data failed");

                  //this._initRouter();
                  oView.setBusy(false);
                  $.when(oPromVH, oPromCatalog, oPromSettings).done(
                    jQuery.proxy(async function (
                      oVHData,
                      oCatalogData,
                      oSettingData
                    ) {
                      this._onValueHelpRetreived(
                        oVHData,
                        oCatalogData,
                        oSettingData
                      );

                      // this.refreshValueHelp();
                      this.dbService.getAllVHAndCatalogs();
                      //await this.dbService.getAllVHAndCatalogs();

                      console.debug("ONBOARDING FINISHED - OFFLINE");

                      // $.when(this.createParticipant(oSettingData.sapUser)).done(jQuery.proxy(function () {
                      // 	this.getParticipantsFromDb();
                      // }, this));

                      // this._initRouter();
                      //this.busyDialog.close();
                    },
                    this)
                  );

                  /*MBox.success(this.getText("QSettingSuccess"), {
								onClose: function () {
									this.getRouter().navTo("reload", {}, true);
								}.bind(this)
							});*/
                }, this)
              );
            //}

            //init value helps
            // var oPromVH = this.service.getValueHelpData(),
            // 	oPromCatalog = this.service.getCatalogSet(),
            // 	oPromSettings = this.service.getSettingSet();

            // this._initRouter();

            // $.when(oPromVH, oPromCatalog, oPromSettings).done(jQuery.proxy(this._onValueHelpRetreived, this));
          }, this)
        );
      },

      _onValueHelpRetreived: function (oVhData, oCatalogData, oSettingData) {
        var oProm = this.dbService.initValueHelp(
          oVhData,
          oCatalogData,
          oSettingData,
          false
        );

        $.when(oProm).done(
          jQuery.proxy(function () {
            this._copyValueHelpToSharedModel();
          }, this)
        );
      },

      _copyValueHelpToSharedModel: function () {
        var oPromInitDb = this.dbService.initializeDB(true, false);

        console.debug("copyValueHelpToSharedModel");

        $.when(oPromInitDb).done(
          jQuery.proxy(function () {
            var oPromCatalog = this.dbService.getEntitySet("Catalog"),
              oPromQmart = this.dbService.getEntitySet("PMNotificationQmartVH"),
              oPromShift = this.dbService.getEntitySet("PMNotificationShiftVH"),
              oPromLangu = this.dbService.getEntitySet("PMNotificationLanguVH"),
              oPromUnWork = this.dbService.getEntitySet(
                "ConfirmationsUnWorkVH"
              ),
              oPromCraft = this.dbService.getEntitySet("PMNotificationCraftVH"),
              oPromActType = this.dbService.getEntitySet(
                "ConfirmationsPMActTypeVH"
              ),
              oPromOteil = this.dbService.getEntitySet("PMNotificationOteilVH"),
              oPromSettings = this.dbService.getSAPSettings(),
              oPromPmenvr = this.dbService.getEntitySet(
                "PMNotificationPmenvrVH"
              ),
              oPromPmqual = this.dbService.getEntitySet(
                "PMNotificationPmqualVH"
              ),
              oPromPmsafe = this.dbService.getEntitySet(
                "PMNotificationPmsafeVH"
              ),
              oPromQuotCoR = this.dbService.getEntitySet(
                "PMNotificationQuotCoRVH"
              ),
              oPromQuotDeR = this.dbService.getEntitySet(
                "PMNotificationQuotDeRVH"
              ),
              oPromQuotPrR = this.dbService.getEntitySet(
                "PMNotificationQuotPrRVH"
              ),
              oPromQuotWcR = this.dbService.getEntitySet(
                "PMNotificationQuotWcRVH"
              ),
              oPromImpactOblCustomizing = this.dbService.getEntitySet(
                "ImpactOblCustomizing"
              ),
              oPromNotifcationType = this.helper.getNotificationTypes();

            $.when(
              oPromQmart,
              oPromCatalog,
              oPromShift,
              oPromLangu,
              oPromUnWork,
              oPromCraft,
              oPromSettings,
              oPromActType,
              oPromPmenvr,
              oPromPmqual,
              oPromPmsafe,
              oPromQuotCoR,
              oPromQuotDeR,
              oPromQuotPrR,
              oPromQuotWcR,
              oPromImpactOblCustomizing,
              oPromNotifcationType
            )
              .done(
                jQuery.proxy(function (
                  _oQmartData,
                  _oCatalogData,
                  _oShiftData,
                  _oLanguData,
                  _oUnWorkData,
                  _oCraftData,
                  _oSettingData,
                  _oActType,
                  _oPmenvrData,
                  _oPmqualData,
                  _oPmsafeData,
                  _oQuotCoRData,
                  _oQuotDeRData,
                  _oQuotPrRData,
                  _oQuotWcRData,
                  _oImpactOblData,
                  oPromNotifcationType
                ) {
                  console.debug("get entity sets done");

                  var oSharedModel = this.getModel("shared"),
                    aQmart = [],
                    aCatalog = [],
                    aShift = [],
                    aLangu = [],
                    aUnWork = [],
                    aCraft = [],
                    aActType = [],
                    aPmqual = [],
                    aPmsafe = [],
                    aQuotCoR = [],
                    aQuotDeR = [],
                    aQuotPrR = [],
                    aQuotWcR = [],
                    aPmenvr = [],
                    aImpactObl = [];

                  // for (var i = 0; i < _oQmartData.rows.length; i++) {
                  // 	aQmart.push(_oQmartData.rows.item(i));
                  // }

                  for (var j = 0; j < _oCatalogData.rows.length; j++) {
                    aCatalog.push(_oCatalogData.rows.item(j));
                  }

                  for (var k = 0; k < _oShiftData.rows.length; k++) {
                    aShift.push(_oShiftData.rows.item(k));
                  }

                  for (var l = 0; l < _oLanguData.rows.length; l++) {
                    aLangu.push(_oLanguData.rows.item(l));
                  }

                  for (var m = 0; m < _oUnWorkData.rows.length; m++) {
                    aUnWork.push(_oUnWorkData.rows.item(m));
                  }

                  for (var n = 0; n < _oCraftData.rows.length; n++) {
                    aCraft.push(_oCraftData.rows.item(n));
                  }

                  for (var o = 0; o < _oActType.rows.length; o++) {
                    aActType.push(_oActType.rows.item(o));
                  }
                  for (var o = 0; o < _oPmenvrData.rows.length; o++) {
                    aPmenvr.push(_oPmenvrData.rows.item(o));
                  }
                  for (var o = 0; o < _oPmqualData.rows.length; o++) {
                    aPmqual.push(_oPmqualData.rows.item(o));
                  }
                  for (var o = 0; o < _oPmsafeData.rows.length; o++) {
                    aPmsafe.push(_oPmsafeData.rows.item(o));
                  }
                  for (var o = 0; o < _oQuotCoRData.rows.length; o++) {
                    aQuotCoR.push(_oQuotCoRData.rows.item(o));
                  }
                  for (var o = 0; o < _oQuotDeRData.rows.length; o++) {
                    aQuotDeR.push(_oQuotDeRData.rows.item(o));
                  }
                  for (var o = 0; o < _oQuotPrRData.rows.length; o++) {
                    aQuotPrR.push(_oQuotPrRData.rows.item(o));
                  }
                  for (var o = 0; o < _oQuotWcRData.rows.length; o++) {
                    aQuotWcR.push(_oQuotWcRData.rows.item(o));
                  }
                  for (var o = 0; o < _oImpactOblData.rows.length; o++) {
                    aImpactObl.push(_oImpactOblData.rows.item(o));
                  }

                  // Issue no. 110 in V13.0
                  aPmenvr.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aPmqual.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aPmsafe.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aQuotCoR.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aQuotDeR.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aQuotPrR.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aQuotWcR.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });
                  aImpactObl.sort((a, b) => {
                    return a.VhKey - b.VhKey;
                  });

                  oSharedModel.setProperty("/vh", {});
                  oSharedModel.setProperty(
                    "/vh/Qmart",
                    oPromNotifcationType.Types
                  );
                  oSharedModel.setProperty("/vh/Catalog", aCatalog);
                  oSharedModel.setProperty("/vh/Shift", aShift);
                  oSharedModel.setProperty("/vh/Langu", aLangu);
                  oSharedModel.setProperty("/vh/UnWork", aUnWork);
                  oSharedModel.setProperty("/vh/Craft", aCraft);
                  oSharedModel.setProperty("/vh/ActType", aActType);
                  oSharedModel.setProperty("/vh/Pmenvr", aPmenvr);
                  oSharedModel.setProperty("/vh/Pmqual", aPmqual);
                  oSharedModel.setProperty("/vh/Pmsafe", aPmsafe);
                  oSharedModel.setProperty("/vh/QuotCoR", aQuotCoR);
                  oSharedModel.setProperty("/vh/QuotDeR", aQuotDeR);
                  oSharedModel.setProperty("/vh/QuotPrR", aQuotPrR);
                  oSharedModel.setProperty("/vh/QuotWcR", aQuotWcR);
                  oSharedModel.setProperty("/vh/ImpactObl", aImpactObl);
                  oSharedModel.setProperty(
                    "/vh/headerLines",
                    aCatalog.filter((aCat) => {
                      return aCat.Code === "";
                    })
                  );

                  if (
                    _oSettingData.sapUser === undefined &&
                    _oSettingData.sapPass === undefined
                  ) {
                    _oSettingData.sapUser = oSharedModel.getProperty(
                      "/sapSettings/sapUser"
                    );
                    _oSettingData.sapPass = oSharedModel.getProperty(
                      "/sapSettings/sapPass"
                    );
                  }
                  oSharedModel.setProperty("/sapSettings", _oSettingData);

                  oSharedModel.setProperty("/isBusy", false);
                },
                this)
              )
              .fail(function (oError) {
                console.debug("get entity sets failed");
                jQuery.sap.log.error(oError.message);
              });
          }, this)
        );
      },

      refreshValueHelp: function () {
        var oModel = null,
          oShared = this.getModel("shared"),
          oSettings = oShared.getProperty("/sapSettings"),
          sUri = this.getManifestEntry("/sap.app/dataSources/odata").uri,
          sUrl = oSettings.host + sUri,
          sConfigUri = this.getManifestEntry(
            "/sap.app/dataSources/configserver"
          ).uri,
          sConfigUrl = oSettings.host + sConfigUri,
          sUrlToBeUsed = "",
          oConfigModel = null;

        var oPromVH = this.service.getValueHelpData(),
          oPromCatalog = this.service.getCatalogSet(),
          oPromSettings = this.service.getSettingSet();

        if (oSettings.langu) {
          sap.ui
            .getCore()
            .getConfiguration()
            .setLanguage(oSettings.langu.toLowerCase());
        }

        if (this.helper.isDevModeActive()) {
          sUrlToBeUsed = sUri;
        } else {
          sUrlToBeUsed = sUrl;
        }

        if (this.service._oConfigModel) {
          oConfigModel = this.service._oConfigModel;
        }

        if (oSettings.sapClient && oSettings.sapClient !== "undefined") {
          sUrlToBeUsed =
            sUrlToBeUsed +
            "?sap-client=" +
            oSettings.sapClient +
            "&saml2=disabled";
        } else {
          sUrlToBeUsed = sUrlToBeUsed + "?saml2=disabled";
        }

        var deviceType = "windows";
        if (!this.helper.isDevModeActive()) {
          deviceType = device.platform;
        }

        if (oShared.getProperty("/publicRelease")) {
          oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
            // user: "",
            // password: "",
            // withCredentials: true,
            defaultBindingMode: "TwoWay",
            defaultCountMode: "Inline",
            metadataUrlParams: {},
            loadMetadataAsync: true,
            useBatch: false,
            headers: {
              Authorization: "Bearer " + oSettings.sapPass,
              TargetSAPSystem: oSettings.sapSysId,
              "Cache-Control": "max-age=0",
            },
          });

          oModel.attachRequestFailed(
            async function (oEvent) {
              console.debug("REQUEST FAILED");
              console.debug(oEvent);
            }.bind(this)
          );
        } else {
          oModel = new sap.ui.model.odata.v2.ODataModel(sUrlToBeUsed, {
            user:
              deviceType.indexOf("win") !== -1 ||
              deviceType.indexOf("Win") !== -1
                ? oSettings.sapUser
                : "",
            password:
              deviceType.indexOf("win") !== -1 ||
              deviceType.indexOf("Win") !== -1
                ? oSettings.sapPass
                : "",
          });
        }

        this.service = new Service(
          oModel,
          oSettings.host,
          sUrlToBeUsed,
          oSettings.deviceName,
          oSettings.sapClient,
          oSettings.sapUser,
          oSettings.sapPass,
          sUri,
          oSettings.langu,
          sConfigUri,
          sConfigUrl,
          this.service._oConfigModel,
          this
        );
        this.gdlApi = new GdlApi(
          oSettings.sapSysId,
          oSettings.sapClient,
          oSettings.GDL_API_URL,
          "BUS2007",
          oSettings.sapUser,
          this
        );
        this.setModel(this.service.getModel(), "odata");

        if (oSettings.fromJSON) {
          delete oSettings.fromJSON;
          this.dbService.saveSAPSettings(oSettings);
        }

        if (
          oSettings.sapUser === undefined &&
          oSettings.sapPass === undefined
        ) {
          oSettings.sapUser = oShared.getProperty("/sapSettings/sapUser");
          oSettings.sapPass = oShared.getProperty("/sapSettings/sapPass");
        }

        oShared.setProperty("/sapSettings", oSettings);

        $.when(oPromVH, oPromCatalog, oPromSettings).done(
          jQuery.proxy(this._onValueHelpRetreived, this)
        );
      },

      createParticipant: function (sSapUser) {
        var aFilters = [],
          d = $.Deferred();

        aFilters.push(
          new sap.ui.model.Filter({
            path: "Pernr",
            operator: sap.ui.model.FilterOperator.EQ,
            value1: sSapUser,
          })
        );
        if (this.service) {
          // && !this.helper.isDevModeActive()) {
          $.when(this.service.getParticipantData(aFilters))
            .done(
              jQuery.proxy(function (oParticipantData) {
                // this.busyDialog.close();
                // this.getView().setBusy(false);
                if (
                  oParticipantData &&
                  oParticipantData.results &&
                  oParticipantData.results.length > 0
                ) {
                  // Valid pernr entered.

                  $.when(
                    this.dbService.updateParticipants(
                      "Participant",
                      oParticipantData.results,
                      this.getModel("local").getProperty("/ParticipantSet")
                    )
                  ).done(
                    jQuery.proxy(function (oData) {
                      d.resolve();
                      // this.getParticipantsFromDb();
                    }, this)
                  );
                } else {
                  d.reject("NO_PARTICIPANT_DATA");
                }
              }, this)
            )
            .fail(
              jQuery.proxy(function (oError) {
                // if (oError.offline === true) {
                // 	// MBox.error(this.getText("NoNetwork"));
                // 	MBox.error(this.getModel("i18n").getResourceBundle().getText("NoNetwork"));
                // 	// this.getView().setBusy(false);
                // } else if (oError.connection === false) {
                // 	// MBox.error(this.getText("ConnectionUnknown"));
                // 	MBox.error(this.getModel("i18n").getResourceBundle().getText("ConnectionUnknown"));
                // 	// this.getView().setBusy(false);
                // }
                d.reject(oError);
              }, this)
            );
        } else {
          d.reject();
        }

        return d.promise();
      },

      getParticipantsFromDb: function () {
        var d = jQuery.Deferred();

        $.when(this.dbService.getEntitySet("Participant"))
          .done(
            jQuery.proxy(function (oData) {
              // var oLocalModel = this.getView().getModel("local"),
              var oSharedModel = this.getModel("shared"),
                aLocalParticipantSet = [];

              // if (!oLocalModel.getProperty("/ParticipantSet")) {
              // 	oLocalModel.setProperty("/ParticipantSet", []);
              // }

              for (var x = 0; x < oData.rows.length; x++) {
                aLocalParticipantSet.push(oData.rows.item(x));
              }

              if (aLocalParticipantSet.length > 0) {
                oSharedModel.setProperty("/hasParticipants", true);
              } else {
                oSharedModel.setProperty("/hasParticipants", false);
              }

              // oLocalModel.setProperty("/ParticipantSet", aLocalParticipantSet);
              oSharedModel.setProperty("/ParticipantSet", aLocalParticipantSet);
              d.resolve(aLocalParticipantSet);
            }, this)
          )
          .fail(
            jQuery.proxy(function (oError) {
              d.reject();
            }, this)
          );
        return d.promise();
      },

      _selectDefaultCountryByLangu: function (sLangu) {
        switch (sLangu.toUpperCase()) {
          case "NL":
            this.getModel("onboarding").setProperty(
              "/country",
              "België/Belgique"
            );
            break;
          case "PL":
            this.getModel("onboarding").setProperty("/country", "Polska");
            break;
          case "DE":
            this.getModel("onboarding").setProperty("/country", "Deutschland");
            break;
          case "ES":
            this.getModel("onboarding").setProperty("/country", "España");
            break;
          case "FR":
            this.getModel("onboarding").setProperty("/country", "France");
            break;
          case "IT":
            this.getModel("onboarding").setProperty("/country", "Italia");
            break;
          case "PT":
            this.getModel("onboarding").setProperty("/country", "Brasil");
            break;
          case "ZH":
            this.getModel("onboarding").setProperty("/country", "中国");
            break;
          case "EN":
            this.getModel("onboarding").setProperty("/country", "");
            break;
        }
      },
      /**
       * To Change Sql Database if tablses are changed in backend.
       * _getSQLForCreateTable will create statement with keys where as orginal setting table is not having any key
       * metaSql = '(SKey TEXT, SValue TEXT)'. Therefore this check is skpied and length reduced
       * @memberOf mobilework.Component
       * @public
       */
      sqlDataBaseUpdate: function () {
        var d = $.Deferred();
        $.when(this.dbService._sqlDataBaseUpdate()).done(
          jQuery.proxy(function (result) {
            var tableNames = this.helper.rowsToArray(result),
              sqlUpdate = true;
            var metaDataObject =
              this.dbService._getMetaObject().dataServices.schema[0].entityType;
            var length = metaDataObject.length;
            metaDataObject.forEach(
              jQuery.proxy(function (entity) {
                if (entity.name === "Setting") {
                  length--;
                  return;
                }
                var tableToBeworked = _.find(tableNames, {
                    tbl_name: entity.name,
                  }),
                  metaSql;
                if (
                  entity.name === "Operation" ||
                  entity.name === "Component" ||
                  entity.name === "PRT" ||
                  entity.name === "AICCustomizing" ||
                  entity.name === "FollowUpNotif" ||
                  entity.name === "wParticipants" ||
                  entity.name === "TimeRegistration" ||
                  entity.name === "Setting"
                ) {
                  metaSql = this.dbService._getSQLForCreateTableNoKeys(
                    entity.name
                  );
                } else if (
                  entity.name === "WCARisks" ||
                  entity.name === "WCAOpeRisks" ||
                  entity.name === "WCAData" ||
                  entity.name === "WCAOpeData"
                ) {
                  metaSql = this.dbService._getSQLForCreateTable(
                    entity.name,
                    null,
                    CustomKeys.find((item) => item.name === entity.name)
                  );
                } else {
                  metaSql = this.dbService._getSQLForCreateTable(entity.name);
                }
                metaSql = metaSql.slice(metaSql.indexOf("("));
                if (
                  tableToBeworked &&
                  tableToBeworked.sql.slice(
                    tableToBeworked.sql.indexOf("(")
                  ) !== metaSql
                ) {
                  length--;
                  sqlUpdate = false;
                  $.when(this.dbService.getEntitySet(entity.name)).done(
                    jQuery.proxy(function (odata) {
                      var tempData = this.helper.rowsToArray(odata);
                      $.when(
                        this.dbService.createTableAndFill(entity, tempData)
                      )
                        .done(function () {
                          d.resolve();
                        })
                        .fail(function () {
                          d.reject();
                        });
                    }, this)
                  );
                } else {
                  length--;
                  if (!length && sqlUpdate) {
                    d.resolve();
                  }
                }
              }, this)
            );
          }, this)
        );
        return d.promise();
      },
      getText: function (sKey, aArray) {
        var _aArray = aArray;
        if (!_aArray) {
          _aArray = [];
        }
        return this.getModel("i18n").getResourceBundle().getText(sKey, _aArray);
      },
    });
  }
);
