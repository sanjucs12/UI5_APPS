var dbMigrator = (function () {
  // Private helper function (not accessible outside this closure)

  function isDevModeActive() {
    if (
      window.location.href.indexOf("webidetesting") !== -1 ||
      window.location.href.indexOf("hana.ondemand.com") !== -1 ||
      window.location.href.indexOf("localhost") !== -1 ||
      window.location.href.indexOf("-workspaces-") !== -1
    ) {
      return true;
    }

    return false;
  }

  function _getDBKey(bPublicRelease) {
    if (!bPublicRelease) {
      return true;
    }

    let d = jQuery.Deferred();

    let ss = new cordova.plugins.SecureStorage(
      jQuery.proxy(function () {
        console.log("Success");
        ss.get(
          jQuery.proxy(function (value) {
            console.log("Success, got " + value);
            console.log("Retrieved KEY");
            console.log(value);
            d.resolve(value);
          }, this),
          jQuery.proxy(function (error) {
            console.log("Error " + error);
            let uuid = self.crypto.randomUUID();
            console.log("GENERATED KEY");
            console.log(uuid);
            ss.set(
              jQuery.proxy(function (key) {
                console.log("Set " + key);
                d.resolve(uuid);
              }, this),
              jQuery.proxy(function (error) {
                console.log("Error " + error);
                d.reject(error);
              }, this),
              "mydbkey",
              uuid
            );
          }, this),
          "mydbkey"
        );
      }, this),
      jQuery.proxy(function (error) {
        console.log("Error " + error);
        d.reject(error);
      }, this),
      "MobileWork"
    );

    return d.promise();
  }

  function loadAndroidWebSQL(bPublicRelease) {
    let d = jQuery.Deferred();

    // Retrieve password
    $.when(_getDBKey(bPublicRelease))
      .done(
        jQuery.proxy(function (sKey) {
          // Continue logic
          if (bPublicRelease) {
            console.log("KEY USED");
            console.log(sKey);

            oDBConfig = {
              name: "mobilework",
              key: sKey, // "dfsqmkljsdf54654vljsmdjv@@#fdkjkfdjs",
              location: "default",
            };
          } else {
            oDBConfig = {
              name: "mobilework",
              location: "default",
            };
          }

          db = window.sqlitePlugin.openDatabase(
            oDBConfig,
            jQuery.proxy(function (db2) {
              console.log("database opened");
              d.resolve(db2);
            }, this),
            jQuery.proxy(function (error) {
              console.error("failed to open database");
            }, this)
          );
        }, this)
      )
      .fail(function (oError) {
        console.log(oError);
      });

    return d.promise();
  }

  // Migrator
  function openWebSQLDB(bPublicRelease) {
    return new Promise(async function (resolve, reject) {
      let oDB;

      if (!isDevModeActive()) {
        oDB = await loadAndroidWebSQL(bPublicRelease);
      } else {
        oDB = window.openDatabase("mobilework", "0.1", "mobilework", 200000);
      }

      oDB.transaction(
        function (tx) {
          console.log("Database is open");
          resolve(oDB);
        },
        function (err) {
          console.error("Open database ERROR: " + JSON.stringify(err));
        }
      );
    });
  }

  // Migrator
  function getTables(db) {
    return new Promise(async function (resolve) {
      // Execute a SQL query to get the list of tables
      let aTableName = [];
      db.transaction(function (tx) {
        tx.executeSql(
          "SELECT name FROM sqlite_master WHERE type='table'",
          [],
          function (tx, results) {
            let len = results.rows.length;
            for (var i = 0; i < len; i++) {
              let tableName = results.rows.item(i).name;
              aTableName.push(tableName);
            }
            console.log(aTableName);
            resolve(aTableName);
            // When processing, skip database table __WebKitDatabaseInfoTable__
          }
        );
      });
    });
  }

  // Migrator
  function extractData(oWebSQLDB, sTable) {
    return new Promise(async function (resolve) {
      let aRows = [];
      oWebSQLDB.transaction(function (tx) {
        tx.executeSql("SELECT * FROM " + sTable, [], function (tx, results) {
          var len = results.rows.length;
          for (var i = 0; i < len; i++) {
            var row = results.rows.item(i);
            // Process each row of data
            aRows.push(row);
          }
          console.log("table: " + sTable + " size: " + aRows.length);
          resolve(aRows);
        });
      });
    });
  }

  async function migrate(bPublicRelease) {
    console.log("migrate");

    console.log("verify if migration is needed");

    let oMigrationStatus = await localforage.getItem("migration");
    if (oMigrationStatus && oMigrationStatus.status === "done") {
      console.log("migration already done");
      return;
    }

    // Open database
    let oWebSQLDB = await openWebSQLDB(bPublicRelease);

    // Get tables
    let aTables = await getTables(oWebSQLDB);

    try {
      aTables.forEach(async (sTable) => {
        if (sTable !== "__WebKitDatabaseInfoTable__") {
          console.log("Migrating table: " + sTable);
          let aRows = await extractData(oWebSQLDB, sTable);

          if (sTable === "Setting") {
            let oSetting = {};
            aRows.forEach((aRow) => {
              if (aRow.SKey === "notifFields") {
                oSetting[aRow.SKey] = aRow.SValue;
              } else {
                oSetting[aRow.SKey] = String(aRow.SValue);
              }
            });
            aRows = oSetting;
          }

          await localforage.setItem(sTable, aRows);
          console.log("Migrating done for table: " + sTable);
        }
      });
    } catch (oError) {
      console.error("Migration failed: " + oError);
      return;
    }

    await localforage.setItem("migration", { status: "done" });
  }

  async function compareContent(bPublicRelease) {
    
    let bIssue = false;

    // Open indexedb
    let aKeys = await localforage.keys();
    aKeys = aKeys.filter((sKey) => sKey !== "trace" && sKey !== "pincode");
    let iLF = aKeys.length;

    // Open database
    let oWebSQLDB = await openWebSQLDB(bPublicRelease);

    // Get number of tables
    let aTables = await getTables(oWebSQLDB);

    let iSQL = aTables.length;

    // Indexeddb --> trace & pincode
    // websql --> __WebKitDatabaseInfoTable__

    // if (!aTables.includes("__WebKitDatabaseInfoTable__") || iLF !== iSQL - 1) {
    //   console.error("DB CHECK FAILED - different number of tables");
    //   bIssue = true;
    //   // MessageBox.error(this.getLocalText("dbcheckfailure"));
    //   return;
    // }

    console.log("Number of tables in IndexedDB: " + iLF);
    console.log("Number of tables in WebSQL: " + iSQL);

    // Array to hold promises
    const promises = [];

    // Do not compare the trace & pincode
    aTables.forEach(async (sKey) => {
      const promise = new Promise(async (resolve, reject) => {
        console.log("WebSQL table: " + sKey);
        if (sKey === "__WebKitDatabaseInfoTable__") {
          console.log("Skipping table: " + sKey);
          resolve();
          return;
        }

        // Content from IndexedDB
        let oIDB = await localforage.getItem(sKey);

        // Content from WebSQL
        let aRows = await extractData(oWebSQLDB, sKey);

        // Remove id & tableid
        //   oIDB.forEach((oRow) => {
        //     oRow.id = parseInt(oRow.id);
        //     delete oRow.tableid;
        //   });

        //   aRows.forEach((oRow) => {
        //     oRow.id = parseInt(oRow.id);
        //     delete oRow.tableid;
        //   });

        if (oIDB === null && _.isEmpty(aRows)) {
          console.log("No entries in table: " + sKey);
          resolve();
          return;
        }

        if (sKey === "Setting") {
          // Exception
          let oSetting = {};
          aRows.forEach((aRow) => {
            oSetting[aRow.SKey] = String(aRow.SValue);
          });
          aRows = oSetting;
          delete aRows.metadata;

          for (let key in oIDB) {
            if (typeof oIDB[key] !== String) {
              oIDB[key] = String(oIDB[key]);
            }
          }
          delete oIDB.metadata;
        }

        if (_.isArray(oIDB)) {
          if (sKey === "KnownScanId") {
            oIDB = oIDB.sort((a, b) => a.ScanId.localeCompare(b.ScanId));
          }

          if (sKey === "Participant") {
            oIDB = oIDB.sort((a, b) => a.Pernr.localeCompare(b.Pernr));
          }

          if (sKey === "TechnicalObject") {
            oIDB = oIDB.sort((a, b) => a.Strno.localeCompare(b.Strno));
          }

          if (sKey === "FuncLocOrg") {
            oIDB = oIDB.sort((a, b) => a.Tplnr.localeCompare(b.Tplnr));
          }

          if (sKey === "Confirmation") {
            oIDB = oIDB.sort((a, b) => a.Handle.localeCompare(b.Handle));
          }

          oIDB.forEach((oItem) => {
            if (sKey === "Operation") {
              // delete oItem.Handle;
            }

            if (sKey === "Picture") {
              oItem.PicIndex = parseInt(oItem.PicIndex);
            }

            if (sKey === "Confirmation") {
              oItem.ActWork = parseFloat(oItem.ActWork);
            }

            if (sKey === "FuncLocCraft") {
              oItem.Iwerk = String(oItem.Iwerk);
              oItem.Swerk = String(oItem.Swerk);
            }

            for (let sItemKey in oItem) {
              if (sKey === "Operation") {
                if (sItemKey === "Quantity") {
                  oItem[sItemKey] = parseFloat(oItem[sItemKey]);
                  continue;
                } else if (sItemKey === "DurationNormal") {
                  oItem[sItemKey] = parseFloat(oItem[sItemKey]);
                  continue;
                }
              }

              if (typeof oItem[sItemKey] !== String) {
                oItem[sItemKey] = String(oItem[sItemKey]);
              }
            }
          });
        }

        if (_.isArray(aRows)) {
          if (sKey === "KnownScanId") {
            aRows = aRows.sort((a, b) => a.ScanId.localeCompare(b.ScanId));
          }

          if (sKey === "TechnicalObject") {
            aRows = aRows.sort((a, b) => a.Strno.localeCompare(b.Strno));
          }

          if (sKey === "FuncLocOrg") {
            aRows = aRows.sort((a, b) => a.Tplnr.localeCompare(b.Tplnr));
          }

          if (sKey === "Confirmation") {
            aRows = aRows.sort((a, b) => a.Handle.localeCompare(b.Handle));
          }

          if (sKey === "Participant") {
            aRows = aRows.sort((a, b) => a.Pernr.localeCompare(b.Pernr));
          }

          aRows.forEach((oItem) => {
            if (sKey === "Operation") {
              // delete oItem.Handle;
            }

            if (sKey === "Confirmation") {
              oItem.ActWork = parseFloat(oItem.ActWork);
            }

            if (sKey === "Picture") {
              oItem.PicIndex = parseInt(oItem.PicIndex);
            }

            for (let sItemKey in oItem) {
              if (sKey === "Operation") {
                if (sItemKey === "Quantity") {
                  oItem[sItemKey] = parseFloat(oItem[sItemKey]);
                  continue;
                } else if (sItemKey === "DurationNormal") {
                  oItem[sItemKey] = parseFloat(oItem[sItemKey]);
                  continue;
                }
              }

              if (typeof oItem[sItemKey] !== String) {
                oItem[sItemKey] = String(oItem[sItemKey]);
              }
            }
          });
        }

        if (!_.isEqual(oIDB, aRows)) {
          console.log("IndexedDB");
          console.log(oIDB);
          console.log("WebSQL");
          console.log(aRows);
          console.error(
            "DB CHECK FAILED - content of table " + sKey + " is different !"
          );

          if (sKey === "Setting") {
            let aProperties = dbMigrator.findDifferentProperties(oIDB, aRows);
            console.log(aProperties);
          } else if (
            sKey === "Operation" ||
            sKey === "PMOrder" ||
            sKey === "Confirmation"
          ) {
            let aProperties = dbMigrator.findDifferentProperties(
              oIDB[0],
              aRows[0]
            );
            console.log(aProperties);
          }

          bIssue = true;
        }
        resolve();
      });

      // Push the promise into the promises array
      promises.push(promise);
    });

    // Wait for all promises to resolve using Promise.all()
    Promise.all(promises).then(() => {
      if (bIssue) {
        // MessageBox.error(this.getLocalText("dbcheckfailure"));
        console.error("DB CHECK FAILURE");
      } else {
        // MessageBox.success(this.getLocalText("dbchecksuccess"));
        console.info("DB CHECK SUCCESS");
        console.log("== DB CHECK SUCCESS ==");
      }
    });
  }

  // Public methods exposed via the returned object
  return {
    check: async function (bPublicRelease) {
      await compareContent(bPublicRelease);
      
    },

    performMigration: async function (bPublicRelease) {
      await migrate(bPublicRelease);
    },

    findDifferentProperties: function (obj1, obj2) {
      const keys = _.union(_.keys(obj1), _.keys(obj2)); // Get all keys from both objects
      const differences = [];

      _.forEach(keys, (key) => {
        if (!_.isEqual(obj1[key], obj2[key])) {
          differences.push(key);
        }
      });

      return differences;
    },

    isDevModeActive: function () {
      return isDevModeActive();
    },

    getHandles: function (oData) {
      return new Promise(async function (resolve, reject) {
        // // Open database
        // let oWebSQLDB = await openWebSQLDB();

        // oWebSQLDB.transaction(function (tx) {
        //   tx.executeSql(
        //     "SELECT Orderid, Activity, handle FROM operation",
        //     [],
        //     function (tx, results) {
        //       console.log("wr");
        //       console.log(results);
        //       let aMapping = [];
        //       for (let i = 0; i < results.rows.length; i++) {
        //         aMapping.push(results.rows.item(i));
        //       }
        //       console.log(aMapping);
        //       resolve(aMapping);
        //     }
        //   );
        // });
        let aOperation = await localforage.getItem("Operation");
        let aMapping = [];
        aOperation.forEach((oOperation) => {
          aMapping.push({
            Orderid: oOperation.Orderid,
            Activity: oOperation.Activity,
            Handle: oOperation.Handle,
          });
        });
        console.log(aMapping);
        resolve(aMapping);
      });
    },
  };
})();
