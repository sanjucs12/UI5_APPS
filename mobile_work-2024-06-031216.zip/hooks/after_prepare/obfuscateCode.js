#!/usr/bin/env node

module.exports = function (ctx) {

	// Make sure android platform is part of build
	if (!ctx.opts.platforms.includes('android')) return;

	var JavaScriptObfuscator = require('javascript-obfuscator');

	var htmlminify = require('html-minifier').minify;

	var fs = require('fs'),
		path = require('path'),
		isRelease;

	if (ctx.opts.options.release) {
		console.log("CORDOVA HOOK ---  RELEASE MODE")
		isRelease = true;
	} else {
		console.log("CORDOVA HOOK ---  DEBUG MODE")
		isRelease = false;
	}

	if (!isRelease) {
		return;
	}

	console.log('obfuscateCode.js START');

	function processFiles(dir) {
		filenames = fs.readdirSync(dir);

		filenames.forEach(function (file) {
			file = path.join(dir, file);
			let oStats = fs.statSync(file);
			if (oStats.isDirectory()) {
				processFiles(file);
			} else {
				compress(file, dir);
			}
		});
	}

	function compress(file, dir) {
		var ext = path.extname(file);
		switch (ext.toLowerCase()) {
			case '.js':
				console.log('Obfuscating JS File: ' + file.split('\\').slice(-5).join('\\'));
				let fileContent = fs.readFileSync(file, 'utf8');

				if (fileContent === "") {
					console.log("empty in");
				}
				let obfuscationResult = JavaScriptObfuscator.obfuscate(fileContent,
					{
						compact: true,
						controlFlowFlattening: true,
						controlFlowFlatteningThreshold: 1,
						numbersToExpressions: true,
						simplify: true,
						stringArrayShuffle: true,
						splitStrings: true,
						stringArrayThreshold: 1
					});
				let sResult = obfuscationResult.getObfuscatedCode();
				if (sResult === "") {
					console.log("empty out");
				}
				fs.writeFileSync(file, sResult, 'utf8');

				break;

			case '.html':
				console.log('Obfuscating HTML File: ' + file.split('\\').slice(-5).join('\\'));

				let htmlContent = fs.readFileSync(file, 'utf8');

				if (htmlContent === "") {
					console.log("empty in");
				}

				const cssOptions = {
					keepSpecialComments: 0
				}

				const htmlOptions = {
					removeAttributeQuotes: true,
					removeComments: true,
					minifyJS: true,
					minifyCSS: cssOptions,
					collapseWhitespace: true,
					conservativeCollapse: true,
					removeComments: true,
					removeEmptyAttributes: true
				}

				let htmlResult = htmlminify(htmlContent, htmlOptions);
				if (htmlResult === "") {
					console.log("empty out");
				}
				fs.writeFileSync(file, htmlResult, 'utf8');

				break;

			default:
				console.error('Not able to process -- ' + file);
				break;
		}
	}

	let oArgs = process.argv;
	let sPlatform;

	if (oArgs.includes("android")) {
		sPlatform = 'android';
		console.log("Android detected")
	}

	let sPWD = path.join(ctx.opts.projectRoot, 'platforms/android/app/src/main/assets/www');

	platformPath = sPWD;

	switch (sPlatform) {
		case 'android':
			console.log("CASE Android");

			console.log("Platform Path:");
			console.log(platformPath);
			break;

		default:
			console.error('Hook currently supports only Android and iOS');
			return;
	}

	processFiles(path.join(sPWD, "plugins"));
	compress(path.join(sPWD, "cordova.js"));
	compress(path.join(sPWD, "cordova_plugins.js"));

	// Compress HTML 
	compress(path.join(sPWD, "index.html"));

	try {
		compress(path.join(sPWD, "WebIDEindex.html"));
	} catch (oError) {
		console.log(oError);
	}

	console.log("obfuscateCode.js FINISHED")

	return "OK";

};