var execute = require("cordova/exec");

var gates = {

    listen: async function (plant,success, error) {
		// return execute(success, error, 'GatesPlugin', 'listen', []);
		return new Promise( resolve => {
			execute( function(oResult){
				console.log(oResult);
				console.log("result");
				resolve(oResult);
			}, function(oError){
				console.log("error");
				console.log(oError);
				resolve("CANCEL");
			}, 'GatesPlugin', 'listen', [plant]);
				
		});
    },

    release: function () {
        return execute(null, null, 'GatesPlugin', 'release', []);
    },
    
    addParticipants: function (config,plant) {
        return new Promise( resolve => {
			execute( function(oResult){
				console.log(oResult);
				console.log("result");
				resolve(oResult);
			}, function(oError){
				console.log("error");
				console.log(oError);
				resolve("CANCEL");
			}, 'GatesPlugin', 'AddParticipants', [config,plant]);
				
		});
    },
    
    onZoneBadge: function (config) {
        return new Promise( resolve => {
			execute( function(oResult){
				console.log(oResult);
				console.log("result");
				resolve(oResult);
			}, function(oError){
				console.log("error");
				console.log(oError);
				resolve("CANCEL");
			}, 'GatesPlugin', config[0], config);
				
		});
    }
	
	

};

module.exports = gates;