package GatesPlugin;

/*
import com.honeywell.aidc.AidcManager;
import com.honeywell.aidc.AidcManager.CreatedCallback;
import com.honeywell.aidc.BarcodeFailureEvent;
import com.honeywell.aidc.BarcodeReadEvent;
import com.honeywell.aidc.BarcodeReader;
import com.honeywell.aidc.ScannerUnavailableException;
import com.honeywell.aidc.ScannerNotClaimedException;
*/

// v 0.0.1
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.apache.cordova.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.List;
import android.content.pm.PackageManager;


public class GatesPlugin extends CordovaPlugin {

    /*
     * IMPORTANT
     * 
     * Wouter Roelandts
     * Kim De Roo
     * 
     *
     * 
     */
	 
	 
	 
	
	public int MY_OP ;
	// private CallbackContext callback = null;

    public static final String LOG_TAG = "gatespluginlog";

	/*
    private static BarcodeReader barcodeReader;
    private AidcManager manager;
	*/

    private CallbackContext callbackContext;
	public CordovaInterface cordova ;
    private Context context;

	public static final String AUTHENTICATOR_APP_PACKAGE_NAME = "com.arcelormittal.europe.flat.whoami";
    // "com.arcelormittal.europe.whoamidev"; // "com.arcelormittal.europe.mockauthenticator"//com.arcelormittal.europe.flat.whoami; 

	/*
    private static final String EXTRA_CONTROL = "com.honeywell.aidc.action.ACTION_CONTROL_SCANNER";
    private static final String EXTRA_SCAN = "com.honeywell.aidc.extra.EXTRA_SCAN";

    public static final String ACTION_BARCODE_DATA = "AMHoneywellPlugin.intent.action.BARCODE";
    private TextView textView;
    int sdkVersion = Build.VERSION.SDK_INT;
    String model = Build.MODEL;
	*/

    // private Handler updateConversationHandler;

    @Override
    public void initialize(CordovaInterface initcordova, CordovaWebView webView) {
        Log.d(LOG_TAG, "START Initialize");
        super.initialize(initcordova, webView);

		cordova = initcordova;
		context = initcordova.getActivity().getApplicationContext();
		MY_OP = 112255;
		/*
        context = cordova.getActivity().getApplicationContext();
        AidcManager.create(context, new CreatedCallback() {
            @Override
            public void onCreated(AidcManager aidcManager) {
                Log.d(LOG_TAG, "START onCreated of callback");
                manager = aidcManager;
                barcodeReader = manager.createBarcodeReader();
                if (barcodeReader != null) {
                    barcodeReader.addBarcodeListener(AMHoneywellPlugin.this);
                }
            }
        });
		*/
    }

    @Override
    public void onResume(boolean multitasking) {
        super.onResume(multitasking);

        Log.d(LOG_TAG, "START onResume of Plugin");

		/*
		
        // Register receiver so my app can listen for intents which action is
        // ACTION_BARCODE_DATA
        IntentFilter intentFilter = new IntentFilter(ACTION_BARCODE_DATA);
        context.registerReceiver(barcodeDataReceiver, intentFilter);

        // Will setup the new configuration of the scanner.
        claimScanner();
		*/
    }

   


    @Override
    public void onPause(boolean multitasking) {
        super.onPause(multitasking);

        Log.d(LOG_TAG, "START onPause of Plugin");

        
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d(LOG_TAG, "START onDestroy of Plugin");

       
    }


    @Override
    public boolean execute(String action, final JSONArray args, final CallbackContext callbackContext)
            throws JSONException {

        Log.d(LOG_TAG, "START execute of Plugin");

        if (action.equals("listen")) {
            this.callbackContext = callbackContext;
			MY_OP += 1;
            Log.d(LOG_TAG, "START listen action");
			
			cordova.setActivityResultCallback(this);
			PackageManager pm = context.getPackageManager(); 	
			Intent intent = pm.getLaunchIntentForPackage(AUTHENTICATOR_APP_PACKAGE_NAME);
			intent.setFlags(0);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			// intent.putExtra("client_id","Mobile_Work_DEV");
			// intent.putExtra("client_secret","MobileWorkSecret");

            intent.putExtra("client_id","Mobile_Work_UAT");
			intent.putExtra("client_secret","W0rkS3cret4U41");
            //intent.putExtra("plant","21"); // POLEN
            intent.putExtra("plant",args.getString(0)); // France


			// FLAG_ACTIVITY_SINGLE_TOP >> put flag
			cordova.startActivityForResult( (CordovaPlugin) this, intent, MY_OP );
			
			return true;
			/*
            PluginResult result = new PluginResult(PluginResult.Status.NO_RESULT);
            result.setKeepCallback(true);
            this.callbackContext.sendPluginResult(result);

            IntentFilter intentFilter = new IntentFilter(ACTION_BARCODE_DATA);
            context.registerReceiver(barcodeDataReceiver, intentFilter);

            claimScanner();
			*/
        }

        else if (action.equals("release")) {

            Log.d(LOG_TAG, "START release action");
            // releaseScanner();
			return true;
        }else if (action.equals("AddParticipants")) {
			this.callbackContext = callbackContext;
			MY_OP += 1;
            Log.d(LOG_TAG, "START add participants action");
            String token = args.getString(0);
            cordova.setActivityResultCallback(this);
			PackageManager pm = context.getPackageManager(); 	
			Intent intent = pm.getLaunchIntentForPackage(AUTHENTICATOR_APP_PACKAGE_NAME);
			// intent.setFlags(0);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("plant",args.getString(1)); // Info by Anees
            intent.putExtra("action","AddParticipants"); // Info by Anees
            intent.putExtra("access_token",token); // Info by Anees

			//// FLAG_ACTIVITY_SINGLE_TOP >> put flag
			cordova.startActivityForResult( (CordovaPlugin) this, intent, MY_OP );
			
			return true;
           // }
        }else if(action.equals("ZoneBadgeIn") || action.equals("ZoneBadgeOut")){
        	this.callbackContext = callbackContext;
			MY_OP += 1;
            Log.d(LOG_TAG, "START add Zone action");
            cordova.setActivityResultCallback(this);
			PackageManager pm = context.getPackageManager();
			Intent intent = pm.getLaunchIntentForPackage(AUTHENTICATOR_APP_PACKAGE_NAME);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			Log.d(LOG_TAG, "Send Intent for Zone action adding string data");
            intent.putExtra("plant",args.getString(1)); 
            //intent.putExtra("plant","11"); 
            intent.putExtra("action",args.getString(0)); 
            intent.putExtra("access_token",args.getString(2)); 
            intent.putExtra("ZoneBadgingMode",args.getString(3));
            intent.putExtra("ZoneBadgingType",args.getString(4));
			cordova.startActivityForResult( (CordovaPlugin) this, intent, MY_OP );
			return true;
        }
        return false;
    }
	
	@Override
	public void onActivityResult( int requestCode, int resultCode, Intent data  ){		
		Log.d(LOG_TAG, "1");
		if( requestCode == MY_OP ){			
			Log.d(LOG_TAG, "2");
			if(resultCode == Activity.RESULT_OK ){
				Log.d(LOG_TAG, "3");
				if( data.hasExtra("access_token") ){ //("user_name") ){// 
					Log.d(LOG_TAG, "4");
					JSONObject bundle = new JSONObject();
					try {
						bundle.putOpt("token", data.getStringExtra("access_token"));
						bundle.putOpt("hash", data.getStringExtra("hash"));
						bundle.putOpt("amei", data.getStringExtra("amei"));
						bundle.putOpt("scannedOn", data.getStringExtra("scannedOn"));
						bundle.putOpt("uid", data.getStringExtra("uid"));
						
					} catch (JSONException e) {
						Log.e(LOG_TAG, "onActivityResult: error" + e.getMessage());
					}
					PluginResult result = new PluginResult( PluginResult.Status.OK, bundle ); // ("user_name") );// 
					Log.d(LOG_TAG, "5");
					result.setKeepCallback(true);
					Log.d(LOG_TAG, "6");
					callbackContext.sendPluginResult(result);
				}else if (data.hasExtra("zone")){
					Log.d(LOG_TAG, "16");
					Log.d(LOG_TAG, "data:" + data.getStringExtra("zone"));
					PluginResult result = new PluginResult( PluginResult.Status.OK, new JSONArray(Arrays.asList(data.getStringExtra("zone"),data.getStringExtra("participants"))));  
					Log.d(LOG_TAG, "17");
					result.setKeepCallback(true);
					Log.d(LOG_TAG, "18");
					callbackContext.sendPluginResult(result);
				}else if (data.hasExtra("participants")){
					Log.d(LOG_TAG, "13");
					Log.d(LOG_TAG, "data:" + data.getStringExtra("participants"));
					PluginResult result = new PluginResult( PluginResult.Status.OK, data.getStringExtra("participants") );  
					Log.d(LOG_TAG, "14");
					result.setKeepCallback(true);
					Log.d(LOG_TAG, "15");
					callbackContext.sendPluginResult(result);
				}else{
					// No token
					Log.d(LOG_TAG, "7");
					PluginResult result = new PluginResult( PluginResult.Status.ERROR, "no params returned successfully" );
					Log.d(LOG_TAG, "8");
					result.setKeepCallback(true);
					Log.d(LOG_TAG, "9");
					callbackContext.sendPluginResult(result);
				}
			}else if(resultCode == Activity.RESULT_CANCELED){
				Log.d(LOG_TAG, "10 - result canceled");
				Log.d(LOG_TAG, "10");
				PluginResult result = new PluginResult( PluginResult.Status.ERROR, "no params returned successfully" );
				Log.d(LOG_TAG, "11");
				result.setKeepCallback(true);
				Log.d(LOG_TAG, "12");
				callbackContext.sendPluginResult(result);
			}
			else{
				// No token
				Log.d(LOG_TAG, "10");
				PluginResult result = new PluginResult( PluginResult.Status.ERROR, "no params returned successfully" );
				Log.d(LOG_TAG, "11");
				result.setKeepCallback(true);
				Log.d(LOG_TAG, "12");
				callbackContext.sendPluginResult(result);
			}
		}
	}
}
