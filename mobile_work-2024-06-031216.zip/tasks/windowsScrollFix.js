const util = require('util');

/*
    This custom task enables scrolling functionality in older edge version 18 which is shipped in the windows installer
*/

module.exports = async function ({ workspace, dependencies, taskUtil, options }) {


    const x = async function(scrollFile2, sTargetPath){
        let oFile = scrollFile2[0];
        console.log(util.inspect(oFile));
    
        let sFileContent = await oFile.getString();
        let aContent = sFileContent.split('\n');
    
        // Create a new array to store the modified lines
        const newLines = [];
    
        // Iterate through the original lines
        for (let i = 0; i < aContent.length; i++) {
            newLines.push(aContent[i]);
    
            // Check if the current line contains the specified condition
            if (aContent[i].includes("var oScrollbar = _private(oTable).oVerticalScrollbar;")) {
                // Insert an extra line after the line containing the condition
                newLines.push("		if (oScrollbar ){");
                newLines.push("			oScrollbar.isConnected = true;");
                newLines.push("		}");
            }
        }
    
        // Join the modified lines to create the updated string
        const sResult = newLines.join('\n');
        let oResource = taskUtil.resourceFactory.createResource({ path: sTargetPath, string: sResult })
        await workspace.write(oResource)
    };


    const scrollFile2 = await dependencies.byGlob("**/Scrolling.js");

    console.log("\nWRITE SCROLLFILE 2 CONTENT ...");

    await x(scrollFile2, '/resources/sap/ui/table/extensions/Scrolling.js');
    

    /////////////////////////////////////////////////////////

    console.log("Scolling fix executed");
    

    

}



module.exports.determineRequiredDependencies = async function ({ availableDependencies, getDependencies, getProject, options }) {

    // Provide all dependencies to the custom task function

    return availableDependencies;
}