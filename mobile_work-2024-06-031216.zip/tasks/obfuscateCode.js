module.exports = async function ({ workspace, dependencies, taskUtil, options }) {

    /*
    npx babel --plugins transform-remove-console dist/Component.js --out-file test.js

    https://www.npmjs.com/package/javascript-obfuscator

    https://www.npmjs.com/package/@todms/ui5-task-babel


    https://github.com/ui5-community/ui5-ecosystem-showcase#readme
    ui5-tooling-modules - direct consumption of NPM packages
    ui5-tooling-transpile - transpile resources using Babel

    Example used
    https://github.com/Yunustuzun/UI5-i18n-cleaner/blob/master/tasks/cleanUnusedi18nKeys.js

    Additionally, various libraries like Babel, Grunt.js can be used while performing these operations.

    */

    console.log("CUSTOM TASK ------- obfuscate code");

    const i18nFiles = await workspace.byGlob("**/*.js");

    await Promise.all(i18nFiles.map(async (i18nFile) => {

        let i18nFileString = await i18nFile.getString();

        var JavaScriptObfuscator = require('javascript-obfuscator');

        var obfuscationResult = JavaScriptObfuscator.obfuscate(i18nFileString, {
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 1
        });

        await i18nFile.setString(obfuscationResult.getObfuscatedCode());

        await workspace.write(i18nFile);

    }));
}